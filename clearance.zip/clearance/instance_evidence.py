"""Evidence for seeding a geometric instance, never a device classifier.

Insufficient geometry remains measurable. A small visible fragment may still
match an existing instance; this module cannot create, merge or delete IDs.
"""
import numpy as np
from scipy.spatial import cKDTree
from .voxel import representatives as voxel_representatives


def _local_residual_p90(residual,counts):
    """Exact linear nanpercentile for neighborhoods of at most 12 native returns.

    Missing-neighbor NaNs sort last. Match NumPy's linear interpolation,
    including its upper-half subtraction for floating-point boundary parity.
    This avoids Python dispatch per local patch, not any native subsampling.
    """
    ordered=np.sort(residual,axis=1)
    position=(np.asarray(counts,dtype=np.int64)-1)*.9
    lower=np.floor(position).astype(np.int64)
    upper=np.ceil(position).astype(np.int64)
    rows=np.arange(len(ordered))
    a,b=ordered[rows,lower],ordered[rows,upper]
    fraction=position-lower
    delta=b-a
    return np.where(fraction>=.5,b-delta*(1.-fraction),a+delta*fraction)


def _current_surface_metrics(points,config):
    if len(points)<6:
        return dict(current_surface_fraction=0.,current_testable_fraction=0.,current_coherence_on_testable=0.)
    distance,index=cKDTree(points).query(points,k=min(12,len(points)))
    radii=config.neighbor_base_m+config.neighbor_angle_rad*np.linalg.norm(points,axis=1)
    weights=(distance<=radii[:,None]+1e-9).astype(float)
    counts=weights.sum(axis=1)
    patches=points[index]
    centers=np.einsum('nki,nk->ni',patches,weights)/counts[:,None]
    centered=patches-centers[:,None,:]
    values,vectors=np.linalg.eigh(np.einsum('nki,nkj,nk->nij',centered,centered,weights)/counts[:,None,None])
    residual=np.abs(np.einsum('nki,ni->nk',centered,vectors[:,:,0]))
    residual[weights==0]=np.nan
    p90=_local_residual_p90(residual,counts)
    # Six actual independent local returns constrain and test a surface;
    # curved bodies may be globally nonplanar but locally well observed.
    testable=(counts>=6)&(values[:,1]>1e-7)
    coherent=testable&(p90<=config.ground_max_confirmation_band_m)
    # A sparse/rank-deficient patch has no testable plane normal. Do not count
    # missing observations as a failed residual measurement. Coverage is a
    # separate requirement, so a tiny valid island cannot certify the cloud.
    return dict(current_surface_fraction=float(coherent.mean()),
                current_testable_fraction=float(testable.mean()),
                current_coherence_on_testable=float(coherent[testable].mean()) if testable.any() else 0.)


def instance_seed_evidence(frame,candidate,indices,normal,config,terrain=None):
    points=frame.xyz_L[indices]
    keep,inverse=voxel_representatives(points,config.neighbor_base_m*.5)
    current=candidate.diagnostics.get('support_neighbor_valid')
    if current is None:
        native_current=np.ones(len(indices),dtype=bool)
    else:
        current=np.asarray(current,dtype=bool)
        rows=current.any(axis=1) if current.ndim==2 else current
        native_current=(np.isin(indices,candidate.point_indices[rows])
            if rows.shape==(len(candidate.point_indices),) else np.zeros(len(indices),dtype=bool))
    occupied_current=np.zeros(len(keep),dtype=bool)
    np.maximum.at(occupied_current,inverse,native_current)
    fraction=float(occupied_current.mean()) if len(keep) else 0.
    evidence=dict(seed_allowed=False,independent_cells=len(keep),current_fraction=fraction,
                  reason='insufficient_independent_surface',semantics='new geometric ID evidence; not equipment taxonomy')
    if len(keep)<3 or fraction<.7:
        return evidence
    if normal is None or not np.isfinite(normal).all() or np.linalg.norm(normal)<1e-9:
        return dict(evidence,reason='no_current_track_orientation')
    up=np.asarray(normal,dtype=float)/np.linalg.norm(normal)
    observed=points[native_current]
    # Choose actual returns deterministically within cells. Native packet order
    # must not change eligibility; this is not an averaged measurement surface.
    observed=observed[np.lexsort((observed[:,2],observed[:,1],observed[:,0]))]
    observed_keep,unused=voxel_representatives(observed,config.neighbor_base_m*.5)
    independent=observed[observed_keep]
    if len(independent)<3:
        return evidence
    centered=independent-independent.mean(axis=0)
    values,vectors=np.linalg.eigh(centered.T@centered/len(independent))
    # Compare independent surface spread with the existing measurement search
    # scale, not raw point density, total device size or minimum device height.
    center=(points.min(0)+points.max(0))*.5
    radius=config.neighbor_base_m+config.neighbor_angle_rad*np.linalg.norm(center)
    two_d=bool(values[1]>(.15*radius)**2)
    horizontal=bool(two_d and values[0]<=.06*max(values[1],1e-12) and abs(vectors[:,0]@up)>=.94)
    metrics=(_current_surface_metrics(independent,config) if current is not None else
             dict(current_surface_fraction=1.,current_testable_fraction=1.,current_coherence_on_testable=1.))
    evidence.update(metrics)
    surface_proven=(metrics['current_testable_fraction']>=.7 and metrics['current_coherence_on_testable']>=.7)
    if two_d and not horizontal:
        if surface_proven:
            return dict(evidence,seed_allowed=True,reason='current_nonhorizontal_or_3d_surface')
    # Neither a roof nor a small pole is rejected merely for being horizontal
    # or line-like. Actual enclosing current terrain can prove it is raised.
    # A missing/one-sided plane abstains, rather than extrapolating the floor.
    planar=bool(np.percentile(np.abs(centered@vectors[:,0]),90)<=config.ground_max_confirmation_band_m)
    terrain_eligible=(not two_d or planar or surface_proven)
    # The qualified core supplies geometric confidence, but cannot hide a
    # native corner or floor return in the actual candidate's terrain proof.
    if terrain_eligible and terrain is not None and terrain.raised_all(frame.xyz_L[candidate.point_indices]):
        return dict(evidence,seed_allowed=True,reason='raised_above_observed_local_terrain')
    return dict(evidence,reason='horizontal_surface_without_raised_witness' if horizontal
                else 'unstructured_current_geometry' if two_d and not surface_proven
                else 'insufficient_independent_surface')
