"""Causal raw-scan identity evidence; never historical distance evidence."""
from collections import Counter
from numbers import Integral
import numpy as np


def qualified_history_instances(current,history,config):
    """Only independently qualified observations can donate closure proof."""
    return _history_instances(current,history,config,states=('qualified',),minimum_observations=2)


def raw_history_identity_instances(current,history,config):
    """Clean actual returns may support an EXISTING ID match from its first scan.

    Tentative means not yet qualified, not conflicted or inherited. These
    records do not qualify a historical reconciliation or donate a distance.
    """
    return _history_instances(current,history,config,states=('tentative','qualified'),minimum_observations=1)


def _history_instances(current,history,config,states,minimum_observations):
    """Missing/invalid records abstain; unresolved native points stay intact.

    A source frame namespaces its labels. Two copies of one record are not
    two observations. The producer recorded actual geometry and status, and
    motion.py aligned the original XYZ/PointRefs into the current sensor L.
    """
    instances = []
    for past in history:
        if (past.session_id!=current.session_id or past.clock_id!=current.clock_id or
                past.motion_status!='compensated_history' or past.ref_time_s!=current.ref_time_s or
                past.diagnostics.get('aligned_to_ref_time_s')!=current.ref_time_s):
            continue
        labels = np.asarray(past.diagnostics.get('object_proposal_labels',()))
        try:
            origins = np.asarray(past.diagnostics.get('object_proposal_origin_time_s',()),dtype=float)
        except (TypeError,ValueError):
            continue
        if labels.shape!=(len(past.xyz_L),) or labels.dtype.kind not in 'iu' or origins.shape!=labels.shape:
            continue
        sources = np.array([ref.frame for ref in past.refs],dtype=np.int64)
        records = past.diagnostics.get('object_proposal_evidence',())
        if not isinstance(records,(tuple,list)):
            continue
        keys = [(r.get('source_frame'),r.get('label')) for r in records if isinstance(r,dict)
                and isinstance(r.get('source_frame'),Integral) and isinstance(r.get('label'),Integral)]
        counts = Counter(keys)
        for record in records:
            if not isinstance(record,dict):
                continue
            source,label = record.get('source_frame'),record.get('label')
            if not isinstance(source,Integral) or not isinstance(label,Integral) or counts[(source,label)]!=1:
                continue
            # A raw matcher can use a clean first tentative observation, but
            # cannot reinterpret an inconsistent qualified/one-observation
            # record as confirmation when a later consumer filters its state.
            required = max(minimum_observations,2 if record.get('state')=='qualified' else 1)
            if (record.get('session_id')!=current.session_id or record.get('clock_id')!=current.clock_id or
                    source>=current.sequence or label<0 or record.get('state') not in states or
                    record.get('independent_geometry') is not True or record.get('geometry_frame')!=source or
                    not isinstance(record.get('observations'),Integral) or record['observations']<required or
                    not isinstance(record.get('object_id'),str) or not record['object_id']):
                continue
            try:
                observed = float(record['source_time_s'])
                proof = float(record['proof_time_s'])
                expiry = float(record['valid_until_s'])
                radius = float(record['radius_m'])
            except (KeyError,TypeError,ValueError):
                continue
            if (not np.isfinite([observed,proof,expiry,radius]).all() or radius<=0 or proof!=observed or
                    observed>=current.ref_time_s or expiry>proof+config.history_seconds+1e-9 or
                    current.scan_span_s[1]>expiry+1e-9):
                continue
            indices = np.flatnonzero((sources==source)&(labels==label))
            if not len(indices) or not np.isfinite(origins[indices]).all() or not np.all(origins[indices]==proof):
                continue
            points = past.xyz_L[indices]
            if not np.isfinite(points).all() or np.any(np.einsum('ij,ij->i',points,points)<=1e-12):
                continue
            refs = tuple(past.refs[int(i)] for i in indices)
            if any(ref.time_s is None or not np.isfinite(ref.time_s) or
                   not 0.<=current.scan_span_s[1]-ref.time_s<=config.history_seconds+1e-9 for ref in refs):
                continue
            instances.append(dict(record,points_L=points,refs=refs))
    # Repeated buffers from the same source cannot become multiple donors.
    counts = Counter((item['source_frame'],item['label']) for item in instances)
    return [item for item in instances if counts[(item['source_frame'],item['label'])]==1]
