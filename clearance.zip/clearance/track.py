"""Spatially balanced observed rail strips and piecewise local track planes.

Initial mounting prior: native +Z approximately along the cart. Ground normal
is estimated, not equated to a fixed gravity plane. No standard gauge enters
the search or fit. This experimental observer is independent of rail_live.
"""
from dataclasses import replace
import numpy as np
from scipy.signal import find_peaks
from .protocol import TrackModel, TrackSegment, TrackUpdate, validate_frame, validate_track
from .voxel import representatives as voxel_representatives


def _representatives(points, voxel=.06):
    indices, _ = voxel_representatives(points, voxel)
    if len(indices) > 5000:
        indices = indices[np.linspace(0, len(indices)-1, 5000).astype(int)]
    return points[indices]


def _ground(points, previous):
    sample = _representatives(points)
    if len(sample) < 3:
        return None
    # Membership is independent of a plane hypothesis. Reuse the same exact
    # YZ cells instead of quantizing/sorting them twice for every RANSAC draw.
    _,cell_inverse=voxel_representatives(np.column_stack((np.zeros(len(sample)),sample[:,[1,2]])),.18)
    central=np.abs(sample[:,1])<.45
    hypotheses = []
    if previous is not None and previous.diagnostics.get('ground_plane'):
        p = previous.diagnostics['ground_plane']
        hypotheses.append((np.asarray(p['normal_L']), float(p['offset_m'])))
    central_sample = sample[np.abs(sample[:,1]) < .45]
    proposal_sample = central_sample if len(central_sample) >= 3 else sample
    # Restrict proposals (not points used for distance) to the transverse
    # mounting-axis mode near the cart. Otherwise distant scene returns can
    # consume all RANSAC draws before a true floor triple is ever proposed.
    if len(proposal_sample) >= 12:
        bins = np.floor(proposal_sample[:,0]/.10).astype(int)
        values, counts = np.unique(bins, return_counts=True)
        mode = values[np.argmax(counts)]
        concentrated = proposal_sample[np.abs(bins-mode) <= 1]
        if len(concentrated) >= 12:
            proposal_sample = concentrated
    rng = np.random.default_rng(7)
    for _ in range(100):
        a, b, c = proposal_sample[rng.choice(len(proposal_sample), 3, replace=False)]
        normal = np.cross(b-a, c-a)
        length = np.linalg.norm(normal)
        if length < 1e-9:
            continue
        normal /= length
        # Sideways Airy mounting: normal approximately transverse to +Z. The
        # sign is estimated toward the sensor, so either roll convention works.
        if abs(normal[2]) > .5 or abs(normal[0]) < .65:
            continue
        offset = float(a@normal)
        if offset > 0:
            normal, offset = -normal, -offset
        hypotheses.append((normal, offset))
    best = None
    for normal, offset in hypotheses:
        inliers = np.abs(sample@normal-offset) < .022
        if inliers.sum() < 3:
            continue
        # Spatial occupancy, not raw return count, is the plane score.
        central_points = sample[inliers & central]
        if len(central_points) < 3:
            continue
        # The cart's own ground corridor anchors initialization. A broad side
        # platform is context, not a more likely floor merely because it has
        # more area. This prior does not mask any trackside object return.
        coverage = 5.*len(np.unique(cell_inverse[inliers&central]))+.1*len(np.unique(cell_inverse[inliers]))
        if best is None or coverage > best[0]:
            best = (coverage, normal, offset, central_points)
    if best is None:
        return None
    _, normal, offset, inliers = best
    center = np.median(inliers, axis=0)
    centered = inliers-center
    _, _, vt = np.linalg.svd(centered, full_matrices=False)
    refined = vt[-1]
    if refined@normal < 0:
        refined = -refined
    offset = float(np.median(inliers@refined))
    normal = refined
    forward = np.array([0., 0., 1.])-normal[2]*normal
    forward /= np.linalg.norm(forward)
    across = np.cross(normal, forward)
    return forward, across, normal, offset


def _strips(points, source_indices, basis, floor):
    forward, across, up = basis
    local = points@np.stack([forward, across, up]).T
    height = local[:,2]-floor
    above = (height > .025) & (height < .4)
    local, source_indices = local[above], source_indices[above]
    if len(local) < 3:
        return []
    edges = np.arange(-2.5, 2.525, .025)
    station_bins = np.floor(local[:,0]/.12).astype(int)
    station_offset = int(station_bins.min())
    bins_count = int(station_bins.max()-station_offset)+1
    scores = np.zeros(len(edges)-1)
    for i in range(len(scores)):
        near = np.abs(local[:,1]-(edges[i]+edges[i+1])/2.) < .035
        if not near.any():
            continue
        low_heights, high_heights = np.full(bins_count, np.inf), np.full(bins_count, -np.inf)
        bins = station_bins[near]-station_offset
        np.minimum.at(low_heights, bins, local[near,2])
        np.maximum.at(high_heights, bins, local[near,2])
        valid = np.isfinite(low_heights)
        # Continuous profile evidence: a long nearly flat floor streak is not
        # stronger rail evidence than a short observed rail web/head profile.
        scores[i] = np.sum(np.minimum(high_heights[valid]-low_heights[valid],.3))
    peaks, _ = find_peaks(scores, distance=3)
    peaks = sorted(peaks, key=lambda i: scores[i], reverse=True)[:12]
    strips = []
    for peak in peaks:
        center_y = (edges[peak]+edges[peak+1])/2.
        selected = np.abs(local[:,1]-center_y) < .055
        if selected.sum() < 3:
            continue
        observations = []
        spans = []
        for station in np.unique(station_bins[selected]):
            at = selected & (station_bins == station)
            if at.sum() < 2:
                continue
            p = local[at]
            spans.append(float(np.percentile(p[:,2],90)-np.percentile(p[:,2],10)))
            observations.append([float(np.median(p[:,0])), float(np.median(p[:,1])),
                                 float(np.percentile(p[:,2], 85))])
        observations = np.asarray(observations)
        if len(observations) < 3:
            continue  # A rank requirement, not a visible-length gate.
        design = np.column_stack([observations[:,0], np.ones(len(observations))])
        fit = np.linalg.lstsq(design, observations[:,1:], rcond=None)[0]
        residual = observations[:,1]-design@fit[:,0]
        retained = np.abs(residual) <= max(.008, 3.*float(np.median(np.abs(residual))))
        if retained.sum() >= 3:
            fit = np.linalg.lstsq(design[retained], observations[retained,1:], rcond=None)[0]
        residual = observations[:,1]-design@fit[:,0]
        strips.append({'fit': fit, 'low': float(observations[:,0].min()),
                       'high': float(observations[:,0].max()), 'sections': len(observations),
                       'y': center_y, 'source_indices': source_indices[selected],
                       'vertical_span_m': float(np.median(spans)),
                       'residual_p95_m': float(np.percentile(np.abs(residual),95)),
                       'observations': observations})
    return strips


def _observed_rail_association(strip, previous, basis, attribute):
    """Compare measured sections only where the propagated rail was observed.

    Endpoint clamping would let a disjoint new rail borrow old identity. The
    section medians also follow a curved profile instead of comparing two
    straight fits at one arbitrary station.
    """
    forward, across, normal = basis
    observations = strip['observations']
    measured = observations @ np.stack([forward, across, normal])
    best_errors = np.full(len(observations), np.inf)
    for segment in previous.segments:
        a, b = getattr(segment, attribute)
        stations = np.array([a@forward, b@forward])
        if abs(stations[1]-stations[0]) < 1e-9:
            continue
        fraction = (observations[:,0]-stations[0])/(stations[1]-stations[0])
        supported = (fraction >= 0.) & (fraction <= 1.)
        foot = a+fraction[:,None]*(b-a)
        delta = measured-foot
        error = np.hypot(delta@segment.across_L, delta@segment.normal_L)
        best_errors[supported] = np.minimum(best_errors[supported], error[supported])
    supported = np.isfinite(best_errors)
    if not supported.any():
        return None
    return {'median_error_m': float(np.median(best_errors[supported])),
            'supported_sections': int(supported.sum()),
            'station_overlap_m': [float(observations[supported,0].min()),
                                  float(observations[supported,0].max())]}


def observe_track(frame, previous, config):
    validate_frame(frame)
    points = frame.xyz_L
    finite = np.isfinite(points).all(axis=1)
    # More fitting context than the 5 m object display; spatially balanced
    # representatives do not remove any raw object boundary return.
    context = (finite & (np.linalg.norm(np.where(finite[:,None], points, 0.), axis=1) < 8.) &
               (points[:,2] > .15) & (points[:,2] < 6.))
    source_indices = np.flatnonzero(context)
    selected = points[context]
    ground = _ground(selected, previous)
    if ground is None:
        return TrackUpdate('initializing', diagnostics={'reason': 'ground_unobservable', 'observer': 'balanced_strip_v1'})
    forward, across, normal, floor = ground
    basis = (forward, across, normal)
    strips = _strips(selected, source_indices, basis, floor)
    diagnostics = {'observer': 'balanced_strip_v1', 'mounting_prior': 'native +Z along cart; transverse ground normal',
                   'ground_plane': {'normal_L': normal.tolist(), 'offset_m': floor},
                   'strip_candidates': [{k: v for k,v in s.items() if k not in ('observations','source_indices')}
                                        for s in strips]}
    pairs = []
    associations = {}
    if previous is not None:
        for strip in strips:
            attribute = 'left_endpoints_L' if strip['y'] < 0 else 'right_endpoints_L'
            associations[id(strip)] = _observed_rail_association(strip, previous, basis, attribute)
    for left in strips:
        for right in strips:
            if not left['y'] < 0 < right['y']:
                continue
            low, high = max(left['low'], right['low']), min(left['high'], right['high'])
            if high <= low:
                continue
            slope_difference = abs(left['fit'][0,0]-right['fit'][0,0])
            profile = min(left['vertical_span_m'],right['vertical_span_m'])
            center_bias = abs((left['y']+right['y'])/2.)
            quality = min(left['sections'], right['sections'])*profile/(1.+20.*slope_difference+
                       50.*(left['residual_p95_m']+right['residual_p95_m'])+2.*center_bias)
            association = {'weight': 1., 'reason': 'no_propagated_observed_support'}
            if previous is not None:
                matched = [associations[id(left)], associations[id(right)]]
                if all(item is not None for item in matched):
                    error = float(np.mean([item['median_error_m'] for item in matched]))
                    # The .055 m strip-selection half width is the association
                    # resolution, not a gauge or visible-length requirement.
                    # A bounded bonus lets strong fresh dual evidence recapture
                    # after bad history, unlike an unbounded mismatch penalty.
                    weight = 1.+2.*float(np.exp(-.5*(error/.055)**2))
                    association = {'weight': weight, 'median_error_m': error,
                                   'left': matched[0], 'right': matched[1],
                                   'reason': 'causal_observed_section_correspondence'}
                    quality *= weight
            pairs.append((quality, left, right, low, high, association))
    if not pairs:
        if strips:
            single = max(strips,key=lambda s:s['sections']*s['vertical_span_m'])
            diagnostics['single_observation'] = dict(fit=single['fit'],low=single['low'],high=single['high'],
                                                       basis=np.stack(basis),source_indices=single['source_indices'])
        return TrackUpdate('initializing', diagnostics=dict(diagnostics, reason='dual_strips_unobservable'))
    pairs.sort(key=lambda p:p[0], reverse=True)
    # History has already affected the scores. It must not switch off the
    # identity test when the remaining alternatives are still comparable.
    if len(pairs) > 1 and pairs[1][0] >= .9*pairs[0][0]:
        return TrackUpdate('ambiguous_track',diagnostics=dict(diagnostics,reason='multiple_comparable_rail_pairs',
                           pair_scores=[float(p[0]) for p in pairs],
                           pair_association=[p[5] for p in pairs[:4]]))
    _, left, right, low, high, association = pairs[0]
    def rail(strip, station):
        # Interpolate local measured sections rather than imposing one
        # infinitely extended line on a changing rail profile.
        obs = strip['observations']
        y = np.interp(station, obs[:,0], obs[:,1])
        h = np.interp(station, obs[:,0], obs[:,2])
        return station*forward+y*across+h*normal
    knots = np.linspace(low, high, max(2, int(np.ceil((high-low)/.4))+1))
    left_points = np.array([rail(left,t) for t in knots])
    right_points = np.array([rail(right,t) for t in knots])
    centers = (left_points+right_points)/2.
    indices = np.unique(np.r_[left['source_indices'],right['source_indices']])
    refs = tuple(frame.refs[int(i)] for i in indices)
    segments = []
    for i in range(len(knots)-1):
        tangent = centers[i+1]-centers[i]
        tangent /= np.linalg.norm(tangent)
        transverse = (right_points[i]+right_points[i+1]-left_points[i]-left_points[i+1])/2.
        transverse -= tangent*float(transverse@tangent)
        transverse /= np.linalg.norm(transverse)
        up = np.cross(tangent, transverse)
        if up@normal < 0:
            up *= -1
        local_stations = points[indices]@forward
        local_refs = tuple(frame.refs[int(k)] for k in indices[
            (local_stations >= knots[i]-.06)&(local_stations <= knots[i+1]+.06)])
        segments.append(TrackSegment(centers[i], centers[i+1], left_points[i:i+2],
                        right_points[i:i+2], up, transverse, float(knots[i]), local_refs))
    diagnostics.update(rail_source_indices=indices, selected_pair_score=float(pairs[0][0]),
                       alternative_pair_scores=[float(p[0]) for p in pairs[1:]],
                       history_association=association,
                       measurement_feature='median visible strip / observed upper surface; no gauge calibration',
                       fit_residual_p95_m=max(left['residual_p95_m'], right['residual_p95_m']),
                       measurement_flags=['experimental_rail_features'])
    width = float(np.median(np.linalg.norm(right_points-left_points,axis=1)))
    observation_times = [frame.refs[int(i)].time_s for i in indices if frame.refs[int(i)].time_s is not None]
    model = TrackModel(frame.session_id, frame.ref_time_s, frame.clock_id, 'observed_dual', tuple(segments),
                       min(observation_times,default=frame.ref_time_s),
                       max(observation_times,default=frame.ref_time_s), width, diagnostics)
    validate_track(model, frame)
    return TrackUpdate('observed_dual', model)


def transform_track(model,frame,relative,mode='predicted_track'):
    rotation,translation = relative[:3,:3],relative[:3,3]
    def point(values):
        return np.asarray(values)@rotation.T+translation
    segments = tuple(replace(s,start_L=point(s.start_L),end_L=point(s.end_L),
                     left_endpoints_L=point(s.left_endpoints_L),right_endpoints_L=point(s.right_endpoints_L),
                     normal_L=rotation@s.normal_L,across_L=rotation@s.across_L) for s in model.segments)
    diagnostics = dict(model.diagnostics,measurement_flags=['propagated_experimental_track'],
                       last_observed_gauge_m=model.observed_gauge_m or model.diagnostics.get('last_observed_gauge_m'))
    if diagnostics.get('ground_plane'):
        original = diagnostics['ground_plane']
        n = rotation@np.asarray(original['normal_L'])
        diagnostics['ground_plane'] = {'normal_L':n.tolist(),'offset_m':float(original['offset_m']+n@translation)}
    out = replace(model,ref_time_s=frame.ref_time_s,mode=mode,segments=segments,observed_gauge_m=None,
                  diagnostics=diagnostics)
    validate_track(out,frame)
    return out


def _associate_single(single, model, frame, config):
    """Associate only inside observed station support and a disjoint rail tube.

    Tube width uses this model's last observed rail separation, not a nominal
    gauge. A strip far from both identities must not drag the historical model.
    """
    forward, across, up = single['basis']
    candidates = {}
    for segment in model.segments:
        for side, endpoints in (('left', segment.left_endpoints_L),
                                ('right', segment.right_endpoints_L)):
            a, b = endpoints
            stations = endpoints @ forward
            low = max(single['low'], float(stations.min()))
            high = min(single['high'], float(stations.max()))
            if high <= low or abs(stations[1]-stations[0]) < 1e-9:
                continue
            station = (low+high)/2.
            fraction = (station-stations[0])/(stations[1]-stations[0])
            foot = a+fraction*(b-a)  # No clamping to an unsupported endpoint.
            measured = station*forward+np.r_[station,1.]@single['fit']@np.stack([across,up])
            left = segment.left_endpoints_L
            right = segment.right_endpoints_L
            width = np.linalg.norm((1.-fraction)*(right[0]-left[0])+fraction*(right[1]-left[1]))
            delta = measured-foot
            shift = (delta@segment.across_L)*segment.across_L+(delta@segment.normal_L)*segment.normal_L
            error = float(np.linalg.norm(shift))
            limit = float(config.single_association_width_fraction*width)
            if error > limit:
                continue
            option = (error, shift, low, high, limit)
            if side not in candidates or error < candidates[side][0]:
                candidates[side] = option
    if not candidates:
        return None, {'single_association': 'unassociated_or_outside_observed_support'}
    ordered = sorted(candidates.items(), key=lambda item: item[1][0])
    if len(ordered) > 1 and ordered[1][1][0] <= ordered[0][1][0]/.9:
        return None, {'single_association': 'ambiguous_rail_identity'}
    side, (error, shift, low, high, limit) = ordered[0]
    indices = single['source_indices']
    stations = frame.xyz_L[indices]@forward
    indices = indices[(stations >= low-1e-9)&(stations <= high+1e-9)]
    if not len(indices):
        return None, {'single_association': 'no_current_returns_in_observed_support'}
    return shift, {'single_association': 'matched_observed_rail', 'single_side': side,
                   'single_residual_m': error, 'single_identity_limit_m': limit,
                   'single_station_overlap_m': [low, high],
                   'last_single_observed_s': frame.ref_time_s,
                   'single_source_refs': [frame.refs[int(i)] for i in indices]}


class TrackTracker:
    def __init__(self,config):
        self.config = config
        self.reset()

    def reset(self):
        self.model = None
        self.history = []
        self.last_frame = None
        self.reference_pose = None

    def update(self,frame,poses=None):
        from .motion import usable_pose, poses_for_frame
        if self.last_frame is not None and (frame.ref_time_s <= self.last_frame.ref_time_s or
                frame.sequence <= self.last_frame.sequence or frame.clock_id != self.last_frame.clock_id or
                frame.session_id != self.last_frame.session_id):
            self.reset()
        current_poses = poses_for_frame(poses, frame)
        current_pose = current_poses.sample(frame.ref_time_s,frame.scan_span_s[1]) if current_poses is not None else None
        if not usable_pose(current_pose,frame.ref_time_s,frame.clock_id,frame.scan_span_s[1]):
            current_pose = None
        pose_reset = (current_pose is not None and self.reference_pose is not None and
                      (current_pose.source != self.reference_pose.source or
                       current_pose.diagnostics.get('clock_epoch') !=
                       self.reference_pose.diagnostics.get('clock_epoch')))
        if pose_reset:
            # Equal device-clock labels do not make separate pose maps share
            # coordinates. Reobserve from this scan after a map/source reset.
            self.reset()
        propagated = None
        if self.model is not None and current_pose is not None and self.reference_pose is not None and \
                current_pose.usable and self.reference_pose.usable and current_pose.clock_id == frame.clock_id:
            relative = np.linalg.inv(current_pose.T_WL)@self.reference_pose.T_WL
            propagated = transform_track(self.model,frame,relative)
        update = observe_track(frame,propagated,self.config)
        if pose_reset:
            update = replace(update, diagnostics=dict(update.diagnostics,
                             history_reset='pose_source_or_epoch_changed'))
        if update.model is not None:
            self.model = update.model
            self.reference_pose = current_pose
        elif propagated is not None and update.mode != 'ambiguous_track':
            single = update.diagnostics.get('single_observation')
            if single is not None:
                shift, association = _associate_single(single, propagated, frame, self.config)
                update = replace(update, diagnostics=dict(update.diagnostics, **association))
                if shift is not None:
                    relative = np.eye(4);relative[:3,3]=shift
                    propagated = transform_track(propagated,frame,relative,'estimated_single')
                    # The absent side still comes from the last dual observation.
                    # Keep its age; record the new single-side evidence separately.
                    propagated = replace(propagated, diagnostics=dict(propagated.diagnostics,
                        **association, measurement_flags=['single_rail_estimate']))
            update = TrackUpdate(propagated.mode,propagated,diagnostics=update.diagnostics)
            self.model,self.reference_pose = propagated,current_pose
        elif self.model is not None and update.mode != 'ambiguous_track':
            update = TrackUpdate('held_snapshot',held_model=self.model,diagnostics={'reason':'relative_pose_unavailable'})
        self.last_frame = frame
        self.history.append(frame)
        self.history = [f for f in self.history if frame.ref_time_s-f.ref_time_s <= self.config.history_seconds+1e-9]
        self.history = self.history[-self.config.history_max_scans:]
        return update
