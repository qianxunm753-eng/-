"""Real-time-rate file arrival; one owned worker and one replaceable pending scan.

Precomputed experimental poses are explicitly not a live odometry process.
Only sequence identifiers cross the request pipe; the worker reads exact XYZ.
"""
import csv
import hashlib
import json
import multiprocessing as mp
from pathlib import Path
import time
import traceback
import numpy as np
from .native import read_native_frames,read_native_metadata
from .protocol import json_value,result_to_dict


class LatestPending:
    def __init__(self):
        self.pending = None
        self.skipped = []

    def offer(self,sequence):
        if self.pending is not None:
            self.skipped.append(self.pending)
        self.pending = sequence

    def take(self):
        result,self.pending = self.pending,None
        return result


class DeviceTrigger:
    def __init__(self,period):
        if period <= 0:
            raise ValueError('positive period required')
        self.period,self.next_time,self.last_time = period,None,None

    def due(self,device_time):
        if self.last_time is not None and device_time < self.last_time:
            self.next_time = None
        self.last_time = device_time
        if self.next_time is None:
            self.next_time = device_time
        if device_time+1e-5 < self.next_time:
            return False
        self.next_time += (max(1,int((device_time-self.next_time+1e-5)/self.period)+1))*self.period
        return True


def _playback_schedule(metadata, fallback_interval):
    """Preserve positive device dt within each epoch on a monotonic wall axis.

    A reset has no observable cross-epoch dt. Use the last *past* positive
    interval (or the requested period at startup), never a future timestamp.
    Original device timestamps remain unchanged in measurement records.
    """
    offsets, epochs = [], []
    elapsed, epoch, last_interval, previous = 0., 0, fallback_interval, None
    for frame in metadata:
        if previous is not None:
            dt = frame.ref_time_s-previous.ref_time_s
            reset = (dt <= 0. or frame.sequence <= previous.sequence or
                     frame.clock_id != previous.clock_id or frame.session_id != previous.session_id)
            if reset:
                epoch += 1
                elapsed += last_interval
            else:
                elapsed += dt
                last_interval = dt
        offsets.append(elapsed);epochs.append(epoch)
        previous = frame
    return offsets, epochs


def _worker(connection,folder,pose_path,output,config,mode):
    try:
        from .motion import load_experimental_poses, poses_for_frame
        from .replay import ReplayEngine
        poses = load_experimental_poses(pose_path,read_native_metadata(folder)) if pose_path else None
        engine = ReplayEngine(config,mode,poses)
        with (output/'clearances.jsonl').open('w',encoding='utf-8') as result_log, \
                (output/'clearances.csv').open('w',encoding='utf-8-sig',newline='') as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow(['frame','device_time_s','track_mode','candidate','observed_min_m',
                             'supported_min_m','source_index','source_time_s','point_count','flags'])
            connection.send({'ready':True})
            while True:
                request = connection.recv()
                if request is None:
                    break
                sequence,sent_time,arrival_time = request
                received = time.perf_counter()
                frame = next(read_native_frames(folder,{sequence}))
                read_done = time.perf_counter()
                update,layers,results = engine.step(frame)
                compute_done = time.perf_counter()
                by_id = {c.candidate_id:c for c in layers.candidates}
                for result in results:
                    result_log.write(json.dumps(result_to_dict(result),allow_nan=False)+'\n')
                    ref = result.observed_evidence.point_ref if result.observed_evidence else None
                    writer.writerow([sequence,frame.ref_time_s,update.mode,result.candidate_id,
                        result.observed_min_distance_m,result.supported_min_distance_m,
                        ref.index if ref else '',ref.time_s if ref else '',
                        len(by_id[result.candidate_id].point_indices),'|'.join(result.flags)])
                result_log.flush();csv_file.flush()
                written = time.perf_counter()
                row = {'sequence':sequence,'device_time_s':frame.ref_time_s,'scan_span_s':frame.scan_span_s,
                    'mode':update.mode,'consumed':True,'fresh_distance':any(
                        r.observed_evidence is not None and r.observed_evidence.point_ref.frame==sequence
                        for r in results),'layers':layers.counts,'motion_status':engine.measurement_frame.motion_status,
                    'diagnostics':update.diagnostics,'scene_diagnostics':layers.diagnostics,
                    'track':json_value(update.model),'timing_ms':dict(engine.timings,
                        native_read=(read_done-received)*1000.,ipc_request=(received-sent_time)*1000.,
                        pending_wait=(sent_time-arrival_time)*1000.,output=(written-compute_done)*1000.),
                    'worker_finished_at':written,'end_to_end_worker_ms':(written-arrival_time)*1000.}
                if poses is not None:
                    scoped = poses_for_frame(poses, frame)
                    sample = scoped.sample(frame.ref_time_s,frame.scan_span_s[1]) if scoped is not None else None
                    upstream = sample.diagnostics.get('core_step_ms') if sample else None
                    row['upstream_experimental_pose_ms']=upstream
                    row['matched_component_estimate_ms'] = ((written-arrival_time)*1000.+upstream
                                                            if upstream is not None else None)
                connection.send({'row':row})
    except BaseException:
        try:
            connection.send({'error':traceback.format_exc()})
        except (EOFError,BrokenPipeError,OSError):
            pass
    finally:
        connection.close()


def run_paced(folder,config,pose_path,output,mode='tracked',source_pcap=None):
    folder,output = Path(folder).resolve(),Path(output).resolve()
    metadata = list(read_native_metadata(folder))
    if not metadata:
        raise ValueError('no input frames')
    if len({f.sequence for f in metadata}) != len(metadata):
        raise ValueError('duplicate native frame identity; split separate recordings')
    offsets, epochs = _playback_schedule(metadata, config.period_s)
    schedule = {f.sequence:(offset,epoch) for f,offset,epoch in zip(metadata,offsets,epochs)}
    output.mkdir(parents=True,exist_ok=False)
    (output/'config.json').write_text(json.dumps(json_value(config),indent=2),encoding='utf-8')
    before_hash = hashlib.file_digest(Path(source_pcap).open('rb'),'sha256').hexdigest() if source_pcap else None
    context = mp.get_context('spawn')
    parent,child = context.Pipe()
    worker = context.Process(target=_worker,args=(child,folder,pose_path,output,config,mode),daemon=True)
    worker.start();child.close()
    rows = {f.sequence:{'sequence':f.sequence,'device_time_s':f.ref_time_s,
            'mode':'not_consumed','consumed':False,'fresh_distance':False,
            'playback_elapsed_s':schedule[f.sequence][0],'clock_epoch':schedule[f.sequence][1],
            'skip_reason':'outside_trigger'} for f in metadata}
    pending,trigger = LatestPending(),DeviceTrigger(config.period_s)
    ready,busy,position = False,False,0
    loaded_at = time.perf_counter()
    received_times = {}
    try:
        if not parent.poll(60):
            raise TimeoutError('owned paced worker startup timed out')
        response = parent.recv()
        if response.get('error'):
            raise RuntimeError(response['error'])
        ready = bool(response.get('ready'))
        start = time.perf_counter()
        while position<len(metadata) or busy or pending.pending is not None:
            now = time.perf_counter()
            while parent.poll():
                message = parent.recv()
                if 'error' in message:
                    raise RuntimeError(message['error'])
                row = message['row']
                offset,epoch = schedule[row['sequence']]
                row['playback_elapsed_s'],row['clock_epoch'] = offset,epoch
                row['arrival_lateness_s'] = rows[row['sequence']].get('arrival_lateness_s',0.)
                row['result_age_s'] = time.perf_counter()-start-offset
                row['timing_ms']['ipc_result']=(time.perf_counter()-row.pop('worker_finished_at'))*1000.
                rows[row['sequence']]=row
                busy,ready = False,True
                print('paced frame=%d mode=%s compute=%.1fms age=%.3fs' %
                    (row['sequence'],row['mode'],row['timing_ms']['compute'],row['result_age_s']),flush=True)
            while position<len(metadata) and now-start+1e-9 >= offsets[position]:
                if position and epochs[position] != epochs[position-1]:
                    trigger = DeviceTrigger(config.period_s)
                offset = offsets[position]
                frame = metadata[position];position+=1
                arrival = start+offset
                received_times[frame.sequence]=arrival
                rows[frame.sequence]['arrival_lateness_s']=max(0.,now-arrival)
                if trigger.due(frame.ref_time_s):
                    rows[frame.sequence]['skip_reason']='pending_replaced'
                    pending.offer(frame.sequence)
            if ready and pending.pending is not None:
                sequence = pending.take()
                sent = time.perf_counter()
                parent.send((sequence,sent,received_times[sequence]))
                busy,ready = True,False
            if not worker.is_alive() and (busy or position<len(metadata)):
                raise RuntimeError('owned paced worker stopped unexpectedly')
            time.sleep(.005)
        parent.send(None)
        worker.join(timeout=10)
        if worker.is_alive():
            raise TimeoutError('owned paced worker did not exit')
        if worker.exitcode!=0:
            raise RuntimeError('owned paced worker exit '+str(worker.exitcode))
    finally:
        if worker.is_alive():
            worker.terminate();worker.join(timeout=5)
            if worker.is_alive():
                worker.kill();worker.join()
        parent.close()
    with (output/'frames.jsonl').open('w',encoding='utf-8') as stream:
        for frame in metadata:
            stream.write(json.dumps(json_value(rows[frame.sequence]),allow_nan=False)+'\n')
    consumed = [r for r in rows.values() if r['consumed']]
    values = [r['timing_ms']['compute'] for r in consumed]
    from collections import Counter
    report = {'input_frames':len(metadata),'consumed_frames':len(consumed),
        'fresh_distance_frames':sum(r['fresh_distance'] for r in consumed),
        'mode_counts':dict(Counter(r['mode'] for r in consumed)),
        'skipped_frames':[r['sequence'] for r in rows.values() if not r['consumed']],
        'pending_replacements':pending.skipped,'mode':mode,'paced':True,'period_s':config.period_s,
        'worker_boot_s':start-loaded_at,'wall_s':time.perf_counter()-start,
        'compute_ms':{'median':float(np.median(values)),'p95':float(np.percentile(values,95)),
                      'max':float(max(values))} if values else {},
        'absolute_accuracy_verified':False,'live_0_2s_verified':False,
        'experimental_pose_lookup_only':True,'upstream_registration_in_worker':False}
    report['clock_epochs'] = max(epochs)+1
    report['playback_time_axis'] = 'positive device dt per epoch; reset gap uses last past interval or period'
    source = {'source_folder':str(folder),'pcap':str(source_pcap) if source_pcap else None,
        'pose_path':str(Path(pose_path).resolve()) if pose_path else None,
        'pose_truth':False,'native_frame_count':len(metadata),'owned_worker_pid':worker.pid,
        'live_deployment':False,'scope':'all exported scans including skipped scans',
        'sha256_before':before_hash}
    if source_pcap:
        with Path(source_pcap).open('rb') as stream:
            source['sha256_after']=hashlib.file_digest(stream,'sha256').hexdigest()
        source['unchanged']=source['sha256_before']==source['sha256_after']
        if not source['unchanged']:
            raise RuntimeError('original PCAP changed')
    (output/'timing.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    (output/'source.json').write_text(json.dumps(source,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in ('skipped_frames','pending_replacements')}),flush=True)
    return report
