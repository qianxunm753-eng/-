"""Conservative scene layers and range-adaptive components of real returns.

No signal-head template, minimum height, object-size gate or display voxel is
used here. Components are observations, not automatically named equipment.
"""
import numpy as np
from dataclasses import replace
from collections.abc import Mapping
from scipy.spatial import cKDTree
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from .geometry import corridor_indices, project_supported
from .protocol import Candidate, SceneLayers, validate_frame,measurement_model
from .voxel import representatives as voxel_representatives


class TemporalSupport(Mapping):
    """Compact native-index lookup; only a selected boundary builds PointRefs.

    This keeps every actual historical ref available, without constructing a
    dictionary and one Python tuple for every supported return on every scan.
    The ordinary Mapping interface preserves grouping/measurement consumers.
    """
    def __init__(self, indices, old_indices, references):
        order = np.argsort(indices, kind='stable')
        self.indices = np.asarray(indices,dtype=np.int64)[order]
        self.old_indices = np.asarray(old_indices,dtype=np.int64)[order]
        self.references = references

    def __len__(self):
        return len(self.indices)

    def __iter__(self):
        return (int(i) for i in self.indices)

    def __contains__(self,index):
        position = int(np.searchsorted(self.indices,index))
        return position < len(self.indices) and self.indices[position] == index

    def __getitem__(self, index):
        position = int(np.searchsorted(self.indices,index))
        if position == len(self.indices) or self.indices[position] != index:
            raise KeyError(index)
        return (self.references[int(self.old_indices[position])],)


class SurfaceTracker:
    """Associate observed surface fragments in a compensated local map.

    This is not semantic equipment recognition. Keep original component IDs,
    indices and minima; an ambiguous split/merge does not inherit a false ID.
    Only small representative sets are retained, never another full point log.
    """
    def __init__(self, config):
        self.config = config
        self.display_identity_seconds = (config.history_seconds if config.display_identity_seconds is None
                                         else config.display_identity_seconds)
        if not np.isfinite(self.display_identity_seconds) or self.display_identity_seconds <= 0:
            raise ValueError('positive finite display identity retention required')
        self.tracks = {}
        self.display_regions = {}
        self.selected_display_ids = set()
        self.next_id = 1
        self.next_display_id = 1
        self.last_context = None
        self.last_map = None
        self.current_link_witnesses = {}
        self.last_reconciliation_count = 0
        self.last_current_closure_diagnostics = {}
        self.last_history_reconciliation_count = 0
        self.last_raw_identity_match_count = 0

    def reset(self):
        self.tracks = {}
        self.display_regions = {}
        self.selected_display_ids = set()
        self.last_context = None
        self.last_map = None
        self.current_link_witnesses = {}
        self.last_reconciliation_count = 0
        self.last_current_closure_diagnostics = {}
        self.last_history_reconciliation_count = 0
        self.last_raw_identity_match_count = 0

    def remember_annotations(self,items):
        # Reserve identities, never old positions/values. Missing current
        # observations produce no line; a short gap does not reassign its slot.
        identities={m.get('display_id') for m in items if m.get('display_id') in self.display_regions}
        if identities:
            self.selected_display_ids=identities

    def _spatial_representatives(self,points,times,maximum=128,voxel_m=None):
        # Repeated observations refresh the same voxel, not its oldest copy.
        order=np.argsort(-times,kind='stable')
        width=self.config.neighbor_base_m*.5 if voxel_m is None else voxel_m
        keep,unused=voxel_representatives(points[order],max(1e-6,width))
        indices=order[keep]
        points=points[indices]
        if len(points)<=maximum:
            return points,times[indices]
        # Spatial coverage, not repeat/density weighted concatenation order.
        # Axis quantiles preserve every spatial extreme without 128 Python
        # farthest-point iterations per active region. Deduplication above
        # prevents repeated dense islands from consuming the sample budget.
        ranks=np.linspace(0,len(points)-1,max(2,maximum//3),dtype=int)
        selected=np.unique(np.concatenate([np.argsort(points[:,axis],kind='stable')[ranks]
                                           for axis in range(3)]))
        return points[selected],times[indices[selected]]

    def _identity_representatives(self,points,times):
        if not self.config.current_instance_reconciliation:
            return self._spatial_representatives(points,times)
        # Every discarded voxel return is within the base association radius
        # of an actual retained return, until the explicit 1024-point budget.
        # No interpolated points and no enlarged spatial matching radius.
        return self._spatial_representatives(points,times,maximum=1024,
            voxel_m=self.config.neighbor_base_m/np.sqrt(3.))

    def _region_observations(self,region,raw_parts=()):
        # An alias part is a bounded set of actual returns and a constraint.
        # The aggregate's 1024 representatives may omit a legitimate corner.
        return [region]+(region.get('alias_parts',[]) if self.config.qualified_history_reconciliation else [])+list(raw_parts)

    def _region_matches(self,region,points,radius,trees,raw_parts=()):
        matches = np.zeros(len(points),dtype=bool)
        for part in self._region_observations(region,raw_parts):
            key = id(part['points'])
            if key not in trees:
                trees[key] = cKDTree(part['points'])
            matches |= trees[key].query(points,k=1)[0]<=min(radius,part['radius'])
        return matches

    def _reconcile_history_regions(self,descriptions,time_s,ownership_points,instances):
        """Two independent qualified raw scans plus complete current closure.

        A past instance must explain EVERY ancestral part of EVERY touched
        region. Current minority owners are checked in full, not by density.
        No old distance or representative is substituted for current returns.
        """
        self.last_history_reconciliation_count = 0
        regions = list(self.display_regions.values())
        if len(regions)<2 or not instances or ownership_points is None:
            return
        source_instances = []
        for instance in instances:
            if (instance.get('state')!='qualified' or instance.get('independent_geometry') is not True or
                    instance.get('geometry_frame')!=instance.get('source_frame')):
                continue
            points = instance['points_W']
            source_instances.append((instance,cKDTree(points),points.min(0),points.max(0)))
        if not source_instances:
            return
        region_parts = [self._region_observations(region) for region in regions]
        lower_bounds = np.array([np.min([part['points'].min(0) for part in parts],axis=0) for parts in region_parts])
        upper_bounds = np.array([np.max([part['points'].max(0) for part in parts],axis=0) for parts in region_parts])
        search_radii = np.array([max(part['radius'] for part in parts) for parts in region_parts])
        covered = []
        for instance,tree,lower,upper in source_instances:
            ids = set()
            delta = np.maximum(0.,np.maximum(lower_bounds-upper,lower-upper_bounds))
            nearby = np.flatnonzero(np.linalg.norm(delta,axis=1)<=np.minimum(search_radii,instance['radius_m']))
            for index in nearby:
                region,parts = regions[index],region_parts[index]
                if all((tree.query(part['points'],k=1)[0]<=min(instance['radius_m'],part['radius'])).mean()>=.7
                       for part in parts):
                    ids.add(region['id'])
            covered.append(ids)
        trees = {}
        proposals = {}
        proposal_support = {}
        proposal_descriptions = {}
        for description,actual in zip(descriptions,ownership_points):
            if not description.get('can_seed',True) or len(actual)<3:
                continue
            delta = np.maximum(0.,np.maximum(actual.min(0)-upper_bounds,lower_bounds-actual.max(0)))
            nearby = np.flatnonzero(np.linalg.norm(delta,axis=1)<=np.minimum(search_radii,description['radius']))
            owners = [regions[index] for index in nearby if
                self._region_matches(regions[index],actual,description['radius'],trees).any()]
            if len(owners)<2:
                continue
            # All competing old owners form the closure, including minorities.
            # A larger parent may not silently erase the small conflicting one.
            actual_tree = cKDTree(actual)
            if not all((actual_tree.query(part['points'],k=1)[0]<=min(description['radius'],part['radius'])).mean()>=.3
                       for region in owners for part in self._region_observations(region)):
                continue
            owner_ids = frozenset(region['id'] for region in owners)
            keep,inverse = voxel_representatives(actual,self.config.neighbor_base_m*.5)
            if len(keep)<3:
                continue
            proofs = {}
            proof_matches = {}
            for (instance,tree,lower,upper),ids in zip(source_instances,covered):
                if not owner_ids.issubset(ids):
                    continue
                delta = np.maximum(0.,np.maximum(actual.min(0)-upper,lower-actual.max(0)))
                radius = min(description['radius'],instance['radius_m'])
                if np.linalg.norm(delta)>radius:
                    continue
                matched = tree.query(actual,k=1)[0]<=radius
                cells = np.ones(len(keep),dtype=bool)
                np.minimum.at(cells,inverse,matched)
                if cells.mean()<.7:
                    continue
                proofs.setdefault(instance['object_id'],set()).add(
                    (instance['source_frame'],instance['source_time_s']))
                by_source = proof_matches.setdefault(instance['object_id'],{})
                source = instance['source_frame']
                by_source[source] = by_source.get(source,np.zeros(len(actual),dtype=bool)) | matched
            qualified = {identity:sources for identity,sources in proofs.items()
                         if len({s[0] for s in sources})>=2 and len({s[1] for s in sources})>=2}
            if len(qualified)==1:
                identity,sources = next(iter(qualified.items()))
                proposals.setdefault(owner_ids,{}).setdefault(identity,set()).update(sources)
                counts = np.sum(list(proof_matches[identity].values()),axis=0)
                # Admit only CURRENT real returns supported by two distinct
                # donor scans. Otherwise sparse old maps can trigger a new ID
                # immediately after their valid historical reconciliation.
                proposal_support.setdefault(owner_ids,[]).append(actual[counts>=2])
                proposal_descriptions.setdefault(owner_ids,[]).append(description)
        # Different overlapping closures cannot choose an owner by list order
        # or transitively connect A-B-C. A complete current closure is required.
        groups = [ids for ids,identities in proposals.items() if len(identities)==1]
        groups = [ids for ids in groups if not any(ids!=other and ids&other for other in proposals)]
        for ids in groups:
            members = [self.display_regions[key] for key in self.display_regions if key in ids]
            constituents = self._unique_alias_parts([part for member in members for part in
                (member.get('alias_parts') or [dict(points=member['points'],point_times=member['point_times'],
                                                  radius=member['radius'])])])
            if len(constituents)>max(1,self.config.history_max_scans*4):
                continue
            chosen = max(range(len(members)),key=lambda i:(members[i]['id'] in self.selected_display_ids,
                members[i]['observations'],-members[i]['first_seen'],-i))
            parent = members[chosen]
            current_points = np.concatenate(proposal_support[ids])
            points,times = self._identity_representatives(np.concatenate([m['points'] for m in members]+[current_points]),
                np.r_[np.concatenate([m['point_times'] for m in members]),np.full(len(current_points),time_s)])
            preview = dict(parent,points=points,radius=min(m['radius'] for m in members),alias_parts=constituents)
            if any(self._region_matches(preview,description['points'],description['radius'],{}).mean()<.5
                   for description in proposal_descriptions[ids]):
                # Two 70% donor covers can share only 40% of the actual face.
                # Do not mutate IDs if the bounded verified map would fail the
                # ordinary current association immediately after the merge.
                continue
            for member in members:
                self.display_regions.pop(member['id'])
            sources = next(iter(proposals[ids].values()))
            self.display_regions[parent['id']] = dict(parent,points=points,point_times=times,
                lower=points.min(0),upper=points.max(0),radius=min(m['radius'] for m in members),
                last_seen=max(m['last_seen'] for m in members),alias_parts=constituents,
                observations=max(m['observations'] for m in members),current_relation_confirmed=True,
                history_evidence_frames=sorted({s[0] for s in sources}))
            self.current_link_witnesses = {key:value for key,value in self.current_link_witnesses.items()
                                           if not ids.intersection(key)}
            self.last_history_reconciliation_count += 1

    def _associate_display(self, descriptions, time_s, current_links=(), ownership_points=None,history_instances=(),
                           raw_identity_instances=()):
        """Visible subsets may match an old region without covering its whole
        surface. Conflicting bridges never replace their distinct parents.
        Only bounded real representative points are retained, not distances.
        """
        full_owner_check=self.config.qualified_instance_ownership and ownership_points is not None
        self.last_raw_identity_match_count = 0
        if full_owner_check and len(ownership_points)!=len(descriptions):
            raise ValueError('current ownership core/description count mismatch')
        recent={}
        for key,item in self.display_regions.items():
            times=item['point_times']
            keep=time_s-times<=self.display_identity_seconds+1e-9
            if time_s-item['last_seen']<=self.display_identity_seconds+1e-9 and keep.any():
                points=item['points'][keep]
                recent[key]=dict(item,points=points,point_times=times[keep],
                                 lower=points.min(axis=0),upper=points.max(axis=0))
                if self.config.qualified_instance_ownership and 'alias_parts' in item:
                    parts=[]
                    for part in item['alias_parts']:
                        visible=time_s-part['point_times']<=self.display_identity_seconds+1e-9
                        if visible.any():
                            parts.append(dict(part,points=part['points'][visible],point_times=part['point_times'][visible]))
                    recent[key]['alias_parts']=parts
        self.display_regions=recent
        if self.config.qualified_instance_ownership:
            self._merge_region_aliases()
        if self.config.qualified_history_reconciliation:
            self._reconcile_history_regions(descriptions,time_s,ownership_points,history_instances)
        if self.config.current_instance_reconciliation:
            self._reconcile_current_regions(descriptions,current_links,time_s,
                ownership_points if full_owner_check else None)
        old = list(self.display_regions.values())
        # Validated causal native returns supplement matching only. They are
        # not persisted, do not resurrect retired IDs, and never enter the
        # reconciliation proof paths above. Exact source radii are retained.
        raw_by_id = {}
        if self.config.raw_history_identity_support and full_owner_check:
            for instance in raw_identity_instances:
                identity = instance['object_id']
                if (identity in self.display_regions and instance.get('state') in ('tentative','qualified')
                        and instance.get('independent_geometry') is True):
                    raw_by_id.setdefault(identity,[]).append(dict(points=instance['points_W'],radius=instance['radius_m']))
        trees=([cKDTree(item['points']) for item in old]
               if self.config.current_instance_reconciliation or full_owner_check else None)
        lower = np.asarray([item['lower'] for item in old]).reshape(-1,3)
        upper = np.asarray([item['upper'] for item in old]).reshape(-1,3)
        alias_trees = {}
        if self.config.qualified_history_reconciliation:
            lower = np.asarray([np.min([part['points'].min(0) for part in
                                       self._region_observations(item,raw_by_id.get(item['id'],()))],axis=0)
                                for item in old]).reshape(-1,3)
            upper = np.asarray([np.max([part['points'].max(0) for part in
                                       self._region_observations(item,raw_by_id.get(item['id'],()))],axis=0)
                                for item in old]).reshape(-1,3)
        radii = np.asarray([item['radius'] for item in old])
        if self.config.qualified_history_reconciliation:
            # Broad phase must cover every retained alias's own radius. Exact
            # queries below still use min(current radius, each part radius).
            radii = np.asarray([max(part['radius'] for part in
                                   self._region_observations(item,raw_by_id.get(item['id'],()))) for item in old])
        matches = []
        match_details=[]
        layout_support = {}
        owner_masks=[]
        raw_rescued=[]
        for description_index,current in enumerate(descriptions):
            actual=ownership_points[description_index] if full_owner_check else current['points']
            radius = (np.minimum(current['radius'],radii) if self.config.qualified_instance_ownership
                      else np.maximum(current['radius'],radii))
            current_lower,current_upper = ((actual.min(0),actual.max(0)) if raw_by_id
                                           else (current['lower'],current['upper']))
            separation = np.maximum(0.,np.maximum(current_lower-upper,lower-current_upper))
            parents = []
            supported_parents = []
            compatible_count = np.zeros(len(current['points']), dtype=np.int64)
            matched_masks = {}
            actual_masks={}
            actual_count=np.zeros(len(actual),dtype=np.int64)
            rescued_parents = set()
            for p in np.flatnonzero(np.linalg.norm(separation,axis=1) <= radius):
                if self.config.qualified_history_reconciliation:
                    compatible = self._region_matches(old[p],current['points'],current['radius'],alias_trees)
                    raw_parts = raw_by_id.get(old[p]['id'],())
                    if raw_parts and current.get('has_current_support',current.get('can_seed',True)):
                        bounded_coverage = compatible.mean()
                        compatible |= self._region_matches(old[p],current['points'],current['radius'],alias_trees,raw_parts)
                        if bounded_coverage<.5 and compatible.mean()>=.5:
                            rescued_parents.add(int(p))
                elif trees is not None:
                    compatible=trees[p].query(current['points'],k=1)[0]<=radius[p]
                else:
                    distances = np.linalg.norm(current['points'][:,None,:]-old[p]['points'][None,:,:],axis=2)
                    compatible = distances.min(axis=1) <= radius[p]
                compatible_count += compatible
                actual_compatible=(self._region_matches(old[p],actual,current['radius'],alias_trees,
                                                       raw_by_id.get(old[p]['id'],()))
                    if full_owner_check and self.config.qualified_history_reconciliation else
                    trees[p].query(actual,k=1)[0]<=radius[p] if full_owner_check else compatible)
                actual_count+=actual_compatible
                if self.config.qualified_instance_ownership and actual_compatible.any():
                    supported_parents.append(int(p))
                    matched_masks[int(p)]=compatible
                    actual_masks[int(p)]=actual_compatible
                if compatible.mean() >= .5:
                    parents.append(int(p))
                    matched_masks[int(p)] = compatible
            if self.config.qualified_instance_ownership and len(supported_parents)>1:
                # A minority of actual core returns at a different current
                # owner is still competing evidence. Majority overlap cannot
                # admit the entire mixed bridge into one parent's local map.
                # Keep both histories and defer the unchanged native minimum.
                parents=supported_parents
            matches.append(parents)
            raw_rescued.append(len(parents)==1 and parents[0] in rescued_parents)
            match_details.append((matched_masks,compatible_count))
            owner_masks.append((actual_masks,actual_count))
            if len(parents) > 1:
                # A mixed bridge cannot inherit identity or distance. However,
                # its CURRENT returns that overlap exactly one recent parent
                # still prove that parent's layout extent is visible. Compare
                # against every nearby parent, not just the majority matches.
                # Shared returns remain ambiguous and cannot hold an anchor.
                for p in parents:
                    exclusive = matched_masks[p] & (compatible_count == 1)
                    if exclusive.any():
                        layout_support.setdefault(p, []).append(current['points'][exclusive])
        for p, parts in layout_support.items():
            points = np.concatenate(parts)
            layout_support[p], unused = self._spatial_representatives(points, np.full(len(points), time_s))
        children = {}
        for i,parents in enumerate(matches):
            if len(parents)==1:
                children.setdefault(parents[0],[]).append(i)
        proposed_members={}
        if self.config.observable_instance_seeding and full_owner_check:
            for parent_index,indices in children.items():
                bodies=[i for i in indices if descriptions[i].get('can_seed',True)]
                if not bodies:
                    continue  # A partial-only view may retain the known ID.
                body_trees={i:cKDTree(ownership_points[i]) for i in bodies}
                accepted=[]
                for i in indices:
                    if i in bodies:
                        accepted.append(i)
                        continue
                    supported=np.zeros(len(ownership_points[i]),dtype=bool)
                    for body in bodies:
                        supported |= body_trees[body].query(ownership_points[i],k=1)[0]<=min(
                            descriptions[i]['radius'],descriptions[body]['radius'])
                    if supported.all():
                        accepted.append(i)
                    else:
                        # Old-map proximity proposes an identity, not current
                        # attachment to a concurrently observed body. Keep the
                        # real range unresolved and do not pollute/refresh it.
                        proposed_members[i]=old[parent_index]['id']
                        matches[i]=[]
                        raw_rescued[i]=False
                children[parent_index]=accepted
        anchors={}
        for parent_index,indices in children.items():
            parent=old[parent_index]
            lower=np.min([descriptions[i]['lower'] for i in indices],axis=0)
            upper=np.max([descriptions[i]['upper'] for i in indices],axis=0)
            separation=np.maximum(0.,np.maximum(lower-parent['anchor_W'],parent['anchor_W']-upper))
            radius=max(descriptions[i]['radius'] for i in indices)
            anchor=parent['anchor_W']
            axis=descriptions[indices[0]].get('layout_axis_W')
            if axis is not None:
                low=min(descriptions[i]['layout_station_range_W'][0] for i in indices)
                high=max(descriptions[i]['layout_station_range_W'][1] for i in indices)
                extra = layout_support.get(parent_index)
                if extra is not None:
                    stations = extra @ axis
                    low = min(low, float(stations.min()))
                    high = max(high, float(stations.max()))
                station=float(anchor@axis)
                detached=max(0.,low-station,station-high)>radius
            else:
                detached=np.linalg.norm(separation)>radius
            if detached:
                if axis is not None:
                    # Make the least required layout movement into the current
                    # station interval. A centroid reset can jump a metre when
                    # only a small end of an otherwise supported face is lost.
                    # This is annotation geometry, not a fabricated return.
                    anchor=anchor+axis*(float(np.clip(station,low,high))-station)
                else:
                    # No current track axis: retain the generic 3D fallback.
                    points=np.concatenate([descriptions[i]['points'] for i in indices])
                    points,unused=self._spatial_representatives(points,np.full(len(points),time_s))
                    anchor=points.mean(axis=0)
            anchors[parent_index]=anchor
        assignments = []
        for description_index,(current,parents) in enumerate(zip(descriptions,matches)):
            if len(parents)==1:
                self.last_raw_identity_match_count += int(raw_rescued[description_index])
                parent = old[parents[0]]
                item = dict(display_id=parent['id'],display_anchor_W=anchors[parents[0]],
                    display_observations=parent['observations']+1,display_first_seen=parent['first_seen'],
                    display_event='same_region_split_or_merge' if len(children[parents[0]])>1 else 'matched',
                    display_layout_support_W=layout_support.get(parents[0], np.empty((0,3))))
            else:
                if self.config.qualified_instance_ownership and not parents and not current.get('can_seed',True):
                    assignments.append(dict(display_id=None,display_anchor_W=current['points'].mean(axis=0),
                        display_observations=0,display_first_seen=time_s,display_event='temporal_only_unowned',
                        proposed_display_id=proposed_members.get(description_index),
                        display_layout_support_W=np.empty((0,3))))
                    continue
                item = dict(display_id='T%d'%self.next_display_id,display_anchor_W=current['points'].mean(axis=0),
                    display_observations=1,display_first_seen=time_s,display_event='ambiguous' if parents else 'new')
                self.next_display_id += 1
                if not parents:
                    self.display_regions[item['display_id']] = dict(id=item['display_id'],
                        anchor_W=item['display_anchor_W'],observations=1,first_seen=time_s,
                        point_times=np.full(len(current['points']),time_s),**current)
                else:
                    # Each parent is still spatially observed by this current
                    # bridge. Retain separate history without treating the
                    # bridge as confirmation, moving anchors or counting it.
                    actual=(ownership_points[description_index] if full_owner_check else current['points'])
                    actual_tree=cKDTree(actual) if full_owner_check else None
                    for p in parents:
                        parent=old[p]
                        stored=self.display_regions[parent['id']]
                        refresh_radius=(min(parent['radius'],current['radius']) if self.config.qualified_instance_ownership
                                        else max(parent['radius'],current['radius']))
                        if actual_tree is not None:
                            seen=actual_tree.query(parent['points'],k=1)[0]<=refresh_radius
                        else:
                            distances=np.linalg.norm(parent['points'][:,None,:]-current['points'][None,:,:],axis=2)
                            seen=distances.min(axis=1)<=refresh_radius
                        times=stored['point_times'].copy()
                        times[seen]=time_s
                        self.display_regions[parent['id']] = dict(stored,last_seen=time_s,point_times=times)
                        if self.config.qualified_instance_ownership and parent.get('alias_parts'):
                            masks,counts=owner_masks[description_index]
                            unique=masks[p]&(counts==1)
                            self.display_regions[parent['id']]['alias_parts']=self._refresh_alias_parts(
                                stored,actual[unique],current['radius'],time_s)
                # An ambiguous bridge is not admitted as a new historical
                # region; otherwise it collapses two devices on the next split.
            assignments.append(item)
        for parent_index,indices in children.items():
            parent = old[parent_index]
            stored=self.display_regions[parent['id']]
            points = np.concatenate([parent['points']]+[descriptions[i]['points'] for i in indices])
            # The same parent can also have an ambiguous bridge in this scan.
            # Keep the supported per-point refresh performed above; starting
            # from the old snapshot would silently undo that observation.
            times=np.r_[self.display_regions[parent['id']]['point_times'],
                        np.full(len(points)-len(parent['points']),time_s)]
            points,times = self._identity_representatives(points,times)
            self.display_regions[parent['id']] = dict(stored,anchor_W=anchors[parent_index],
                points=points,point_times=times,lower=points.min(axis=0),
                upper=points.max(axis=0),last_seen=time_s,observations=parent['observations']+1,
                radius=max([parent['radius']]+[descriptions[i]['radius'] for i in indices]))
            if self.config.qualified_instance_ownership and stored.get('alias_parts'):
                observed=np.concatenate([descriptions[i]['points'] for i in indices])
                self.display_regions[parent['id']]['alias_parts']=self._refresh_alias_parts(
                    stored,observed,min(descriptions[i]['radius'] for i in indices),time_s)
        return assignments

    def _reconcile_current_regions(self, descriptions, links, time_s, ownership_points=None):
        """Two consecutive exclusive current geometric links, never ID proximity.

        Geometry was independently checked on native qualified cores upstream.
        Only IDs/representatives are reconciled; no old minimum, old index or
        invented return can enter the actual current measurement candidates.
        """
        self.last_reconciliation_count=0
        complete=self.config.complete_current_reconciliation
        self.last_current_closure_diagnostics=dict(links=len(links),alias_regions=0,
            competing_current_views=0,incomplete_current_views=0,
            incomplete_reverse_views=0,incomplete_ancestral_pairs=0) if complete else {}
        if not links:
            self.current_link_witnesses={}
            return
        if complete and (ownership_points is None or len(ownership_points)!=len(descriptions)):
            self.current_link_witnesses={}
            return
        regions=list(self.display_regions.values())
        trees=[] if complete else [cKDTree(r['points']) for r in regions]
        parents=[]
        observed_parts=[]
        region_by_id={r['id']:r for r in regions}
        def constituents(region):
            return region.get('alias_parts') or [region]
        observed_regions=[self._region_observations(r) if complete else [r] for r in regions]
        if complete:
            self.last_current_closure_diagnostics['alias_regions']=sum(bool(r.get('alias_parts')) for r in regions)
        lower=np.asarray([np.min([p['points'].min(0) for p in parts],axis=0) for parts in observed_regions]).reshape(-1,3)
        upper=np.asarray([np.max([p['points'].max(0) for p in parts],axis=0) for parts in observed_regions]).reshape(-1,3)
        search_radii=np.asarray([max(p['radius'] for p in parts) for parts in observed_regions])
        alias_trees={}
        needed={index for pair in links for index in pair}
        for description_index,current in enumerate(descriptions):
            matches=[]
            supported_regions=0
            if description_index in needed and current.get('can_seed',True):
                actual=ownership_points[description_index] if complete else current['points']
                if not len(actual):
                    parents.append(None)
                    observed_parts.append(np.empty(0,dtype=bool))
                    continue
                current_tree=cKDTree(actual)
                current_lower,current_upper=(actual.min(0),actual.max(0)) if complete else (current['lower'],current['upper'])
                if complete:
                    keep,inverse=voxel_representatives(actual,self.config.neighbor_base_m*.5)
                for index,region in enumerate(regions):
                    radius=min(current['radius'],region['radius'])
                    delta=np.maximum(0.,np.maximum(
                        current_lower-upper[index],lower[index]-current_upper))
                    if np.linalg.norm(delta)>min(current['radius'],search_radii[index]):
                        continue
                    if complete:
                        actual_compatible=self._region_matches(region,actual,current['radius'],alias_trees)
                        cells=np.ones(len(keep),dtype=bool)
                        np.minimum.at(cells,inverse,actual_compatible)
                        coverage=float(cells.mean())
                    else:
                        compatible=trees[index].query(current['points'],k=1)[0]<=radius
                        actual_compatible=(trees[index].query(ownership_points[description_index],k=1)[0]<=radius
                                           if ownership_points is not None else compatible)
                        coverage=float(compatible.mean())
                    supported_regions+=bool(actual_compatible.any())
                    if complete and actual_compatible.any() and coverage<.7:
                        self.last_current_closure_diagnostics['incomplete_current_views']+=1
                    if coverage>=.7:
                        reverse=(current_tree.query(region['points'],k=1)[0]<=radius).mean()
                        if reverse>=.3:
                            matches.append(region['id'])
                        elif complete:
                            self.last_current_closure_diagnostics['incomplete_reverse_views']+=1
            if supported_regions!=1:
                matches=[]
                if complete and supported_regions>1:
                    self.last_current_closure_diagnostics['competing_current_views']+=1
            parents.append(matches[0] if len(matches)==1 else None)
            covered=[]
            if len(matches)==1:
                for part in constituents(region_by_id[matches[0]]):
                    radius=min(current['radius'],part['radius'])
                    covered.append((current_tree.query(part['points'],k=1)[0]<=radius).mean()>=.3)
            observed_parts.append(np.asarray(covered,dtype=bool))
        witnesses={}
        proofs={}
        for a,b in links:
            left,right=parents[a],parents[b]
            if left is None or right is None or left==right:
                continue
            key=tuple(sorted((left,right)))
            coverage=observed_parts[a][:,None]&observed_parts[b][None,:]
            if key[0]!=left:
                coverage=coverage.T
            if key in proofs:
                proofs[key]|=coverage
            else:
                proofs[key]=coverage
        for key,coverage in proofs.items():
            # An aggregate ID must not erase its constituent obligations:
            # observing B-C twice still cannot prove the missing A-C edge
            # after A-B was merged on an earlier scan.
            if not coverage.size or not coverage.all():
                if complete:
                    self.last_current_closure_diagnostics['incomplete_ancestral_pairs']+=1
                continue
            old=self.current_link_witnesses.get(key)
            count=(old['count']+1 if old is not None and
                   0.<time_s-old['time_s']<=self.display_identity_seconds+1e-9 else 1)
            if old is not None and time_s==old['time_s']:
                count=old['count']
            witnesses[key]=dict(count=count,time_s=time_s)
        self.current_link_witnesses=witnesses
        keys=list(self.display_regions)
        compatible=np.eye(len(keys),dtype=bool)
        for i,key in enumerate(keys):
            for j in range(i+1,len(keys)):
                evidence=witnesses.get(tuple(sorted((key,keys[j]))))
                if evidence is not None and evidence['count']>=2:
                    compatible[i,j]=compatible[j,i]=True
        groups=[]
        for i in range(len(keys)):
            for group in groups:
                if compatible[i,group].all():
                    group.append(i)
                    break
            else:
                groups.append([i])
        for group in groups:
            if len(group)<2:
                continue
            members=[self.display_regions[keys[i]] for i in group]
            constituents=self._unique_alias_parts([p for member in members for p in
                (member.get('alias_parts') or [dict(points=member['points'],
                    point_times=member['point_times'],radius=member['radius'])])])
            if len(constituents)>max(1,self.config.history_max_scans*4):
                continue
            chosen=max(range(len(members)),key=lambda i:(members[i]['id'] in self.selected_display_ids,
                members[i]['observations'],-members[i]['first_seen'],-i))
            parent=members[chosen]
            points,times=self._identity_representatives(np.concatenate([m['points'] for m in members]),
                np.concatenate([m['point_times'] for m in members]))
            for member in members:
                self.display_regions.pop(member['id'])
            self.display_regions[parent['id']]=dict(parent,points=points,point_times=times,
                lower=points.min(0),upper=points.max(0),radius=min(m['radius'] for m in members),
                last_seen=max(m['last_seen'] for m in members),alias_parts=constituents,
                observations=max(m['observations'] for m in members),
                current_relation_confirmed=True)
            self.last_reconciliation_count+=1
            changed={m['id'] for m in members}
            self.current_link_witnesses={key:value for key,value in self.current_link_witnesses.items()
                if not changed.intersection(key)}

    def _refresh_alias_parts(self, parent, points, radius, time_s):
        output=[]
        tree=cKDTree(points) if len(points) else None
        for part in parent['alias_parts']:
            times=part['point_times'].copy()
            if tree is not None:
                times[tree.query(part['points'],k=1)[0]<=min(radius,part['radius'])]=time_s
            output.append(dict(part,point_times=times))
        return output

    def _unique_alias_parts(self, constituents):
        """Deduplicate identical constraints, never approximate away a conflict."""
        unique={}
        for part in constituents:
            order=np.lexsort((part['points'][:,2],part['points'][:,1],part['points'][:,0]))
            points=np.ascontiguousarray(part['points'][order])
            times=part['point_times'][order]
            key=(float(part['radius']),len(points),points.tobytes())
            if key in unique:
                unique[key]['point_times']=np.maximum(unique[key]['point_times'],times)
            else:
                unique[key]=dict(part,points=points,point_times=times.copy())
        return list(unique.values())

    def _merge_region_aliases(self):
        """Canonicalize mutually observed local aliases, never a proximity chain.

        Only qualified core returns enter these regions. Require mutual 3-D
        support at the actual association radius; equal clearance, boxes or a
        bridging third region cannot prove ownership. No distance is retained.
        """
        keys=list(self.display_regions)
        if len(keys)<2:
            return
        regions=[self.display_regions[k] for k in keys]
        lower=np.array([r['lower'] for r in regions])
        upper=np.array([r['upper'] for r in regions])
        radii=np.array([r['radius'] for r in regions])
        compatible=np.eye(len(keys),dtype=bool)
        trees={}
        def parts(region):
            return region.get('alias_parts') or [dict(points=region['points'],
                point_times=region['point_times'],radius=region['radius'])]
        def mutually_supported(a,b):
            limit=min(a['radius'],b['radius'])
            for part,other in ((a,b),(b,a)):
                key=id(other['points'])
                if key not in trees:
                    trees[key]=cKDTree(other['points'])
                if (trees[key].query(part['points'],k=1)[0]<=limit).mean()<.7:
                    return False
            return True
        for i,a in enumerate(regions):
            separation=np.maximum(0.,np.maximum(lower[i]-upper,lower-upper[i]))
            limit=np.minimum(radii[i],radii)
            for j in np.flatnonzero(np.linalg.norm(separation,axis=1)<=limit):
                if j<=i:
                    continue
                b=regions[j]
                if (mutually_supported(a,b) and all(mutually_supported(x,y) for x in parts(a) for y in parts(b))):
                    compatible[i,j]=compatible[j,i]=True
        groups=[]
        for i in range(len(keys)):
            for group in groups:
                if compatible[i,group].all():
                    group.append(i)
                    break
            else:
                groups.append([i])
        for group in groups:
            if len(group)<2:
                continue
            constituents=self._unique_alias_parts([part for i in group for part in parts(regions[i])])
            if len(constituents)>max(1,self.config.history_max_scans*4):
                # Refuse a costly/unresolved merge instead of deleting old
                # incompatibility constraints to fit the budget.
                continue
            chosen=max(group,key=lambda i:(keys[i] in self.selected_display_ids,
                regions[i]['observations'],-regions[i]['first_seen'],-i))
            parent=regions[chosen]
            points=np.concatenate([regions[i]['points'] for i in group])
            times=np.concatenate([regions[i]['point_times'] for i in group])
            points,times=self._identity_representatives(points,times)
            for i in group:
                self.display_regions.pop(keys[i],None)
            self.display_regions[parent['id']]=dict(parent,points=points,point_times=times,
                lower=points.min(axis=0),upper=points.max(axis=0),
                last_seen=max(regions[i]['last_seen'] for i in group),
                observations=max(regions[i]['observations'] for i in group),
                radius=max(regions[i]['radius'] for i in group),alias_parts=constituents)
            if self.config.current_instance_reconciliation:
                changed={keys[i] for i in group}
                self.current_link_witnesses={key:value for key,value in self.current_link_witnesses.items()
                    if not changed.intersection(key)}

    def update(self, frame, layers, pose, model=None,history_instances=()):
        from .motion import usable_pose, pose_map_key
        validate_frame(frame)
        context = (frame.session_id, frame.clock_id, frame.sequence, frame.ref_time_s)
        previous = self.last_context
        if previous is not None and (context[:2] != previous[:2] or
                context[2] <= previous[2] or context[3] <= previous[3]):
            self.reset()
        self.last_context = context
        if not usable_pose(pose, frame.ref_time_s, frame.clock_id, frame.scan_span_s[1]):
            self.tracks = {}
            self.display_regions = {}
            self.selected_display_ids = set()
            self.last_map = None
            self.current_link_witnesses = {}
            candidates = tuple(replace(c, diagnostics=dict(c.diagnostics,
                surface_id=None, surface_observations=0, surface_association='pose_unavailable',
                display_id=None,display_anchor_L=None,display_observations=0,
                display_association='pose_unavailable'))
                for c in layers.candidates)
            if self.config.qualified_instance_ownership:
                candidates=tuple(replace(c,diagnostics=dict(c.diagnostics,
                    object_id=None,object_association='uncompensated',
                    object_identity_semantics='unconfirmed current observation; not equipment identity'))
                    for c in candidates)
                if self.config.current_observation_gating:
                    from .objects import qualified_core_indices
                    from .instance_evidence import instance_seed_evidence
                    from .rsview_cache import _CurrentGroundContext
                    terrain=_CurrentGroundContext(frame,layers,model,self.config)
                    normal=np.mean([s.normal_L for s in model.segments],axis=0) if model is not None else None
                    checked=[]
                    reasons={}
                    for candidate in candidates:
                        core=np.intersect1d(qualified_core_indices(frame,candidate,self.config),candidate.supported_indices)
                        evidence=instance_seed_evidence(frame,candidate,core,normal,self.config,terrain)
                        reasons[evidence['reason']]=reasons.get(evidence['reason'],0)+1
                        checked.append(replace(candidate,diagnostics=dict(candidate.diagnostics,
                            instance_seed_evidence=evidence)))
                    candidates=tuple(checked)
                    # No persistent ID or history is created without a usable
                    # pose. Only current observation eligibility is assessed.
                    layers=replace(layers,diagnostics=dict(layers.diagnostics,instance_seeding_evidence=reasons))
            return replace(layers, candidates=candidates)
        current_map = pose_map_key(pose)
        if self.last_map is not None and current_map != self.last_map:
            self.tracks = {}
            self.display_regions = {}
            self.selected_display_ids = set()
            self.current_link_witnesses = {}
        self.last_map = current_map
        self.tracks = {key: item for key, item in self.tracks.items()
                       if frame.ref_time_s-item['last_seen'] <= self.config.history_seconds+1e-9}
        old = list(self.tracks.values())
        old_lower = np.asarray([item['lower'] for item in old]).reshape(-1,3)
        old_upper = np.asarray([item['upper'] for item in old]).reshape(-1,3)
        old_radii = np.asarray([item['radius'] for item in old])
        layout_axis_W=None
        if model is not None:
            normal=np.mean([s.normal_L for s in model.segments],axis=0)
            normal/=np.linalg.norm(normal)
            axis=model.segments[-1].end_L-model.segments[0].start_L
            axis-=normal*float(axis@normal)
            if np.linalg.norm(axis)>1e-9:
                layout_axis_W=pose.T_WL[:3,:3]@(axis/np.linalg.norm(axis))
        descriptions = []
        for candidate in layers.candidates:
            points_L = frame.xyz_L[candidate.point_indices]
            points = points_L@pose.T_WL[:3, :3].T+pose.T_WL[:3, 3]
            representatives = points[np.linspace(0, len(points)-1, min(len(points), 64), dtype=int)]
            if self.config.display_balance_sides:
                representatives,unused=self._spatial_representatives(
                    points,np.full(len(points),frame.ref_time_s),maximum=64)
            radius = 2.*(self.config.neighbor_base_m+
                         self.config.neighbor_angle_rad*np.linalg.norm(points_L.mean(axis=0)))
            descriptions.append(dict(points=representatives, lower=points.min(axis=0),
                upper=points.max(axis=0), radius=radius, last_seen=frame.ref_time_s))
            if layout_axis_W is not None:
                stations=points@layout_axis_W
                descriptions[-1].update(layout_axis_W=layout_axis_W,
                    layout_station_range_W=[float(stations.min()),float(stations.max())])
        possible = [[] for unused in descriptions]
        reverse = [[] for unused in old]
        for index, current in enumerate(descriptions):
            # Vectorized spatial rejection: don't execute Python geometry for
            # every pair of small scan fragments. The exact overlap test and
            # split/merge semantics below remain unchanged.
            radii = np.maximum(current['radius'],old_radii)
            separation = np.maximum(0.,np.maximum(current['lower']-old_upper,
                                                  old_lower-current['upper']))
            nearby = np.flatnonzero(np.linalg.norm(separation,axis=1) <= radii)
            for old_index in nearby:
                past,radius = old[old_index],radii[old_index]
                distances = np.linalg.norm(current['points'][:, None, :]-past['points'][None, :, :], axis=2)
                # Partial visibility is allowed. Both sets must actually share
                # observed local surface; bounding-box overlap alone is not ID.
                if ((distances.min(axis=1) <= radius).mean() >= .5 and
                        (distances.min(axis=0) <= radius).mean() >= .3):
                    possible[index].append(old_index)
                    reverse[old_index].append(index)
        # Retire consumed or conflicted parents; otherwise one ambiguous split
        # leaves duplicate old geometry competing with its children forever.
        for old_index, children in enumerate(reverse):
            if children:
                self.tracks.pop(old[old_index]['id'], None)
        if self.config.qualified_instance_ownership:
            from .objects import qualified_core_indices
            seed_reports={}
            terrain_context=None
            if self.config.observable_instance_seeding:
                from .instance_evidence import instance_seed_evidence
                from .rsview_cache import _CurrentGroundContext
                terrain_context=_CurrentGroundContext(frame,layers,model,self.config)
            qualified=[]
            ownership_points=[]
            indices=[]
            for i,candidate in enumerate(layers.candidates):
                core=np.intersect1d(qualified_core_indices(frame,candidate,self.config),candidate.supported_indices)
                if not len(core):
                    continue
                native=frame.xyz_L[core]
                points=native@pose.T_WL[:3,:3].T+pose.T_WL[:3,3]
                if self.config.current_instance_reconciliation:
                    sample,unused=self._identity_representatives(points,np.full(len(points),frame.ref_time_s))
                else:
                    sample,unused=self._spatial_representatives(points,np.full(len(points),frame.ref_time_s),maximum=64)
                center=(native.min(axis=0)+native.max(axis=0))*.5
                radius=self.config.neighbor_base_m+self.config.neighbor_angle_rad*np.linalg.norm(center)
                description=dict(points=sample,lower=points.min(axis=0),upper=points.max(axis=0),
                    radius=radius,last_seen=frame.ref_time_s)
                current_support=candidate.diagnostics.get('support_neighbor_valid')
                can_seed=True
                if current_support is not None:
                    current_support=np.asarray(current_support,dtype=bool)
                    supported_rows=current_support.any(axis=1) if current_support.ndim==2 else current_support
                    can_seed=bool(supported_rows.shape==(len(candidate.point_indices),) and
                        np.isin(core,candidate.point_indices[supported_rows]).any())
                if self.config.observable_instance_seeding:
                    # Existing-ID matching uses real current support even when
                    # the partial view is too weak to originate another ID.
                    description['has_current_support']=can_seed
                    evidence=instance_seed_evidence(frame,candidate,core,
                        np.mean([s.normal_L for s in model.segments],axis=0) if model is not None else None,
                        self.config,terrain_context)
                    can_seed &= evidence['seed_allowed']
                    seed_reports[i]=evidence
                description['can_seed']=can_seed
                if layout_axis_W is not None:
                    stations=points@layout_axis_W
                    description.update(layout_axis_W=layout_axis_W,
                        layout_station_range_W=[float(stations.min()),float(stations.max())])
                qualified.append(description)
                ownership_points.append(points)
                indices.append(i)
            display_assignments=[dict(display_id=None,display_anchor_W=d['points'].mean(axis=0),
                display_observations=0,display_first_seen=frame.ref_time_s,display_event='role_unresolved',
                display_layout_support_W=np.empty((0,3))) for d in descriptions]
            links=[]
            if self.config.current_instance_reconciliation:
                by_id={layers.candidates[index].candidate_id:i for i,index in enumerate(indices)}
                for link in layers.diagnostics.get('current_ownership_links',()):
                    pair=link.get('candidate_ids',())
                    if (link.get('evidence')=='qualified_current_shared_geometry' and len(pair)==2 and
                            all(key in by_id for key in pair) and pair[0]!=pair[1]):
                        links.append((by_id[pair[0]],by_id[pair[1]]))
            history_W = [dict(instance,points_W=instance['points_L']@pose.T_WL[:3,:3].T+pose.T_WL[:3,3])
                         for instance in history_instances] if self.config.qualified_history_reconciliation else []
            qualified_history_W = [instance for instance in history_W if instance.get('state')=='qualified']
            raw_kwargs = {'raw_identity_instances':history_W} if self.config.raw_history_identity_support else {}
            for i,item in zip(indices,self._associate_display(qualified,frame.ref_time_s,links,ownership_points,
                                                             history_instances=qualified_history_W,**raw_kwargs)):
                display_assignments[i]=item
        else:
            display_assignments = self._associate_display(descriptions,frame.ref_time_s)
        candidates = []
        # Association has finalized every region for this call. Several
        # fragments may share it, but the fit must never survive to next scan.
        region_variances={}
        for index, (candidate, description) in enumerate(zip(layers.candidates, descriptions)):
            parents = possible[index]
            unique = len(parents) == 1 and len(reverse[parents[0]]) == 1
            if unique:
                parent = old[parents[0]]
                description.update(id=parent['id'], observations=parent['observations']+1,
                                   first_seen=parent['first_seen'])
                event = 'matched'
            else:
                description.update(id='S%d' % self.next_id, observations=1, first_seen=frame.ref_time_s)
                self.next_id += 1
                event = 'ambiguous' if parents else 'new'
            description.update(display_assignments[index])
            anchor_L = (description['display_anchor_W']-pose.T_WL[:3,3])@pose.T_WL[:3,:3]
            layout_support_W = description.get('display_layout_support_W', np.empty((0,3)))
            layout_support_L = (layout_support_W-pose.T_WL[:3,3])@pose.T_WL[:3,:3]
            self.tracks[description['id']] = description
            candidates.append(replace(candidate, diagnostics=dict(candidate.diagnostics,
                surface_id=description['id'], surface_observations=description['observations'],
                surface_association=event, surface_first_seen_s=description['first_seen'],
                surface_bounds_W=[description['lower'].tolist(), description['upper'].tolist()],
                display_id=description['display_id'],display_anchor_L=anchor_L.tolist(),
                display_layout_support_L=layout_support_L,
                display_slot_reserved=description['display_id'] in self.selected_display_ids,
                display_observations=description['display_observations'],display_association=description['display_event'])))
            if self.config.qualified_instance_ownership:
                region=self.display_regions.get(description['display_id'])
                spatial_points=region['points'] if region is not None else description['points']
                region_id=description['display_id']
                if region is not None and region_id in region_variances:
                    variances=region_variances[region_id]
                else:
                    variances=(np.maximum(0.,np.linalg.eigvalsh(np.cov(spatial_points,rowvar=False))).tolist()
                               if len(spatial_points)>=3 else [0.,0.,0.])
                    if region is not None:
                        region_variances[region_id]=variances
                candidates[-1]=replace(candidates[-1],diagnostics=dict(candidates[-1].diagnostics,
                    object_id=description['display_id'],object_association=description['display_event'],
                    object_identity_reconciled=bool(region and region.get('current_relation_confirmed')),
                    object_spatial_variances=variances.copy(),
                    object_identity_semantics='qualified compensated local proposal; not equipment type or GPS identity'))
                if description.get('proposed_display_id') is not None:
                    candidates[-1]=replace(candidates[-1],diagnostics=dict(candidates[-1].diagnostics,
                        proposed_object_id=description['proposed_display_id']))
                if self.config.observable_instance_seeding and index in seed_reports:
                    candidates[-1]=replace(candidates[-1],diagnostics=dict(candidates[-1].diagnostics,
                        instance_seed_evidence=seed_reports[index]))
        extra={}
        if self.config.current_instance_reconciliation:
            extra['current_reconciled_region_groups']=self.last_reconciliation_count
            if self.config.complete_current_reconciliation:
                extra['current_closure_evidence']=self.last_current_closure_diagnostics
        if self.config.qualified_history_reconciliation:
            extra['qualified_history_instances']=sum(instance.get('state')=='qualified' for instance in history_instances)
            extra['history_reconciled_region_groups']=self.last_history_reconciliation_count
        if self.config.raw_history_identity_support:
            extra['raw_history_identity_instances']=len(history_instances)
            extra['raw_history_identity_matches']=self.last_raw_identity_match_count
        if self.config.observable_instance_seeding and self.config.qualified_instance_ownership:
            extra['instance_seeding_evidence']={reason:sum(r['reason']==reason for r in seed_reports.values())
                for reason in sorted({r['reason'] for r in seed_reports.values()})}
        return replace(layers, candidates=tuple(candidates), diagnostics=dict(layers.diagnostics,
            surface_association='experimental_pose_compensated', tracked_surface_count=len(self.tracks),**extra))


def _lower_terrain_mask(points, normal, offset, config, representatives,
                        cell_inverse, tree, context_noise_band, diagnostics):
    """Confirm separately supported lower terrain, not all below-track points.

    The rail reference stays unchanged. Local planes discover a lower surface;
    broad 2-D support and the surrounding lower envelope establish terrain.
    Small isolated horizontal parts and lids above nearby terrain stay objects.
    Original returns are checked against a measured plane/noise band individually.
    """
    mask=np.zeros(len(points),dtype=bool)
    lower_cells=np.unique(cell_inverse[points@normal-offset < -config.ground_seed_band_m])
    if len(lower_cells)<20 or len(representatives)<20:
        return mask
    distances,neighbors=tree.query(representatives[lower_cells],k=20)
    patches=representatives[neighbors]
    centers=patches.mean(axis=1)
    centered=patches-centers[:,None,:]
    values,vectors=np.linalg.eigh(np.einsum('nki,nkj->nij',centered,centered)/20.)
    normals=vectors[:,:,0]
    local=(values[:,0]<=.06*np.maximum(values[:,1],1e-12)) & (values[:,1]>1e-7)
    local &= (np.abs(normals@normal)>=.94) & (distances[:,-1]<=.45)
    local &= (np.abs(np.einsum('ni,ni->n',representatives[lower_cells]-centers,normals))
              <=config.ground_max_confirmation_band_m)
    cells=lower_cells[local]
    normals=normals[local]
    centers=centers[local]
    signed=np.einsum('nki,ni->nk',centered[local],normals)
    sigma=1.4826*np.median(np.abs(signed-np.median(signed,axis=1)[:,None]),axis=1)
    local_bands=np.minimum(config.ground_max_confirmation_band_m,
        np.maximum(config.ground_numerical_band_m,config.ground_noise_sigma_factor*sigma))
    if len(cells)<20:
        return mask
    surface=representatives[cells]
    links=cKDTree(surface).query_pairs(.35,output_type='ndarray')
    delta=surface[links[:,1]]-surface[links[:,0]]
    # Do not bridge a height step or a lid simply because its XY overlaps.
    consistent=(np.abs(np.einsum('ni,ni->n',delta,normals[links[:,0]]))
                <=local_bands[links[:,0]])
    consistent &= (np.abs(np.einsum('ni,ni->n',delta,normals[links[:,1]]))
                   <=local_bands[links[:,1]])
    links=links[consistent]
    graph=coo_matrix((np.ones(len(links),dtype=bool),(links[:,0],links[:,1])),
                     shape=(len(cells),len(cells))).tocsr()
    _,labels=connected_components(graph,directed=False)
    projected=surface-(surface@normal)[:,None]*normal
    context_points=representatives-(representatives@normal)[:,None]*normal
    regions=[]
    rejected_context=[]
    confirmed=0
    for label in np.unique(labels):
        members=np.flatnonzero(labels==label)
        if len(members)<20:
            continue
        patch=surface[members]
        covariance=np.cov(patch.T,bias=True)
        eigenvalues,eigenvectors=np.linalg.eigh(covariance)
        # Two independent directions of observed terrain, equivalent to a
        # uniformly sampled ~.6 m extent; not an object-height cutoff.
        if eigenvalues[1]<.6**2/12.:
            continue
        candidate_normal=eigenvectors[:,0]
        if abs(candidate_normal@normal)<.94:
            continue
        # A lower horizontal object can still have a wide lid. If another
        # supported local surface is lower in its immediate XY neighborhood,
        # this is not a terrain lower-envelope confirmation. Keep it intact.
        # Contrary lower returns need not themselves have a clean planar fit:
        # rough ballast or sparse visible ground still disproves a lid being
        # the local lower envelope. Test independent native cells against the
        # nearest local patch, so terrain curvature is not a fake height step.
        context_distance,nearest=cKDTree(projected[members]).query(context_points,k=1)
        other_surface=np.flatnonzero(context_distance<=.45)
        other_surface=other_surface[~np.isin(other_surface,cells[members])]
        nearest=members[nearest[other_surface]]
        below=np.einsum('ni,ni->n',representatives[other_surface]-centers[nearest],normals[nearest])
        # PCA normals have arbitrary signs; orient the comparison along up.
        below*=np.sign(normals[nearest]@normal)
        # A very clean subset may understate the scan's measured noise. Compare
        # two surfaces with both uncertainties, rather than using that subset
        # to turn ordinary rough returns into a spurious terrain/lid step.
        lower=below < -2.*np.maximum(local_bands[nearest],context_noise_band)
        # Three nearby returns on one scan row cannot establish a different
        # lower terrain sheet. Require genuinely 2-D independent context, not
        # a single sparse/noisy scan strip vetoing an entire broad ground patch.
        lower_variance=(float(np.linalg.eigvalsh(np.cov(context_points[other_surface[lower]].T,bias=True))[1])
                        if lower.sum()>=3 else 0.)
        if lower_variance>=.1**2/12.:
            patch_xy=patch@eigenvectors[:,1:]
            lower_xy=representatives[other_surface[lower]]@eigenvectors[:,1:]
            # A tiny corner depression is compatible with broad uneven terrain,
            # not proof that the entire terrain sheet is a raised object lid.
            # Contrary lower support must cover a meaningful fraction of both
            # footprint directions. This is contextual evidence, not a shape
            # or minimum-height requirement imposed on measurement candidates.
            if np.any(np.ptp(lower_xy,axis=0)<.25*np.ptp(patch_xy,axis=0)):
                regions.append(members)
                confirmed+=1
                continue
            rejected_context.append(dict(region_cells=len(members),context_cells=len(below),
                lower_cells=int(lower.sum()),below_min_m=float(below.min()),
                below_median_m=float(np.median(below)),lower_plane_variance_m2=lower_variance,
                patch_bounds_2d=[patch_xy.min(axis=0).tolist(),patch_xy.max(axis=0).tolist()],
                lower_bounds_2d=[lower_xy.min(axis=0).tolist(),lower_xy.max(axis=0).tolist()]))
            continue
        regions.append(members)
        confirmed+=1
    for members in regions:
        # Extend to local boundary cells whose neighborhood was mixed with a
        # raised object. Three actual terrain cells AND pointwise residual are
        # needed; proximity alone or shared voxel membership never suffices.
        patch=surface[members]
        region_tree=cKDTree(patch)
        fit_distance,fit_neighbors=region_tree.query(patch,k=min(20,len(patch)))
        fitting=patch[fit_neighbors]
        fit_centers=fitting.mean(axis=1)
        centered=fitting-fit_centers[:,None,:]
        values,vectors=np.linalg.eigh(np.einsum('nki,nkj->nij',centered,centered)/fitting.shape[1])
        fit_normals=vectors[:,:,0]
        planar=(values[:,0]<=.06*np.maximum(values[:,1],1e-12)) & (values[:,1]>1e-7)
        planar &= (np.abs(fit_normals@normal)>=.94) & (fit_distance[:,-1]<=.45)
        signed=np.einsum('nki,ni->nk',centered,fit_normals)
        sigma=1.4826*np.median(np.abs(signed-np.median(signed,axis=1)[:,None]),axis=1)
        bands=np.minimum(config.ground_max_confirmation_band_m,
            np.maximum(config.ground_numerical_band_m,config.ground_noise_sigma_factor*sigma))
        # Fit confirmation patches from the region's actual cells, not mixed
        # object/ground neighborhoods used only to discover the region.
        distance,neighbors=region_tree.query(points,k=3)
        indices=np.flatnonzero(distance[:,-1]<=.45)
        nearby=neighbors[indices]
        residual=np.abs(np.einsum('nki,nki->nk',points[indices,None,:]-fit_centers[nearby],fit_normals[nearby]))
        mask[indices[((residual<=bands[nearby])&planar[nearby]).sum(axis=1)>=2]]=True
    diagnostics.update(lower_terrain_regions=confirmed,lower_terrain_points=int(mask.sum()),
        lower_context_rejections=rejected_context,
        lower_terrain_semantics='local lower-envelope planar terrain; native point residual confirmation')
    return mask


def _ground_mask(points, plane, config, diagnostics):
    ground = np.zeros(len(points), dtype=bool)
    if not plane or len(points) < 3:
        return ground
    normal = np.asarray(plane['normal_L'], dtype=float)
    if normal.shape != (3,) or not np.isfinite(normal).all():
        raise ValueError('invalid ground normal')
    normal /= np.linalg.norm(normal)
    offset = float(plane['offset_m'])
    seed = points[np.abs(points@normal-offset) <= config.ground_seed_band_m]
    if len(seed) >= 12:
        # Refine a slightly biased global seed robustly. Being inside the
        # proposal band never establishes membership in the ground surface.
        axis = int(np.argmax(np.abs(normal)))
        others = [i for i in range(3) if i != axis]
        design = np.column_stack([seed[:, others], np.ones(len(seed))])
        target = seed[:, axis]
        parameters = np.r_[-normal[others]/normal[axis], offset/normal[axis]]
        for _ in range(5):
            residual = target-design@parameters
            weights = np.minimum(1., .006/np.maximum(np.abs(residual), 1e-9))
            parameters = np.linalg.lstsq(design*weights[:, None], target*weights, rcond=None)[0]
        refined = np.zeros(3)
        refined[axis] = 1.
        refined[others] = -parameters[:2]
        sign = 1. if refined@normal >= 0 else -1.
        scale = np.linalg.norm(refined)
        candidate_normal = sign*refined/scale
        if candidate_normal@normal >= .94:
            normal = candidate_normal
            offset = sign*float(parameters[2])/scale
    if len(seed) < 3:
        diagnostics['reason'] = 'insufficient_ground_seed'
        return ground
    signed_seed = seed@normal-offset
    sigma = 1.4826*float(np.median(np.abs(signed_seed-np.median(signed_seed))))
    band = min(config.ground_max_confirmation_band_m,
               max(config.ground_numerical_band_m, config.ground_noise_sigma_factor*sigma))
    diagnostics.update(seed_residual_sigma_m=sigma, confirmation_band_m=band,
                       confirmation='local planar residual with measured seed noise; not a height deletion gate')
    residual = np.abs(points@normal-offset)
    eligible = np.flatnonzero(residual <= config.ground_seed_band_m)
    if not len(eligible):
        return ground
    # A return merely near a plane is not enough: its local surface must be
    # locally planar with a ground-facing normal. Sparse low bases survive.
    representative_indices, cell_inverse = voxel_representatives(points,.05)
    representatives = points[representative_indices]
    if len(representatives) < 3:
        diagnostics['reason'] = 'insufficient_independent_planar_geometry'
        return ground  # No independent planar geometry; retain as ambiguous.
    tree = cKDTree(representatives)
    # Many native returns occupy the same local surface cell. Fit its local
    # plane once, then evaluate EVERY original eligible return against it.
    # This reduces redundant covariance/eigen fits, not native boundary data.
    patch_cells, patch_inverse = np.unique(cell_inverse[eligible],return_inverse=True)
    distances, neighbors = tree.query(representatives[patch_cells], k=min(20,len(representatives)))
    patches = representatives[neighbors]
    centers = patches.mean(axis=1)
    centered = patches-patches.mean(axis=1, keepdims=True)
    covariance = np.einsum('nki,nkj->nij', centered, centered)/patches.shape[1]
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)
    normals = eigenvectors[:, :, 0]
    planar = eigenvalues[:, 0] <= .06*np.maximum(eigenvalues[:, 1], 1e-12)
    spans_plane = eigenvalues[:, 1] > 1e-7
    aligned = np.abs(normals@normal) >= .94
    local = distances[:, -1] <= .45
    surface_residual = np.abs(np.einsum('ni,ni->n',points[eligible]-centers[patch_inverse],normals[patch_inverse]))
    surface = (planar & spans_plane & aligned & local)[patch_inverse] & (surface_residual <= band)
    ground[eligible[surface & (residual[eligible] <= band)]] = True
    for _ in range(12):
        # Propagate along the confirmed local surface, not across a height
        # discontinuity. A shallow return must also satisfy the measured local
        # noise band; proximity to many ground neighbors is not membership.
        # Curvature may leave the global seed plane, but not the local surface.
        support = (ground[representative_indices[neighbors]].sum(axis=1) >= 3)[patch_inverse]
        additional = eligible[surface & support & ~ground[eligible]]
        if not len(additional):
            break
        ground[additional] = True
    ground |= _lower_terrain_mask(points,normal,offset,config,representatives,
                                   cell_inverse,tree,band,diagnostics)
    return ground


def _rail_mask(points, model):
    mask = np.zeros(len(points), dtype=bool)
    if model is None:
        return mask
    for segment in model.segments:
        for endpoints in (segment.left_endpoints_L, segment.right_endpoints_L):
            a, b = np.asarray(endpoints)
            vector = b-a
            length2 = float(vector@vector)
            if length2 <= 1e-12:
                continue
            fraction = (points-a)@vector/length2
            feet = a+np.clip(fraction, 0., 1.)[:, None]*vector
            mask |= ((fraction >= 0.) & (fraction <= 1.) &
                     (np.linalg.norm(points-feet, axis=1) <= .035))
    return mask


def _rail_profile_roles(points, model, noise_band=0., config=None):
    """Confirm repeated observed web/foot cells, never a whole rail-input strip.

    Coordinates follow each finite local rail segment and its measured ground
    normal. Every profile observation is from THIS cloud; historical source
    indices are deliberately not consulted. Sparse/unrepeated cells remain
    unknown, not a confident equipment or an automatically deleted rail.
    """
    confirmed = np.zeros(len(points), dtype=bool)
    unknown = np.zeros(len(points), dtype=bool)
    diagnostics = dict(method='current_repeated_rail_cross_sections',
                       confirmed_points=0, unknown_points=0, profile_cells=0,
                       uncertainty_margin_m=float(noise_band))
    if model is None or not len(points):
        return confirmed, unknown, diagnostics
    context = config is not None and config.track_structure_context
    diagnostics['structure_context_enabled'] = context
    diagnostics['extended_unknown_points'] = 0
    radii = (config.neighbor_base_m+config.neighbor_angle_rad*np.linalg.norm(points,axis=1)
             if context else np.zeros(len(points)))
    plane = model.diagnostics.get('ground_plane')
    if not plane:
        diagnostics['reason'] = 'ground_reference_unavailable'
        return confirmed, unknown, diagnostics
    ground_normal = np.asarray(plane['normal_L'], dtype=float)
    ground_normal /= np.linalg.norm(ground_normal)
    floor_height = points@ground_normal-float(plane['offset_m'])
    # Both rail sides use the same finite centreline station. Reuse only
    # within this call; rail-specific feet, residuals and ties stay unchanged.
    # Two side-local proposal buffers bound memory independently of the
    # segment count; never retain an N-points array for every segment.
    attributes=('left_endpoints_L','right_endpoints_L')
    profiles={attribute:(np.full((len(points),2),np.nan),
                         np.full(len(points),np.nan),np.full(len(points),np.inf))
              for attribute in attributes}
    for segment in model.segments:
        tangent = np.asarray(segment.end_L)-segment.start_L
        length = float(np.linalg.norm(tangent))
        if length <= 1e-9:
            continue
        tangent /= length
        along = (points-segment.start_L)@tangent
        for attribute in attributes:
            delta,station,best=profiles[attribute]
            a, b = np.asarray(getattr(segment, attribute))
            # Use the same finite support as clearance projection. A lower
            # web return on a sloped rail must not fall through a rail-tangent
            # gap while its centerline station is actually supported.
            feet = a+(np.clip(along, 0., length)/length)[:, None]*(b-a)
            displacement = points-feet
            lateral = displacement@segment.across_L
            height = displacement@segment.normal_L
            # A proposal envelope, NOT membership. Targets above the observed
            # head and beside the narrow rail cross-section are never erased.
            eligible = ((along >= 0.) & (along <= length) &
                        (np.abs(lateral) <= .075) &
                        (height <= .035+np.maximum(noise_band,2.*radii)) &
                        (floor_height > .005))
            take = eligible & (np.abs(lateral) < best)
            best[take] = np.abs(lateral[take])
            delta[take] = np.column_stack((lateral[take], height[take]))
            station[take] = segment.station_start_m+along[take]
    for attribute in attributes:
        delta,station,unused=profiles[attribute]
        indices = np.flatnonzero(np.isfinite(station))
        if not len(indices):
            continue
        # Counts use distinct longitudinal cells, not the number of dense
        # duplicate returns. A local isolated protrusion cannot teach a profile.
        section = np.rint(delta[indices]/.015).astype(np.int64)
        longitudinal = np.floor(station[indices]/.12).astype(np.int64)
        cells, inverse = np.unique(section, axis=0, return_inverse=True)
        occupancy = np.unique(np.column_stack((inverse, longitudinal)), axis=0)
        counts = np.bincount(occupancy[:, 0], minlength=len(cells))
        low = np.full(len(cells), np.iinfo(np.int64).max, dtype=np.int64)
        high = np.full(len(cells), np.iinfo(np.int64).min, dtype=np.int64)
        np.minimum.at(low, occupancy[:, 0], occupancy[:, 1])
        np.maximum.at(high, occupancy[:, 0], occupancy[:, 1])
        repeated = (counts >= 3) & (high-low >= 2)
        # Noise can widen uncertainty, never widen confirmed rail membership.
        strict = delta[indices,1] <= .035+noise_band
        confirmation_repeated=repeated
        if context:
            # Unknown search observations must not teach a confirmed profile,
            # even when quantization puts them in the same section cell.
            occupancy=np.unique(np.column_stack((inverse[strict],longitudinal[strict])),axis=0)
            count=np.bincount(occupancy[:,0],minlength=len(cells))
            low=np.full(len(cells),np.iinfo(np.int64).max,dtype=np.int64)
            high=np.full(len(cells),np.iinfo(np.int64).min,dtype=np.int64)
            np.minimum.at(low,occupancy[:,0],occupancy[:,1])
            np.maximum.at(high,occupancy[:,0],occupancy[:,1])
            confirmation_repeated=(count>=3)&(high-low>=2)
        is_rail = confirmation_repeated[inverse] & (delta[indices,1] <= .035)
        confirmed[indices[is_rail]] = True
        extension = np.zeros(len(indices),dtype=bool)
        if context and is_rail.any():
            # Expanded search is uncertainty only, NEVER expanded rail
            # membership. An extension needs both repeated longitudinal cells
            # and a cross-section connection to a confirmed observed profile.
            # An isolated 5cm target is not classified by height/proximity.
            profile = np.unique(section[is_rail],axis=0)*.015
            distance = cKDTree(profile).query(delta[indices],k=1)[0]
            extension = ~strict & repeated[inverse] & (distance <= 2.*radii[indices])
            diagnostics['extended_unknown_points'] += int(extension.sum())
        unknown[indices[~is_rail & (strict | extension)]] = True
        diagnostics['profile_cells'] += int(len(np.unique(inverse[is_rail])))
    unknown &= ~confirmed
    diagnostics.update(confirmed_points=int(confirmed.sum()), unknown_points=int(unknown.sum()),
        semantics='observed rail-profile role only; not equipment classification or a minimum clearance gate')
    return confirmed, unknown, diagnostics


def _components(points, source_indices, frame, config):
    if not len(points):
        return ()
    radii = config.neighbor_base_m+config.neighbor_angle_rad*np.linalg.norm(points, axis=1)
    tree = cKDTree(points)
    # Connectivity and boundary support have different budgets. A k-nearest
    # graph of native returns misses adjacent scan rows when all k neighbors
    # are on the same very dense row. Small voxels are connectivity vertices
    # only; every native return remains in its component and in measurement.
    voxel = config.neighbor_base_m/np.sqrt(3.)
    representative_indices, inverse = voxel_representatives(points,voxel)
    representatives = points[representative_indices]
    representative_radii = radii[representative_indices]
    links = cKDTree(representatives).query_pairs(float(representative_radii.max()),output_type='ndarray')
    distances = np.linalg.norm(representatives[links[:,0]]-representatives[links[:,1]],axis=1)
    links = links[distances <= np.minimum(representative_radii[links[:,0]],representative_radii[links[:,1]])]
    graph = coo_matrix((np.ones(len(links),dtype=bool),
                       (links[:,0],links[:,1])),
                      shape=(len(representative_indices),len(representative_indices))).tocsr()
    _, representative_labels = connected_components(graph, directed=False)
    labels = representative_labels[inverse]
    # Representatives establish only a subset of valid native connections.
    # Check every potentially adjoining provisional component against actual
    # native boundary returns. Internal dense-cell pairs are already connected
    # and need not be materialized (quadratic memory for repeated dense returns).
    provisional_order = np.argsort(labels,kind='stable')
    groups = np.split(provisional_order,np.flatnonzero(np.diff(labels[provisional_order]))+1)
    if len(groups) > 1:
        lower = np.array([points[g].min(axis=0) for g in groups])
        upper = np.array([points[g].max(axis=0) for g in groups])
        maximum = np.array([radii[g].max() for g in groups])
        spatial_order = np.argsort(lower[:,0],kind='stable')
        starts = lower[spatial_order,0]
        parents = list(range(len(groups)))
        group_trees = {}
        def root(i):
            while parents[i] != i:
                parents[i] = parents[parents[i]]
                i = parents[i]
            return i
        for position,i in enumerate(spatial_order):
            end = np.searchsorted(starts,upper[i,0]+maximum[i],side='right')
            other = spatial_order[position+1:end]
            gaps = np.maximum(0.,np.maximum(lower[i]-upper[other],lower[other]-upper[i]))
            other = other[np.linalg.norm(gaps,axis=1) <= np.minimum(maximum[i],maximum[other])]
            for j in other:
                if root(int(i)) == root(int(j)):
                    continue
                a,b = groups[i],groups[j]
                # Only actual returns close to the other component's box can
                # provide a bridge. This broad phase never confirms membership.
                gap_a = np.maximum(0.,np.maximum(lower[j]-points[a],points[a]-upper[j]))
                a = a[np.linalg.norm(gap_a,axis=1) <= np.minimum(radii[a],maximum[j])]
                if not len(a):
                    continue
                if j not in group_trees:
                    group_trees[j] = cKDTree(points[b])
                matches = group_trees[j].query_ball_point(points[a],np.minimum(radii[a],maximum[j]))
                bridge = False
                for k,neighbors in zip(a,matches):
                    if len(neighbors):
                        native = b[np.asarray(neighbors,dtype=np.int64)]
                        if np.any(np.linalg.norm(points[native]-points[k],axis=1) <= np.minimum(radii[k],radii[native])):
                            bridge = True
                            break
                if bridge:
                    ra,rb = root(int(i)),root(int(j))
                    parents[max(ra,rb)] = min(ra,rb)
        roots = np.array([root(i) for i in range(len(groups))])
        _, final_labels = np.unique(roots,return_inverse=True)
        labels = final_labels[labels]
    nearest_distances, nearest_indices = tree.query(points, k=min(4, len(points)))
    if len(points) == 1:
        nearest_distances = nearest_distances[:, None]
        nearest_indices = nearest_indices[:, None]
    # Keep the native-index neighbor table in arrays. Only each actually
    # selected nearest return materializes PointRefs, not every object point.
    neighbor_valid = ((nearest_distances > 1e-7)&
        (nearest_distances <= np.minimum(radii[:,None],radii[nearest_indices]))&
        (labels[:,None] == labels[nearest_indices]))
    supported_rows = neighbor_valid.any(axis=1)
    order = np.argsort(labels, kind='stable')
    boundaries = np.flatnonzero(np.diff(labels[order]))+1
    candidates = []
    for local in np.split(order, boundaries):
        indices = source_indices[local]
        supported = indices[supported_rows[local]]
        candidates.append(Candidate(
            'frame%d-component%d' % (frame.sequence, int(labels[local[0]])), indices.copy(),
            supported, frame.ref_time_s, frame.ref_time_s,
            {'type': 'trackside_object',
             'support_neighbor_indices':source_indices[nearest_indices[local]],
             'support_neighbor_valid':neighbor_valid[local],
             'flags': () if len(supported) else ('low_support',)}))
    return tuple(candidates)


def extract_scene(frame, track, history, config):
    """Keep every unconfirmed return in the ROI, including singletons.

    Current-frame geometric support is separated from temporal support. History
    is not concatenated without an explicit pose transform.
    """
    validate_frame(frame)
    finite = np.isfinite(frame.xyz_L).all(axis=1)
    valid = finite & (np.linalg.norm(np.where(finite[:, None], frame.xyz_L, 0.), axis=1) > 1e-9)
    model = measurement_model(track)
    if model is not None:
        roi_indices = corridor_indices(frame, model, config)
        roi_source = 'track_corridor'
    else:
        ranges = np.linalg.norm(np.where(finite[:, None], frame.xyz_L, 0.), axis=1)
        roi_indices = np.flatnonzero(valid & (ranges >= config.preview_radius_m[0]) &
                                    (ranges <= config.preview_radius_m[1]))
        roi_source = 'sensor_preview'
    points = frame.xyz_L[roi_indices]
    plane = model.diagnostics.get('ground_plane') if model is not None else None
    ground_diagnostics = {}
    ground = _ground_mask(points, plane, config, ground_diagnostics)
    noise_band = min(config.ground_max_confirmation_band_m,
                     ground_diagnostics.get('confirmation_band_m', config.ground_numerical_band_m))
    rail_unknown = np.zeros(len(points), dtype=bool)
    rail_diagnostics = {}
    if config.rail_profile_roles:
        rail_points, rail_unknown, rail_diagnostics = _rail_profile_roles(points, model, noise_band, config)
        rails = rail_points & ~ground
    else:
        rails = _rail_mask(points, model) & ~ground
    body = np.zeros(len(points), dtype=bool)
    for lower, upper in config.confirmed_body_boxes:
        body |= ((points >= np.asarray(lower)) & (points <= np.asarray(upper))).all(axis=1)
    objects = ~ground & ~rails & ~body
    indices = {'roi': roi_indices, 'ground': roi_indices[ground], 'rails': roi_indices[rails],
               'body': roi_indices[body], 'object': roi_indices[objects],
               'invalid': np.flatnonzero(~valid), 'outside_roi': np.flatnonzero(valid &
                   ~np.isin(np.arange(len(valid)), roi_indices))}
    # Near-ground, not-confirmed points stay visible in the candidate channel.
    indices['ambiguous'] = (roi_indices[objects &
        (np.abs(points@np.asarray(plane['normal_L'])-plane['offset_m']) < config.ground_seed_band_m)]
        if plane else np.empty(0, dtype=np.int64))
    indices['unknown_track_structure'] = roi_indices[objects & rail_unknown]
    indices['ambiguous'] = np.union1d(indices['ambiguous'], indices['unknown_track_structure'])
    unknown_ground = np.zeros(len(points), dtype=bool)
    if config.rail_profile_roles and plane:
        normal = np.asarray(plane['normal_L'], dtype=float)
        normal /= np.linalg.norm(normal)
        signed_height = points@normal-float(plane['offset_m'])
        # A noise-sized crossing of the proposal boundary is not evidence of
        # an independent object. Keep it unknown rather than promote it.
        unknown_ground = (objects & (signed_height >= -config.ground_seed_band_m-noise_band) &
                          (signed_height <= noise_band))
    indices['unknown_ground_structure'] = roi_indices[unknown_ground]
    indices['ambiguous'] = np.union1d(indices['ambiguous'], indices['unknown_ground_structure'])
    measurement_objects = objects.copy()
    scope_uncertain=np.zeros(len(points),dtype=bool)
    scope_band=0.
    if config.above_rail_measurement_only and model is not None:
        projection = project_supported(points, model)
        above = np.isfinite(projection.height_m) & (projection.height_m > 1e-9)
        indices['below_rail_scope'] = roi_indices[objects & ~above]
        measurement_objects &= above
        indices['measurement_object'] = roi_indices[measurement_objects]
        if config.above_rail_uncertainty:
            # Use the existing current measured noise scale, not a fixed
            # equipment minimum height or a calibrated confidence interval.
            # These positive-height native returns remain measurements; their
            # ABOVE-scope membership is unresolved and cannot seed an asset.
            scope_band=noise_band
            scope_uncertain=objects & above & (projection.height_m<=scope_band)
            indices['uncertain_rail_scope']=roi_indices[scope_uncertain]
            indices['ambiguous']=np.union1d(indices['ambiguous'],indices['uncertain_rail_scope'])
        # Ground/rail/object display and the full source coordinates are intact.
        # A missing track cannot manufacture a horizontal height cut.
    # Preserve BOTH original sets as candidates, but do not let unresolved
    # on-ground returns bridge into a real positive-height low object.
    unknown_track = objects & rail_unknown & ~unknown_ground if config.track_structure_context else np.zeros(len(points),dtype=bool)
    candidates = _components(points[measurement_objects & ~unknown_ground & ~unknown_track],
                             roi_indices[measurement_objects & ~unknown_ground & ~unknown_track], frame, config)
    candidates += tuple(replace(c,candidate_id=c.candidate_id+'-unknown-track',
        diagnostics=dict(c.diagnostics,point_role='unknown_track')) for c in
        _components(points[unknown_track & measurement_objects],roi_indices[unknown_track & measurement_objects],frame,config))
    candidates += tuple(replace(c, candidate_id=c.candidate_id+'-unknown-ground',
        diagnostics=dict(c.diagnostics, point_role='unknown_ground')) for c in
        _components(points[unknown_ground & measurement_objects], roi_indices[unknown_ground & measurement_objects], frame, config))
    historical_points, historical_refs = [], []
    for past in history:
        if (past.session_id != frame.session_id or past.clock_id != frame.clock_id or
                past.motion_status != 'compensated_history' or
                past.diagnostics.get('aligned_to_ref_time_s') != frame.ref_time_s or
                past.ref_time_s != frame.ref_time_s):
            continue
        mask = np.array([r.frame < frame.sequence and r.time_s is not None and
                         0. <= frame.scan_span_s[1]-r.time_s <= config.history_seconds+.1+1e-9
                         for r in past.refs],dtype=bool)
        mask &= np.isfinite(past.xyz_L).all(axis=1)
        mask &= np.linalg.norm(np.where(mask[:,None],past.xyz_L,0.),axis=1)>1e-9
        if mask.any():
            historical_points.append(past.xyz_L[mask])
            historical_refs.extend(past.refs[int(i)] for i in np.flatnonzero(mask))
    temporal = np.full(len(frame.xyz_L),-1,dtype=np.int64)
    if historical_points and objects.any():
        historical_points = np.concatenate(historical_points)
        tree = cKDTree(historical_points)
        d,k = tree.query(points[objects],k=1)
        radii = config.neighbor_base_m+config.neighbor_angle_rad*np.linalg.norm(points[objects],axis=1)
        matched = d <= radii
        temporal[roi_indices[objects][matched]] = k[matched]
    enriched = []
    ambiguous_mask = np.zeros(len(frame.xyz_L),dtype=bool)
    ambiguous_mask[indices['ambiguous']] = True
    scope_uncertain_mask=None
    if config.above_rail_uncertainty:
        scope_uncertain_mask=np.zeros(len(frame.xyz_L),dtype=bool)
        scope_uncertain_mask[roi_indices[scope_uncertain]]=True
    for candidate in candidates:
        old_indices = temporal[candidate.point_indices]
        evidence_indices = candidate.point_indices[old_indices >= 0]
        old_indices = old_indices[old_indices >= 0]
        evidence = TemporalSupport(evidence_indices,old_indices,historical_refs)
        ambiguous = candidate.point_indices[ambiguous_mask[candidate.point_indices]]
        flags = list(candidate.diagnostics.get('flags',()))
        if len(ambiguous):
            flags.append('ambiguous_surface')
        if evidence:
            flags = [f for f in flags if f != 'low_support']
            flags.append('experimental_temporal_support')
        supported = np.union1d(candidate.supported_indices,evidence_indices)
        times = [historical_refs[int(i)].time_s for i in old_indices]
        scope_details={}
        if scope_uncertain_mask is not None:
            count=int(scope_uncertain_mask[candidate.point_indices].sum())
            if count:
                scope_details=dict(rail_scope_uncertain_count=count,rail_scope_uncertainty_band_m=scope_band)
                if count==len(candidate.point_indices) and candidate.diagnostics.get('point_role') is None:
                    scope_details['point_role']='unknown_rail_scope'
        enriched.append(replace(candidate,supported_indices=supported,
            first_seen_s=min([candidate.first_seen_s]+times),diagnostics=dict(candidate.diagnostics,
            temporal_support_refs=evidence,ambiguous_indices=ambiguous,flags=tuple(flags),**scope_details)))
    candidates = tuple(enriched)
    if config.track_structure_context and unknown_track.any():
        # Splitting uncertain rail roles must not upgrade their orphan residue
        # into a confirmed object just by reducing its ambiguity fraction.
        near=cKDTree(points[unknown_track])
        unknown_radii=config.neighbor_base_m+config.neighbor_angle_rad*np.linalg.norm(points[unknown_track],axis=1)
        enriched=[]
        for candidate in candidates:
            if candidate.diagnostics.get('point_role') in ('unknown_track','unknown_ground'):
                enriched.append(candidate)
                continue
            native=frame.xyz_L[candidate.point_indices]
            distance,nearest=near.query(native,k=1)
            radius=config.neighbor_base_m+config.neighbor_angle_rad*np.linalg.norm(native,axis=1)
            pending=bool(np.any(distance<=np.minimum(radius,unknown_radii[nearest])))
            enriched.append(replace(candidate,diagnostics=dict(candidate.diagnostics,
                structure_split_pending=pending,
                flags=tuple(dict.fromkeys(candidate.diagnostics.get('flags',())+
                            (('competing_track_structure',) if pending else ()))))))
        candidates=tuple(enriched)
    counts = {name: len(values) for name, values in indices.items()}
    counts['raw'] = len(frame.xyz_L)
    counts['components'] = len(candidates)
    diagnostics={'roi_source': roi_source, 'temporal_support_used': bool(np.any(temporal >= 0)),
        'history_scans_supplied': len(history), 'ground_confirmation': ground_diagnostics,
        'rail_roles': rail_diagnostics}
    if config.above_rail_uncertainty:
        diagnostics['rail_scope_uncertainty']=dict(band_m=scope_band,uncertain_points=int(scope_uncertain.sum()),
            source='current_ground_confirmation_noise_scale',
            semantics='unresolved above-rail scope; not a rail/device classifier or a fixed height deletion')
    return SceneLayers(indices,candidates,counts,diagnostics)
