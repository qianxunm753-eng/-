"""Causal adapter for experimental scan poses, never an independent truth source."""
from dataclasses import replace
from pathlib import Path
import json
import hashlib
import numpy as np
from scipy.spatial.transform import Rotation
from .protocol import CloudFrame, PoseSample, validate_frame


def valid_matrix(matrix):
    matrix = np.asarray(matrix,dtype=float)
    return (matrix.shape == (4,4) and np.isfinite(matrix).all() and
            np.allclose(matrix[3],[0,0,0,1],atol=1e-8) and
            np.allclose(matrix[:3,:3].T@matrix[:3,:3],np.eye(3),atol=1e-6) and
            abs(np.linalg.det(matrix[:3,:3])-1.) < 1e-6)


def usable_pose(sample,time_s,clock_id,available_until_s):
    if sample is None or not sample.usable or sample.clock_id != clock_id:
        return False
    lo,hi = sample.coverage_s
    return (np.isfinite([sample.time_s,lo,hi,sample.available_until_s]).all() and
            abs(sample.time_s-time_s) <= 1e-6 and lo-1e-9 <= time_s <= hi+1e-9 and
            sample.available_until_s <= available_until_s+1e-9 and valid_matrix(sample.T_WL))


def pose_map_key(sample):
    if sample is None:
        return None
    return (sample.source,sample.diagnostics.get('clock_epoch',0),
            sample.diagnostics.get('pose_map_id'))


class RecordedPoses:
    def __init__(self, rows, clock_id, map_id=None):
        # Sequence order is the arrival order. Sorting repeated device times
        # mixes pre-reset and post-reset maps, even if their clocks have the
        # same name and their timestamps happen to overlap.
        self.rows = []
        epoch, previous = 0, None
        for row in rows:
            if previous is not None and (row['time'] <= previous['time'] or
                                          row['sequence'] <= previous['sequence']):
                epoch += 1
            self.rows.append(dict(row, epoch=row.get('epoch', epoch)))
            previous = row
        self.clock_id = clock_id
        self.map_id = map_id
        self.by_sequence = {r['sequence']:r for r in self.rows}
        if len(self.by_sequence) != len(self.rows):
            raise ValueError('duplicate pose frame identity; split separate recordings')

    def for_frame(self, frame):
        row = self.by_sequence.get(frame.sequence)
        if (row is None or frame.clock_id != self.clock_id or
                abs(row['time']-frame.ref_time_s) > 1e-6):
            return None
        scoped = RecordedPoses([r for r in self.rows if r['epoch'] == row['epoch'] and
                                 r['sequence'] <= frame.sequence], self.clock_id,self.map_id)
        scoped.source_path = getattr(self, 'source_path', None)
        return scoped

    def _context(self,t,available_until):
        if len({r['epoch'] for r in self.rows}) > 1:
            return None  # An unscoped time alone cannot identify its epoch.
        available = [r for r in self.rows if r['end'] <= available_until+1e-9]
        for row in reversed(available):
            if not row['usable']:
                if row['start']-1e-9 <= t <= row['end']+1e-9:
                    return None
                continue
            if row['start']-1e-9 <= t <= row['end']+1e-9:
                previous = next((p for p in reversed(available) if p['epoch'] == row['epoch'] and
                                 p['sequence'] < row['sequence'] and p['time'] < row['time'] and p['usable']),None)
                return row,previous
        return None

    @staticmethod
    def _interpolate(row,previous,times):
        times = np.asarray(times)
        if previous is None:
            if np.any(np.abs(times-row['time']) > 1e-9):
                return None
            return np.broadcast_to(row['matrix'],(len(times),4,4)).copy()
        fraction = (times-previous['time'])/(row['time']-previous['time'])
        r0 = Rotation.from_matrix(previous['matrix'][:3,:3])
        r1 = Rotation.from_matrix(row['matrix'][:3,:3])
        relative = (r0.inv()*r1).as_rotvec()
        rotations = (r0*Rotation.from_rotvec(fraction[:,None]*relative)).as_matrix()
        matrices = np.broadcast_to(np.eye(4),(len(times),4,4)).copy()
        matrices[:,:3,:3] = rotations
        matrices[:,:3,3] = ((1.-fraction[:,None])*previous['matrix'][:3,3]+fraction[:,None]*row['matrix'][:3,3])
        return matrices

    def sample(self,time_s,available_until_s):
        context = self._context(time_s,available_until_s)
        if context is None:
            return None
        row,previous = context
        matrices = self._interpolate(row,previous,[time_s])
        if matrices is None:
            return None
        return PoseSample(time_s,matrices[0],self.clock_id,(row['start'],row['end']),row['end'],
                          'experimental_pose',True,
                          {'approximation': 'causal observed scan velocity / rotation',
                           'rank':row.get('rank'),'core_step_ms':row.get('core_step_ms'),
                           'clock_epoch':row['epoch'],
                           'pose_map_id':self.map_id,
                           'independent_truth':False,'gyro_bias_calibrated':False})

    def point_matrices(self,frame,times):
        row = self.by_sequence.get(frame.sequence)
        if row is None or not row['usable'] or row['end'] > frame.scan_span_s[1]+1e-9:
            return None
        if np.any(times < row['start']-1e-9) or np.any(times > row['end']+1e-9):
            return None
        previous = next((p for p in reversed(self.rows) if p['epoch'] == row['epoch'] and
                         p['sequence'] < row['sequence'] and p['time'] < row['time'] and
                         p['end'] <= frame.scan_span_s[1]+1e-9 and p['usable']),None)
        return self._interpolate(row,previous,times)


def load_experimental_poses(path,frames):
    content = Path(path).read_bytes()
    document = json.loads(content.decode('utf-8-sig'))
    matrices = {r['frame']:r['matrix'] for r in document['poses']}
    diagnostics = {r['frame']:r for r in document['diagnostics']}
    rows,clock,session = [],None,None
    for frame in frames:
        if clock is None:
            clock,session = frame.clock_id,frame.session_id
        if frame.clock_id != clock or frame.session_id != session:
            raise ValueError('pose input spans different sessions/clocks')
        d = diagnostics.get(frame.sequence,{})
        matrix = np.asarray(matrices.get(frame.sequence,np.full((4,4),np.nan)),dtype=float)
        timestamp = d.get('timestamp')
        matched = timestamp is not None and abs(float(timestamp)-frame.ref_time_s) <= 1e-6
        # Only the first map anchor is allowed to omit rank diagnostics. It
        # cannot deskew that first scan without an observed motion interval.
        anchor = 'rank' not in d and document.get('frame_start')==frame.sequence
        usable = (matched and valid_matrix(matrix) and (d.get('rank')==6 or anchor) and
                  not d.get('insufficient_correspondences',False))
        rows.append({'sequence':frame.sequence,'time':frame.ref_time_s,'start':frame.scan_span_s[0],
                     'end':frame.scan_span_s[1],'matrix':matrix,'usable':usable,'rank':d.get('rank'),
                     'core_step_ms':d.get('core_step_ms')})
    result = RecordedPoses(rows,clock,hashlib.sha256(content).hexdigest())
    result.source_path = str(Path(path).resolve())
    return result


class CausalScanPoses(RecordedPoses):
    """Anchored acceleration hypothesis, checked against an older unused knot.

    No wheel model, IMU or independent pose truth. Rotation retains the
    observed two-knot model; failed/short evidence retains linear translation.
    """
    def __init__(self,rows,clock_id,map_id=None):
        super().__init__(rows,clock_id,map_id)
        self.curves={}

    def for_frame(self,frame):
        scoped=super().for_frame(frame)
        if scoped is None:
            return None
        return CausalScanPoses(scoped.rows,scoped.clock_id,scoped.map_id)

    def _curve(self,row):
        key=row['sequence']
        if key in self.curves:
            return self.curves[key]
        self.curves[key]=None
        rows=[r for r in self.rows if r['epoch']==row['epoch'] and
              r['sequence']<=row['sequence'] and r['end']<=row['end']+1e-9][-4:]
        if len(rows)!=4 or not all(r['usable'] and valid_matrix(r['matrix']) for r in rows):
            return None
        times=np.array([r['time'] for r in rows],dtype=float)
        gaps=np.diff(times)
        if (not np.isfinite(times).all() or np.any(gaps<=1e-6) or
                np.any(gaps>1.+1e-9) or times[-1]-times[0]>3.+1e-9):
            return None
        positions=np.array([r['matrix'][:3,3] for r in rows])
        scale=times[-1]-times[-2]
        offsets=np.array([row['start']-row['time'],row['end']-row['time']],dtype=float)
        if (not np.isfinite(offsets).all() or offsets[0]>0. or offsets[1]<0. or
                np.max(np.abs(offsets))>scale+1e-9):
            return None  # Do not extend a short-knot fit across a long scan.
        u=(times[1:3]-times[-1])/scale
        design=np.column_stack((u,.5*u*u))
        try:
            coefficients=np.linalg.solve(design,positions[1:3]-positions[-1])
        except np.linalg.LinAlgError:
            return None
        velocity,acceleration=coefficients[0]/scale,coefficients[1]/scale**2
        check_offsets=np.r_[offsets,np.clip(-scale*.5,offsets[0],offsets[1])]
        observed_velocity=(positions[-1]-positions[-2])/scale
        correction=(check_offsets[:,None]*(velocity-observed_velocity)+
                    .5*check_offsets[:,None]**2*acceleration)
        if np.max(np.linalg.norm(correction,axis=1))>.08:
            return None  # Extra correction must stay inside the fine capture scale.
        dt=times[0]-times[-1]
        predicted=positions[-1]+velocity*dt+.5*acceleration*dt*dt
        linear=positions[-1]+(positions[-1]-positions[-2])*(dt/scale)
        error=float(np.linalg.norm(predicted-positions[0]))
        linear_error=float(np.linalg.norm(linear-positions[0]))
        # This is trajectory-model evidence, NOT a 1 cm accuracy claim.
        # The older knot was not used to fit the candidate curve.
        if (not np.isfinite([*velocity,*acceleration,error,linear_error]).all() or
                error>.01 or error+1e-4>=.5*linear_error):
            return None
        curve=dict(velocity=velocity,acceleration=acceleration,check_error_m=error)
        self.curves[key]=curve
        return curve

    def _matrices(self,row,previous,times):
        matrices=self._interpolate(row,previous,times)
        curve=self._curve(row)
        if matrices is not None and curve is not None:
            dt=np.asarray(times,dtype=float)-row['time']
            matrices[:,:3,3]=(row['matrix'][:3,3]+dt[:,None]*curve['velocity']+
                              .5*dt[:,None]**2*curve['acceleration'])
        return matrices

    def sample(self,time_s,available_until_s):
        context=self._context(time_s,available_until_s)
        if context is None:
            return None
        row,previous=context
        matrices=self._matrices(row,previous,[time_s])
        if matrices is None:
            return None
        curve=self._curve(row)
        return PoseSample(time_s,matrices[0],self.clock_id,(row['start'],row['end']),row['end'],
            'experimental_pose',True,dict(clock_epoch=row['epoch'],pose_map_id=self.map_id,
                independent_truth=False,gyro_bias_calibrated=False,rank=row.get('rank'),
                translation_model='older_knot_checked_acceleration' if curve else 'observed_velocity',
                acceleration_check_error_m=curve['check_error_m'] if curve else None))

    def point_matrices(self,frame,times):
        row=self.by_sequence.get(frame.sequence)
        if (row is None or not row['usable'] or row['end']>frame.scan_span_s[1]+1e-9 or
                np.any(times<row['start']-1e-9) or np.any(times>row['end']+1e-9)):
            return None
        previous=next((p for p in reversed(self.rows) if p['epoch']==row['epoch'] and
            p['sequence']<row['sequence'] and p['time']<row['time'] and p['usable'] and
            p['end']<=frame.scan_span_s[1]+1e-9),None)
        return self._matrices(row,previous,times)


class LiveLidarPoses:
    """Bounded causal local-map registration using the existing plane-ICP model.

    This estimates relative motion from current/past real scans. It reads no
    recorded trajectory, has no GPS origin, and is never independent truth.
    Degenerate geometry drops compensation instead of inventing a zero pose.
    """
    def __init__(self,max_scans=6,adaptive=False):
        self.adaptive=bool(adaptive)
        self.max_scans=max(2,int(max_scans))
        self.rows=[]
        self.keys=[]
        self.last_frame=None
        self.pose=np.eye(4)
        self.velocity=None
        self.velocity_dt=None
        self.epoch=0
        self.diagnostics={'usable':False,'reason':'awaiting_scan_pair'}
        self.geometry_cache=None
        self.key_pose=None
        self.key_time=None
        self.map_builds=0

    @staticmethod
    def _sample(points,maximum=3500):
        from .voxel import representatives
        valid=np.isfinite(points).all(axis=1)&(np.einsum('ij,ij->i',points,points)>1e-12)
        points=points[valid]
        indices,_=representatives(points,.07)
        if len(indices)>maximum:
            indices=indices[np.linspace(0,len(indices)-1,maximum,dtype=int)]
        return points[indices]

    def _anchor(self,frame,sample,usable=True):
        self.epoch+=1
        self.pose=np.eye(4)
        self.keys=[sample]
        self.velocity=self.velocity_dt=None
        self.geometry_cache=None
        self.key_pose=self.pose.copy()
        self.key_time=frame.ref_time_s
        self.rows=[dict(sequence=frame.sequence,time=frame.ref_time_s,start=frame.scan_span_s[0],
            end=frame.scan_span_s[1],matrix=self.pose.copy(),usable=usable,rank=None)]

    def _poses(self,frame):
        provider=CausalScanPoses if self.adaptive else RecordedPoses
        return provider(self.rows,frame.clock_id,
                             'live-relative:%s:%d'%(frame.session_id,self.epoch))

    def _map_geometry(self):
        from scipy.spatial import cKDTree
        if self.adaptive and self.geometry_cache is not None:
            return self.geometry_cache,True
        target=self._sample(np.concatenate(self.keys),maximum=9000)
        if len(target)<50:
            return (target,None,None,None),False
        tree=cKDTree(target)
        _,neighbors=tree.query(target,k=min(12,len(target)),workers=1)
        patches=target[neighbors]
        centered=patches-patches.mean(axis=1,keepdims=True)
        values,vectors=np.linalg.eigh(np.einsum('nki,nkj->nij',centered,centered)/patches.shape[1])
        normals=vectors[:,:,0]
        confidence=np.clip((values[:,1]-values[:,0])/np.maximum(values[:,2],1e-12),.02,1.)
        geometry=(target,tree,normals,confidence)
        self.map_builds+=1
        if self.adaptive:
            self.geometry_cache=geometry
        return geometry,False

    def update(self,frame):
        import time
        started=time.perf_counter()
        validate_frame(frame)
        sample=self._sample(frame.xyz_L)
        previous=self.last_frame
        reset=(previous is None or frame.session_id!=previous.session_id or
            frame.clock_id!=previous.clock_id or frame.sequence<=previous.sequence or
            frame.ref_time_s<=previous.ref_time_s or frame.ref_time_s-previous.ref_time_s>1.)
        if reset:
            self._anchor(frame,sample)
            self.last_frame=frame
            self.diagnostics=dict(usable=False,reason='awaiting_scan_pair',map_epoch=self.epoch,
                                  elapsed_ms=(time.perf_counter()-started)*1000.)
            return self._poses(frame)
        if len(sample)>=50:
            (target,tree,normals,confidence),cache_hit=self._map_geometry()
        else:
            target=self._sample(np.concatenate(self.keys),maximum=9000)
            tree=normals=confidence=None
            cache_hit=False
        count=iterations=rank=0
        residual_p90=float('inf')
        pose=self.pose.copy()
        if self.velocity is not None:
            ratio=(frame.ref_time_s-previous.ref_time_s)/self.velocity_dt
            advance=np.eye(4)
            advance[:3,:3]=Rotation.from_rotvec(
                Rotation.from_matrix(self.velocity[:3,:3]).as_rotvec()*ratio).as_matrix()
            advance[:3,3]=self.velocity[:3,3]*ratio
            pose=pose@advance
        usable=False
        if len(sample)>=50 and len(target)>=50:
            # Coarse-to-fine geometric capture only; no wheel/RPM acceptance gate.
            for maximum in (.65,.20,.08):
                for _ in range(6):
                    points=sample@pose[:3,:3].T+pose[:3,3]
                    distance,indices=tree.query(points,distance_upper_bound=maximum,workers=1)
                    keep=np.isfinite(distance)
                    count=int(keep.sum())
                    if count<50:
                        break
                    points,q,n=points[keep],target[indices[keep]],normals[indices[keep]]
                    residual=np.einsum('ij,ij->i',q-points,n)
                    jacobian=np.column_stack((np.cross(points,n),n))
                    weight=np.sqrt(np.minimum(1.,.025/(np.abs(residual)+1e-9))*confidence[indices[keep]])
                    step,_,rank,singular=np.linalg.lstsq(jacobian*weight[:,None],residual*weight,rcond=1e-5)
                    if rank!=6 or not np.isfinite(step).all():
                        break
                    delta=np.eye(4)
                    delta[:3,:3]=Rotation.from_rotvec(step[:3]).as_matrix()
                    delta[:3,3]=step[3:]
                    pose=delta@pose
                    iterations+=1
                    if np.linalg.norm(step[:3])<2e-5 and np.linalg.norm(step[3:])<5e-5:
                        break
                if count<50 or rank!=6:
                    break
            # Re-evaluate AFTER applying the last correction, not stale residuals.
            points=sample@pose[:3,:3].T+pose[:3,3]
            distance,indices=tree.query(points,distance_upper_bound=.08,workers=1)
            keep=np.isfinite(distance)
            count=int(keep.sum())
            if count>=50:
                residual=np.einsum('ij,ij->i',target[indices[keep]]-points[keep],normals[indices[keep]])
                residual_p90=float(np.quantile(np.abs(residual),.9))
                n=normals[indices[keep]]
                jacobian=np.column_stack((np.cross(points[keep],n),n))
                weight=np.sqrt(np.minimum(1.,.025/(np.abs(residual)+1e-9))*confidence[indices[keep]])
                singular=np.linalg.svd(jacobian*weight[:,None],compute_uv=False)
                rank=int(np.sum(singular>singular[0]*1e-5))
            usable=(rank==6 and count>=max(50,len(sample)*.35) and
                    residual_p90<=.04 and valid_matrix(pose))
        if usable:
            self.velocity=np.linalg.inv(self.pose)@pose
            self.velocity_dt=frame.ref_time_s-previous.ref_time_s
            self.pose=pose
            self.rows.append(dict(sequence=frame.sequence,time=frame.ref_time_s,
                start=frame.scan_span_s[0],end=frame.scan_span_s[1],matrix=pose.copy(),usable=True,rank=rank))
            self.rows=self.rows[-self.max_scans:]
            key_update=True
            if self.adaptive:
                translation=np.linalg.norm(pose[:3,3]-self.key_pose[:3,3])
                angle=Rotation.from_matrix(self.key_pose[:3,:3].T@pose[:3,:3]).magnitude()
                lever=float(np.max(np.linalg.norm(sample,axis=1)))
                observed_motion=translation+2.*lever*np.sin(angle*.5)
                key_update=(observed_motion>=.07 or frame.ref_time_s-self.key_time>=.4-1e-9)
            if key_update:
                self.keys.append(sample@pose[:3,:3].T+pose[:3,3])
                self.keys=self.keys[-3:]
                self.key_pose=pose.copy()
                self.key_time=frame.ref_time_s
                self.geometry_cache=None
        else:
            self._anchor(frame,sample,usable=False)
        self.last_frame=frame
        self.diagnostics=dict(usable=bool(usable),reason='observed_relative_motion' if usable else
            'degenerate_or_insufficient_registration',correspondences=count,rank=int(rank),
            residual_p90_m=residual_p90 if np.isfinite(residual_p90) else None,
            iterations=iterations,map_epoch=self.epoch,independent_truth=False,
            elapsed_ms=(time.perf_counter()-started)*1000.)
        if self.adaptive:
            self.diagnostics.update(map_cache_hit=bool(cache_hit),map_geometry_builds=self.map_builds,
                map_points=len(target),keyframe_updated=bool(usable and key_update),
                wheel_model_used=False)
        return self._poses(frame)


def _raw(frame,flag):
    diagnostics = dict(frame.diagnostics)
    diagnostics['flags'] = list(dict.fromkeys(diagnostics.get('flags',[])+[flag]))
    return replace(frame,motion_status='raw',diagnostics=diagnostics)


def poses_for_frame(poses, frame):
    return poses.for_frame(frame) if poses is not None and hasattr(poses,'for_frame') else poses


def deskew_frame(frame,poses):
    validate_frame(frame)
    poses = poses_for_frame(poses, frame)
    if poses is None:
        return _raw(frame,'pose_unavailable_or_underconstrained')
    finite = np.isfinite(frame.xyz_L).all(axis=1)
    finite &= np.linalg.norm(np.where(finite[:,None],frame.xyz_L,0.),axis=1) > 1e-9
    if any(frame.refs[int(i)].time_s is None for i in np.flatnonzero(finite)):
        return _raw(frame,'missing_point_time')
    reference = poses.sample(frame.ref_time_s,frame.scan_span_s[1])
    if not usable_pose(reference,frame.ref_time_s,frame.clock_id,frame.scan_span_s[1]):
        return _raw(frame,'pose_unavailable_or_underconstrained')
    times = np.array([frame.refs[int(i)].time_s for i in np.flatnonzero(finite)],dtype=float)
    if hasattr(poses,'point_matrices'):
        matrices = poses.point_matrices(frame,times)
    else:
        samples = [poses.sample(float(t),frame.scan_span_s[1]) for t in times]
        if any(not usable_pose(s,float(t),frame.clock_id,frame.scan_span_s[1])
               for s,t in zip(samples,times)):
            return _raw(frame,'point_time_coverage_missing')
        matrices = np.asarray([s.T_WL for s in samples])
    if matrices is None:
        return _raw(frame,'point_time_coverage_missing')
    if matrices.shape != (len(times),4,4) or not np.isfinite(matrices).all():
        return _raw(frame,'invalid_point_pose_matrix')
    if not isinstance(poses,RecordedPoses) and any(not valid_matrix(m) for m in matrices):
        return _raw(frame,'invalid_point_pose_matrix')
    relative = np.linalg.inv(reference.T_WL)[None,:,:]@matrices
    xyz = frame.xyz_L.copy()
    xyz[finite] = np.einsum('nij,nj->ni',relative[:,:3,:3],frame.xyz_L[finite])+relative[:,:3,3]
    diagnostics = dict(frame.diagnostics,pose_source=reference.source,
                       compensation_approximation='observed scan velocity and rotation; not tightly coupled LIO',
                       independent_pose_truth=False)
    if 'translation_model' in reference.diagnostics:
        diagnostics.update(translation_model=reference.diagnostics['translation_model'],
            acceleration_check_error_m=reference.diagnostics['acceleration_check_error_m'])
        if reference.diagnostics['translation_model']=='older_knot_checked_acceleration':
            diagnostics['compensation_approximation']='checked causal translation curve and observed rotation; not tightly coupled LIO'
    return replace(frame,xyz_L=xyz,motion_status='deskewed_experimental',diagnostics=diagnostics)


def transform_history(history,current,poses,config,include_current=True):
    validate_frame(current)
    if config.history_max_scans <= 1:
        return current
    if any(f.ref_time_s >= current.ref_time_s or f.sequence >= current.sequence for f in history):
        return replace(current,diagnostics=dict(current.diagnostics,flags=
                       current.diagnostics.get('flags',[])+['history_reset_clock_reversal']))
    if current.motion_status != 'deskewed_experimental':
        return current
    poses = poses_for_frame(poses, current)
    if poses is None:
        return current
    reference = poses.sample(current.ref_time_s,current.scan_span_s[1])
    if not usable_pose(reference,current.ref_time_s,current.clock_id,current.scan_span_s[1]):
        return current
    # Track fitting needs current+past scans. Object temporal support needs
    # only the transformed past: don't copy the entire current raw scan just
    # for scene.py to reject every one of its refs as self-support.
    clouds = [current.xyz_L] if include_current else []
    refs = list(current.refs) if include_current else []
    rings = [current.rings] if include_current else []
    proposal_labels = []
    proposal_origins = []
    def labels_for(frame):
        values = np.asarray(frame.diagnostics.get('object_proposal_labels', ()))
        if values.shape != (len(frame.xyz_L),) or values.dtype.kind not in 'iu':
            return np.full(len(frame.xyz_L),-1,dtype=np.int64)
        return values.astype(np.int64,copy=False)
    if config.temporal_object_proposals and include_current:
        proposal_labels.append(labels_for(current))
        proposal_origins.append(np.full(len(current.xyz_L),current.ref_time_s))
    accepted = []
    inverse = np.linalg.inv(reference.T_WL)
    for frame in history[-max(0,config.history_max_scans-1):]:
        if (current.ref_time_s-frame.ref_time_s > config.history_seconds+1e-9 or
                frame.clock_id != current.clock_id or frame.session_id != current.session_id or
                frame.motion_status != 'deskewed_experimental'):
            continue
        frame_poses = poses_for_frame(poses, frame)
        pose = frame_poses.sample(frame.ref_time_s,current.scan_span_s[1]) if frame_poses is not None else None
        if not usable_pose(pose,frame.ref_time_s,current.clock_id,current.scan_span_s[1]):
            continue
        if pose_map_key(pose) != pose_map_key(reference):
            continue
        observed_map = frame.diagnostics.get('pose_map_key')
        if observed_map is not None and tuple(observed_map) != pose_map_key(reference):
            continue  # A replacement pose provider cannot reinterpret old deskewed data.
        relative = inverse@pose.T_WL
        transformed = frame.xyz_L.copy()
        valid = np.isfinite(transformed).all(axis=1)
        valid &= np.linalg.norm(np.where(valid[:,None],transformed,0.),axis=1) > 1e-9
        transformed[valid] = transformed[valid]@relative[:3,:3].T+relative[:3,3]
        clouds.append(transformed)
        if config.temporal_object_proposals:
            proposal_labels.append(labels_for(frame))
            origins=np.asarray(frame.diagnostics.get('object_proposal_origin_time_s',
                np.full(len(frame.xyz_L),frame.ref_time_s)),dtype=float)
            proposal_origins.append(origins if origins.shape==(len(frame.xyz_L),)
                                    else np.full(len(frame.xyz_L),np.nan))
        refs.extend(frame.refs)
        rings.append(frame.rings)
        accepted.append(frame)
    if not accepted:
        return current
    out = replace(current,xyz_L=np.concatenate(clouds),refs=tuple(refs),
                  rings=np.concatenate(rings) if all(r is not None for r in rings) else None,
                  scan_span_s=(min(f.scan_span_s[0] for f in accepted),current.scan_span_s[1]),
                  motion_status='compensated_history',diagnostics=dict(current.diagnostics,
                  history_sequences=[f.sequence for f in accepted],
                  current_point_count=len(current.xyz_L) if include_current else 0,
                  aligned_to_ref_time_s=current.ref_time_s))
    if config.temporal_object_proposals:
        # Labels are point-parallel metadata, not point indices in the new
        # cloud. Source frame IDs in refs namespace each historical proposal.
        out = replace(out,diagnostics=dict(out.diagnostics,
                      object_proposal_labels=np.concatenate(proposal_labels),
                      object_proposal_origin_time_s=np.concatenate(proposal_origins)))
        if config.qualified_history_reconciliation:
            # Preserve the original frame namespace and status. Never copy
            # current evidence onto old returns or renew a source proof here.
            evidence = [dict(record) for frame in accepted
                        for record in frame.diagnostics.get('object_proposal_evidence',())
                        if isinstance(record,dict)]
            out = replace(out,diagnostics=dict(out.diagnostics,object_proposal_evidence=evidence))
    validate_frame(out)
    return out
