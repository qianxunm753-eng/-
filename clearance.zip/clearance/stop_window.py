"""Bounded lossless raw parking window; sampled display is never measurement truth."""
from dataclasses import replace
import time
import zlib
import numpy as np
from .protocol import CloudFrame,PointRef,validate_frame
from .motion import valid_matrix


class StopWindow:
    def __init__(self,radius_m=10.,voxel_m=.025,budget_s=60.,byte_budget=96*1024**2,
                 point_budget=12000000,map_budget=120000,clock=time.monotonic):
        if not all(np.isfinite(v) and v>0 for v in (radius_m,voxel_m,budget_s,byte_budget,point_budget,map_budget)):
            raise ValueError('positive finite parking window limits required')
        self.radius_m,self.voxel_m,self.budget_s=float(radius_m),float(voxel_m),float(budget_s)
        self.byte_budget,self.point_budget,self.map_budget=int(byte_budget),int(point_budget),int(map_budget)
        self.clock=clock
        self.clear()

    def clear(self):
        self.chunks=[]
        self.representatives={}
        self.support_counts={}
        self.reference_pose=self.reference_sequence=self.latest=self.started=None
        self.compressed_bytes=self.point_count=0
        self.reason='awaiting_stationary_scans'

    @property
    def scan_count(self):return len(self.chunks)

    @property
    def elapsed_s(self):return max(0.,self.clock()-self.started) if self.started is not None else 0.

    def expired(self):return self.started is not None and self.elapsed_s>self.budget_s

    def add(self,frame,T_WL):
        validate_frame(frame)
        matrix=np.asarray(T_WL,dtype=float)
        if not valid_matrix(matrix):raise ValueError('valid parking scan pose required')
        if self.latest is not None:
            if (frame.session_id,frame.clock_id,frame.sequence,frame.ref_time_s)==(
                self.latest.session_id,self.latest.clock_id,self.latest.sequence,self.latest.ref_time_s):
                return False
            if (frame.session_id!=self.latest.session_id or frame.clock_id!=self.latest.clock_id or
                frame.sequence<=self.latest.sequence or frame.ref_time_s<=self.latest.ref_time_s):
                self.clear()
        # Never resume a partially rejected window simply because a later
        # scan fits. Only a deliberate clear/source reset starts a new window.
        if self.reason in ('capacity_reached','time_budget_exceeded'):return False
        if self.expired():self.reason='time_budget_exceeded';return False
        reference=self.reference_pose if self.reference_pose is not None else matrix
        transform=np.linalg.inv(reference)@matrix
        inside=np.isfinite(frame.xyz_L).all(axis=1)
        norm=np.einsum('ij,ij->i',np.where(inside[:,None],frame.xyz_L,0.),np.where(inside[:,None],frame.xyz_L,0.))
        inside&=(norm<=self.radius_m**2+1e-12)&(norm>1e-18)
        rows=np.flatnonzero(inside)
        xyz=frame.xyz_L[rows]@transform[:3,:3].T+transform[:3,3]
        retained=np.einsum('ij,ij->i',xyz,xyz)<=self.radius_m**2+1e-12
        rows,xyz=rows[retained],xyz[retained]
        if not len(rows):self.reason='empty_scene';return False
        keys=np.floor(xyz/self.voxel_m).astype(np.int64)
        unique,first=np.unique(keys,axis=0,return_index=True)
        tuples=[tuple(k) for k in unique]
        new_keys=sum(key not in self.representatives for key in tuples)
        indices=np.array([frame.refs[int(i)].index for i in rows],dtype='<i8')
        times=np.array([frame.refs[int(i)].time_s if frame.refs[int(i)].time_s is not None else np.nan for i in rows],dtype='<f8')
        rings=None if frame.rings is None else np.asarray(frame.rings[rows],dtype='<i4')
        buffers={'xyz':zlib.compress(np.asarray(xyz,dtype='<f8').tobytes(),1),
                 'indices':zlib.compress(indices.tobytes(),1),'times':zlib.compress(times.tobytes(),1),
                 'rings':None if rings is None else zlib.compress(rings.tobytes(),1)}
        size=sum(len(value) for value in buffers.values() if value is not None)
        if (self.compressed_bytes+size>self.byte_budget or self.point_count+len(rows)>self.point_budget or
            len(self.representatives)+new_keys>self.map_budget):
            self.reason='capacity_reached';return False
        if self.started is None:self.started=self.clock()
        if self.reference_pose is None:
            self.reference_pose=matrix.copy();self.reference_sequence=frame.sequence
        chunk=dict(buffers=buffers,count=len(rows),sequence=frame.sequence,time=frame.ref_time_s,
            session=frame.session_id,clock=frame.clock_id,span=frame.scan_span_s,transform=transform.tolist())
        offset=len(self.chunks)
        self.chunks.append(chunk)
        for key,row in zip(tuples,first):
            self.representatives.setdefault(key,(offset,int(row)))
            self.support_counts[key]=self.support_counts.get(key,0)+1
        self.latest=replace(frame,xyz_L=np.empty((0,3)),refs=(),rings=None)
        self.point_count+=len(rows);self.compressed_bytes+=size
        self.reason='collecting'
        return True

    @staticmethod
    def decode(chunk):
        buffers=chunk['buffers']
        xyz=np.frombuffer(zlib.decompress(buffers['xyz']),dtype='<f8').reshape(-1,3)
        indices=np.frombuffer(zlib.decompress(buffers['indices']),dtype='<i8')
        times=np.frombuffer(zlib.decompress(buffers['times']),dtype='<f8')
        rings=None if buffers['rings'] is None else np.frombuffer(zlib.decompress(buffers['rings']),dtype='<i4')
        if len(xyz)!=chunk['count'] or len(indices)!=len(xyz) or len(times)!=len(xyz):
            raise ValueError('parking chunk provenance length mismatch')
        return xyz,indices,times,rings

    def iter_aligned(self):
        for chunk in self.chunks:
            xyz,indices,times,rings=self.decode(chunk)
            refs=tuple(PointRef(chunk['sequence'],int(index),float(stamp) if np.isfinite(stamp) else None)
                       for index,stamp in zip(indices,times))
            yield CloudFrame(chunk['session'],chunk['sequence'],chunk['time'],chunk['clock'],xyz,refs,rings,
                tuple(chunk['span']),'stop_window_aligned',{'window_reference_sequence':self.reference_sequence,
                'transform_to_window':chunk['transform'],'real_returns_only':True})

    def geometry(self):
        if self.latest is None:raise ValueError('parking geometry has no accepted scans')
        keys=list(self.representatives)
        points=np.empty((len(keys),3));refs=[None]*len(keys);ring_values=np.empty(len(keys),dtype=np.int32)
        groups={}
        for row,key in enumerate(keys):
            chunk,index=self.representatives[key]
            groups.setdefault(chunk,[]).append((row,index))
        have_rings=all(chunk['buffers']['rings'] is not None for chunk in self.chunks)
        for chunk_id,selections in groups.items():
            chunk=self.chunks[chunk_id]
            xyz,indices,times,rings=self.decode(chunk)
            for row,index in selections:
                points[row]=xyz[index]
                refs[row]=PointRef(chunk['sequence'],int(indices[index]),float(times[index]) if np.isfinite(times[index]) else None)
                if have_rings:ring_values[row]=rings[index]
        return CloudFrame(self.latest.session_id,self.latest.sequence,self.latest.ref_time_s,self.latest.clock_id,
            points,tuple(refs),ring_values if have_rings else None,
            (self.chunks[0]['span'][0],self.chunks[-1]['span'][1]),'stop_window_geometry',
            {'window_reference_sequence':self.reference_sequence,'voxel_keys':np.asarray(keys,dtype=np.int64),
             'scan_support_counts':np.array([self.support_counts[k] for k in keys]),'real_returns_only':True})

    def progress(self):
        return dict(scan_count=self.scan_count,raw_points=self.point_count,map_points=len(self.representatives),
            compressed_bytes=self.compressed_bytes,byte_budget=self.byte_budget,elapsed_s=self.elapsed_s,
            reason=self.reason,reference_sequence=self.reference_sequence,
            source_frames=[chunk['sequence'] for chunk in self.chunks])
