"""Isolated, evidence-preserving trackside clearance calculations (metres)."""
