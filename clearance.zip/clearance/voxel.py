"""Fast exact voxel membership; not averaging or distance subsampling."""
import math
import numpy as np


def representatives(points, voxel):
    points = np.asarray(points)
    if points.ndim != 2 or points.shape[1] != 3 or not np.isfinite(points).all() or not np.isfinite(voxel) or voxel <= 0:
        raise ValueError('finite XYZ and positive voxel required')
    if not len(points):
        return np.empty(0,dtype=np.int64), np.empty(0,dtype=np.int64)
    cells = np.floor(points/voxel).astype(np.int64)
    # Tiny fragments need no general unique-key sorting. Quantization and
    # validation still run, and ordering remains lexicographic cell ordering.
    if len(cells)==1:
        return np.zeros(1,dtype=np.int64),np.zeros(1,dtype=np.int64)
    if len(cells)==2:
        left,right=tuple(cells[0]),tuple(cells[1])
        if left==right:
            return np.zeros(1,dtype=np.int64),np.zeros(2,dtype=np.int64)
        order=np.array([0,1] if left<right else [1,0],dtype=np.int64)
        return order,order.copy()
    lower, upper = cells.min(axis=0), cells.max(axis=0)
    sizes = tuple(int(b)-int(a)+1 for a,b in zip(lower,upper))
    if math.prod(sizes) > np.iinfo(np.int64).max:
        _, indices, inverse = np.unique(cells,axis=0,return_index=True,return_inverse=True)
    else:
        shifted = cells-lower
        keys = (shifted[:,0]*sizes[1]+shifted[:,1])*sizes[2]+shifted[:,2]
        _, indices, inverse = np.unique(keys,return_index=True,return_inverse=True)
    return indices, inverse
