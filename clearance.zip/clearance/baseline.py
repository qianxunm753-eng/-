"""Unmodified legacy rail observer, explicitly a comparison, not the new tracker."""
from pathlib import Path
import importlib
import sys
import numpy as np
from .protocol import TrackSegment, TrackModel, TrackUpdate, validate_track


def adapt_legacy_measurement(frame, result, ground):
    if result is None:
        return TrackUpdate('initializing', diagnostics={'observer': 'legacy_single_frame_baseline'})
    start, end = np.asarray(result['endpoints'], dtype=float)
    tangent = (end-start)/np.linalg.norm(end-start)
    across = np.asarray(result['right_point'])-np.asarray(result['left_point'])
    across -= tangent*float(across@tangent)
    across /= np.linalg.norm(across)
    normal = np.cross(tangent, across)
    ground_normal, floor = ground
    if normal@np.asarray(ground_normal) < 0:
        normal *= -1
    endpoints = np.stack([start, end])
    width = float(result['gauge'])
    segment = TrackSegment(start, end, endpoints-across*width/2.,
                           endpoints+across*width/2., normal, across, float(start@tangent))
    warnings = list(result.get('quality_warnings', ()))
    model = TrackModel(frame.session_id, frame.ref_time_s, frame.clock_id, 'observed_dual',
                       (segment,), frame.ref_time_s, frame.ref_time_s, width,
                       {'observer': 'legacy_single_frame_baseline', 'quality_warnings': warnings,
                        'measurement_flags': ['legacy_observer_baseline']+(['rail_fit_warning'] if warnings else []),
                        'ground_plane': {'normal_L': list(ground_normal), 'offset_m': float(floor)},
                        'fit_residual_p95_m': result.get('fit_residual_p95_m')})
    validate_track(model, frame)
    return TrackUpdate('observed_dual', model)


def observe_legacy(frame):
    # Legacy sources use flat Python-2-compatible imports. This offline adapter
    # does not change the installed application or those sources.
    parent = str(Path(__file__).resolve().parents[1])
    sys.path.insert(0, parent)
    try:
        legacy = importlib.import_module('rail_live')
    finally:
        sys.path.pop(0)
    points = frame.xyz_L
    valid = np.isfinite(points).all(axis=1)
    roi = valid & (points[:, 2] > .3) & (points[:, 2] < 6.2) & (np.sum(points*points, axis=1) < 49)
    fit_points = list(map(tuple, points[roi]))
    analysis = legacy.analyze_live(fit_points)
    if analysis['measurement'] is None:
        return TrackUpdate('initializing', diagnostics={
            'observer': 'legacy_single_frame_baseline', 'reason': analysis['code'],
            'message': analysis['message'], 'legacy': analysis['diagnostics']})
    ground = legacy._ground_basis(fit_points)
    if ground is None:
        return TrackUpdate('initializing', diagnostics={'reason': 'ground_not_found'})
    basis, floor = ground
    return adapt_legacy_measurement(frame, analysis['measurement'], (basis[2], floor))
