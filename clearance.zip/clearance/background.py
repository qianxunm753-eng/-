"""Auditable user-confirmed background, scoped to a recording and pose map.

This is a scene prior, not automatic semantic recognition or a target-distance
hint. Unknown objects on either side survive. Invalid pose/source means no mask.
"""
from dataclasses import replace
import json
from pathlib import Path
import numpy as np
from scipy.spatial import cKDTree
from .motion import usable_pose
from .scene import TemporalSupport


def _reference_reason(document, frame, pose):
    if frame.session_id != document['session_id'] or frame.clock_id != document['clock_id']:
        return 'foreign_recording_or_clock'
    if (not document.get('source_sha256') or
            frame.diagnostics.get('source_sha256') != document['source_sha256']):
        return 'unverified_or_different_source_content'
    if frame.motion_status != 'deskewed_experimental' or not usable_pose(
            pose,frame.ref_time_s,frame.clock_id,frame.scan_span_s[1]):
        return 'no_valid_current_compensated_pose'
    if (pose.source != document['pose_source'] or
            pose.diagnostics.get('clock_epoch',0) != document.get('clock_epoch',0) or
            not document.get('pose_map_id') or pose.diagnostics.get('pose_map_id') != document['pose_map_id']):
        return 'different_pose_map'
    return None


def _exclude_observations(frame, layers, excluded, diagnostics):
    """Remove measurement membership, not current context or native provenance."""
    removed = np.zeros(len(frame.xyz_L),dtype=bool)
    removed[excluded] = True
    output = []
    for candidate in layers.candidates:
        keep = ~removed[candidate.point_indices]
        if not keep.any():
            continue
        d = dict(candidate.diagnostics)
        remaining = candidate.point_indices[keep]
        if 'support_neighbor_indices' in d:
            neighbors = d['support_neighbor_indices'][keep]
            valid = d['support_neighbor_valid'][keep]&~removed[neighbors]
            d.update(support_neighbor_indices=neighbors,support_neighbor_valid=valid)
            supported = remaining[valid.any(axis=1)]
            temporal = d.get('temporal_support_refs',{})
            if isinstance(temporal,TemporalSupport):
                temporal_indices = remaining[np.isin(remaining,temporal.indices)]
            else:
                temporal_indices = np.asarray([i for i in remaining if int(i) in temporal],dtype=np.int64)
            supported = np.union1d(supported,temporal_indices)
        else:
            supported = candidate.supported_indices[~removed[candidate.supported_indices]]
        d['ambiguous_indices'] = np.asarray([i for i in d.get('ambiguous_indices',()) if not removed[i]],dtype=np.int64)
        d['background_removed_points'] = int((~keep).sum())
        output.append(replace(candidate,point_indices=remaining,supported_indices=supported,diagnostics=d))
    indices = layers.indices['object']
    background = np.union1d(layers.indices.get('background',np.empty(0,dtype=np.int64)),excluded)
    new_indices = dict(layers.indices,object=indices[~removed[indices]],background=background)
    ambiguous = new_indices.get('ambiguous',np.empty(0,dtype=np.int64))
    new_indices['ambiguous'] = ambiguous[~removed[ambiguous]]
    counts = dict(layers.counts,object=len(new_indices['object']),background=len(background),
                  ambiguous=len(new_indices['ambiguous']),components=len(output))
    return replace(layers,indices=new_indices,candidates=tuple(output),counts=counts,
                   diagnostics=dict(layers.diagnostics,**diagnostics))


class MeasurementScopeReference:
    """Explicit world half-space ROI for ONE confirmed experimental recording.

    Never inferred from a filename, current sensor left/right or object class.
    A foreign/invalid map leaves all unknown objects measurable.
    """
    def __init__(self, document):
        if (document.get('format') != 'clearance-confirmed-measurement-scope-v1' or
                document.get('confirmation') != 'user_confirmed_measurement_scope'):
            raise ValueError('measurement ROI requires explicit confirmation and format')
        for key in ('session_id','clock_id','source_sha256','pose_source','pose_map_id'):
            if not document.get(key):
                raise ValueError('missing scoped measurement identity: '+key)
        self.origin = np.asarray(document['plane_origin_W'],dtype=float)
        self.normal = np.asarray(document['keep_normal_W'],dtype=float)
        if (self.origin.shape != (3,) or self.normal.shape != (3,) or
                not np.isfinite(self.origin).all() or not np.isfinite(self.normal).all() or
                np.linalg.norm(self.normal) < 1e-9):
            raise ValueError('invalid world measurement scope plane')
        self.normal = self.normal/np.linalg.norm(self.normal)
        self.document = document

    @classmethod
    def from_path(cls,path):
        path=Path(path)
        if path.stat().st_size > 32768:
            raise ValueError('oversized measurement scope')
        return cls(json.loads(path.read_text(encoding='utf-8-sig')))

    def update(self,frame,layers,pose,config=None):
        reason=_reference_reason(self.document,frame,pose)
        if reason:
            return replace(layers,diagnostics=dict(layers.diagnostics,measurement_scope='not_applied',
                                                  measurement_scope_reason=reason))
        indices=layers.indices['object']
        world=frame.xyz_L[indices]@pose.T_WL[:3,:3].T+pose.T_WL[:3,3]
        excluded=indices[(world-self.origin)@self.normal < -1e-9]
        return _exclude_observations(frame,layers,excluded,dict(
            measurement_scope='explicit_recording_scoped_roi',measurement_scope_excluded_points=len(excluded),
            measurement_scope_semantics='user-confirmed experimental ROI, not automatic object recognition'))


class BackgroundReference:
    def __init__(self, document):
        if document.get('format') != 'clearance-confirmed-background-v1' or document.get('confirmation') != 'user_confirmed_background':
            raise ValueError('background requires explicit confirmation and named format')
        points = np.asarray(document['points_W'], dtype=float)
        if points.ndim != 2 or points.shape[1] != 3 or not 0 < len(points) <= 100000 or not np.isfinite(points).all():
            raise ValueError('invalid or unbounded background reference')
        self.document = document
        self.tree = cKDTree(points)

    @classmethod
    def from_path(cls, path):
        path = Path(path)
        if path.stat().st_size > 16*1024**2:
            raise ValueError('oversized background prior')
        return cls(json.loads(path.read_text(encoding='utf-8-sig')))

    def update(self, frame, layers, pose, config=None):
        reason = _reference_reason(self.document,frame,pose)
        if reason:
            return replace(layers,diagnostics=dict(layers.diagnostics,confirmed_background='not_applied',
                                                  background_reason=reason))
        indices = layers.indices['object']
        points = frame.xyz_L[indices]
        world = points@pose.T_WL[:3,:3].T+pose.T_WL[:3,3]
        distance = self.tree.query(world,k=1)[0]
        base = config.neighbor_base_m if config is not None else .04
        angle = config.neighbor_angle_rad if config is not None else .012
        background = indices[distance <= base+angle*np.linalg.norm(points,axis=1)]
        return _exclude_observations(frame,layers,background,dict(
            confirmed_background='explicit_recording_scoped_prior',background_removed_points=len(background),
            background_semantics='user confirmation, not automatic classification'))


def prepare_reference(frames_folder, pose_path, selection_path, pcap, output):
    """Build a small explicit annotation prior; never feed future motion frames.

    The reference scan is human annotation provenance, not a hidden causal
    discovery result. It is used only in this recording's experimental map.
    """
    import hashlib
    from .native import read_native_frames,read_native_metadata
    from .motion import load_experimental_poses,poses_for_frame
    from .replay import ReplayEngine
    from .rsview_cache import playback_config
    selection = json.loads(Path(selection_path).read_text(encoding='utf-8-sig'))
    if selection.get('confirmation') != 'user_confirmed_background':
        raise ValueError('unconfirmed background annotation')
    frame_id = int(selection['reference_frame'])
    poses = load_experimental_poses(pose_path,read_native_metadata(frames_folder))
    config = replace(playback_config(),confirmed_background_path=None)
    engine = ReplayEngine(config,'tracked',poses)
    update,layers,results = engine.step(next(read_native_frames(frames_folder,{frame_id})))
    current = engine.measurement_frame
    source = poses_for_frame(poses,current)
    pose = source.sample(current.ref_time_s,current.scan_span_s[1])
    if not usable_pose(pose,current.ref_time_s,current.clock_id,current.scan_span_s[1]):
        raise ValueError('background reference has no usable pose')
    selected, audit = [], []
    for seed in selection['native_seed_indices']:
        matches = [c for c in layers.candidates if int(seed) in c.point_indices]
        if len(matches) != 1:
            raise ValueError('background seed does not name exactly one current component')
        c = matches[0]
        selected.extend(c.point_indices)
        audit.append(dict(seed_index=int(seed),member_count=len(c.point_indices),source_frame=frame_id))
    selected = np.unique(np.asarray(selected,dtype=np.int64))
    points = current.xyz_L[selected]@pose.T_WL[:3,:3].T+pose.T_WL[:3,3]
    with Path(pcap).open('rb') as stream:
        digest = hashlib.file_digest(stream,'sha256').hexdigest()
    document = dict(format='clearance-confirmed-background-v1',confirmation='user_confirmed_background',
        session_id=current.session_id,clock_id=current.clock_id,pose_source=pose.source,
        pose_map_id=pose.diagnostics['pose_map_id'],
        clock_epoch=pose.diagnostics.get('clock_epoch',0),source_sha256=digest,points_W=points.tolist(),
        source_pcap=str(Path(pcap).resolve()),annotation=dict(reference_frame=frame_id,
        device_time_s=current.ref_time_s,selections=audit,native_indices=selected.tolist()),
        note='Explicit offline human scene prior; not automatic detection or a physical distance truth')
    output = Path(output)
    if output.exists():
        raise FileExistsError('refusing to overwrite background prior')
    output.write_text(json.dumps(document,separators=(',',':')),encoding='utf-8')
    return {'points':len(selected),'bytes':output.stat().st_size,'source_sha256':digest}


if __name__ == '__main__':
    import argparse
    p=argparse.ArgumentParser(__doc__)
    for field in ('frames','poses','selection','pcap','output'):
        p.add_argument('--'+field,type=Path,required=True)
    args=p.parse_args()
    print(json.dumps(prepare_reference(args.frames,args.poses,args.selection,args.pcap,args.output)))
