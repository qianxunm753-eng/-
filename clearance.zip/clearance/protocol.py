"""Typed records; no Qt, VTK or nominal track gauge dependency."""
from dataclasses import dataclass, field, fields, is_dataclass
from typing import Any
import math
import numpy as np

TRACK_MODES = frozenset(('observed_dual', 'compensated_dual', 'estimated_single',
                        'predicted_track', 'held_snapshot', 'initializing', 'ambiguous_track'))


@dataclass(frozen=True)
class ClearanceConfig:
    config_id: str = 'clearance-experiment-v2'
    corridor_half_width_m: float = 5.0
    along_half_window_m: float = 5.0
    preview_radius_m: tuple[float, float] = (.2, 5.)
    history_seconds: float = .6
    history_max_scans: int = 6
    period_s: float = .2
    neighbor_base_m: float = .04
    neighbor_angle_rad: float = .012
    display_voxel_m: float = .025
    confirmed_body_boxes: tuple = ()
    single_association_width_fraction: float = .25
    ground_seed_band_m: float = .08
    ground_max_confirmation_band_m: float = .012
    ground_noise_sigma_factor: float = 3.
    ground_numerical_band_m: float = 1e-6
    # Explicit test scope; None preserves the original offline corridor.
    # This bounds the scene, not a minimum allowed object height.
    measurement_height_range_m: tuple[float, float] | None = None
    sensor_max_range_m: float | None = None
    confirmed_background_path: str | None = None
    confirmed_measurement_scope_path: str | None = None
    live_motion_estimation: bool = False
    # Layout ID retention only: never extends point support or holds distances.
    display_identity_seconds: float | None = None
    display_balance_sides: bool = False
    # Current-scan repeated rail cross-section roles; legacy playback is opt-in.
    rail_profile_roles: bool = False
    spatial_object_ownership: bool = False
    geometry_label_priority: bool = False
    # Experimental structure/proposal refinements, opt-in for legacy playback.
    track_structure_context: bool = False
    temporal_object_proposals: bool = False
    surface_object_proposals: bool = False
    local_terrain_validation: bool = False
    qualified_object_cores: bool = False
    # Local geometric object lineage only; not a semantic equipment/GPS ID.
    qualified_instance_ownership: bool = False
    # Repeated independently verified current edges may reconcile provisional IDs.
    current_instance_reconciliation: bool = False
    # Wheel-independent causal translation model and bounded map reuse.
    adaptive_motion_compensation: bool = False
    # Experimental recorded-input features. Native LIVE must reject these.
    # The scope affects measurement candidates, never the source point cloud.
    above_rail_measurement_only: bool = False
    scanline_object_proposals: bool = False
    body_fragment_proposals: bool = False
    qualified_history_reconciliation: bool = False
    raw_history_identity_support: bool = False
    qualified_history_owner_keys: bool = False
    observable_instance_seeding: bool = False
    stable_instance_labels: bool = False
    # Replay startup still needs current geometry checks without a world pose.
    current_observation_gating: bool = False
    complete_current_reconciliation: bool = False
    native_shared_edge_evidence: bool = False
    above_rail_uncertainty: bool = False
    recorded_playback_continuity: bool = False
    stop_window_fusion: bool = False
    stop_window_stages: tuple = (20,40,80,160)
    stop_window_budget_s: float = 60.
    stop_stable_scans: int = 5
    stop_translation_rate_mps: float = .03
    stop_rotation_rate_degps: float = .3
    stop_anchor_shift_m: float = .03
    stop_anchor_angle_deg: float = .3
    stop_window_byte_budget: int = 96*1024**2
    stop_window_point_budget: int = 12000000
    stop_window_map_budget: int = 120000
    stop_window_voxel_m: float = .025
    stop_distance_tolerance_m: float = .01


@dataclass(frozen=True)
class PointRef:
    frame: int
    index: int
    time_s: float | None


@dataclass(frozen=True)
class CloudFrame:
    session_id: str
    sequence: int
    ref_time_s: float
    clock_id: str
    xyz_L: np.ndarray
    refs: tuple[PointRef, ...]
    rings: np.ndarray | None
    scan_span_s: tuple[float, float]
    motion_status: str = 'raw'
    diagnostics: dict = field(default_factory=dict)


@dataclass(frozen=True)
class PoseSample:
    time_s: float
    T_WL: np.ndarray
    clock_id: str
    coverage_s: tuple[float, float]
    available_until_s: float
    source: str
    usable: bool
    diagnostics: dict = field(default_factory=dict)


@dataclass(frozen=True)
class TrackSegment:
    start_L: np.ndarray
    end_L: np.ndarray
    left_endpoints_L: np.ndarray
    right_endpoints_L: np.ndarray
    normal_L: np.ndarray
    across_L: np.ndarray
    station_start_m: float
    observation_refs: tuple[PointRef, ...] = ()


@dataclass(frozen=True)
class TrackModel:
    session_id: str
    ref_time_s: float
    clock_id: str
    mode: str
    segments: tuple[TrackSegment, ...]
    first_observed_s: float
    last_observed_s: float
    observed_gauge_m: float | None
    diagnostics: dict = field(default_factory=dict)


@dataclass(frozen=True)
class TrackUpdate:
    mode: str
    model: TrackModel | None = None
    held_model: TrackModel | None = None
    diagnostics: dict = field(default_factory=dict)


@dataclass(frozen=True)
class ProjectionBatch:
    distance_m: np.ndarray
    foot_L: np.ndarray
    projected_L: np.ndarray
    signed_side_m: np.ndarray
    station_m: np.ndarray
    height_m: np.ndarray
    segment_index: np.ndarray
    supported: np.ndarray


@dataclass(frozen=True)
class Candidate:
    candidate_id: str
    point_indices: np.ndarray
    supported_indices: np.ndarray
    first_seen_s: float
    last_seen_s: float
    diagnostics: dict = field(default_factory=dict)


@dataclass(frozen=True)
class SceneLayers:
    indices: dict[str, np.ndarray]
    candidates: tuple[Candidate, ...]
    counts: dict
    diagnostics: dict = field(default_factory=dict)


@dataclass(frozen=True)
class BoundaryEvidence:
    point_ref: PointRef
    point_L: np.ndarray
    projected_L: np.ndarray
    foot_L: np.ndarray
    support_refs: tuple[PointRef, ...] = ()
    support_span_s: tuple[float, float] | None = None
    diagnostics: dict = field(default_factory=dict)


@dataclass(frozen=True)
class ClearanceResult:
    session_id: str
    config_id: str
    sequence: int
    ref_time_s: float
    clock_id: str
    track_mode: str
    candidate_id: str
    observed_min_distance_m: float | None
    supported_min_distance_m: float | None
    observed_evidence: BoundaryEvidence | None
    supported_evidence: BoundaryEvidence | None
    side: str | None = None
    station_m: float | None = None
    height_m: float | None = None
    observation_span_s: tuple[float, float] | None = None
    track_age_s: float | None = None
    flags: tuple[str, ...] = ()
    timing_ms: dict = field(default_factory=dict)
    layer_counts: dict = field(default_factory=dict)


def validate_frame(frame: CloudFrame) -> None:
    if frame.xyz_L.ndim != 2 or frame.xyz_L.shape[1] != 3:
        raise ValueError('XYZ must have shape N,3')
    if len(frame.refs) != len(frame.xyz_L):
        raise ValueError('return provenance length mismatch')
    if frame.rings is not None and frame.rings.shape != (len(frame.xyz_L),):
        raise ValueError('Ring length mismatch')
    lo, hi = frame.scan_span_s
    if not all(math.isfinite(v) for v in (lo, hi, frame.ref_time_s)) or lo > hi:
        raise ValueError('invalid device time')
    if not lo-1e-9 <= frame.ref_time_s <= hi+1e-9:
        raise ValueError('reference time outside scan span')
    if not frame.session_id or not frame.clock_id:
        raise ValueError('missing session or device clock identity')


def validate_track(model: TrackModel, frame: CloudFrame | None = None) -> None:
    if model.mode not in TRACK_MODES or not model.segments:
        raise ValueError('invalid or unsupported track model')
    if not all(math.isfinite(t) for t in (model.ref_time_s, model.first_observed_s,
                                         model.last_observed_s)):
        raise ValueError('invalid track device time')
    if frame is not None:
        validate_frame(frame)
        if (model.session_id != frame.session_id or model.clock_id != frame.clock_id or
                abs(model.ref_time_s-frame.ref_time_s) > 1e-9):
            raise ValueError('track/cloud session, clock or reference time mismatch')
    for s in model.segments:
        for endpoints in (s.left_endpoints_L,s.right_endpoints_L):
            if np.asarray(endpoints).shape!=(2,3) or not np.isfinite(endpoints).all():
                raise ValueError('invalid observed rail endpoints')
        values = (s.start_L, s.end_L, s.normal_L, s.across_L)
        if any(np.asarray(v).shape != (3,) or not np.isfinite(v).all() for v in values):
            raise ValueError('invalid track vectors')
        delta = s.end_L-s.start_L
        length = np.linalg.norm(delta)
        if length < 1e-9:
            raise ValueError('zero-length observed support')
        tangent = delta/length
        if (abs(np.linalg.norm(s.normal_L)-1.) > 1e-6 or
                abs(np.linalg.norm(s.across_L)-1.) > 1e-6 or
                abs(tangent@s.normal_L) > 1e-6 or
                abs(tangent@s.across_L) > 1e-6 or
                abs(s.normal_L@s.across_L) > 1e-6):
            raise ValueError('non-orthonormal track plane')
        if not math.isfinite(s.station_start_m):
            raise ValueError('invalid track station')


def measurement_model(update):
    return update.model if update.mode in ('observed_dual','compensated_dual',
        'estimated_single','predicted_track') and update.model is not None and \
        update.model.mode==update.mode else None


def json_value(value: Any) -> Any:
    """Only convert types; never turn an invalid number into a valid zero."""
    if is_dataclass(value):
        return {f.name: json_value(getattr(value, f.name)) for f in fields(value)}
    if isinstance(value, np.ndarray):
        return json_value(value.tolist())
    if isinstance(value, np.generic):
        return json_value(value.item())
    if isinstance(value, dict):
        return {str(k): json_value(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [json_value(v) for v in value]
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError('non-finite JSON output')
    return value


def result_to_dict(result: ClearanceResult) -> dict:
    return json_value(result)
