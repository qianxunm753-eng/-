"""Planar projection with finite observation support, never infinite rail claims."""
import numpy as np
from .protocol import CloudFrame, TrackModel, ProjectionBatch, ClearanceConfig, validate_track


def _projections(points_L: np.ndarray, model: TrackModel):
    validate_track(model)
    points = np.asarray(points_L, dtype=np.float64).reshape(-1, 3)
    for s in model.segments:
        direction = s.end_L-s.start_L
        length = np.linalg.norm(direction)
        tangent = direction/length
        delta = points-s.start_L
        height = delta@s.normal_L
        planar = points-height[:, None]*s.normal_L
        along = delta@tangent
        foot = s.start_L+np.clip(along, 0, length)[:, None]*tangent
        supported = (along >= -1e-9) & (along <= length+1e-9) & np.isfinite(points).all(axis=1)
        yield (np.linalg.norm(planar-foot, axis=1), foot, planar,
               delta@s.across_L, s.station_start_m+along, height, supported)


def project_supported(points_L: np.ndarray, model: TrackModel) -> ProjectionBatch:
    n = len(points_L)
    best = np.full(n,np.inf)
    diagnostic = np.full(n,np.inf)
    valid = np.zeros(n,dtype=bool)
    select = np.zeros(n,dtype=np.int64)
    values = None
    # Stream one finite segment at a time instead of allocating N x segments
    # clouds for every output field. Strict '<' preserves first-segment ties.
    for index,choice in enumerate(_projections(points_L,model)):
        if values is None:
            values = [v.copy() for v in choice[:6]]
        distance = choice[0]
        finite_support = choice[6]&np.isfinite(distance)
        diagnostic_cost = np.nan_to_num(distance,nan=np.inf)
        use = (finite_support&(distance<best)) | (~valid&~finite_support&
                                                  (diagnostic_cost<diagnostic))
        for output,current in zip(values,choice[:6]):
            output[use] = current[use]
        select[use] = index
        best[finite_support] = np.minimum(best[finite_support],distance[finite_support])
        diagnostic = np.minimum(diagnostic,diagnostic_cost)
        valid |= finite_support
    return ProjectionBatch(*values, select.astype(np.int64), valid)


def corridor_indices(frame: CloudFrame, model: TrackModel, config: ClearanceConfig) -> np.ndarray:
    validate_track(model, frame)
    finite = np.isfinite(frame.xyz_L).all(axis=1) & (np.linalg.norm(frame.xyz_L, axis=1) > 1e-9)
    keep = np.zeros(len(frame.xyz_L), dtype=bool)
    heights = getattr(config, 'measurement_height_range_m', None)
    max_range = getattr(config, 'sensor_max_range_m', None)
    if heights is not None and (len(heights) != 2 or not np.isfinite(heights).all() or heights[0] > heights[1]):
        raise ValueError('invalid measurement height range')
    if max_range is not None:
        if not np.isfinite(max_range) or max_range <= 0:
            raise ValueError('invalid sensor near-field range')
        finite &= np.linalg.norm(frame.xyz_L, axis=1) <= max_range+1e-9
    for s in model.segments:
        tangent = s.end_L-s.start_L
        tangent = tangent/np.linalg.norm(tangent)
        delta = frame.xyz_L-s.start_L
        lateral = delta@s.across_L
        # Centered on the sensor projection, not on the segment start/end.
        forward = frame.xyz_L@tangent
        within = ((np.abs(lateral) <= config.corridor_half_width_m+1e-9) &
                  (np.abs(forward) <= config.along_half_window_m+1e-9))
        if heights is not None:
            height = delta@s.normal_L
            within &= (height >= heights[0]-1e-9) & (height <= heights[1]+1e-9)
        keep |= within
    return np.flatnonzero(keep & finite)
