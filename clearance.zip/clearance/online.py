"""Persistent current-cloud engine, isolated from RSView's embedded Python 2.

Only explicit simulated-PCAP mode can read experimental recorded poses. Live
relative registration uses current/past real scans, never a recorded trajectory.
"""
from dataclasses import fields
from dataclasses import replace
import hashlib
import time

import numpy as np

from .protocol import CloudFrame, ClearanceConfig, PointRef, PoseSample, validate_frame
from .motion import valid_matrix
from .replay import ReplayEngine
from .rsview_cache import build_packet, playback_config


def _array(value, dtype, shape=None):
    if isinstance(value, dict):
        data = value['data']
        if isinstance(data, str):
            data = data.encode('latin1')  # Protocol-2 bytes emitted by Python 2.
        result = np.frombuffer(data, dtype=value.get('dtype', dtype))
    else:
        result = np.asarray(value, dtype=dtype)
    return result.reshape(shape) if shape is not None else result


class SuppliedPoses:
    """Bounded causal samples; supplied matrices do not imply GPS/INS calibration."""
    def __init__(self, max_scans):
        self.samples = []
        self.max_scans = max(1, max_scans)

    def add(self, pose, frame):
        if not pose:
            return
        if 'samples' in pose:
            proposed = []
            source = pose.get('source','explicit_supplied_trajectory')
            available = float(pose.get('available_until_s',frame.scan_span_s[1]))
            clock = pose.get('clock_id',frame.clock_id)
            previous = -np.inf
            for row in pose['samples']:
                timestamp = float(row['time_s'])
                matrix = np.asarray(row['matrix'],dtype=float)
                if (not np.isfinite([timestamp,available]).all() or timestamp <= previous or
                    available > frame.scan_span_s[1]+1e-9 or timestamp > available+1e-9 or
                    clock != frame.clock_id or not valid_matrix(matrix)):
                    raise ValueError('supplied trajectory is invalid, noncausal or unordered')
                proposed.append(PoseSample(timestamp,matrix,clock,(timestamp,timestamp),available,
                    source,bool(row.get('usable',pose.get('usable',False))),
                    {'pose_map_id':pose.get('map_id'),'independent_truth':False}))
                previous = timestamp
            # Replace matching knot times atomically; never blend providers/maps.
            if not proposed or (self.samples and (self.samples[-1].source != source or
                 self.samples[-1].diagnostics.get('pose_map_id') != pose.get('map_id'))):
                self.samples = []
            knots = {p.time_s:p for p in self.samples}
            knots.update({p.time_s:p for p in proposed})
            self.samples = sorted(knots.values(),key=lambda p:p.time_s)[-self.max_scans*4:]
            return
        matrix = np.asarray(pose['matrix'], dtype=float)
        timestamp = float(pose.get('time_s', frame.ref_time_s))
        coverage = tuple(pose.get('coverage_s', (timestamp, timestamp)))
        available = float(pose.get('available_until_s', coverage[1]))
        clock = pose.get('clock_id', frame.clock_id)
        if (not valid_matrix(matrix) or len(coverage) != 2 or
                not np.isfinite([timestamp, available, *coverage]).all() or
                coverage[0] > coverage[1] or available > frame.scan_span_s[1]+1e-9 or
                abs(timestamp-frame.ref_time_s) > 1e-6 or clock != frame.clock_id):
            raise ValueError('supplied pose identity, coverage or causal availability invalid')
        # A single matrix has no justified within-scan velocity. It covers only
        # its named timestamp; arbitrary scan-wide constant-pose deskew is unsafe.
        sample = PoseSample(timestamp, matrix, clock, (timestamp, timestamp), available,
                            pose.get('source', 'explicit_supplied_pose'),
                            bool(pose.get('usable', False)),
                            {'supplied_coverage_s':coverage, 'independent_truth':False,
                             'pose_map_id':pose.get('map_id')})
        if self.samples and (self.samples[-1].source != sample.source or
             self.samples[-1].diagnostics.get('pose_map_id') != pose.get('map_id')):
            self.samples = []
        knots = {p.time_s:p for p in self.samples}
        knots[timestamp] = sample
        self.samples = sorted(knots.values(),key=lambda p:p.time_s)[-self.max_scans:]

    def sample(self, time_s, available_until_s):
        exact = next((p for p in reversed(self.samples)
                     if abs(p.time_s-time_s) <= 1e-6 and
                     p.available_until_s <= available_until_s+1e-9), None)
        if exact is not None:
            return exact
        available = [p for p in self.samples if p.available_until_s <= available_until_s+1e-9]
        for a,b in zip(available,available[1:]):
            if a.usable and b.usable and a.time_s <= time_s <= b.time_s:
                from .motion import RecordedPoses
                matrix = RecordedPoses._interpolate(dict(time=b.time_s,matrix=b.T_WL),
                           dict(time=a.time_s,matrix=a.T_WL),[time_s])[0]
                return replace(b,time_s=time_s,T_WL=matrix,coverage_s=(a.time_s,b.time_s))
        return None

    def point_matrices(self, frame, times):
        from .motion import RecordedPoses
        available = [p for p in self.samples if p.available_until_s <= frame.scan_span_s[1]+1e-9]
        matrices = np.empty((len(times),4,4))
        covered = np.zeros(len(times),dtype=bool)
        for a,b in zip(available,available[1:]):
            if not a.usable or not b.usable:
                continue
            selected = (times >= a.time_s-1e-9)&(times <= b.time_s+1e-9)
            matrices[selected] = RecordedPoses._interpolate(dict(time=b.time_s,matrix=b.T_WL),
                                dict(time=a.time_s,matrix=a.T_WL),times[selected])
            covered |= selected
        for sample in available:
            selected = np.abs(times-sample.time_s)<=1e-9
            if sample.usable:
                matrices[selected] = sample.T_WL
                covered |= selected
        return matrices if covered.all() else None


class OnlineEngine:
    def __init__(self, config=None, source_mode='live', experimental_pose_path=None):
        if source_mode not in ('live', 'recorded_pcap', 'simulated_pcap'):
            raise ValueError('source mode must be live, recorded_pcap or simulated_pcap')
        if experimental_pose_path and source_mode != 'simulated_pcap':
            raise ValueError('recorded poses require explicit simulated_pcap mode')
        allowed = {f.name for f in fields(ClearanceConfig)}
        if config is None:
            config = playback_config()
            if source_mode in ('live', 'recorded_pcap'):
                config = replace(config,confirmed_background_path=None,confirmed_measurement_scope_path=None)
        elif isinstance(config, dict):
            if set(config)-allowed:
                raise ValueError('unknown clearance config fields')
            config = ClearanceConfig(**config)
        if source_mode == 'live' and (config.above_rail_measurement_only or config.scanline_object_proposals
                                     or config.body_fragment_proposals or config.qualified_history_reconciliation
                                     or config.raw_history_identity_support or config.qualified_history_owner_keys
                                     or config.observable_instance_seeding or config.stable_instance_labels
                                     or config.current_observation_gating or config.complete_current_reconciliation
                                     or config.native_shared_edge_evidence or config.above_rail_uncertainty
                                     or config.recorded_playback_continuity or config.stop_window_fusion):
            raise ValueError('replay-only features cannot enter live measurement')
        if config.current_observation_gating and not (config.observable_instance_seeding and config.qualified_instance_ownership):
            raise ValueError('current observation gating requires observable seeding and qualified ownership')
        if config.complete_current_reconciliation and not (config.current_instance_reconciliation and
                config.qualified_instance_ownership and config.qualified_history_reconciliation):
            raise ValueError('complete current reconciliation requires qualified current/history ownership')
        if config.native_shared_edge_evidence and not (config.qualified_object_cores and
                config.surface_object_proposals and config.qualified_instance_ownership and config.current_instance_reconciliation):
            raise ValueError('native shared edge evidence requires qualified current surface ownership')
        if config.above_rail_uncertainty and not (config.above_rail_measurement_only and
                config.qualified_object_cores and config.qualified_instance_ownership):
            raise ValueError('above-rail uncertainty requires qualified rail-plane measurement scope')
        self.config, self.source_mode = config, source_mode
        self.pose_path = experimental_pose_path
        self.pose_document = None
        if self.pose_path:
            import json
            from pathlib import Path
            content = Path(self.pose_path).read_bytes()
            self.pose_document = json.loads(content.decode('utf-8-sig'))
            self.pose_map_id = hashlib.sha256(content).hexdigest()
        self.epoch = None
        self.last_identity = None
        self.engine = None

    def _reset(self, epoch):
        self.epoch = epoch
        self.explicit_poses = SuppliedPoses(self.config.history_max_scans)
        self.recorded_rows = []
        self.engine = ReplayEngine(self.config, 'tracked', None)
        from .motion import LiveLidarPoses
        self.live_poses = LiveLidarPoses(self.config.history_max_scans,
            adaptive=self.config.adaptive_motion_compensation)

    def _recorded_poses(self, frame):
        from .motion import RecordedPoses
        doc = self.pose_document
        matrices = {row['frame']: row['matrix'] for row in doc['poses']}
        diagnostics = {row['frame']:row for row in doc['diagnostics']}
        diagnostic = diagnostics.get(frame.sequence, {})
        matrix = np.asarray(matrices.get(frame.sequence, np.full((4,4),np.nan)), dtype=float)
        timestamp = diagnostic.get('timestamp')
        usable = (timestamp is not None and abs(float(timestamp)-frame.ref_time_s) <= 1e-6 and
                  valid_matrix(matrix) and diagnostic.get('rank') == 6 and
                  not diagnostic.get('insufficient_correspondences', False))
        self.recorded_rows.append(dict(sequence=frame.sequence,time=frame.ref_time_s,
            start=frame.scan_span_s[0],end=frame.scan_span_s[1],matrix=matrix,usable=usable,
            rank=diagnostic.get('rank')))
        self.recorded_rows = self.recorded_rows[-self.config.history_max_scans:]
        return RecordedPoses(self.recorded_rows, frame.clock_id,self.pose_map_id)

    def process(self, request, epoch=0):
        started = time.perf_counter()
        xyz = _array(request['xyz'], '<f8', (-1,3))
        sequence, timestamp = int(request['sequence']), float(request['device_time_s'])
        session, clock = request['session_id'], request['clock_id']
        times = (_array(request['point_times'], '<f8', (-1,))
                 if request.get('point_times') is not None else None)
        rings = (_array(request['rings'], '<i4', (-1,))
                 if request.get('rings') is not None else None)
        if times is not None and len(times) != len(xyz):
            raise ValueError('point time length mismatch')
        input_points = len(xyz)
        native_indices = np.arange(input_points)
        if rings is not None and len(rings) != input_points:
            raise ValueError('ring length mismatch')
        if self.config.sensor_max_range_m is not None:
            # Crop, never decimate. Retain every real in-range boundary return
            # and its ORIGINAL native index; the source PCAP/cloud is untouched.
            inside = np.isfinite(xyz).all(axis=1) & (np.einsum('ij,ij->i',xyz,xyz) <=
                       self.config.sensor_max_range_m**2+1e-12)
            native_indices = native_indices[inside]
            xyz = xyz[inside]
            times = times[inside] if times is not None else None
            rings = rings[inside] if rings is not None else None
        refs = tuple(PointRef(sequence, int(i), float(t) if times is not None else None)
                     for i,t in zip(native_indices,times if times is not None else [None]*len(xyz)))
        span = tuple(request.get('scan_span_s', (timestamp,timestamp)))
        frame = CloudFrame(session, sequence, timestamp, clock, xyz, refs, rings, span,
                           diagnostics={'source_mode':self.source_mode,'online':True,
                                        'source_sha256':request.get('source_sha256')})
        validate_frame(frame)
        identity = (session,clock,sequence,timestamp)
        reset = (self.last_identity is not None and
                 (identity[:2] != self.last_identity[:2] or sequence <= self.last_identity[2] or
                  timestamp <= self.last_identity[3]))
        if self.engine is None or epoch != self.epoch or reset:
            self._reset(epoch)
        pose = request.get('pose')
        if pose is not None:
            self.explicit_poses.add(pose, frame)
            self.engine.poses = self.explicit_poses
            pose_scope = 'explicit_supplied_pose'
        elif self.pose_document is not None:
            self.engine.poses = self._recorded_poses(frame)
            pose_scope = 'recorded_experimental_simulation_only'
        elif self.config.live_motion_estimation:
            self.engine.poses = self.live_poses.update(frame)
            pose_scope = 'live_lidar_relative_experimental'
        else:
            self.engine.poses = None
            pose_scope = 'unavailable_uncompensated'
        update,layers,results = self.engine.step(frame)
        packet = build_packet(self.engine.measurement_frame,update,layers,results,self.config,
                              selection=self.engine.surface_tracker)
        if (self.source_mode in ('live', 'recorded_pcap') and self.config.live_motion_estimation and
                (self.engine.measurement_frame.motion_status != 'deskewed_experimental' or
                 (pose_scope == 'live_lidar_relative_experimental' and
                  not self.live_poses.diagnostics.get('usable',False)))):
            # Keep genuine current geometry visible, but never present a raw
            # startup/degenerate scan as a compensated, confirmed measurement.
            for measurement in packet['measurements']:
                measurement['uncertain'] = True
                measurement['flags'] = list(dict.fromkeys(
                    measurement['flags']+['relative_motion_unavailable']))
        for name, xyz_display in packet['_display'].items():
            packet['_display'][name] = dict(data=xyz_display.tobytes(),count=len(xyz_display),
                                           dtype='little-float32-xyz')
        packet.update(calculation='online_current_cloud',session_id=session,epoch=epoch,
            source_mode=self.source_mode,pose_scope=pose_scope,
            input_points=input_points,retained_points=len(xyz),
            motion_status=self.engine.measurement_frame.motion_status,status='completed',
            absolute_accuracy_verified=False,live_0_2s_verified=False,
            timing_ms=dict(self.engine.timings, packet_total=(time.perf_counter()-started)*1000.,
                           native_pack=request.get('native_pack_ms',0.),
                           relative_pose=self.live_poses.diagnostics.get('elapsed_ms',0.)))
        packet['relative_pose_diagnostics'] = dict(self.live_poses.diagnostics)
        packet['native_pack_routes'] = request.get('native_pack_routes',{})
        if self.config.adaptive_motion_compensation:
            packet['motion_translation_model']=self.engine.measurement_frame.diagnostics.get('translation_model')
            packet['motion_curve_check_error_m']=self.engine.measurement_frame.diagnostics.get('acceleration_check_error_m')
        self.last_identity = identity
        return packet
