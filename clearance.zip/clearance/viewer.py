"""Evidence plots; display selection is never a measurement input."""
from pathlib import Path
import json
import html
from collections import Counter
import numpy as np


def plot_frame(frame, update, layers, results, output):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.style.use('dark_background')
    fig, axes = plt.subplots(1, 2, figsize=(13, 6), constrained_layout=True)
    if update.model is not None:
        segment = update.model.segments[0]
        tangent = segment.end_L-segment.start_L
        tangent /= np.linalg.norm(tangent)
        basis = np.stack([segment.across_L, tangent, segment.normal_L])
        origin = segment.start_L
    else:
        # Airy sideways cart mounting: native +Z forward; +X approximately up.
        basis = np.array([[0,1,0], [0,0,1], [1,0,0.]])
        origin = np.zeros(3)
    def local(xyz):
        return (np.asarray(xyz)-origin)@basis.T
    coordinates = local(frame.xyz_L)
    for layer, color, size in (('ground', '#46516b', 1), ('rails', '#58c7ff', 2),
                               ('object', '#b9f887', 2), ('ambiguous', '#ffac57', 2)):
        indices = layers.indices.get(layer, np.empty(0, dtype=int))
        if len(indices) > 15000:
            indices = indices[np.linspace(0, len(indices)-1, 15000).astype(int)]
        for axis, yindex in zip(axes, (1, 2)):
            axis.scatter(coordinates[indices, 0], coordinates[indices, yindex], s=size,
                         c=color, alpha=.65, linewidths=0, label=layer)
    if update.model is not None:
        for segment in update.model.segments:
            center = local([segment.start_L, segment.end_L])
            for axis, yindex in zip(axes, (1, 2)):
                axis.plot(center[:, 0], center[:, yindex], color='#ed7fff', lw=2)
    by_id = {c.candidate_id: c for c in layers.candidates}
    # Only eight labels are placed to avoid hiding the cloud. All candidates,
    # including singletons and low surfaces, remain in JSON/CSV.
    selected = [r for r in results if r.observed_evidence is not None]
    selected.sort(key=lambda r: len(by_id[r.candidate_id].point_indices), reverse=True)
    for number, result in enumerate(selected[:8]):
        e = result.observed_evidence
        line = local([e.projected_L, e.foot_L])
        for axis, yindex in zip(axes, (1, 2)):
            axis.plot(line[:, 0], line[:, yindex], color='#fff46e', lw=1.4)
        point = local(e.point_L)
        axes[1].scatter(*point[[0,2]], c='#fff46e', s=25, marker='x')
        axes[0].annotate('%d: %.3f m' % (number+1, result.observed_min_distance_m),
                         line[0, :2], xytext=(4, 5+number%2*9), textcoords='offset points', fontsize=8)
    axes[0].set(xlabel='Across-track (m)', ylabel='Along-track from supported start (m)', title='Track-plane projection')
    axes[1].set(xlabel='Across-track (m)', ylabel='Height above track plane (m)', title='Front section: original returns')
    for axis in axes:
        axis.set_aspect('equal', adjustable='box')
        axis.grid(alpha=.15)
        axis.legend(loc='upper right', fontsize=8)
    # Only the result view hides overhead context. It remains in candidate
    # logs and is not silently removed from distance calculations.
    axes[1].set_ylim(-.5,3.5)
    fig.suptitle('Frame %d | %s | %s | raw=%d, candidates=%d\nObserved surfaces, not semantic equipment recognition or absolute accuracy'
                 % (frame.sequence, update.mode, frame.motion_status, len(frame.xyz_L), len(results)), fontsize=11)
    fig.savefig(output, dpi=150)
    plt.close(fig)
    return Path(output)


def _records(path):
    with Path(path).open(encoding='utf-8-sig') as stream:
        for line in stream:
            if line.strip():
                yield json.loads(line)


def _stats(values):
    values = [v for v in values if v is not None and np.isfinite(v)]
    return {'median':float(np.median(values)),'p95':float(np.percentile(values,95)),
            'max':float(max(values))} if values else {'median':None,'p95':None,'max':None}


def summarize_run(run_dir):
    root = Path(run_dir)
    frames = [_light_frame(r) for r in _records(root/'frames.jsonl')]
    by_seq = {r['sequence']:r for r in frames}
    if len(by_seq)!=len(frames):
        raise ValueError('duplicate input frame records')
    counts = Counter(r['mode'] for r in frames)
    flags, fresh, support_diff, nulls = Counter(),set(),[],0
    active_modes = {'observed_dual','compensated_dual','estimated_single','predicted_track'}
    candidates = Counter()
    for r in _records(root/'clearances.jsonl'):
        seq = r['sequence'];candidates[seq]+=1
        flags.update(r.get('flags',()))
        raw,supported = r.get('observed_min_distance_m'),r.get('supported_min_distance_m')
        evidence = r.get('observed_evidence')
        if (seq in by_seq and by_seq[seq]['mode'] in active_modes and raw is not None and
                evidence and evidence.get('point_ref',{}).get('frame') == seq):
            fresh.add(seq)
        nulls += raw is None
        if raw is not None and supported is not None:
            support_diff.append(supported-raw)
    consumed = [r for r in frames if r.get('consumed',True)]
    fresh_rows = [r for r in frames if r['sequence'] in fresh]
    # Paced runs keep original (possibly reset) device times as evidence but
    # use their explicit monotonic playback axis for latency/gap summaries.
    playback_axis = bool(frames) and all('playback_elapsed_s' in r for r in frames)
    time_field = 'playback_elapsed_s' if playback_axis else 'device_time_s'
    first = frames[0][time_field] if frames else 0.
    last = frames[-1][time_field] if frames else first
    fresh_times = [r[time_field] for r in fresh_rows]
    boundaries = [first]+fresh_times+[last]
    max_gap = max((b-a for a,b in zip(boundaries,boundaries[1:])),default=0.)
    timing_stages = {k:_stats([r.get('timing_ms',{}).get(k) for r in consumed])
                     for k in {k for r in consumed for k in r.get('timing_ms',{})}}
    source = json.loads((root/'source.json').read_text(encoding='utf-8-sig'))
    timing = json.loads((root/'timing.json').read_text(encoding='utf-8-sig'))
    return {'run_dir':str(root.resolve()),'mode':timing.get('mode'),
        'paced':timing.get('paced',False),'input_frames':len(frames),'consumed_frames':len(consumed),
        'fresh_distance_frames':len(fresh),'fresh_rate_all_input':len(fresh)/len(frames) if frames else 0.,
        'fresh_rate_consumed':len(fresh)/len(consumed) if consumed else 0.,
        'dual_observed_frames':sum(r['mode'] in ('observed_dual','compensated_dual') for r in consumed),
        'current_dual_frames':sum(r['mode']=='observed_dual' for r in consumed),
        'compensated_dual_frames':sum(r['mode']=='compensated_dual' for r in consumed),
        'estimated_reference_fresh_frames':sum(r['mode'] in ('estimated_single','predicted_track') for r in fresh_rows),
        'mode_counts':dict(counts),'initialization_duration_s':fresh_times[0]-first if fresh_times else None,
        'max_fresh_gap_device_s':max_gap,'fresh_gap_time_axis':time_field,
        'candidate_count':sum(candidates.values()),
        'null_candidate_distances':nulls,'result_flag_counts':dict(flags),'support_difference_m':_stats(support_diff),
        'stage_ms':timing_stages,'result_age_s':_stats([r.get('result_age_s') for r in consumed]),
        'rail_feature_separation_m':_stats([r.get('track',{}).get('observed_gauge_m')
            for r in consumed if r.get('track')]),
        'rail_fit_residual_p95_m':_stats([r.get('track_diagnostics',{}).get('fit_residual_p95_m') for r in consumed]),
        'matched_upstream_component_estimate_ms':_stats([r.get('matched_component_estimate_ms') for r in consumed]),
        'reacquired_dual_sequences':[b['sequence'] for a,b in zip(frames,frames[1:])
                if a['mode'] not in ('observed_dual','compensated_dual') and
                   b['mode'] in ('observed_dual','compensated_dual')],
        'absolute_accuracy_verified':False,'live_0_2s_verified':False,'source':source,
        'skipped_sequences':[r['sequence'] for r in frames if not r.get('consumed',True)],
        'human_semantic_annotation_count':0}


def _compact_track(track):
    if not track:
        return None
    return {k:v for k,v in track.items() if k!='diagnostics' and k!='segments'} | {
        'segments':[{k:v for k,v in s.items() if k!='observation_refs'} for s in track['segments']]}


def _light_frame(row):
    track = row.get('track')
    diagnostics = track.get('diagnostics',{}) if track else {}
    return dict(row,track=_compact_track(track),track_diagnostics={k:diagnostics[k] for k in (
        'observer','fit_residual_p95_m','measurement_flags','history_sequences','ground_plane') if k in diagnostics})


def build_viewer(run_dir,output):
    root,output = Path(run_dir),Path(output)
    if output.exists():
        raise FileExistsError('refusing existing viewer')
    folder = output.with_name(output.stem+'-data')
    folder.mkdir(parents=True,exist_ok=False)
    frames = [_light_frame(r) for r in _records(root/'frames.jsonl')]
    by_seq = {r['sequence']:r for r in frames}
    # Native logs are sequential. Spool each scan without loading every
    # candidate of the complete recording into memory at once.
    current,results = None,[]
    written = set()
    def write(seq,items):
        row = by_seq[seq]
        snapshot = None
        path = root/('geometry-%d.npz' % seq)
        if path.is_file():
            with np.load(path) as arrays:
                snapshot = {k:arrays[k].tolist() for k in arrays.files}
                snapshot['bits']={'raw':1,'ground':2,'rails':4,'body':8,'object':16,'ambiguous':32}
        payload = {'row':row,'results':items,'snapshot':snapshot}
        (folder/('frame-%d.js'%seq)).write_text('window.acceptFrame('+str(seq)+','+
            json.dumps(payload,separators=(',',':'),allow_nan=False).replace('<','\\u003c')+');',encoding='utf-8')
        written.add(seq)
    for result in _records(root/'clearances.jsonl'):
        seq = result['sequence']
        if current is not None and seq!=current:
            write(current,results);results=[]
        current = seq;results.append(result)
    if current is not None:
        write(current,results)
    for seq in by_seq.keys()-written:
        write(seq,[])
    summary = summarize_run(root)
    # Template is an offline, dependency-free canvas viewer. Records and
    # evidence are read-only; layer selection changes only paint visibility.
    template = Path(__file__).with_name('viewer_template.html').read_text(encoding='utf-8')
    options = ''.join('<option value="%d">%d | %s%s</option>' %
        (r['sequence'],r['sequence'],html.escape(r['mode']),
         ' | 点云快照' if (root/('geometry-%d.npz'%r['sequence'])).is_file() else '') for r in frames)
    page = template.replace('__FRAMES__',options).replace('__DATA_FOLDER__',folder.name)
    page = page.replace('__SUMMARY__',html.escape(json.dumps(summary,ensure_ascii=False,indent=2)))
    output.write_text(page,encoding='utf-8')
    return output


def write_report(run_dirs,output):
    output = Path(output)
    if output.exists():
        raise FileExistsError('refusing existing report')
    summaries = [summarize_run(p) for p in run_dirs]
    lines = ['# 轨旁物体到中心线最近距离：离线核心实验',
        '', '本报告使用所有输入帧；失败、预测、历史快照及跳帧不从分母删除。',
        '', '未验证绝对精度；未验收实车高速 80–300 rpm 或完整 0.2 s 链路。无独立位置真值、设备边界标注、GPS 同步与安装外参验收。',
        '', '“新距离”仅指本扫描真实返回到当前参考系下模型的横向投影距离。它不是类别识别正确率，也不是被遮挡物体完整边界的物理最小值。',
        '', '| 回放 | 输入 / 消费 | 当前双轨 / 补偿双轨 | 新距离帧 | 计算 median / P95 ms | 最大新值间隔 s |',
        '|---|---:|---:|---:|---:|---:|']
    for s in summaries:
        c = s['stage_ms'].get('compute',{})
        lines.append('| %s | %d / %d | %d / %d | %d (%.1f%%输入) | %s / %s | %.3f |' %
          (Path(s['run_dir']).name,s['input_frames'],s['consumed_frames'],s['current_dual_frames'],
           s['compensated_dual_frames'],s['fresh_distance_frames'],100*s['fresh_rate_all_input'],
           str(round(c.get('median'),1)) if c.get('median') is not None else '未记录',
           str(round(c.get('p95'),1)) if c.get('p95') is not None else '未记录',s['max_fresh_gap_device_s']))
    lines += ['', '## 当前边界与核查', '',
        '- 未删除不确定低矮边缘：近地碎点、疑似轨道残留可能进入候选，nearest_ambiguous_surface 不是已确认设备距离。',
        '- 所有分量均为临时候选片段，不能直接当作信号机、箱体或统一设备 ID；大列车表面不因尺寸删除。',
        '- 实验位姿使用过去局部地图、IMU 旋转及已观察扫描速度近似；rank=6 不是精度合格证明。',
        '- 起始 0–5 帧原始扫描仍计入分母，位姿源未虚构标定过渡扫描；输入解码裁剪完整性尚未认证。',
        '- paced 是预计算位姿查表的独立计算进程测试。上游逐帧配准另外列出；匹配同帧组件估计不是现场端到端验收。',
        '- 计算与输出耗时分开；并发顺序回放可能争用 CPU，不能把它们当独占硬件基准。',
        '- 视觉快照仅供几何核查；没有人工语义真值，不报告设备识别率或厘米精度。',
        '', '## 完整统计与来源', '']
    for s in summaries:
        lines += ['### '+Path(s['run_dir']).name,'','```json',json.dumps(s,ensure_ascii=False,indent=2),'```','']
    output.write_text('\n'.join(lines),encoding='utf-8')
    return output
