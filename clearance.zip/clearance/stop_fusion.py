"""Stationary-candidate replay fusion; source window is explicit, never a current scan."""
from dataclasses import replace
import time
import uuid
import numpy as np
from .protocol import ClearanceConfig,CloudFrame,PointRef,SceneLayers,TrackUpdate,validate_frame,measurement_model
from .online import _array
from .motion import LiveLidarPoses,deskew_frame,usable_pose
from .stop_window import StopWindow
from .track import observe_track
from .scene import extract_scene
from .objects import refine_objects,qualified_core_indices
from .measure import measure_candidates
from .rsview_cache import build_packet,FORMAT


def _records(keys):
    return np.ascontiguousarray(keys,dtype='<i8').view([('x','<i8'),('y','<i8'),('z','<i8')]).reshape(-1)


def measure_window(window,track,layers,config,check_budget=None):
    """Literal raw minima per geometric owner, independent of display voxel representatives."""
    geometry=window.geometry()
    keys=geometry.diagnostics['voxel_keys']
    records=_records(keys);order=np.argsort(records);sorted_records=records[order]
    seen=geometry.diagnostics['scan_support_counts']
    counts=np.zeros(len(keys),dtype=int)
    for candidate in layers.candidates:counts[candidate.point_indices]+=1
    membership=[]
    for candidate in layers.candidates:
        member=np.zeros(len(keys),dtype=bool);member[candidate.point_indices]=True
        supported=np.zeros(len(keys),dtype=bool);supported[candidate.supported_indices]=True
        ambiguous=np.zeros(len(keys),dtype=bool)
        ambiguous[np.asarray(candidate.diagnostics.get('ambiguous_indices',()),dtype=int)]=True
        supported&=(seen>=3)&(counts==1)&~ambiguous
        membership.append((candidate,member,supported,ambiguous|(counts>1)))
    aggregate={}
    for raw in window.iter_aligned():
        if check_budget is not None:check_budget()
        raw_keys=_records(np.floor(raw.xyz_L/window.voxel_m).astype(np.int64))
        positions=np.searchsorted(sorted_records,raw_keys)
        valid=positions<len(keys)
        clipped=np.minimum(positions,max(0,len(keys)-1))
        valid&=sorted_records[clipped]==raw_keys
        rows=order[clipped]
        candidates=[]
        for candidate,member,supported,ambiguous in membership:
            indices=np.flatnonzero(valid&member[rows])
            if not len(indices):continue
            support=np.flatnonzero(valid&supported[rows])
            diagnostics={k:v for k,v in candidate.diagnostics.items() if k not in
                ('ambiguous_indices','support_neighbors','support_neighbor_indices','support_neighbor_valid','temporal_support_refs')}
            diagnostics['ambiguous_indices']=np.flatnonzero(valid&member[rows]&ambiguous[rows])
            candidates.append(replace(candidate,point_indices=indices,supported_indices=support,diagnostics=diagnostics))
        if not candidates:continue
        # Cloud time is the window model's reference time; refs retain real scan
        # timestamps and original native indices. Coordinates use the fixed window frame.
        frame=replace(raw,sequence=geometry.sequence,ref_time_s=geometry.ref_time_s,scan_span_s=geometry.scan_span_s)
        chunk_layers=SceneLayers({},tuple(candidates),layers.counts,{})
        for result in measure_candidates(frame,track,chunk_layers,config):
            old=aggregate.get(result.candidate_id)
            if old is None:aggregate[result.candidate_id]=result;continue
            observed=(result if result.observed_min_distance_m is not None and
                (old.observed_min_distance_m is None or result.observed_min_distance_m<old.observed_min_distance_m) else old)
            supported=(result if result.supported_min_distance_m is not None and
                (old.supported_min_distance_m is None or result.supported_min_distance_m<old.supported_min_distance_m) else old)
            aggregate[result.candidate_id]=replace(observed,supported_min_distance_m=supported.supported_min_distance_m,
                supported_evidence=supported.supported_evidence)
    # Cell occupancy is not support for every return in that cell. Verify the
    # selected actual boundary against three distinct scans within the configured
    # experimental repeatability radius; retain any unsupported closer raw value.
    output=[]
    for result in aggregate.values():
        evidence=result.supported_evidence
        if evidence is None:output.append(result);continue
        # A nearby competing/unsupported cell is not evidence for this owner.
        supported=next(item[2] for item in membership if item[0].candidate_id==result.candidate_id)
        witnesses=[]
        for raw in window.iter_aligned():
            if check_budget is not None:check_budget()
            raw_records=_records(np.floor(raw.xyz_L/window.voxel_m).astype(np.int64))
            pos=np.searchsorted(sorted_records,raw_records);clipped=np.minimum(pos,len(keys)-1)
            eligible=(pos<len(keys))&(sorted_records[clipped]==raw_records)&supported[order[clipped]]
            distance=np.einsum('ij,ij->i',raw.xyz_L-evidence.point_L,raw.xyz_L-evidence.point_L)
            eligible&=distance<=config.stop_distance_tolerance_m**2+1e-12
            eligible_rows=np.flatnonzero(eligible)
            if len(eligible_rows):witnesses.append(raw.refs[int(eligible_rows[np.argmin(distance[eligible_rows])])])
            if len(witnesses)>=3:break
        if len(witnesses)<3:
            result=replace(result,supported_evidence=None,supported_min_distance_m=None,
                flags=tuple(dict.fromkeys(result.flags+('nearest_return_without_support','boundary_not_repeatable_in_window'))))
        else:
            result=replace(result,supported_evidence=replace(evidence,support_refs=tuple(witnesses),
                diagnostics=dict(evidence.diagnostics,window_independent_support_scans=len(witnesses))))
        output.append(result)
    return tuple(output)


class StopFusionEngine:
    def __init__(self,config=None,source_mode='recorded_pcap',experimental_pose_path=None,poses=None,clock=time.monotonic):
        if source_mode!='recorded_pcap' or experimental_pose_path:
            raise ValueError('parking fusion is replay-only, without recorded pose substitution')
        self.config=ClearanceConfig(**config) if isinstance(config,dict) else config or ClearanceConfig(stop_window_fusion=True)
        self.config=replace(self.config,sensor_max_range_m=10.,config_id='rsview-stop-window-beta-v33',
            stop_window_fusion=True,measurement_height_range_m=None,above_rail_measurement_only=True)
        stages=tuple(int(value) for value in self.config.stop_window_stages)
        if not stages or stages[0]<20 or stages!=tuple(sorted(set(stages))) or self.config.stop_stable_scans<2:
            raise ValueError('parking stages must start at 20 distinct scans and strictly increase')
        if not all(np.isfinite(value) and value>0 for value in (self.config.stop_translation_rate_mps,
            self.config.stop_rotation_rate_degps,self.config.stop_anchor_shift_m,
            self.config.stop_anchor_angle_deg,self.config.stop_distance_tolerance_m)):
            raise ValueError('positive finite parking motion/repeatability thresholds required')
        self.stages=stages;self.clock=clock;self.supplied_poses=poses;self.source_mode=source_mode
        self.identity=None;self.last_frame=None;self.last_packet=None
        self._reset()

    def _reset(self):
        cfg=self.config
        self.window=StopWindow(10.,cfg.stop_window_voxel_m,cfg.stop_window_budget_s,
            cfg.stop_window_byte_budget,cfg.stop_window_point_budget,cfg.stop_window_map_budget,self.clock)
        self.pose_tracker=self.supplied_poses or LiveLidarPoses(6,adaptive=True)
        self.pending=[];self.previous_pose=None;self.state='awaiting_stationary'
        self.stage_scans=0;self.confirmed=False;self.previous_distances={};self.region_ids={};self.next_region=1
        self.last_packet=None
        self.operation_started=None
        self.operation_token=uuid.uuid4().hex

    def _frame(self,request):
        xyz=_array(request['xyz'],'<f8',(-1,3));count=len(xyz)
        times=_array(request['point_times'],'<f8',(-1,)) if request.get('point_times') is not None else None
        rings=_array(request['rings'],'<i4',(-1,)) if request.get('rings') is not None else None
        if times is None or len(times)!=count or (rings is not None and len(rings)!=count):
            raise ValueError('parking fusion needs native per-point timestamps and aligned buffers')
        valid=np.isfinite(xyz).all(axis=1)&(np.einsum('ij,ij->i',np.nan_to_num(xyz),np.nan_to_num(xyz))<=100.+1e-12)
        valid&=np.einsum('ij,ij->i',np.nan_to_num(xyz),np.nan_to_num(xyz))>1e-18
        indices=np.flatnonzero(valid);sequence=int(request['sequence']);timestamp=float(request['device_time_s'])
        frame=CloudFrame(request['session_id'],sequence,timestamp,request['clock_id'],xyz[indices],
            tuple(PointRef(sequence,int(i),float(times[i])) for i in indices),rings[indices] if rings is not None else None,
            tuple(request.get('scan_span_s',(timestamp,timestamp))),diagnostics={'source_sha256':request.get('source_sha256')})
        validate_frame(frame)
        return frame

    def _budget(self):
        if self.window.expired() or (self.operation_started is not None and
            self.clock()-self.operation_started>self.config.stop_window_budget_s):
            raise TimeoutError('parking measurement total time budget exceeded')

    def _empty(self,frame):
        rows=np.linspace(0,len(frame.xyz_L)-1,min(len(frame.xyz_L),20000),dtype=int) if len(frame.xyz_L) else np.empty(0,dtype=int)
        return dict(format=FORMAT,sequence=frame.sequence,device_time_s=frame.ref_time_s,
            session_id=frame.session_id,clock_id=frame.clock_id,status='completed',mode='initializing',
            motion_status=frame.motion_status,config_id=self.config.config_id,centerline=[],measurements=[],
            secondary_measurements=[],candidate_count=0,retained_points=len(frame.xyz_L),
            annotation_region_count=0,measurement_region_count=0,scene_diagnostics={},layer_counts={},
            _display={'object':np.asarray(frame.xyz_L[rows],dtype='<f4')})

    def _stage(self):
        self._budget();geometry=self.window.geometry();keys=geometry.diagnostics['voxel_keys']
        local=np.flatnonzero(np.einsum('ij,ij->i',geometry.xyz_L,geometry.xyz_L)<=25.+1e-12)
        rail_frame=replace(geometry,xyz_L=geometry.xyz_L[local],refs=tuple(geometry.refs[int(i)] for i in local),
            rings=None if geometry.rings is None else geometry.rings[local])
        track=observe_track(rail_frame,None,self.config)
        layers=extract_scene(geometry,track,[],self.config)
        layers=refine_objects(geometry,track,layers,self.config)
        candidates=[];new_regions={};used=set()
        for candidate in layers.candidates:
            occupied=frozenset(tuple(k) for k in keys[candidate.point_indices])
            scores=[(len(occupied&previous)/max(1,len(occupied|previous)),name)
                    for name,previous in self.region_ids.items() if name not in used]
            score,name=max(scores,default=(0.,None))
            if score<.5:name='W%d'%self.next_region;self.next_region+=1
            used.add(name);new_regions[name]=occupied
            diagnostics=dict(candidate.diagnostics,object_id=name,display_id=name,
                object_association='window_geometric_region',display_association='window_geometric_region',
                object_identity_semantics='parking geometric region, not semantic equipment identity')
            # Whole uncertain roles remain unconfirmed even in a dense map.
            if not len(qualified_core_indices(geometry,candidate,self.config)):
                diagnostics['object_association']='role_unresolved'
            candidates.append(replace(candidate,diagnostics=diagnostics))
        self.region_ids=new_regions;layers=replace(layers,candidates=tuple(candidates))
        results=measure_window(self.window,track,layers,self.config,self._budget)
        packet=build_packet(geometry,track,layers,results,self.config)
        region_names={candidate.candidate_id:candidate.diagnostics['object_id'] for candidate in candidates}
        for item in packet['measurements']:
            item['object_id']=region_names[item['candidate_id']]
            item['display_id']=item['object_id']
        distances={m['object_id']:m['distance_m'] for m in packet['measurements'] if not m['uncertain']}
        stable=bool(distances) and distances.keys()==self.previous_distances.keys() and all(
            abs(value-self.previous_distances[name])<=self.config.stop_distance_tolerance_m for name,value in distances.items())
        self.previous_distances=distances;self.stage_scans=self.window.scan_count
        self.confirmed=bool(stable and measurement_model(track) is not None)
        self.state=('complete' if self.confirmed and self.stage_scans>=self.stages[-1] else
                    'stage_converged' if self.confirmed else
                    'stage_limit_unconfirmed' if self.stage_scans>=self.stages[-1] else 'stage_preview')
        for item in packet['measurements']:
            item['uncertain']=bool(item['uncertain'] or not self.confirmed)
            item['measurement_basis']='stop_window'
            item['object_identity_semantics']='parking geometric region, not a verified equipment identity'
            item['point_age_s']=max(0.,geometry.ref_time_s-item['source_time_s']) if item['source_time_s'] is not None else None
            item['label']=('Window ' if not item['uncertain'] else 'Window pending ')+(item.get('object_id') or item['candidate_id'])+' %.3f m'%item['distance_m']
        self._budget()
        packet['display_window_last_sequence']=geometry.sequence
        packet['display_window_source_frames']=self.window.progress()['source_frames']
        self.last_packet=packet

    def process(self,request,epoch=0):
        started=self.clock();frame=self._frame(request)
        identity=(frame.session_id,frame.clock_id,int(epoch))
        reset=(identity!=self.identity or self.last_frame is not None and
            (frame.sequence<self.last_frame.sequence or frame.ref_time_s<self.last_frame.ref_time_s or
             frame.ref_time_s-self.last_frame.ref_time_s>.6+1e-9))
        if reset:self._reset();self.last_frame=None
        self.identity=identity
        if self.operation_started is None:self.operation_started=self.clock()
        expired=self.clock()-self.operation_started>self.config.stop_window_budget_s
        duplicate=self.last_frame is not None and (frame.sequence,frame.ref_time_s)==(
            self.last_frame.sequence,self.last_frame.ref_time_s)
        pose_diagnostics={}
        # Capture deadlines do not disable validation of an already completed
        # window. Any subsequent motion/unusable pose must invalidate it.
        if not duplicate and (not expired or self.state=='complete'):
            provider=self.pose_tracker.update(frame);pose_diagnostics=dict(self.pose_tracker.diagnostics)
            pose=provider.sample(frame.ref_time_s,frame.scan_span_s[1]) if provider is not None else None
            deskewed=deskew_frame(frame,provider)
            usable=usable_pose(pose,frame.ref_time_s,frame.clock_id,frame.scan_span_s[1]) and deskewed.motion_status=='deskewed_experimental'
            stationary=bool(usable)
            if usable and self.previous_pose is not None:
                old,time_s=self.previous_pose;dt=frame.ref_time_s-time_s
                delta=np.linalg.inv(old)@pose.T_WL
                angle=np.degrees(np.arccos(np.clip((np.trace(delta[:3,:3])-1)*.5,-1.,1.)))
                stationary=dt>0 and np.linalg.norm(delta[:3,3])/dt<=self.config.stop_translation_rate_mps and angle/dt<=self.config.stop_rotation_rate_degps
            if stationary and self.window.reference_pose is not None:
                delta=np.linalg.inv(self.window.reference_pose)@pose.T_WL
                angle=np.degrees(np.arccos(np.clip((np.trace(delta[:3,:3])-1)*.5,-1.,1.)))
                stationary=np.linalg.norm(delta[:3,3])<=self.config.stop_anchor_shift_m and angle<=self.config.stop_anchor_angle_deg
            if not stationary:
                self.window.clear();self.pending=[];self.last_packet=None;self.stage_scans=0;self.confirmed=False
                self.previous_distances={};self.region_ids={};self.state='motion_detected' if usable else 'awaiting_stationary'
            else:
                if self.window.scan_count==0:
                    self.pending.append((deskewed,pose.T_WL.copy()))
                    if len(self.pending)>=self.config.stop_stable_scans:
                        for candidate,matrix in self.pending:
                            if not self.window.add(candidate,matrix):break
                        self.pending=[]
                elif self.state not in ('complete','stage_limit_unconfirmed'):self.window.add(deskewed,pose.T_WL)
                if self.window.reason in ('capacity_reached','time_budget_exceeded'):
                    self.state=self.window.reason;self.confirmed=False
                elif self.window.scan_count in self.stages and self.window.scan_count!=self.stage_scans:
                    try:self._stage()
                    except TimeoutError:self.state='time_budget_exceeded';self.confirmed=False
                elif self.window.scan_count and self.stage_scans==0:self.state='collecting'
            self.previous_pose=(pose.T_WL.copy(),frame.ref_time_s) if usable else None
            self.last_frame=frame
        if (self.window.expired() or expired) and self.state!='complete':
            self.state='time_budget_exceeded';self.confirmed=False
        packet=dict(self.last_packet) if self.last_packet is not None else self._empty(frame)
        packet['measurements']=[dict(item) for item in packet['measurements']]
        if self.state in ('capacity_reached','time_budget_exceeded'):
            for item in packet['measurements']:item['uncertain']=True
        packet.update(sequence=frame.sequence,device_time_s=frame.ref_time_s,session_id=frame.session_id,
            clock_id=frame.clock_id,epoch=int(epoch),status='completed',source_mode='recorded_pcap',
            measurement_basis='stop_window',current_scan_measurement=False,calculation='stop_window_replay',
            pose_scope='stop_window_relative_experimental',retained_points=len(frame.xyz_L),
            scope=dict(sensor_max_range_m=10.,track_reference_radius_m=5.),relative_pose_diagnostics=pose_diagnostics,
            stop_window=dict(self.window.progress(),state=self.state,stage_scans=self.stage_scans,confirmed=self.confirmed,
                operation_token=self.operation_token,budget_s=self.config.stop_window_budget_s,
                elapsed_s=max(0.,self.clock()-self.operation_started),capture_elapsed_s=self.window.elapsed_s,
                checkpoints=list(self.stages),stationary_semantics='experimental LiDAR small-motion candidate, not independent stop truth'),
            absolute_accuracy_verified=False,semantic_one_object_one_label_verified=False,
            motion_status='stop_window_aligned' if self.window.scan_count else 'raw',
            timing_ms={'packet_total':max(0.,self.clock()-started)*1000.})
        packet['_display']={name:(dict(value) if isinstance(value,dict) else
            dict(data=np.asarray(value,dtype='<f4').tobytes(),count=len(value),dtype='little-float32-xyz'))
            for name,value in packet['_display'].items()}
        return packet
