"""Read exact native buffers without applying preview/measurement cropping."""
import hashlib
import json
from pathlib import Path
from collections.abc import Iterator
import numpy as np
from .protocol import CloudFrame, PointRef, validate_frame

DTYPES = {'float': '<f4', 'double': '<f8', 'int': '<i4', 'unsigned int': '<u4',
          'unsigned char': 'u1', 'unsigned short': '<u2', 'short': '<i2'}


def _array(folder: Path, entry: dict, components: int, count: int | None = None) -> np.ndarray:
    if entry['dtype'] not in DTYPES or entry['components'] != components:
        raise ValueError('unsupported native dtype or components')
    tuples = int(entry['tuples'])
    if tuples < 0 or (count is not None and tuples != count):
        raise ValueError('native tuple count mismatch')
    target = (folder/entry['file']).resolve()
    if not target.is_relative_to(folder.resolve()):
        raise ValueError('buffer outside export directory')
    dtype = np.dtype(DTYPES[entry['dtype']])
    if target.stat().st_size != tuples*components*dtype.itemsize:
        raise ValueError('native buffer byte count mismatch: '+entry['file'])
    data = np.fromfile(target, dtype=dtype)
    return data.reshape(tuples, components) if components > 1 else data


def read_native_frames(folder: Path, sequences=None) -> Iterator[CloudFrame]:
    folder = Path(folder)
    manifest = json.loads((folder/'manifest.json').read_text(encoding='utf-8-sig'))
    if manifest.get('error') or manifest.get('byte_order', 'little') != 'little':
        raise ValueError('native export error or unsupported byte order')
    input_id = str(manifest.get('input', folder.resolve()))
    session = hashlib.sha256(input_id.encode('utf-8')).hexdigest()[:16]
    clock = 'lidar-device:'+session
    for row in manifest['frames']:
        if 'xyz' not in row:
            continue  # Export manifests may also list non-exported decoded scans.
        if sequences is not None and row['frame'] not in sequences:
            continue
        xyz = _array(folder, row['xyz'], 3).astype(np.float64)
        attrs = row.get('attributes', {})
        stamps = _array(folder, attrs['timestamp'], 1, len(xyz)) if 'timestamp' in attrs else None
        ring_name = next((k for k in ('Ring', 'ring', 'laser_id') if k in attrs), None)
        rings = _array(folder, attrs[ring_name], 1, len(xyz)).astype(np.int64) if ring_name else None
        good_times = stamps[np.isfinite(stamps)] if stamps is not None else np.empty(0)
        span = (float(good_times.min()), float(good_times.max())) if len(good_times) else tuple(
            float(v) for v in row.get('timestamp_range', (row['step'], row['step'])))
        ref = (span[0]+span[1])/2
        refs = tuple(PointRef(int(row['frame']), i,
                              float(stamps[i]) if stamps is not None and np.isfinite(stamps[i]) else None)
                     for i in range(len(xyz)))
        flags = [] if stamps is not None else ['missing_point_time']
        frame = CloudFrame(session, int(row['frame']), ref, clock, xyz, refs, rings, span,
                           diagnostics={'flags': flags, 'source_folder': str(folder.resolve()),
                                        'raw_points': len(xyz), 'export_step': row['step'],
                                        'native_frame_count': manifest.get('native_frame_count'),
                                        'decoder_crop_report': manifest.get('GetCropDistReturns')})
        validate_frame(frame)
        yield frame


def read_native_metadata(folder):
    """Time/identity only for replay scheduling/pose lookup, not measurement."""
    folder = Path(folder)
    manifest = json.loads((folder/'manifest.json').read_text(encoding='utf-8-sig'))
    if manifest.get('error') or manifest.get('byte_order','little') != 'little':
        raise ValueError('native export error or unsupported byte order')
    session = hashlib.sha256(str(manifest.get('input',folder.resolve())).encode('utf-8')).hexdigest()[:16]
    for row in manifest['frames']:
        if 'xyz' not in row:
            continue
        attr = row.get('attributes',{}).get('timestamp')
        stamps = _array(folder,attr,1,row['xyz']['tuples']) if attr else np.empty(0)
        stamps = stamps[np.isfinite(stamps)]
        span = ([float(stamps.min()),float(stamps.max())] if len(stamps) else
                row.get('timestamp_range',[row['step'],row['step']]))
        span = tuple(float(t) for t in span)
        frame = CloudFrame(session,int(row['frame']),sum(span)/2,'lidar-device:'+session,
            np.empty((0,3)),(),None,span,diagnostics={'metadata_only':True,'source_folder':str(folder.resolve())})
        validate_frame(frame)
        yield frame
