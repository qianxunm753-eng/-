"""Small, frame-exact RSView playback packets; not a live-compute benchmark.

Reuse the existing native export. Never serialize TrackModel observation_refs
or neighbor tables into per-frame logs. Display sampling cannot change minima.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import time
from dataclasses import replace
from collections import Counter

import numpy as np
from scipy.spatial import cKDTree,ConvexHull,QhullError
from .voxel import representatives as voxel_representatives

from .protocol import ClearanceConfig, measurement_model
from ..clearance_overlay import measurement_priority,select_display_measurements

FORMAT = 'rsview-clearance-playback-v1'


def playback_config():
    prior = Path(__file__).resolve().parents[1]/'confirmed_background_1212121_v2.json'
    scope = prior.parent/'confirmed_measurement_scope_1212121.json'
    return replace(ClearanceConfig(), config_id='rsview-region-layout-test-v9',
        sensor_max_range_m=5., measurement_height_range_m=(-.3, 3.5),
        confirmed_background_path=str(prior) if prior.is_file() else None,
        confirmed_measurement_scope_path=str(scope) if scope.is_file() else None)


def _group_display_regions(measurements):
    groups = {}
    for item in measurements:
        key = ('region',item['display_id']) if item.get('display_id') else ('fragment',item['candidate_id'])
        groups.setdefault(key,[]).append(item)
    output = []
    for members in groups.values():
        supported = [m for m in members if m['supported_distance_m'] is not None]
        selected = dict(min(supported or members,key=lambda m:m['distance_m']))
        observed = min(members,key=lambda m:m['observed_min_distance_m'])
        for key in ('observed_min_distance_m','observed_source_index','observed_point_L',
                    'observed_projected_L','observed_foot_L','observed_source_frame','observed_source_time_s'):
            if key in observed:
                selected[key] = observed[key]
        warning = (observed['raw_near_warning'] or
                   observed['observed_min_distance_m'] < selected['distance_m']-1e-9)
        selected.update(point_count=sum(m['point_count'] for m in members),
            raw_near_warning=bool(warning),uncertain=not bool(supported) or bool(warning) or
                any('object_identity_pending' in m['flags'] for m in members),
            member_fragment_ids=list(dict.fromkeys(i for m in members for i in m['member_fragment_ids'])),
            member_surface_ids=list(dict.fromkeys(m['surface_id'] for m in members if m['surface_id'])),
            display_member_count=len(members),
            display_region_semantics='observed connected-region lineage, not semantic equipment identity')
        selected['flags'] = list(dict.fromkeys(selected['flags']+observed['flags']))
        if any('object_identity_pending' in m['flags'] for m in members):
            selected['flags']=list(dict.fromkeys(selected['flags']+['object_identity_pending']))
        visible=[np.asarray(m['_display_points_L'],dtype=float) for m in members
                 if m.get('_display_points_L') is not None]
        if visible:
            selected['_display_points_L']=np.concatenate(visible)
        footprints=[m['_annotation_footprint'] for m in members if '_annotation_footprint' in m]
        if footprints:
            selected['_annotation_footprint']=[np.min([b[0] for b in footprints],axis=0),
                                                np.max([b[1] for b in footprints],axis=0)]
        native_indices=[m['_native_indices'] for m in members if '_native_indices' in m]
        if native_indices:
            selected['_native_indices']=np.unique(np.concatenate(native_indices))
        if all('selection_quality' in m for m in members):
            selected['selection_quality']=dict(role='observed_surface',
                occupied_cells=sum(m['selection_quality']['occupied_cells'] for m in members),
                boundary_supported=bool(supported),
                total_cells=sum(m['selection_quality']['total_cells'] for m in members),
                ambiguous_cells=sum(m['selection_quality']['ambiguous_cells'] for m in members),
                boundary_gap_m=max(0.,selected['distance_m']-observed['observed_min_distance_m']),
                neighbor_radius_m=selected['selection_quality']['neighbor_radius_m'],
                semantics='current supported spatial cells, capped for annotation selection; not semantic identity')
            selected['selection_quality']['ambiguity_fraction']=(
                float(selected['selection_quality']['ambiguous_cells'])/
                max(1,selected['selection_quality']['total_cells']))
        output.append(selected)
    return output


def _coalesce_annotation_regions(measurements, config):
    """Current shared footprints may share a label, not semantic asset identity.

    Complete-link grouping prevents an intermediary from joining neighbors.
    Each represented region keeps its real measurement record outside this UI.
    """
    n=len(measurements)
    if n<2:
        return measurements
    compatible=np.eye(n,dtype=bool)
    for i,a in enumerate(measurements):
        if ('_annotation_footprint' not in a or measurement_priority(a)[0] or
                'ambiguous_object_ownership' in a.get('flags',())):
            continue
        lo,hi=a['_annotation_footprint']
        for j in range(i+1,n):
            b=measurements[j]
            if (a.get('side') != b.get('side') or '_annotation_footprint' not in b or measurement_priority(b)[0] or
                    'ambiguous_object_ownership' in b.get('flags',())):
                continue
            other_lo,other_hi=b['_annotation_footprint']
            gap=max(0.,float(lo[0]-other_hi[0]),float(other_lo[0]-hi[0]))
            intersection=max(0.,float(min(hi[1],other_hi[1])-max(lo[1],other_lo[1])))
            union=float(max(hi[1],other_hi[1])-min(lo[1],other_lo[1]))
            if gap<=config.neighbor_base_m and union>1e-9 and intersection/union>=.7:
                compatible[i,j]=compatible[j,i]=True
    groups=[]
    for i in range(n):
        for group in groups:
            if compatible[i,group].all():
                group.append(i)
                break
        else:
            groups.append([i])
    output=[]
    for group in groups:
        members=[measurements[i] for i in group]
        if len(members)==1:
            output.extend(members)
            continue
        identity=max(members,key=lambda m:(bool(m.get('display_slot_reserved')),
            m.get('display_observations',0),str(m.get('display_id') or m['candidate_id'])))
        # Reuse current-minimum selection without giving the grouping a fake
        # physical ID or mutating any upstream candidate/result record.
        copies=[dict(m,display_id=identity.get('display_id') or identity['candidate_id']) for m in members]
        item=_group_display_regions(copies)[0]
        for key in ('display_id','display_observations','display_slot_reserved','_display_anchor_L'):
            if key in identity:
                item[key]=identity[key]
        item.update(annotation_region_ids=[m.get('display_id') or m['candidate_id'] for m in members],
            annotation_grouping='current_shared_footprint_layout_only')
        output.append(item)
    return output


class _CurrentGroundContext:
    """Only confirmed current terrain may justify a lower raised annotation.

    This gates UI eligibility, not raw point membership or literal measurement.
    A global plane alone cannot distinguish an unmodelled lower floor from a lid.
    """
    def __init__(self, frame, layers, model, config):
        self.config=config
        self.tree=None
        self.outside_footprint_queries=0
        plane=model.diagnostics.get('ground_plane') if model is not None else None
        if not plane:
            return
        self.normal=np.asarray(plane['normal_L'],dtype=float)
        self.normal/=np.linalg.norm(self.normal)
        axis=model.segments[-1].end_L-model.segments[0].start_L
        axis-=self.normal*float(axis@self.normal)
        if np.linalg.norm(axis)<1e-9:
            return
        axis/=np.linalg.norm(axis)
        self.axes=np.column_stack((axis,np.cross(self.normal,axis)))
        points=frame.xyz_L[layers.indices.get('ground',np.empty(0,dtype=int))]
        if len(points)<6:
            return
        keep,unused=voxel_representatives(points,.05)
        self.points=points[keep]
        if len(self.points)>=6:
            self.tree=cKDTree(self.points@self.axes)

    def raised(self, point):
        if self.tree is None:
            return False
        if self.config.local_terrain_validation:
            # Nearest-k can discard the sparse enclosing side of otherwise
            # valid terrain. The same finite radius supplies spatial support;
            # ground cells are already independently sampled at 5cm.
            neighbors=self.tree.query_ball_point(np.asarray(point)@self.axes,.45)
            patch=self.points[np.asarray(neighbors,dtype=np.int64)]
        else:
            distances,neighbors=self.tree.query(np.asarray(point)@self.axes,k=min(12,len(self.points)))
            patch=self.points[np.asarray(neighbors)[distances<=.45]]
        proof=self._terrain_patch_model(patch)
        return bool(self._raised_from_patch(np.asarray(point)[None,:],proof)[0])

    def _terrain_patch_model(self,patch):
        """One exact current patch fit, reusable for all queries with this patch."""
        if len(patch)<6:
            return None
        center=patch.mean(axis=0)
        centered=patch-center
        values,vectors=np.linalg.eigh(centered.T@centered/len(patch))
        normal=vectors[:,0]
        if normal@self.normal<0:
            normal=-normal
        residual=np.abs(centered@normal)
        if (values[1]<=1e-7 or normal@self.normal<.94 or
                np.percentile(residual,90)>self.config.ground_max_confirmation_band_m):
            return None
        if self.config.local_terrain_validation:
            # A nearby plane on only one side cannot establish the terrain
            # below this return. Require interpolation in actual 2-D support,
            # not an extrapolated global/bounding-box plane.
            footprint=(patch-center)@self.axes
            try:
                hull=ConvexHull(footprint).equations
            except QhullError:
                return None
        else:
            hull=None
        sigma=1.4826*float(np.median(np.abs(centered@normal-np.median(centered@normal))))
        band=min(self.config.ground_max_confirmation_band_m,
                 max(self.config.ground_numerical_band_m,self.config.ground_noise_sigma_factor*sigma))
        return center,normal,band,hull

    def _raised_from_patch(self,points,proof):
        if proof is None:
            return np.zeros(len(points),dtype=bool)
        center,normal,band,hull=proof
        raised=(points-center)@normal>band
        if hull is not None:
            position=(points-center)@self.axes
            outside=np.any(position@hull[:,:2].T+hull[:,2]>self.config.ground_numerical_band_m,axis=1)
            self.outside_footprint_queries+=int(outside.sum())
            raised &= ~outside
        return raised

    def _terrain_patch_models(self,keys):
        """Vectorized fits of exact neighbor patches; hulls stay patch-specific."""
        output=[]
        for start in range(0,len(keys),128):
            batch=keys[start:start+128]
            counts=np.asarray([len(key) for key in batch])
            width=max(1,int(counts.max()))
            patches=np.zeros((len(batch),width,3))
            valid=np.arange(width)[None,:]<counts[:,None]
            for i,key in enumerate(batch):
                patches[i,:len(key)]=self.points[np.asarray(key,dtype=np.int64)]
            centers=patches.sum(axis=1)/np.maximum(counts,1)[:,None]
            centered=(patches-centers[:,None,:])*valid[:,:,None]
            values,vectors=np.linalg.eigh(np.einsum('nki,nkj->nij',centered,centered)/np.maximum(counts,1)[:,None,None])
            normals=vectors[:,:,0]
            normals*=np.where(normals@self.normal<0,-1.,1.)[:,None]
            signed=np.einsum('nki,ni->nk',centered,normals)
            signed[~valid]=np.nan
            for i,key in enumerate(batch):
                if counts[i]<6:
                    output.append(None)
                    continue
                residual=signed[i,:counts[i]]
                if (values[i,1]<=1e-7 or normals[i]@self.normal<.94 or
                        np.percentile(np.abs(residual),90)>self.config.ground_max_confirmation_band_m):
                    output.append(None)
                    continue
                hull=None
                if self.config.local_terrain_validation:
                    hull=self._finite_footprint_hull(centered[i,:counts[i]]@self.axes)
                    if hull is None:
                        output.append(None)
                        continue
                sigma=1.4826*float(np.median(np.abs(residual-np.median(residual))))
                band=min(self.config.ground_max_confirmation_band_m,
                         max(self.config.ground_numerical_band_m,self.config.ground_noise_sigma_factor*sigma))
                output.append((centers[i],normals[i],band,hull))
        return output

    @staticmethod
    def _finite_footprint_hull(footprint):
        # Exact 2-D monotone chain of actual terrain vertices. Batch Qhull
        # calls open a Windows diagnostic temp file per patch; no such IO is
        # needed for this small finite planar interpolation polygon.
        ordered=np.unique(footprint,axis=0).tolist()
        def chain(points):
            result=[]
            for point in points:
                while len(result)>=2:
                    a,b=result[-2:]
                    cross=(b[0]-a[0])*(point[1]-a[1])-(b[1]-a[1])*(point[0]-a[0])
                    if cross>0:
                        break
                    result.pop()
                result.append(point)
            return result
        vertices=np.asarray(chain(ordered)[:-1]+chain(ordered[::-1])[:-1])
        if len(vertices)<3:
            return None
        edges=np.roll(vertices,-1,axis=0)-vertices
        normals=np.column_stack((edges[:,1],-edges[:,0]))
        norms=np.linalg.norm(normals,axis=1)
        if np.any(norms<=0):
            return None
        normals/=norms[:,None]
        return np.column_stack((normals,-np.einsum('ij,ij->i',normals,vertices)))

    def raised_many(self,points):
        """Exact batch: no subsampled queries, extrapolation or approximate patch keys."""
        points=np.asarray(points,dtype=float)
        answer=np.zeros(len(points),dtype=bool)
        if self.tree is None or not len(points):
            return answer
        if self.config.local_terrain_validation:
            neighbors=self.tree.query_ball_point(points@self.axes,.45)
            keys=[tuple(sorted(ids)) for ids in neighbors]
        else:
            distances,neighbors=self.tree.query(points@self.axes,k=min(12,len(self.points)))
            keys=[tuple(sorted(ids[ds<=.45])) for ds,ids in zip(distances,neighbors)]
        groups={}
        for i,key in enumerate(keys):
            groups.setdefault(key,[]).append(i)
        unique_keys=list(groups)
        models=(self._terrain_patch_models(unique_keys) if len(unique_keys)>16 else
                [self._terrain_patch_model(self.points[np.asarray(key,dtype=np.int64)]) for key in unique_keys])
        for key,proof in zip(unique_keys,models):
            rows=groups[key]
            answer[rows]=self._raised_from_patch(points[rows],proof)
        return answer

    def raised_all(self,points):
        # Bound temporary query storage; every distinct actual return still
        # has to pass. Duplicate native returns cannot alter this obligation.
        unique=np.unique(points,axis=0)
        return bool(len(unique) and all(self.raised_many(unique[start:start+4096]).all()
            for start in range(0,len(unique),4096)))

    def raised_region(self, boundary, points):
        if not self.raised(boundary):
            return False
        keep,unused=voxel_representatives(points,.05)
        keep=keep[np.linspace(0,len(keep)-1,min(16,len(keep)),dtype=int)]
        return bool(len(keep) and np.mean([self.raised(points[int(i)]) for i in keep])>=.7)


def _dimension_annotation(item, model):
    anchor = item.pop('_display_anchor_L',None)
    visible = item.pop('_display_points_L',None)
    if anchor is None or model is None:
        return
    anchor = np.asarray(anchor,dtype=float)
    if anchor.shape != (3,) or not np.isfinite(anchor).all():
        raise ValueError('invalid compensated annotation anchor')
    # Layout station is not another clearance measurement. Projecting a point
    # 2-5 m beside each short noisy segment amplifies tiny slope changes into
    # large station jumps. Use one longitudinal coordinate, interpolate the
    # *finite current polyline*, and keep the original minimum/evidence intact.
    nodes=np.asarray([model.segments[0].start_L]+[s.end_L for s in model.segments])
    normal=np.mean([s.normal_L for s in model.segments],axis=0)
    normal/=np.linalg.norm(normal)
    axis=nodes[-1]-nodes[0]
    axis-=normal*float(axis@normal)
    length=np.linalg.norm(axis)
    if length<1e-9:
        return
    axis/=length
    stations=(nodes-nodes[0])@axis
    if np.any(np.diff(stations)<=1e-9):
        # A folded local reference has no unambiguous layout station. Draw
        # the actual current evidence rather than an extrapolated old anchor.
        return
    station=float((anchor-nodes[0])@axis)
    supported=stations[0]-1e-9<=station<=stations[-1]+1e-9
    policy='observed_station'
    if visible is not None:
        points=np.asarray(visible,dtype=float).reshape(-1,3)
        points=points[np.isfinite(points).all(axis=1)]
        if len(points):
            current=(points-nodes[0])@axis
            low=max(stations[0],float(current.min()))
            high=min(stations[-1],float(current.max()))
            if low>high:
                return
            station=float(np.clip(station,low,high))
            policy='current_visible_station'
    station=float(np.clip(station,stations[0],stations[-1]))
    foot=np.array([np.interp(station,stations,nodes[:,i]) for i in range(3)])
    segment_index=min(int(np.searchsorted(stations,station,side='right'))-1,len(model.segments)-1)
    segment=model.segments[max(0,segment_index)]
    # A local secant keeps curvature but suppresses individual knot kinks.
    # This only orients the dimension annotation, never changes the raw foot.
    span=2.*float(np.median(np.diff(stations)))
    ends=np.clip([station-span,station+span],stations[0],stations[-1])
    section=np.array([np.interp(ends,stations,nodes[:,i]) for i in range(3)])
    tangent=section[:,1]-section[:,0]
    across=np.cross(tangent,normal)
    across/=np.linalg.norm(across)
    if across@segment.across_L<0:
        across*=-1
    side = np.dot(np.asarray(item['projected_L'])-item['foot_L'],across)
    endpoint = foot+across*(item['distance_m'] if side >= 0 else -item['distance_m'])
    item.update(dimension_model='stable_annotation',dimension_foot_L=foot.tolist(),
        dimension_projected_L=endpoint.tolist(),dimension_anchor_L=anchor.tolist(),
        dimension_anchor_supported=True,dimension_historical_anchor_in_support=bool(supported),
        dimension_anchor_policy=policy,
        dimension_semantics='current finite-polyline layout station; actual current minimum and foot remain separate')


def build_packet(frame, track, layers, results, config, max_labels=8, selection=None):
    model = measurement_model(track)
    centerline = ([] if model is None else
        [[s.start_L.tolist(), s.end_L.tolist()] for s in model.segments])
    by_id = {c.candidate_id: c for c in layers.candidates}
    measurements = []
    secondary=[]
    unknown_track_refs = ({frame.refs[int(i)] for i in layers.indices.get('unknown_track_structure', ())}
                          if config.rail_profile_roles else set())
    unknown_track_annotations = 0
    unknown_ground_annotations = 0
    lower_reference_deferred=0
    deferred_indices=[]
    ground_context=None
    observed_rail_tree=None
    if config.geometry_label_priority and model is not None:
        ground_context=_CurrentGroundContext(frame,layers,model,config)
        rail_indices=layers.indices.get('rails',np.empty(0,dtype=int))
        if len(rail_indices):
            observed_rail_tree=cKDTree(frame.xyz_L[rail_indices])
    footprint_axes=None
    if config.geometry_label_priority and model is not None:
        normal=np.mean([s.normal_L for s in model.segments],axis=0)
        normal/=np.linalg.norm(normal)
        along=model.segments[-1].end_L-model.segments[0].start_L
        along-=normal*float(along@normal)
        if np.linalg.norm(along)>1e-9:
            along/=np.linalg.norm(along)
            across=np.cross(along,normal)
            footprint_axes=np.column_stack((across,along))
    for result in results:
        observed = result.observed_evidence
        if result.observed_min_distance_m is None or observed is None:
            continue
        candidate = by_id[result.candidate_id]
        object_association=candidate.diagnostics.get('object_association',candidate.diagnostics.get('display_association'))
        supported = result.supported_evidence
        current_only_owner_warning=False
        evidence = supported if supported is not None else observed
        def defer(reason):
            if config.geometry_label_priority or config.qualified_instance_ownership:
                secondary.append(dict(candidate_id=result.candidate_id,reason=reason,
                    observed_min_distance_m=result.observed_min_distance_m,
                    supported_min_distance_m=result.supported_min_distance_m,
                    source_frame=evidence.point_ref.frame,source_index=evidence.point_ref.index,
                    source_time_s=evidence.point_ref.time_s,point_L=evidence.point_L.tolist(),
                    observed_source_index=observed.point_ref.index,observed_source_time_s=observed.point_ref.time_s,
                    observed_point_L=observed.point_L.tolist(),flags=list(result.flags)))
                if config.qualified_instance_ownership:
                    secondary[-1].update(object_id=candidate.diagnostics.get('object_id'),
                        object_association=object_association,display_id=candidate.diagnostics.get('display_id'))
        if config.above_rail_uncertainty and candidate.diagnostics.get('point_role')=='unknown_rail_scope':
            deferred_indices.extend(candidate.point_indices)
            defer('unconfirmed_above_rail_scope')
            continue
        if config.current_observation_gating and object_association=='uncompensated':
            current_evidence=candidate.diagnostics.get('instance_seed_evidence')
            if current_evidence is None or not current_evidence.get('seed_allowed',False):
                deferred_indices.extend(candidate.point_indices)
                defer('unconfirmed_uncompensated_geometry')
                if current_evidence is not None:
                    secondary[-1]['instance_seed_evidence']=current_evidence
                continue
        if config.qualified_instance_ownership and object_association in ('ambiguous','role_unresolved','temporal_only_unowned'):
            deferred_indices.extend(candidate.point_indices)
            defer('ambiguous_object_ownership' if object_association=='ambiguous' else
                  'unconfirmed_instance_geometry' if config.observable_instance_seeding and
                      not candidate.diagnostics.get('instance_seed_evidence',{}).get('seed_allowed',True) else
                  'unresolved_current_object_support' if object_association=='temporal_only_unowned' else 'unresolved_object_core')
            if config.observable_instance_seeding and 'instance_seed_evidence' in candidate.diagnostics:
                secondary[-1]['instance_seed_evidence']=candidate.diagnostics['instance_seed_evidence']
                if candidate.diagnostics.get('proposed_object_id') is not None:
                    secondary[-1]['proposed_object_id']=candidate.diagnostics['proposed_object_id']
                    secondary[-1]['reason']='unverified_current_body_attachment'
            if object_association=='ambiguous' and config.qualified_object_cores and supported is not None:
                from .objects import qualified_core_indices
                current_only_owner_warning=bool(len(qualified_core_indices(frame,candidate,config)))
            if not current_only_owner_warning:
                continue
            # Keep identity unresolved, not the valid current distance hidden.
            # No historical ID/GPS asset is assigned to this orange boundary.
            secondary[-1].update(object_id=None,display_id=None)
        if config.track_structure_context and candidate.diagnostics.get('structure_split_pending'):
            deferred_indices.extend(candidate.point_indices)
            defer('structure_role_split_pending')
            continue
        if config.rail_profile_roles and candidate.diagnostics.get('point_role') == 'unknown_ground':
            unknown_ground_annotations += 1
            defer('unknown_ground_role')
            continue
        if supported is None and observed.point_ref in unknown_track_refs:
            # Keep the unknown return/cloud and literal raw result, but do not
            # present an unresolved rail fragment as an equipment dimension.
            unknown_track_annotations += 1
            defer('unknown_track_role')
            continue
        evidence = supported if supported is not None else observed
        distance = result.supported_min_distance_m if supported is not None else result.observed_min_distance_m
        if observed_rail_tree is not None and observed_rail_tree.query(evidence.point_L)[0]<=.035:
            # Actual current rail returns establish adjacency, not a nominal
            # half-gauge cutoff or a semantic object rejection. Preserve raw
            # evidence as secondary until independent object ownership exists.
            deferred_indices.extend(candidate.point_indices)
            defer('near_current_observed_rail')
            continue
        if ground_context is not None:
            plane=model.diagnostics.get('ground_plane')
            if plane:
                normal=np.asarray(plane['normal_L'],dtype=float)
                normal/=np.linalg.norm(normal)
                heights=frame.xyz_L[candidate.point_indices]@normal-float(plane['offset_m'])
                if heights.max()<=config.ground_numerical_band_m and not ground_context.raised_region(
                        evidence.point_L,frame.xyz_L[candidate.point_indices]):
                    lower_reference_deferred+=1
                    deferred_indices.extend(candidate.point_indices)
                    defer('unresolved_lower_reference')
                    continue
        raw_warning = ('nearest_return_without_support' in result.flags or
                       'nearest_ambiguous_surface' in result.flags)
        identity_pending=config.qualified_instance_ownership and object_association in ('new','pose_unavailable','uncompensated','ambiguous')
        uncertain = supported is None or raw_warning or identity_pending
        layout_support = np.asarray(candidate.diagnostics.get('display_layout_support_L', ()),
                                    dtype=float).reshape(-1,3)
        measurements.append(dict(candidate_id=result.candidate_id,
            distance_m=distance,
            supported_distance_m=result.supported_min_distance_m,
            point_L=evidence.point_L.tolist(), projected_L=evidence.projected_L.tolist(),
            foot_L=evidence.foot_L.tolist(), source_frame=evidence.point_ref.frame,
            source_index=evidence.point_ref.index, source_time_s=evidence.point_ref.time_s,
            point_count=len(candidate.point_indices), uncertain=bool(uncertain),
            surface_id=candidate.diagnostics.get('surface_id'),
            surface_observations=candidate.diagnostics.get('surface_observations',0),
            surface_association=candidate.diagnostics.get('surface_association','untracked'),
            display_id=candidate.diagnostics.get('display_id'),
            display_observations=candidate.diagnostics.get('display_observations',0),
            display_association=candidate.diagnostics.get('display_association','untracked'),
            display_slot_reserved=candidate.diagnostics.get('display_slot_reserved',False),
            _display_anchor_L=candidate.diagnostics.get('display_anchor_L'),
            _display_points_L=np.concatenate((frame.xyz_L[candidate.point_indices], layout_support)),
            display_layout_support_count=len(layout_support),
            display_layout_semantics='current unique fragment plus exclusive current bridge returns; layout only, not measurement membership',
            object_ownership=candidate.diagnostics.get('object_ownership','unresolved_fragment'),
            object_proposal_parent=candidate.diagnostics.get('object_proposal_parent'),
            member_fragment_ids=candidate.diagnostics.get('member_fragment_ids',[candidate.candidate_id]),
            boundary_choice='supported_current_return' if supported is not None else 'unconfirmed_observed_return',
            observed_min_distance_m=result.observed_min_distance_m,
            observed_source_index=observed.point_ref.index,
            observed_source_frame=observed.point_ref.frame,observed_source_time_s=observed.point_ref.time_s,
            observed_point_L=observed.point_L.tolist(), observed_projected_L=observed.projected_L.tolist(),
            observed_foot_L=observed.foot_L.tolist(), raw_near_warning=bool(raw_warning),
            flags=list(result.flags), side=result.side))
        if current_only_owner_warning:
            measurements[-1].update(display_id=None,display_slot_reserved=False)
            measurements[-1]['flags'].append('ambiguous_object_ownership')
        if config.qualified_instance_ownership:
            measurements[-1].update(object_id=None if current_only_owner_warning else candidate.diagnostics.get('object_id'),
                object_association=object_association,
                object_identity_reconciled=candidate.diagnostics.get('object_identity_reconciled',False),
                object_spatial_variances=candidate.diagnostics.get('object_spatial_variances'),
                object_identity_semantics='local geometric proposal, not semantic equipment identity')
            if current_only_owner_warning:
                measurements[-1]['object_identity_semantics']='current supported boundary; ownership unresolved; not a GPS asset identity'
            if identity_pending:
                measurements[-1]['flags'].append('object_identity_pending')
        if config.geometry_label_priority:
            measurements[-1]['_native_indices']=candidate.point_indices
            supported_indices=np.setdiff1d(candidate.supported_indices,
                                           candidate.diagnostics.get('ambiguous_indices',()))
            quality_points=frame.xyz_L[supported_indices]
            occupied, unused=voxel_representatives(quality_points,config.neighbor_base_m)
            all_cells,inverse=voxel_representatives(frame.xyz_L[candidate.point_indices],config.neighbor_base_m)
            ambiguous_cells=np.zeros(len(all_cells),dtype=bool)
            np.maximum.at(ambiguous_cells,inverse,np.isin(candidate.point_indices,
                          candidate.diagnostics.get('ambiguous_indices',())))
            measurements[-1]['selection_quality']=dict(role='observed_surface',occupied_cells=len(occupied),
                boundary_supported=supported is not None,total_cells=len(all_cells),
                ambiguous_cells=int(ambiguous_cells.sum()),
                neighbor_radius_m=config.neighbor_base_m+config.neighbor_angle_rad*float(np.linalg.norm(evidence.point_L)))
            if footprint_axes is not None:
                footprint=frame.xyz_L[candidate.point_indices]@footprint_axes
                measurements[-1]['_annotation_footprint']=[footprint.min(axis=0),footprint.max(axis=0)]
    measurements = _group_display_regions(measurements)
    region_count=len(measurements)
    if config.geometry_label_priority:
        qualified=[]
        for item in measurements:
            if measurement_priority(item)[0]:
                deferred_indices.extend(item['_native_indices'])
                secondary.append({key:item[key] for key in ('candidate_id','observed_min_distance_m',
                    'source_frame','source_index','source_time_s','point_L','flags',
                    'observed_source_index','observed_point_L','observed_source_frame','observed_source_time_s')})
                secondary[-1]['supported_min_distance_m']=item['supported_distance_m']
                secondary[-1]['reason']='unresolved_annotation_quality'
            else:
                qualified.append(item)
        measurements=qualified
        measurements=_coalesce_annotation_regions(measurements,config)
    annotation_count=len(measurements)
    measurements=select_display_measurements(measurements,max_labels,config.display_balance_sides)
    for item in measurements:
        item.pop('_annotation_footprint',None)
        item.pop('_native_indices',None)
        _dimension_annotation(item,model)
    # Current region selection and stable geometry are display-only. All
    # per-fragment raw minima still exist in the measurement engine's results.
    if selection is not None:
        selection.remember_annotations(measurements[:8] if config.display_balance_sides else measurements[:4])
    display = {}
    ambiguous = np.union1d(layers.indices.get('ambiguous', np.empty(0, dtype=int)),deferred_indices).astype(np.int64)
    for name in ('object', 'ambiguous', 'rails', 'ground', 'background'):
        indices = layers.indices.get(name, np.empty(0, dtype=int))
        if name == 'ambiguous':
            indices=ambiguous
        if name == 'object':
            indices = indices[~np.isin(indices, ambiguous)]
        xyz = frame.xyz_L[indices]
        if len(xyz):
            keep, unused_inverse = voxel_representatives(xyz,config.display_voxel_m)
            # Bound rendering only; distances still use every native return.
            keep = keep[np.linspace(0, len(keep)-1, min(len(keep), 20000), dtype=int)]
            xyz = xyz[keep]
        display[name] = np.asarray(xyz, dtype='<f4')
    return dict(format=FORMAT, sequence=frame.sequence, device_time_s=frame.ref_time_s,
        session_id=frame.session_id, motion_status=frame.motion_status,
        clock_id=frame.clock_id, calculation='offline_precomputed', mode=track.mode,
        config_id=config.config_id, centerline=centerline,
        measurements=measurements, candidate_count=len(layers.candidates),
        measurement_region_count=region_count,display_limit=min(max_labels,8) if config.display_balance_sides else 4,
        annotation_region_count=annotation_count,
        unknown_track_annotations=unknown_track_annotations,
        unknown_ground_annotations=unknown_ground_annotations,
        lower_reference_annotations_deferred=lower_reference_deferred,
        secondary_measurements=secondary,
        display_selection='balanced_current_regions' if config.display_balance_sides else 'legacy_priority',
        stable_instance_labels=config.stable_instance_labels,
        observable_instance_seeding=config.observable_instance_seeding,
        current_observation_gating=config.current_observation_gating,
        complete_current_reconciliation=config.complete_current_reconciliation,
        native_shared_edge_evidence=config.native_shared_edge_evidence,
        above_rail_uncertainty=config.above_rail_uncertainty,
        recorded_playback_continuity=config.recorded_playback_continuity,
        scope=dict(sensor_max_range_m=config.sensor_max_range_m,
                   measurement_height_range_m=config.measurement_height_range_m,
                   corridor_half_width_m=config.corridor_half_width_m),
        layer_counts=layers.counts, scene_diagnostics={k:layers.diagnostics[k] for k in
            ('ground_confirmation','rail_roles','object_grouping','grouped_fragments',
             'temporal_proposal_groups','current_surface_proposal_groups','semantic_identity_confirmed',
             'qualified_object_cores_used','scanline_proposal_pairs','body_fragment_proposal_pairs',
             'body_fragment_history_veto_pairs',
             'qualified_history_instances','history_reconciled_region_groups',
             'current_reconciled_region_groups','current_closure_evidence','rail_scope_uncertainty',
             'raw_history_identity_instances','raw_history_identity_matches',
             'historical_instance_owner_alias_groups',
             'instance_seeding_evidence',
             'confirmed_background','background_reason','background_removed_points','background_semantics',
             'measurement_scope','measurement_scope_reason','measurement_scope_excluded_points','measurement_scope_semantics')
            if k in layers.diagnostics}, _display=display,
        local_terrain_support=dict(footprint_required=config.local_terrain_validation,
            outside_footprint_queries=ground_context.outside_footprint_queries if ground_context is not None else 0),
        note='Stable region dimension annotations; actual nearest returns remain separate; no semantic or absolute accuracy claim')


def write_packet(folder, packet):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    sequence = int(packet['sequence'])
    target = folder/('frame-%04d.json' % sequence)
    if target.exists():
        raise FileExistsError('refusing to overwrite an existing frame packet')
    record = {k: v for k, v in packet.items() if not k.startswith('_')}
    record['clouds'] = {}
    for name, xyz in packet['_display'].items():
        filename = 'frame-%04d-%s.bin' % (sequence, name)
        buffer_path = folder/filename
        if buffer_path.exists():
            raise FileExistsError('refusing to overwrite a display buffer')
        xyz.tofile(buffer_path)
        record['clouds'][name] = dict(file=filename, count=len(xyz), dtype='little-float32-xyz')
    target.write_text(json.dumps(record, allow_nan=False, separators=(',', ':')), encoding='utf-8')
    return target


def prepare_cache(frames_folder, pose_path, pcap, output, stop_after=None):
    from .native import read_native_frames, read_native_metadata
    from .motion import load_experimental_poses
    from .replay import ReplayEngine
    output = Path(output)
    if output.exists():
        raise FileExistsError('new playback cache directory required')
    if shutil.disk_usage(output.parent).free < 1024**3:
        raise OSError('less than 1 GiB free; refusing new cache')
    output.mkdir()
    with Path(pcap).open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    cfg = playback_config()
    poses = load_experimental_poses(pose_path, read_native_metadata(frames_folder))
    engine = ReplayEngine(cfg, 'tracked', poses)
    count, fresh, times = 0, 0, []
    modes,associations,stage_times = Counter(),Counter(),{}
    for frame in read_native_frames(frames_folder):
        frame = replace(frame,diagnostics=dict(frame.diagnostics,source_sha256=digest))
        started = time.perf_counter()
        track, layers, results = engine.step(frame)
        times.append((time.perf_counter()-started)*1000.)
        modes[track.mode] += 1
        for key,value in engine.timings.items():
            stage_times.setdefault(key,[]).append(value)
        packet = build_packet(engine.measurement_frame, track, layers, results, cfg,
                              selection=engine.surface_tracker)
        associations.update(m['surface_association'] for m in packet['measurements'][:4])
        write_packet(output, packet)
        count += 1
        fresh += bool(packet['measurements'])
        if count % 20 == 0:
            print('RSView cache frame=%d fresh=%d compute=%.1fms' %
                  (frame.sequence, fresh, times[-1]), flush=True)
        if stop_after is not None and count >= stop_after:
            break
    with Path(pcap).open('rb') as stream:
        after_digest = hashlib.file_digest(stream,'sha256').hexdigest()
    if after_digest != digest:
        raise RuntimeError('source PCAP changed while preparing playback; cache not published')
    manifest = dict(format=FORMAT, source_pcap=str(Path(pcap).resolve()), source_sha256=digest,
        source_sha256_after=after_digest,source_unchanged=True,
        frames=count, fresh_frames=fresh, session_id=frame.session_id,clock_id=frame.clock_id,
        native_source=str(Path(frames_folder).resolve()),
        poses_source=str(Path(pose_path).resolve()), calculation='offline_precomputed',
        live_0_2s_verified=False, compute_median_ms=float(np.median(times)),
        compute_p95_ms=float(np.percentile(times, 95)),
        mode_counts=dict(modes),visible_surface_association_counts=dict(associations),
        stage_median_ms={key:float(np.median(values)) for key,values in stage_times.items()},
        surface_identity='causal pose-compensated fragments; not semantic equipment IDs',
        config=dict(cfg.__dict__), bytes=sum(p.stat().st_size for p in output.iterdir()))
    (output/'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print(json.dumps(manifest), flush=True)
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--frames', type=Path, required=True)
    parser.add_argument('--poses', type=Path, required=True)
    parser.add_argument('--pcap', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--stop-after', type=int)
    args = parser.parse_args()
    prepare_cache(args.frames, args.poses, args.pcap, args.output, args.stop_after)
