"""First sequential experiment: full input/failure accounting, no live deployment."""
import argparse
import csv
import hashlib
import html
import json
from collections import Counter
from pathlib import Path
import time
import numpy as np
from dataclasses import replace
from .protocol import ClearanceConfig, json_value, result_to_dict, TrackUpdate,measurement_model
from .native import read_native_frames,read_native_metadata
from .scene import extract_scene, SurfaceTracker
from .measure import measure_candidates


class ReplayEngine:
    def __init__(self,config,mode,poses=None,observer=None):
        if mode not in ('single_frame','compensated_observation','tracked'):
            raise ValueError('invalid replay mode')
        from .track import TrackTracker
        self.config,self.mode,self.poses,self.observer = config,mode,poses,observer
        self.tracker = TrackTracker(config)
        self.surface_tracker = SurfaceTracker(config)
        from .background import BackgroundReference,MeasurementScopeReference
        self.background = (BackgroundReference.from_path(config.confirmed_background_path)
                           if config.confirmed_background_path else None)
        self.measurement_scope = (MeasurementScopeReference.from_path(config.confirmed_measurement_scope_path)
                                  if config.confirmed_measurement_scope_path else None)
        self.history = []
        self.object_history = []
        self.last_frame = None
        self.timings = {}
        self.measurement_frame = None
        self.last_pose_map = None

    def step(self,frame):
        from .track import observe_track
        from .motion import deskew_frame,transform_history,poses_for_frame,usable_pose,pose_map_key
        started = time.perf_counter()
        if self.last_frame is not None and (frame.ref_time_s <= self.last_frame.ref_time_s or
                frame.sequence <= self.last_frame.sequence or frame.clock_id != self.last_frame.clock_id or
                frame.session_id != self.last_frame.session_id):
            self.history = []
            self.object_history = []
            self.tracker.reset()
            self.surface_tracker.reset()
        current = (deskew_frame(frame,self.poses) if self.mode != 'single_frame' and self.poses is not None else frame)
        pose_source = poses_for_frame(self.poses,current)
        pose = (pose_source.sample(current.ref_time_s,current.scan_span_s[1])
                if pose_source is not None and current.motion_status == 'deskewed_experimental' else None)
        current_map = (pose_map_key(pose) if usable_pose(pose,current.ref_time_s,current.clock_id,
                                                     current.scan_span_s[1]) else None)
        if self.last_pose_map != current_map:
            self.history = []
            self.object_history = []
            self.tracker.reset()
            self.surface_tracker.reset()
        self.last_pose_map = current_map
        if current_map is not None:
            current = replace(current,diagnostics=dict(current.diagnostics,pose_map_key=current_map))
        compensated = time.perf_counter()
        if self.observer is not None:
            update = self.observer(current)
        elif self.mode == 'tracked':
            update = self.tracker.update(current,self.poses)
        else:
            fitting = (transform_history(self.history,current,self.poses,self.config)
                       if self.mode == 'compensated_observation' and self.poses is not None else current)
            update = observe_track(fitting,None,self.config)
            if update.model is not None and fitting.motion_status == 'compensated_history':
                model = replace(update.model,mode='compensated_dual',diagnostics=dict(update.model.diagnostics,
                      history_sequences=fitting.diagnostics.get('history_sequences',[])))
                update = TrackUpdate('compensated_dual',model)
        track_done = time.perf_counter()
        aligned_history = []
        if self.mode != 'single_frame' and self.poses is not None and self.object_history:
            aligned = transform_history(self.object_history,current,self.poses,self.config,include_current=False)
            if aligned.motion_status == 'compensated_history':
                aligned_history = [aligned]
        history_done = time.perf_counter()
        layers = extract_scene(current,update,aligned_history,self.config)
        if self.background is not None:
            layers = self.background.update(current,layers,pose,self.config)
        if self.measurement_scope is not None:
            layers = self.measurement_scope.update(current,layers,pose,self.config)
        from .objects import refine_objects,qualified_core_indices
        layers = refine_objects(current,update,layers,self.config,aligned_history)
        scene_done = time.perf_counter()
        if self.config.qualified_history_reconciliation:
            from .history_evidence import qualified_history_instances,raw_history_identity_instances
            selector = (raw_history_identity_instances if self.config.raw_history_identity_support
                        else qualified_history_instances)
            instances = selector(current,aligned_history,self.config)
            layers = self.surface_tracker.update(current,layers,pose,measurement_model(update),
                history_instances=instances)
        else:
            layers = self.surface_tracker.update(current,layers,pose,measurement_model(update))
        association_done = time.perf_counter()
        results = measure_candidates(current,update,layers,self.config)
        done = time.perf_counter()
        self.timings = {'compensation':(compensated-started)*1000.,'track':(track_done-compensated)*1000.,
                        'object_history_alignment':(history_done-track_done)*1000.,
                        'scene':(scene_done-history_done)*1000.,
                        'surface_association':(association_done-scene_done)*1000.,
                        'measure':(done-association_done)*1000.,
                        'compute':(done-started)*1000.}
        self.measurement_frame = current
        self.history.append(current)
        self.history = [f for f in self.history if frame.ref_time_s-f.ref_time_s <= self.config.history_seconds+1e-9]
        self.history = self.history[-self.config.history_max_scans:]
        indices = layers.indices['object']
        history_diagnostics = dict(current.diagnostics)
        if self.config.temporal_object_proposals:
            labels = np.full(len(current.xyz_L),-1,dtype=np.int64)
            origins = np.full(len(current.xyz_L),np.nan)
            evidence = []
            for label,candidate in enumerate(layers.candidates):
                # Only the qualified observed core donates ownership labels.
                # Unknown returns retain ordinary temporal/raw support, but
                # cannot acquire a confirmed role by inheriting the core label.
                core=qualified_core_indices(current,candidate,self.config)
                if not len(core):
                    continue
                labels[core] = label
                parent=candidate.diagnostics.get('object_proposal_parent',{})
                origins[core]=parent.get('proof_time_s',current.ref_time_s)
                if self.config.qualified_history_reconciliation:
                    association = candidate.diagnostics.get('object_association')
                    observations = int(candidate.diagnostics.get('display_observations',0))
                    support = candidate.diagnostics.get('support_neighbor_valid')
                    independent = not parent and current.motion_status=='deskewed_experimental'
                    if support is not None:
                        support = np.asarray(support,dtype=bool)
                        observed = support.any(axis=1) if support.ndim==2 else support
                        independent &= (observed.shape==(len(candidate.point_indices),) and
                            np.isin(core,candidate.point_indices[observed]).all())
                    if association=='ambiguous':
                        state = 'conflicted'
                    elif parent:
                        state = 'inherited'
                    elif not independent or association in (None,'uncompensated','role_unresolved'):
                        state = 'unresolved'
                    elif not candidate.diagnostics.get('object_id') or observations<2:
                        state = 'tentative'
                    else:
                        state = 'qualified'
                    proof_time = parent.get('proof_time_s',current.ref_time_s)
                    evidence.append(dict(source_frame=current.sequence,source_time_s=current.ref_time_s,
                        label=label,session_id=current.session_id,clock_id=current.clock_id,
                        object_id=candidate.diagnostics.get('object_id'),state=state,
                        observations=observations,independent_geometry=bool(independent),
                        geometry_frame=current.sequence if independent else None,
                        proof_time_s=proof_time,valid_until_s=proof_time+self.config.history_seconds,
                        radius_m=self.config.neighbor_base_m+self.config.neighbor_angle_rad*
                            float(np.linalg.norm((current.xyz_L[core].min(0)+current.xyz_L[core].max(0))*.5))))
            history_diagnostics['object_proposal_labels'] = labels[indices]
            history_diagnostics['object_proposal_origin_time_s'] = origins[indices]
            if self.config.qualified_history_reconciliation:
                history_diagnostics['object_proposal_evidence'] = evidence
        self.object_history.append(replace(current,xyz_L=current.xyz_L[indices],
            refs=tuple(current.refs[int(i)] for i in indices),
            rings=current.rings[indices] if current.rings is not None else None,
            diagnostics=history_diagnostics))
        self.object_history = [f for f in self.object_history if frame.ref_time_s-f.ref_time_s <= self.config.history_seconds+1e-9]
        self.object_history = self.object_history[-self.config.history_max_scans:]
        self.last_frame = frame
        return update,layers,results


def run_replay(frames, config, poses=None, output=None, mode='single_frame',
               paced=False, observer=None, previews=(220, 240, 260, 280, 300, 320, 340, 360, 380)):
    if paced:
        from .paced import run_paced
        if isinstance(frames,(str,Path)):
            folder = frames
        else:
            first = next(iter(frames))
            folder = first.diagnostics.get('source_folder')
        if not folder:
            raise ValueError('paced replay requires file-backed native frames')
        if poses is not None and not getattr(poses,'source_path',None):
            raise ValueError('paced file replay requires a recorded pose source')
        return run_paced(folder,config,getattr(poses,'source_path',None),output,mode)
    engine = ReplayEngine(config,mode,poses,observer)
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    (output/'config.json').write_text(json.dumps(json_value(config), indent=2), encoding='utf-8')
    counts, fresh, elapsed_values, source, preview_files = Counter(), 0, [], {}, []
    total = 0
    with (output/'frames.jsonl').open('w', encoding='utf-8') as frame_log, \
            (output/'clearances.jsonl').open('w', encoding='utf-8') as measurements, \
            (output/'clearances.csv').open('w', encoding='utf-8-sig', newline='') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(['frame', 'device_time_s', 'track_mode', 'candidate', 'observed_min_m',
                         'supported_min_m', 'source_index', 'source_time_s', 'point_count', 'flags'])
        for frame in frames:
            started = time.perf_counter()
            update,layers,results = engine.step(frame)
            measured_frame = engine.measurement_frame
            done = time.perf_counter()
            compute_ms = (done-started)*1000.
            elapsed_values.append(compute_ms)
            has_fresh = any(r.observed_min_distance_m is not None for r in results)
            fresh += int(has_fresh)
            counts[update.mode] += 1
            total += 1
            row = {'sequence': frame.sequence, 'device_time_s': frame.ref_time_s,
                   'scan_span_s': frame.scan_span_s, 'mode': update.mode, 'motion_status': measured_frame.motion_status,
                   'fresh_distance': has_fresh, 'layers': layers.counts,
                   'diagnostics': update.diagnostics, 'scene_diagnostics': layers.diagnostics,
                   'track': json_value(update.model),
                   'timing_ms': engine.timings}
            frame_log.write(json.dumps(json_value(row), allow_nan=False)+'\n')
            candidate_by_id = {c.candidate_id:c for c in layers.candidates}
            for result in results:
                measurements.write(json.dumps(result_to_dict(result), allow_nan=False)+'\n')
                ref = result.observed_evidence.point_ref if result.observed_evidence else None
                candidate = candidate_by_id[result.candidate_id]
                writer.writerow([frame.sequence, frame.ref_time_s, update.mode, result.candidate_id,
                                 result.observed_min_distance_m, result.supported_min_distance_m,
                                 ref.index if ref else '', ref.time_s if ref else '',
                                 len(candidate.point_indices), '|'.join(result.flags)])
            if frame.sequence in previews:
                from .viewer import plot_frame
                name = 'preview-%d.png' % frame.sequence
                plot_frame(measured_frame, update, layers, results, output/name)
                preview_files.append(name)
                # Save actual source indices for every selected frame/candidate,
                # so the picture can be audited against the native XYZ buffers.
                np.savez_compressed(output/('layers-%d.npz' % frame.sequence), **layers.indices,
                    **{c.candidate_id: c.point_indices for c in layers.candidates})
            if not source:
                source = {'session_id': frame.session_id, 'clock_id': frame.clock_id,
                          'native': frame.diagnostics, 'scope': 'only exported frames, not entire PCAP',
                          'observer': update.model.diagnostics.get('observer') if update.model else update.diagnostics.get('observer'),
                          'reference_semantics': 'current sensor L at scan midpoint; object minima from current scan',
                          'truth_available': False, 'live_deployment': False}
            if total % 10 == 0:
                frame_log.flush()
                measurements.flush()
                print('frame=%d processed=%d fresh=%d mode=%s compute=%.1fms candidates=%d' %
                      (frame.sequence, total, fresh, update.mode, compute_ms, len(results)), flush=True)
    report = {'input_frames': total, 'fresh_distance_frames': fresh, 'mode_counts': dict(counts),
              'mode': mode, 'observer': source.get('observer'), 'absolute_accuracy_verified': False,
              'live_0_2s_verified': False, 'compute_ms': {
                  'median': float(np.median(elapsed_values)) if elapsed_values else None,
                  'p95': float(np.percentile(elapsed_values, 95)) if elapsed_values else None,
                  'max': float(max(elapsed_values)) if elapsed_values else None}}
    (output/'source.json').write_text(json.dumps(source, indent=2), encoding='utf-8')
    (output/'timing.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    cards = ''.join('<section><h2>'+html.escape(n)+'</h2><img src="'+n+'"></section>' for n in preview_files)
    (output/'comparison.html').write_text('''<!doctype html><meta charset="utf-8"><title>轨旁最近距离：真实帧基线</title>
<style>body{background:#101723;color:#e5ecf6;font:16px system-ui;margin:24px}img{width:100%;max-width:1500px}pre{white-space:pre-wrap}section{border-top:1px solid #445;margin-top:24px}</style>
<h1>真实连续帧：轨旁表面到有观测支持的中心线</h1><p>旧中心线观察器作为对照。未进行语义设备识别、绝对精度或实车 0.2 s 验收；孤立点及不确定近地表面保留。仅画八条标签，完整候选均在 CSV/JSONL。</p>
<pre>'''+html.escape(json.dumps(report, ensure_ascii=False, indent=2))+'</pre>'+cards, encoding='utf-8')
    print(json.dumps(report), flush=True)
    return report


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--frames', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--mode', choices=('single_frame','compensated_observation','tracked'),default='single_frame')
    parser.add_argument('--poses',type=Path)
    parser.add_argument('--paced',action='store_true')
    parser.add_argument('--source-pcap', type=Path)
    parser.add_argument('--observer', choices=('legacy','balanced'), default='balanced')
    args = parser.parse_args()
    if args.paced:
        from .paced import run_paced
        return run_paced(args.frames,ClearanceConfig(),args.poses,args.output,args.mode,args.source_pcap)
    source_hash = None
    if args.source_pcap:
        with args.source_pcap.open('rb') as stream:
            source_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
    observer = None
    if args.observer == 'legacy':
        from .baseline import observe_legacy
        observer = observe_legacy
    poses = None
    if args.poses:
        from .motion import load_experimental_poses
        poses = load_experimental_poses(args.poses,read_native_metadata(args.frames))
    report = run_replay(read_native_frames(args.frames), ClearanceConfig(), output=args.output,
                        mode=args.mode, observer=observer,poses=poses)
    if source_hash:
        path = args.output/'source.json'
        source = json.loads(path.read_text())
        with args.source_pcap.open('rb') as stream:
            after_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
        source.update(pcap=str(args.source_pcap.resolve()), sha256_before=source_hash,
                      sha256_after=after_hash, unchanged=source_hash == after_hash)
        path.write_text(json.dumps(source, indent=2), encoding='utf-8')
        if source_hash != after_hash:
            raise RuntimeError('original source changed during replay')
    return report


if __name__ == '__main__':
    main()
