"""Nearest *observed* surface to the supported track plane, without averaging it."""
import time
import numpy as np
from .geometry import project_supported
from .protocol import (BoundaryEvidence, ClearanceResult, ProjectionBatch, validate_frame,
                       validate_track,measurement_model)


def _indices(values, count):
    values = np.asarray(values)
    if values.ndim != 1 or values.dtype.kind not in 'iu':
        raise ValueError('candidate indices must be an integer vector')
    if np.any(values < 0) or np.any(values >= count):
        raise ValueError('candidate index outside source cloud')
    return values.astype(np.int64, copy=False)


def measure_candidates(frame, track, layers, config):
    """Return literal minima and their provenance; unsupported values stay null.

    `supported` is an additional evidence channel, not permission to discard a
    nearer isolated return. A held model is intentionally not a current model.
    """
    started = time.perf_counter()
    validate_frame(frame)
    model = measurement_model(track)
    if model is not None:
        validate_track(model, frame)
    batches = []
    for candidate in layers.candidates:
        indices = _indices(candidate.point_indices, len(frame.xyz_L))
        supported = _indices(candidate.supported_indices, len(frame.xyz_L))
        if not np.isin(supported, indices).all():
            raise ValueError('supported set is not part of the candidate')
        batches.append((candidate,indices,supported))
    all_indices = (np.unique(np.concatenate([b[1] for b in batches])) if batches else
                   np.empty(0,dtype=np.int64))
    full_projection = project_supported(frame.xyz_L[all_indices],model) if model is not None else None
    positions_in_batch = np.full(len(frame.xyz_L),-1,dtype=np.int64)
    positions_in_batch[all_indices] = np.arange(len(all_indices))
    output = []
    for candidate,indices,supported in batches:
        flags = list(candidate.diagnostics.get('flags', ()))
        observed_min = supported_min = None
        observed_evidence = supported_evidence = None
        side = station = height = age = None
        if model is None:
            flags.append(track.mode)
        elif len(indices):
            positions = positions_in_batch[indices]
            projection = ProjectionBatch(*(getattr(full_projection,name)[positions] for name in
                         ('distance_m','foot_L','projected_L','signed_side_m','station_m',
                          'height_m','segment_index','supported')))
            valid = projection.supported & np.isfinite(projection.distance_m)
            if config.above_rail_measurement_only:
                above = np.isfinite(projection.height_m) & (projection.height_m > 1e-9)
                if np.any(valid & ~above):
                    flags.append('outside_above_rail_scope')
                valid &= above
            supported_mask = valid & np.isin(indices, supported)
            supported_mask &= ~np.isin(indices, candidate.diagnostics.get('ambiguous_indices', ()))
            if not valid.all():
                flags.append('partial_track_support' if valid.any() else 'outside_track_support')

            def minimum(mask):
                positions = np.flatnonzero(mask)
                if not len(positions):
                    return None, None, None
                position = int(positions[np.argmin(projection.distance_m[positions])])
                source_index = int(indices[position])
                neighbor_indices = candidate.diagnostics.get('support_neighbors', {}).get(source_index, ())
                if 'support_neighbor_indices' in candidate.diagnostics:
                    neighbor_indices = candidate.diagnostics['support_neighbor_indices'][position][
                        candidate.diagnostics['support_neighbor_valid'][position]][:3]
                neighbor_refs = tuple(frame.refs[int(i)] for i in neighbor_indices)
                neighbor_refs += tuple(candidate.diagnostics.get('temporal_support_refs',{}).get(source_index,()))
                evidence = BoundaryEvidence(
                    frame.refs[source_index], frame.xyz_L[source_index].copy(),
                    projection.projected_L[position].copy(), projection.foot_L[position].copy(),
                    neighbor_refs, (candidate.first_seen_s, candidate.last_seen_s),
                    {'segment_index': int(projection.segment_index[position]),
                     'motion_status': frame.motion_status})
                return float(projection.distance_m[position]), evidence, position

            observed_min, observed_evidence, selected = minimum(valid)
            supported_min, supported_evidence, _ = minimum(supported_mask)
            if selected is not None:
                side = 'left' if projection.signed_side_m[selected] < 0 else 'right'
                station = float(projection.station_m[selected])
                height = float(projection.height_m[selected])
                if not supported_mask[selected]:
                    flags.append('nearest_return_without_support')
                if int(indices[selected]) in candidate.diagnostics.get('ambiguous_indices',()):
                    flags.append('nearest_ambiguous_surface')
            age = max(0., frame.ref_time_s-model.last_observed_s)
            flags.extend(model.diagnostics.get('measurement_flags', ()))
        output.append(ClearanceResult(
            frame.session_id, config.config_id, frame.sequence, frame.ref_time_s,
            frame.clock_id, track.mode, candidate.candidate_id,
            observed_min, supported_min, observed_evidence, supported_evidence,
            side, station, height, (candidate.first_seen_s, candidate.last_seen_s), age,
            tuple(dict.fromkeys(flags)),
            {'measure': (time.perf_counter()-started)*1000.}, dict(layers.counts)))
    return output
