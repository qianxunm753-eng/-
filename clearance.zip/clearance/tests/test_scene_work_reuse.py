"""Per-call work reuse must retain native geometry and uncertainty decisions."""
from dataclasses import replace
import unittest
from unittest.mock import patch
import numpy as np

from rsview_centerline.clearance.scene import _rail_profile_roles,SurfaceTracker
from rsview_centerline.clearance.protocol import ClearanceConfig
from rsview_centerline.clearance.tests.test_rail_roles import profile_scene
from rsview_centerline.clearance.tests.fixtures import line_track,cloud
from rsview_centerline.clearance.tests.test_instance_ownership import parts
from rsview_centerline.clearance.tests.test_current_instance_reconciliation import configuration,faces
from rsview_centerline.clearance.tests.test_surface_tracking import pose
from rsview_centerline.clearance.objects import qualified_core_indices


class SceneWorkReuseTests(unittest.TestCase):
    def test_unambiguous_current_core_skips_empty_membership_search(self):
        frame=cloud([[2.,.3,.5],[2.,.4,.5]])
        candidate=parts(frame,[np.arange(2)]).candidates[0]
        for ambiguity in ((),[],np.empty(0,dtype=np.int64)):
            with self.subTest(ambiguity=type(ambiguity).__name__):
                candidate=replace(candidate,diagnostics={'ambiguous_indices':ambiguity})
                with patch('numpy.isin',wraps=np.isin) as membership:
                    core=qualified_core_indices(frame,candidate,configuration())
                np.testing.assert_array_equal(core,[0,1])
                self.assertEqual(membership.call_count,0,'empty ambiguity still builds a membership mask')

    def test_mixed_observation_times_still_refresh_each_cell_with_latest_real_return(self):
        tracker=SurfaceTracker(configuration())
        points=np.array([[.11,0.,0.],[0.,0.,0.],[.12,0.,0.],[-.06,0.,0.]])
        actual,stamps=tracker._spatial_representatives(points,np.array([1.,1.,1.1,1.]),
                                                    maximum=64,voxel_m=.05)
        np.testing.assert_array_equal(actual,points[[3,1,2]])
        np.testing.assert_array_equal(stamps,[1.,1.,1.1])

    def test_current_shared_region_variance_is_fitted_once_without_aliasing_diagnostics(self):
        a,b=faces()
        tracker=SurfaceTracker(configuration())
        first=cloud(a+b)
        tracker.update(first,parts(first,[np.arange(len(a)+len(b))]),pose(first),line_track())
        frame=cloud(a+b,sequence=1,time=1.1)
        layers=parts(frame,[np.arange(len(a)),np.arange(len(a),len(a)+len(b))])
        with patch('numpy.linalg.eigvalsh',wraps=np.linalg.eigvalsh) as fits:
            result=tracker.update(frame,layers,pose(frame),line_track(time=1.1))
        self.assertEqual(len({c.diagnostics['object_id'] for c in result.candidates}),1)
        first_variance=result.candidates[0].diagnostics['object_spatial_variances']
        second_variance=result.candidates[1].diagnostics['object_spatial_variances']
        self.assertEqual(first_variance,second_variance)
        self.assertTrue(all(v>0. for v in first_variance))
        self.assertIsNot(first_variance,second_variance,'one candidate can mutate another diagnostic')
        self.assertEqual(fits.call_count,1,'each fragment refitted the same final current region')

    def test_left_and_right_profiles_share_current_segment_station_work(self):
        rails,unused,model=profile_scene()
        segments=[]
        for station in (0.,1.,2.):
            segment=line_track(start=(0.,station,.17),end=(0.,station+1.,.17),gauge=1.44).segments[0]
            segments.append(replace(segment,station_start_m=station))
        model=replace(model,segments=tuple(segments))
        # Isolated protrusions and observations beyond finite support remain
        # unknown/object-like even when the two rail sides share station work.
        targets=np.array([[-.675,1.23,.09],[-.675,1.24,.09],[.72,3.1,.1]])
        points=np.vstack((rails,targets))
        vector_calls=[]
        norm=np.linalg.norm
        def measured_norm(values,*args,**kwargs):
            if np.asarray(values).shape==(3,):
                vector_calls.append(np.asarray(values).copy())
            return norm(values,*args,**kwargs)
        with patch('numpy.linalg.norm',side_effect=measured_norm):
            confirmed,unknown,diagnostic=_rail_profile_roles(points,model,0.,
                ClearanceConfig(track_structure_context=True))
        self.assertTrue(confirmed[:len(rails)].all())
        self.assertFalse(confirmed[len(rails):].any())
        np.testing.assert_array_equal(unknown[len(rails):],[True,True,False])
        self.assertEqual(diagnostic['confirmed_points'],len(rails))
        self.assertEqual(len(vector_calls),len(segments)+1,
            'left and right profiles repeated the same segment tangent/station setup')


if __name__=='__main__':
    unittest.main()
