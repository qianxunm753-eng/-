"""Embedded-native boundary contracts, without a modern NumPy UI dependency."""
import array
import unittest

from rsview_centerline import clearance_overlay


class NativeArray:
    def __init__(self, rows, dtype='double'):
        self.rows, self.dtype = rows, dtype
    def GetDataTypeAsString(self):
        return self.dtype
    def GetNumberOfComponents(self):
        return len(self.rows[0])
    def GetNumberOfTuples(self):
        return len(self.rows)
    def GetTuple(self, i):
        return self.rows[i]
    def GetRange(self):
        return min(r[0] for r in self.rows), max(r[0] for r in self.rows)


class NativeCloud:
    def __init__(self, xyz, stamps):
        self.xyz, self.stamps = NativeArray(xyz), NativeArray([(t,) for t in stamps])
    def GetPoints(self):
        return self
    def GetData(self):
        return self.xyz
    def GetPointData(self):
        return self
    def GetArray(self, name):
        return self.stamps if name == 'timestamp' else None


class NativeOnlineTests(unittest.TestCase):
    def test_recording_decoder_is_explicit_and_restorable_without_gui_settings_write(self):
        from types import SimpleNamespace
        from rsview_centerline.clearance_native import patch_recording_decoder
        names=('vvCalibrationDialog','vvNetworkConfigPcapDialog','vvLaserSelectionDialog',
               'vvColumnSelectionDialog','vvPointsSelectionDialog','vvCropReturnsDialog','vvCropDistReturnsDialog')
        native_dialog = SimpleNamespace(GetSensorType=lambda:1,GetMsopPort=lambda:0,untouched='native')
        factory = lambda unused: native_dialog
        logic = SimpleNamespace(**dict((name,factory) for name in names))
        saved = patch_recording_decoder(logic)
        calibration=logic.vvCalibrationDialog(None)
        network=logic.vvNetworkConfigPcapDialog(None)
        self.assertEqual(calibration.GetSensorType(),13)
        self.assertEqual(calibration.GetSensorTypeName(),'RSAIRY')
        self.assertEqual(network.GetMsopPort(),6699)
        self.assertEqual(network.GetDifopPort(),7788)
        self.assertEqual(calibration.GetPosition(),'')
        self.assertEqual(calibration.untouched,'native')
        self.assertEqual(logic.vvCropReturnsDialog(None).GetCropReturns().split()[:2],['0','0'])
        self.assertEqual(logic.vvLaserSelectionDialog(None).getLaserSelection(),'1'*480)
        for name,original in saved.items():
            setattr(logic,name,original)
        self.assertEqual(logic.vvCalibrationDialog(None).GetSensorType(),1)
        self.assertEqual(logic.vvNetworkConfigPcapDialog(None).GetMsopPort(),0)

    def test_reader_startup_decodes_before_reading_time_steps(self):
        from rsview_centerline.clearance_native import prepare_pcap_reader

        class DeferredReader:
            def __init__(self):
                self.TimestepValues = []
                self.events = []
            def GetClientSideObject(self):
                return self
            def Modified(self):
                self.events.append('modified')
            def UpdatePipeline(self, step):
                self.events.append(('decode', step))
                self.TimestepValues = list(range(687))
            def UpdatePipelineInformation(self):
                self.events.append('information')

        reader = DeferredReader()
        steps = prepare_pcap_reader(reader)
        self.assertEqual(len(steps), 687)
        self.assertEqual(reader.events, ['modified', ('decode', 1.), 'information'])

    def test_native_frame_number_must_match_the_actual_device_scan_not_previous_output(self):
        from rsview_centerline.clearance_native import validate_scan_identity
        request=dict(sequence=260,scan_span_s=(29.5,29.6))
        with self.assertRaises(ValueError):
            validate_scan_identity(request,(54.9,55.))
        validate_scan_identity(dict(request,scan_span_s=(54.9,55.)),(54.9,55.))

    def test_native_input_keeps_all_raw_returns_and_device_timestamps(self):
        from rsview_centerline.clearance_native import native_request
        # Far/low points must not disappear in a UI-side legacy rail ROI.
        cloud = NativeCloud([(1., 2., .01), (30., 2., -1.)], [5., 5.1])
        request = native_request(cloud, 7, 'session', 'clock')
        self.assertEqual(request['xyz']['count'], 2)
        self.assertEqual(request['scan_span_s'], (5., 5.1))
        self.assertAlmostEqual(request['device_time_s'], 5.05)
        values = array.array('d')
        values.frombytes(request['xyz']['data'])
        self.assertEqual(list(values), [1., 2., .01, 30., 2., -1.])

    def test_native_input_does_not_replace_missing_device_time_with_wall_clock(self):
        from rsview_centerline.clearance_native import native_request
        cloud = NativeCloud([(1., 2., .01)], [5.])
        cloud.GetArray = lambda name: None
        with self.assertRaises(ValueError):
            native_request(cloud, 7, 'session', 'clock')

    def test_native_integer_ring_fallback_preserves_typed_values(self):
        from rsview_centerline.clearance_native import native_request
        cloud = NativeCloud([(1.,2.,.01)], [5.])
        stamps, rings = cloud.stamps, NativeArray([(16.,)],dtype='int')
        cloud.GetArray=lambda name: stamps if name == 'timestamp' else rings if name == 'Ring' else None
        request=native_request(cloud,7,'session','clock')
        values=array.array('i')
        values.frombytes(request['rings']['data'])
        self.assertEqual(list(values),[16])

    def test_memory_cloud_is_bounded_and_has_no_disk_cache_fallback(self):
        cache = clearance_overlay.MemoryPacketCache()
        values = array.array('f', [1., 2., 3.])
        self.assertEqual(list(cache.cloud(dict(data=values.tobytes(), count=1,
                                               dtype='little-float32-xyz'))), list(values))
        for entry in (dict(data=b'', count=20001, dtype='little-float32-xyz'),
                      dict(file='frame.bin', count=1),
                      dict(data=b'', count=1, dtype='little-float32-xyz')):
            with self.assertRaises((ValueError, KeyError)):
                cache.cloud(entry)

    def test_displayed_result_is_not_fresh_after_input_advances_or_epoch_changes(self):
        from rsview_centerline.clearance_native import display_state
        identity = dict(sequence=7, device_time_s=5.05, session_id='s', clock_id='c', epoch=0)
        packet = dict(identity, received_at=100., status='completed', measurements=[{}])
        self.assertTrue(display_state(packet, identity, 100.2)['fresh_distance'])
        self.assertFalse(display_state(packet, dict(identity, sequence=8), 100.2)['fresh_distance'])
        self.assertFalse(display_state(packet, dict(identity, epoch=1), 100.2)['fresh_distance'])
        self.assertAlmostEqual(display_state(packet, identity, 102.)['result_age_s'], 2.)

    def test_raw_boundary_warning_is_visible_separate_from_supported_number(self):
        item = dict(surface_id='S7', uncertain=True, distance_m=2.,
                    raw_near_warning=True, observed_min_distance_m=1.2)
        text = clearance_overlay.measurement_label(item)
        self.assertIn('2.000', text)
        self.assertIn('raw 1.200', text)
        self.assertNotIn('confirmed', text.lower())

    def test_current_scan_with_no_track_distance_is_explicit_in_native_status(self):
        from types import SimpleNamespace
        from rsview_centerline.clearance_native import VtkOnlineClearanceOverlay
        overlay=SimpleNamespace(source_mode='simulated_pcap',last_input=284)
        packet=dict(sequence=284,current_source=True,mode='ambiguous_track',measurements=[],
                    motion_status='deskewed_experimental',result_age_s=.8,timing_ms={'packet_total':420.})
        text=VtkOnlineClearanceOverlay.packet_status(overlay,packet)
        self.assertIn('CURRENT SCAN',text)
        self.assertIn('ambiguous_track, 0 distances',text)
        self.assertIn('420ms',text)


if __name__ == '__main__':
    unittest.main()
