import json
import importlib
from pathlib import Path
import tempfile
import unittest


def write_fixture(root):
    modes = ('initializing','observed_dual','compensated_dual','estimated_single',
             'predicted_track','held_snapshot','ambiguous_track')
    rows = [dict(sequence=i,device_time_s=i*.1,mode=m,fresh_distance=True,timing_ms={'compute':10.})
            for i,m in enumerate(modes)]
    results = [dict(sequence=i,candidate_id='generic-'+str(i),track_mode=m,
        observed_min_distance_m=1.2,supported_min_distance_m=2.,flags=['nearest_return_without_support'],
        observed_evidence={'point_ref':{'frame':i,'index':99,'time_s':i*.1},
                           'point_L':[1.2,1,1],'projected_L':[1.2,1,0],'foot_L':[0,1,0]},
        supported_evidence=None) for i,m in enumerate(modes)]
    (root/'frames.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
    (root/'clearances.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in results))
    (root/'timing.json').write_text(json.dumps({'input_frames':7,'live_0_2s_verified':False}))
    (root/'source.json').write_text(json.dumps({'truth_available':False}))


class ViewerReportTests(unittest.TestCase):
    def test_all_modes_count_but_snapshot_and_prediction_are_not_dual_observations(self):
        from rsview_centerline.clearance.viewer import summarize_run
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory);write_fixture(root)
            summary = summarize_run(root)
            self.assertEqual(summary['input_frames'],7)
            self.assertEqual(summary['fresh_distance_frames'],4)
            self.assertEqual(summary['dual_observed_frames'],2)
            self.assertEqual(summary['estimated_reference_fresh_frames'],2)

    def test_reset_run_summary_uses_monotonic_playback_time_not_negative_device_gap(self):
        from rsview_centerline.clearance.viewer import summarize_run
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);write_fixture(root)
            frames=[dict(sequence=i,device_time_s=t,playback_elapsed_s=i*.1,
                         mode='initializing' if i<3 else 'observed_dual',timing_ms={'compute':1.})
                    for i,t in enumerate((100.,100.1,100.2,0.,.1,.2,.3))]
            (root/'frames.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in frames))
            summary=summarize_run(root)
            self.assertAlmostEqual(summary['initialization_duration_s'],.3)
            self.assertAlmostEqual(summary['max_fresh_gap_device_s'],.3)

    def test_viewer_preserves_all_candidates_and_original_evidence(self):
        from rsview_centerline.clearance.viewer import build_viewer
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory);write_fixture(root)
            before = (root/'clearances.jsonl').read_bytes()
            page = build_viewer(root,root/'audit.html')
            self.assertTrue(page.is_file())
            data = (root/'audit-data/frame-1.js').read_text()
            self.assertIn('generic-1',data)
            self.assertIn('nearest_return_without_support',data)
            self.assertIn('"index":99',data)
            self.assertEqual(before,(root/'clearances.jsonl').read_bytes())

    def test_report_does_not_claim_accuracy_without_truth(self):
        from rsview_centerline.clearance.viewer import write_report
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory);write_fixture(root)
            report = write_report([root],root/'report.md').read_text(encoding='utf-8')
            self.assertIn('未验证绝对精度',report)
            self.assertIn('未验收实车高速',report)
            self.assertNotIn('厘米级精度已达到',report)

    def test_frame_index_keeps_geometry_but_not_repeated_heavy_fit_refs(self):
        from rsview_centerline.clearance.viewer import _light_frame
        original={'sequence':1,'track':{'segments':[{'start_L':[0,0,0],
            'observation_refs':[{'frame':1,'index':2}]}],'observed_gauge_m':1.5,
            'diagnostics':{'rail_source_indices':list(range(5000)),'fit_residual_p95_m':.01}}}
        light=_light_frame(original)
        self.assertNotIn('observation_refs',light['track']['segments'][0])
        self.assertEqual(light['track_diagnostics']['fit_residual_p95_m'],.01)
        self.assertIn('observation_refs',original['track']['segments'][0])

    def test_snapshot_helper_refuses_existing_page_before_mutating_source(self):
        hydrate_snapshots = importlib.import_module('rsview_centerline.analysis.20261002_clearance.make_assets').hydrate_snapshots
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory);write_fixture(root)
            source = json.dumps({'source_folder':str(root),'truth_available':False}).encode()
            (root/'source.json').write_bytes(source)
            (root/'audit.html').write_text('previous audit')
            with self.assertRaises(FileExistsError):
                hydrate_snapshots(root)
            self.assertEqual((root/'source.json').read_bytes(),source)

    def test_snapshot_helper_refuses_existing_geometry_before_mutating_source(self):
        hydrate_snapshots = importlib.import_module('rsview_centerline.analysis.20261002_clearance.make_assets').hydrate_snapshots
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory);write_fixture(root)
            source = json.dumps({'source_folder':str(root),'truth_available':False}).encode()
            (root/'source.json').write_bytes(source)
            (root/'layers-1.npz').write_bytes(b'placeholder')
            (root/'geometry-1.npz').write_bytes(b'previous geometry')
            with self.assertRaises(FileExistsError):
                hydrate_snapshots(root)
            self.assertEqual((root/'source.json').read_bytes(),source)
            self.assertEqual((root/'geometry-1.npz').read_bytes(),b'previous geometry')


if __name__ == '__main__':
    unittest.main()
