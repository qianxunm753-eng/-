import importlib.util
from pathlib import Path
import unittest


class PosePrepareTests(unittest.TestCase):
    def test_partial_scans_without_imu_coverage_remain_explicitly_unposed(self):
        script = Path(__file__).resolve().parents[2]/'analysis'/'20261002_clearance'/'prepare_experimental_pose.py'
        spec = importlib.util.spec_from_file_location('pose_prepare_test',script)
        module = importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        manifest = {'frames':[{'frame':0,'timestamp_range':[0.,.2]},
                              {'frame':1,'timestamp_range':[.2,.3]},
                              {'frame':2,'timestamp_range':[.95,1.05]}]}
        selected,excluded = module.select_pose_rows(manifest,(.1,1.))
        self.assertEqual([r['frame'] for r in selected],[1])
        self.assertEqual([r['frame'] for r in excluded],[0,2])
        self.assertEqual(len(manifest['frames']),3)

    def test_calibration_transition_is_not_used_as_a_complete_pose_scan(self):
        script = Path(__file__).resolve().parents[2]/'analysis'/'20261002_clearance'/'prepare_experimental_pose.py'
        spec = importlib.util.spec_from_file_location('pose_prepare_test',script)
        module = importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        manifest = {'frames':[{'frame':i,'timestamp_range':[.2+i*.1,.3+i*.1]} for i in range(4)]}
        selected,excluded = module.select_pose_rows(manifest,(0.,1.),{0:False,1:False,2:True,3:True})
        self.assertEqual([r['frame'] for r in selected],[3])
        self.assertEqual(len(excluded),3)


if __name__ == '__main__':
    unittest.main()
