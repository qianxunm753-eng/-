"""A qualified instance may have multiple source-local fragment labels."""
from dataclasses import dataclass,replace
import os
import unittest
from unittest.mock import patch
import numpy as np
from rsview_centerline import clearance_native
from rsview_centerline.clearance.history_evidence import qualified_history_instances
from rsview_centerline.clearance.motion import deskew_frame,transform_history
from rsview_centerline.clearance.objects import _historical_owners,refine_objects
from rsview_centerline.clearance.measure import measure_candidates
from rsview_centerline.clearance.protocol import TrackUpdate
from rsview_centerline.clearance.tests.fixtures import cloud,line_track
from rsview_centerline.clearance.tests.test_history_instance_evidence import AnalyticPoses,engine,face
from rsview_centerline.clearance.tests.test_raw_identity_support import RawConfig
from rsview_centerline.clearance.tests.test_instance_ownership import parts


@dataclass(frozen=True)
class OwnerConfig(RawConfig):
    qualified_history_owner_keys: bool = True


def configuration(enabled=True):
    return OwnerConfig(qualified_history_owner_keys=enabled,temporal_object_proposals=True,
        qualified_object_cores=True,qualified_instance_ownership=True,spatial_object_ownership=True,
        surface_object_proposals=True,current_instance_reconciliation=True,
        above_rail_measurement_only=True,geometry_label_priority=True,display_identity_seconds=1.2)


def fixture(other_identity='T1'):
    lower = np.array([[2.,y,z] for y in np.arange(.3,.701,.02) for z in np.arange(.3,.501,.02)])
    upper = lower+np.array([0.,0.,.5])
    current = deskew_frame(cloud(np.concatenate([lower,upper]),sequence=2,time=1.2),AnalyticPoses())
    layers = parts(current,[np.arange(len(lower)),np.arange(len(lower),len(current.xyz_L))])
    labels = (current.xyz_L[:,1]>.5).astype(np.int64)
    base = dict(source_frame=1,source_time_s=1.1,session_id='test',clock_id='device:test',
        state='qualified',observations=2,independent_geometry=True,geometry_frame=1,
        proof_time_s=1.1,valid_until_s=1.7,radius_m=.07)
    records = [dict(base,label=0,object_id='T1'),dict(base,label=1,object_id=other_identity)]
    past = replace(cloud(current.xyz_L,sequence=1,time=1.1),ref_time_s=1.2,motion_status='compensated_history',
        diagnostics=dict(aligned_to_ref_time_s=1.2,object_proposal_labels=labels,
            object_proposal_origin_time_s=np.full(len(labels),1.1),object_proposal_evidence=records))
    return current,layers,past


class HistoryOwnerKeyTests(unittest.TestCase):
    def test_two_valid_fragment_labels_of_same_existing_id_are_one_owner(self):
        current,layers,past = fixture()
        owners,conflicts = _historical_owners(current,layers.candidates,[past],configuration())
        self.assertEqual(conflicts.tolist(),[False,False],
                         'same qualified geometric ID was counted as competing objects')
        self.assertEqual(owners,[(1,0,1.1),(1,0,1.1)])

    def test_v24_disabled_route_preserves_label_based_conflict(self):
        current,layers,past = fixture()
        owners,conflicts = _historical_owners(current,layers.candidates,[past],configuration(False))
        self.assertEqual(owners,[None,None])
        self.assertEqual(conflicts.tolist(),[True,True])

    def test_refinement_rejoins_current_parts_without_replacing_minimum_or_refs(self):
        current,layers,past = fixture()
        current.xyz_L[-1,0] = 1.98  # a real supported current return, not a centroid
        track = TrackUpdate('observed_dual',line_track(time=1.2))
        result = refine_objects(current,track,layers,configuration(),[past])
        self.assertEqual(len(result.candidates),1,
                         'false same-ID historical conflict vetoed the current footprint proof')
        np.testing.assert_array_equal(result.candidates[0].point_indices,np.arange(len(current.xyz_L)))
        measured = measure_candidates(current,track,result,configuration())
        self.assertEqual(len(measured),1)
        self.assertAlmostEqual(measured[0].observed_min_distance_m,1.98)
        self.assertEqual(measured[0].observed_evidence.point_ref,current.refs[-1])
        self.assertEqual(result.diagnostics['historical_instance_owner_alias_groups'],1)

    def test_distinct_existing_ids_still_compete_and_remain_separate(self):
        current,layers,past = fixture('T2')
        owners,conflicts = _historical_owners(current,layers.candidates,[past],configuration())
        self.assertEqual(owners,[None,None])
        self.assertEqual(conflicts.tolist(),[True,True])
        result = refine_objects(current,TrackUpdate('observed_dual',line_track(time=1.2)),layers,configuration(),[past])
        self.assertEqual(len(result.candidates),2)

    def test_minority_unqualified_return_still_competes_outside_the_qualified_core(self):
        current,layers,past = fixture()
        foreign = np.array([[1.84,.42,.4]])
        new_current = replace(current,xyz_L=np.concatenate([current.xyz_L,foreign]),
            refs=current.refs+(replace(current.refs[-1],index=len(current.refs)),))
        ids = np.r_[layers.candidates[0].point_indices,len(current.refs)]
        candidate = replace(layers.candidates[0],point_indices=ids,supported_indices=ids,
            diagnostics=dict(ambiguous_indices=np.array([len(current.refs)])))
        altered = replace(past,xyz_L=np.concatenate([past.xyz_L,foreign]),
            refs=past.refs+(replace(past.refs[-1],index=len(past.refs)),),
            diagnostics=dict(past.diagnostics,object_proposal_labels=np.r_[past.diagnostics['object_proposal_labels'],2],
                object_proposal_origin_time_s=np.r_[past.diagnostics['object_proposal_origin_time_s'],1.1],
                object_proposal_evidence=past.diagnostics['object_proposal_evidence']+[
                    dict(past.diagnostics['object_proposal_evidence'][0],label=2,state='tentative',observations=1)]))
        owners,conflicts = _historical_owners(new_current,[candidate],[altered],configuration())
        self.assertEqual(owners,[None],'qualified majority erased an unresolved same-ID-labelled foreground return')
        self.assertEqual(conflicts.tolist(),[True])

    def test_unqualified_same_id_label_remains_an_independent_competitor(self):
        current,layers,past = fixture()
        record = past.diagnostics['object_proposal_evidence'][1]
        for change in ({'state':'tentative','observations':1},{'state':'conflicted'},
                {'state':'inherited'},{'observations':1},{'valid_until_s':1.19},
                {'proof_time_s':1.},{'clock_id':'other'},{'session_id':'other'},
                {'independent_geometry':False},{'geometry_frame':2}):
            with self.subTest(change=change):
                altered = replace(past,diagnostics=dict(past.diagnostics,
                    object_proposal_evidence=[past.diagnostics['object_proposal_evidence'][0],dict(record,**change)]))
                owners,conflicts = _historical_owners(current,layers.candidates,[altered],configuration())
                self.assertEqual(owners,[None,None])
                self.assertEqual(conflicts.tolist(),[True,True])

    def test_missing_and_duplicate_records_cannot_supply_alias_identity(self):
        current,layers,past = fixture()
        for records in (past.diagnostics['object_proposal_evidence'][:1],
                        past.diagnostics['object_proposal_evidence']*2,[]):
            with self.subTest(record_count=len(records)):
                altered = replace(past,diagnostics=dict(past.diagnostics,object_proposal_evidence=records))
                owners,conflicts = _historical_owners(current,layers.candidates,[altered],configuration())
                self.assertEqual(owners,[None,None])
                self.assertEqual(conflicts.tolist(),[True,True])

    def test_same_id_in_two_source_frames_never_combines_label_namespaces(self):
        current,layers,past = fixture()
        second = replace(past,refs=tuple(replace(ref,frame=0,time_s=1.) for ref in past.refs),
            diagnostics=dict(past.diagnostics,object_proposal_origin_time_s=np.full(len(past.refs),1.),
                object_proposal_evidence=[dict(record,source_frame=0,geometry_frame=0,source_time_s=1.,
                    proof_time_s=1.,valid_until_s=1.6,object_id='unrelated-old')
                    for record in past.diagnostics['object_proposal_evidence']]))
        for history in ([past,second],[second,past]):
            owners,conflicts = _historical_owners(current,layers.candidates,history,configuration())
            self.assertEqual(owners,[(1,0,1.1),(1,0,1.1)])
            self.assertEqual(conflicts.tolist(),[False,False])

    def test_point_and_record_order_do_not_choose_a_different_owner(self):
        current,layers,past = fixture()
        order = np.random.default_rng(21).permutation(len(past.refs))
        reordered = replace(past,xyz_L=past.xyz_L[order],refs=tuple(past.refs[i] for i in order),
            diagnostics=dict(past.diagnostics,object_proposal_labels=past.diagnostics['object_proposal_labels'][order],
                object_proposal_origin_time_s=past.diagnostics['object_proposal_origin_time_s'][order],
                object_proposal_evidence=past.diagnostics['object_proposal_evidence'][::-1]))
        owners,conflicts = _historical_owners(current,layers.candidates,[reordered],configuration())
        self.assertEqual(owners,[(1,0,1.1),(1,0,1.1)])
        self.assertEqual(conflicts.tolist(),[False,False])

    def test_real_replay_producer_split_views_share_a_valid_object_id(self):
        cfg = configuration()
        worker = engine(cfg)
        whole = np.array(face())
        worker.step(cloud(whole))
        split = whole[(whole[:,1]<.43)|(whole[:,1]>.57)]
        worker.step(cloud(split,sequence=1,time=1.1))
        records = worker.object_history[-1].diagnostics['object_proposal_evidence']
        self.assertEqual(len(records),2,'native split-view fixture did not produce two fragments')
        self.assertTrue(all(r['object_id']=='T1' and r['state']=='qualified' for r in records))
        current = deskew_frame(cloud(whole,sequence=2,time=1.2),AnalyticPoses())
        aligned = transform_history(worker.object_history,current,AnalyticPoses(),cfg,include_current=False)
        self.assertEqual(len(qualified_history_instances(current,[aligned],cfg)),2)
        owners,conflicts = _historical_owners(current,parts(current,[np.arange(len(whole))]).candidates,[aligned],cfg)
        self.assertEqual(owners,[(1,0,1.1)])
        self.assertEqual(conflicts.tolist(),[False])

    def test_native_v25_only_enables_the_new_owner_key_rule(self):
        with patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':'v25'}):
            cfg = clearance_native.recorded_measurement_config()
            self.assertTrue(cfg.get('qualified_history_owner_keys',False))
            self.assertTrue(cfg.get('qualified_history_reconciliation',False))
            self.assertTrue(cfg.get('raw_history_identity_support',False))
        for variant in ('v24','v23','v22','v21','1','0'):
            with patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':variant}):
                self.assertFalse(clearance_native.recorded_measurement_config().get('qualified_history_owner_keys',False))

    def test_live_rejects_owner_keys_without_other_replay_flags(self):
        from rsview_centerline.clearance.online import OnlineEngine
        with self.assertRaisesRegex(ValueError,'replay-only'):
            OnlineEngine(OwnerConfig(qualified_history_reconciliation=False,raw_history_identity_support=False),source_mode='live')


if __name__ == '__main__':
    unittest.main()
