"""An explicitly confirmed test ROI cannot silently mask another recording."""
from dataclasses import replace
import unittest
import numpy as np
from rsview_centerline.clearance.protocol import Candidate,SceneLayers,PoseSample,ClearanceConfig
from rsview_centerline.clearance.tests.fixtures import cloud


class MeasurementScopeTests(unittest.TestCase):
    def document(self):
        return dict(format='clearance-confirmed-measurement-scope-v1',
            confirmation='user_confirmed_measurement_scope',session_id='test',clock_id='device:test',
            source_sha256='test-sha',pose_source='test-pose',pose_map_id='test-map',clock_epoch=0,
            plane_origin_W=[0.,0.,0.],keep_normal_W=[1.,0.,0.])

    def apply(self,document=None,matrix=None,frame_changes=None,pose_changes=None):
        from rsview_centerline.clearance.background import MeasurementScopeReference
        frame=replace(cloud([[2.,1.,.03],[-2.,1.,1.]]),motion_status='deskewed_experimental',
            diagnostics={'source_sha256':'test-sha'})
        if frame_changes:
            frame=replace(frame,**frame_changes)
        sample=PoseSample(1.,np.eye(4) if matrix is None else matrix,'device:test',(.9,1.1),1.05,
                          'test-pose',True,{'pose_map_id':'test-map'})
        if pose_changes:
            sample=replace(sample,**pose_changes)
        d=dict(support_neighbor_indices=np.array([[1],[0]]),support_neighbor_valid=np.ones((2,1),dtype=bool))
        layers=SceneLayers({'object':np.array([0,1]),'ground':np.array([9]),'background':np.array([8])},
            (Candidate('mixed',np.array([0,1]),np.array([0,1]),1.,1.,d),),{})
        return MeasurementScopeReference(document or self.document()).update(frame,layers,sample,ClearanceConfig())

    def test_only_confirmed_scope_excludes_candidates_not_ground_or_context(self):
        output=self.apply()
        self.assertEqual(output.indices['object'].tolist(),[0])
        self.assertEqual(output.indices['background'].tolist(),[1,8])
        self.assertEqual(output.indices['ground'].tolist(),[9])
        self.assertEqual(output.candidates[0].point_indices.tolist(),[0])
        self.assertEqual(output.candidates[0].supported_indices.tolist(),[]) # removed neighbor cannot support
        self.assertEqual(output.diagnostics['measurement_scope'],'explicit_recording_scoped_roi')

    def test_world_scope_not_sensor_left_right_mask(self):
        matrix=np.eye(4); matrix[:2,:2]=[[-1.,0.],[0.,-1.]]
        self.assertEqual(self.apply(matrix=matrix).indices['object'].tolist(),[1])

    def test_foreign_source_clock_pose_or_map_do_not_apply_roi(self):
        cases=[dict(frame_changes={'session_id':'other'}),dict(frame_changes={'clock_id':'other'}),
               dict(frame_changes={'diagnostics':{}}),dict(frame_changes={'motion_status':'raw'}),
               dict(pose_changes={'usable':False}),dict(pose_changes={'available_until_s':2.}),
               dict(pose_changes={'source':'other'}),dict(pose_changes={'diagnostics':{'pose_map_id':'other'}}),
               dict(pose_changes={'diagnostics':{'pose_map_id':'test-map','clock_epoch':1}})]
        for case in cases:
            with self.subTest(**case):
                output=self.apply(**case)
                self.assertEqual(output.indices['object'].tolist(),[0,1])
                self.assertEqual(output.diagnostics['measurement_scope'],'not_applied')

    def test_invalid_or_unconfirmed_scope_is_rejected(self):
        from rsview_centerline.clearance.background import MeasurementScopeReference
        for field,value in [('confirmation','unknown'),('keep_normal_W',[0,0,0]),
                            ('plane_origin_W',[0,float('nan'),0])]:
            with self.subTest(field=field),self.assertRaises(ValueError):
                MeasurementScopeReference(dict(self.document(),**{field:value}))


if __name__=='__main__':
    unittest.main()
