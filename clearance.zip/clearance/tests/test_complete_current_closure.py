"""Current ID closure must see retained aliases and the full current core."""
from dataclasses import dataclass,replace
import os
import unittest
from unittest.mock import patch
import numpy as np
from rsview_centerline import clearance_native
from rsview_centerline.clearance.scene import SurfaceTracker
from rsview_centerline.clearance.tests.test_current_instance_reconciliation import configuration as base_config


@dataclass(frozen=True)
class ClosureConfig(type(base_config())):
    complete_current_reconciliation: bool = True


def configuration(enabled=True):
    return ClosureConfig(**dict(base_config().__dict__,qualified_history_reconciliation=True,
                               complete_current_reconciliation=enabled))


def description(points,time=1.,radius=.05):
    points=np.asarray(points,dtype=float)
    return dict(points=points,lower=points.min(0),upper=points.max(0),radius=radius,
                last_seen=time,can_seed=True)


def faces():
    z=np.arange(.5,.8,.03)
    main=np.array([[2.,y,h] for y in np.arange(0.,.6,.03) for h in z])
    tail=np.array([[2.,y,h] for y in np.arange(.6,1.03,.03) for h in z])
    side=np.array([[x,1.05,h] for x in np.arange(2.08,2.21,.03) for h in z])
    return main,tail,side


def prepared(hidden_competitor=False,enabled=True):
    main,tail,side=faces()
    aggregate=np.vstack([main,tail[-1:],tail[-11:-10]])
    tracker=SurfaceTracker(configuration(enabled))
    old=[description(aggregate),description(side)]
    if hidden_competitor:
        old.append(description([[4.,2.,.5],[4.,2.1,.6],[4.,2.2,.7]]))
    tracker._associate_display(old,1.)
    tracker.display_regions['T1']['alias_parts']=[dict(points=p,point_times=np.full(len(p),1.),radius=.05)
        for p in (main,tail)]
    if hidden_competitor:
        r=tracker.display_regions['T1']
        r['points']=np.vstack([main,tail])
        r['point_times']=np.full(len(r['points']),1.)
        r['lower'],r['upper']=r['points'].min(0),r['points'].max(0)
        r=tracker.display_regions['T3']
        r['alias_parts']=[dict(points=r['points'],point_times=r['point_times'],radius=.05),
                          dict(points=main[35:36],point_times=np.array([1.]),radius=.05)]
    current=[description(np.vstack([main,tail])),description(side)]
    return tracker,current


class CompleteCurrentClosureTests(unittest.TestCase):
    def test_retained_native_tail_counts_in_both_current_connection_observations(self):
        tracker,current=prepared()
        actual=[c['points'] for c in current]
        first=tracker._associate_display(current,1.1,[(0,1)],ownership_points=actual)
        self.assertEqual(len({x['display_id'] for x in first}),2)
        second=tracker._associate_display(current,1.2,[(0,1)],ownership_points=actual)
        self.assertEqual(len({x['display_id'] for x in second}),1,
                         'retained actual tail was omitted from the first current closure witness')

    def test_hidden_native_alias_is_still_a_competing_owner(self):
        tracker,current=prepared(hidden_competitor=True)
        for time in (1.1,1.2):
            tracker._associate_display(current,time,[(0,1)],ownership_points=[c['points'] for c in current])
        self.assertEqual(len(tracker.display_regions),3,
                         'compression hid a real competing alias and permitted an incomplete owner closure')

    def test_full_current_cells_not_representative_coverage_define_a_witness(self):
        cfg=configuration()
        tracker=SurfaceTracker(cfg)
        a=np.array([[2.003,y,z] for y in np.arange(0.,.6,.03) for z in np.arange(.5,.8,.03)])
        b=np.array([[x,.64,z] for x in np.arange(2.15,2.28,.03) for z in np.arange(.5,.8,.03)])
        tracker._associate_display([description(a,radius=.06),description(b,radius=.06)],1.)
        inside=a+np.array([.0599,0.,0.])
        outside=a+np.array([.0601,0.,0.])
        actual=[np.vstack([inside,outside]),b]
        current=[description(inside,radius=.06),description(b,radius=.06)]
        for time in (1.1,1.2):
            tracker._reconcile_current_regions(current,[(0,1)],time,ownership_points=actual)
        self.assertEqual(len(tracker.display_regions),2,
                         'sampled matching hid unowned returns in every current spatial cell')

    def test_one_current_observation_never_reconciles_two_ids(self):
        tracker,current=prepared()
        tracker._associate_display(current,1.1,[(0,1)],ownership_points=[c['points'] for c in current])
        self.assertEqual(len(tracker.display_regions),2)

    def test_failed_reverse_coverage_has_an_explicit_diagnostic(self):
        tracker=SurfaceTracker(configuration())
        a=np.array([[2.,y,.5] for y in np.arange(0.,1.,.01)])
        b=np.array([[3.,y,.5] for y in np.arange(0.,1.,.01)])
        tracker._associate_display([description(a),description(b)],1.)
        current=[description(a[:3]),description(b[:3])]
        tracker._reconcile_current_regions(current,[(0,1)],1.1,
            ownership_points=[d['points'] for d in current])
        self.assertEqual(tracker.last_current_closure_diagnostics.get('incomplete_reverse_views'),2)
        self.assertEqual(tracker.current_link_witnesses,{})

    def test_missing_ancestral_edge_has_an_explicit_diagnostic(self):
        tracker=SurfaceTracker(configuration())
        current=[description([[2.,shift+y,.5] for y in (0.,.03,.06)])
                 for shift in (0.,.5,1.)]
        tracker._associate_display(current,1.)
        actual=[d['points'] for d in current]
        for now in (1.1,1.2):
            tracker._reconcile_current_regions(current,[(0,1)],now,ownership_points=actual)
        self.assertEqual(len(tracker.display_regions),2)
        tracker._reconcile_current_regions(current,[(1,2)],1.3,ownership_points=actual)
        self.assertEqual(tracker.last_current_closure_diagnostics.get('incomplete_ancestral_pairs'),1)
        self.assertEqual(tracker.current_link_witnesses,{})

    def test_expired_alias_cannot_confirm_a_missing_current_connection(self):
        tracker,current=prepared()
        tracker.display_regions['T1']['alias_parts'][1]['point_times'][:]=-1.
        for time in (1.1,1.2):
            tracker._associate_display(current,time,[(0,1)],ownership_points=[c['points'] for c in current])
        self.assertEqual(len(tracker.display_regions),2)

    def test_v27_disabled_route_is_preserved(self):
        tracker,current=prepared(enabled=False)
        for time in (1.1,1.2):
            output=tracker._associate_display(current,time,[(0,1)],ownership_points=[c['points'] for c in current])
        self.assertEqual(len({x['display_id'] for x in output}),2)

    def test_v28_explicit_preset_and_independent_live_rejection(self):
        with patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':'v28'}):
            self.assertTrue(clearance_native.recorded_measurement_config().get('complete_current_reconciliation',False))
        with patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':'v27'}):
            self.assertFalse(clearance_native.recorded_measurement_config().get('complete_current_reconciliation',False))
        from rsview_centerline.clearance.online import OnlineEngine
        with self.assertRaisesRegex(ValueError,'replay-only'):
            OnlineEngine({'complete_current_reconciliation':True},source_mode='live')


if __name__=='__main__':
    unittest.main()
