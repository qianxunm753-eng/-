"""No nominal gauge or minimum visible-length gate in the new observer."""
import unittest
import time
import numpy as np
from dataclasses import replace
from rsview_centerline.clearance.protocol import ClearanceConfig, PoseSample
from rsview_centerline.clearance.tests.fixtures import cloud


def rail_scene(width=1.5, length=2., slope=0., one=False, side_height=.0):
    rng = np.random.default_rng(13)
    along = np.linspace(.3, .3+length, max(8, int(length/.08)))
    ground = [[-.55+rng.normal(0,.001), y, z] for y in np.linspace(-2,2,55)
              for z in np.linspace(.2, .4+length, 35)]
    rails = []
    for z in along:
        for sign in (-1,1) if not one else (-1,):
            for height in np.linspace(-.50, -.38+sign*side_height/2, 12):
                rails.append([height, sign*width/2+slope*z+rng.normal(0,.001), z])
    return cloud(ground+rails)


class TrackTests(unittest.TestCase):
    def test_ground_hypotheses_reuse_exact_voxel_membership(self):
        from unittest.mock import patch
        from rsview_centerline.clearance import track
        frame=rail_scene()
        with patch.object(track,'voxel_representatives',wraps=track.voxel_representatives) as voxel:
            result=track._ground(frame.xyz_L,None)
        self.assertIsNotNone(result)
        self.assertAlmostEqual(result[3],-.55,delta=.01)
        self.assertLessEqual(voxel.call_count,2,'voxel occupancy is rebuilt for each plane hypothesis')

    def setUp(self):
        from rsview_centerline.clearance.track import observe_track
        self.observe = observe_track
        self.cfg = ClearanceConfig()

    def test_nonstandard_gauge(self):
        for width in (1.3, 1.7):
            u = self.observe(rail_scene(width), None, self.cfg)
            self.assertEqual(u.mode, 'observed_dual')
            self.assertAlmostEqual(u.model.observed_gauge_m, width, delta=.01)
            for s in u.model.segments:
                self.assertAlmostEqual(s.start_L[1], 0., delta=.01)

    def test_short_supported_track(self):
        u = self.observe(rail_scene(length=.7), None, self.cfg)
        self.assertEqual(u.mode, 'observed_dual')
        self.assertLess(np.linalg.norm(u.model.segments[-1].end_L-u.model.segments[0].start_L), 1.)

    def test_plane_follows_actual_rail_cross_slope(self):
        u = self.observe(rail_scene(side_height=.08), None, self.cfg)
        self.assertEqual(u.mode, 'observed_dual')
        segment = u.model.segments[0]
        self.assertGreater(abs(segment.across_L[0]), .015)

    def test_single_without_history_does_not_create_missing_rail(self):
        u = self.observe(rail_scene(one=True), None, self.cfg)
        self.assertEqual(u.mode, 'initializing')
        self.assertIsNone(u.model)

    def test_empty_cloud_does_not_throw(self):
        self.assertEqual(self.observe(cloud([]), None, self.cfg).mode, 'initializing')

    def test_rail_reference_has_actual_source_refs(self):
        f = rail_scene()
        u = self.observe(f, None, self.cfg)
        self.assertTrue(u.model.segments[0].observation_refs)
        refs = {r.index for s in u.model.segments for r in s.observation_refs}
        self.assertTrue(refs.issubset(set(range(len(f.xyz_L)))))

    def test_large_side_platform_cannot_win_ground_by_area(self):
        f = rail_scene(width=1.6)
        background = [[-.8, y, z] for y in np.linspace(1.8,4.5,90)
                      for z in np.linspace(.2,4.5,90)]
        u = self.observe(cloud(np.vstack([f.xyz_L, background])), None, self.cfg)
        self.assertEqual(u.mode, 'observed_dual')
        self.assertAlmostEqual(u.model.observed_gauge_m, 1.6, delta=.01)
        self.assertAlmostEqual(u.model.diagnostics['ground_plane']['offset_m'], -.55, delta=.01)

    def test_weak_ground_proposals_with_many_background_returns(self):
        f = rail_scene(width=1.6)
        rng = np.random.default_rng(54)
        background = np.column_stack([rng.uniform(-5,5,25000),rng.uniform(-5,5,25000),
                                      rng.uniform(.2,5.5,25000)])
        u = self.observe(cloud(np.vstack([f.xyz_L, background])), None, self.cfg)
        self.assertEqual(u.mode, 'observed_dual')
        self.assertAlmostEqual(u.model.observed_gauge_m, 1.6, delta=.03)

    def test_long_thin_ground_ridge_cannot_replace_short_rail(self):
        f = rail_scene(width=1.5, length=.7)
        false_ridge = [[x,.4,z] for z in np.linspace(.3,4.,100)
                       for x in np.linspace(-.523,-.519,6)]
        u = self.observe(cloud(np.vstack([f.xyz_L,false_ridge])), None, self.cfg)
        self.assertEqual(u.mode, 'observed_dual')
        self.assertAlmostEqual(u.model.observed_gauge_m, 1.5, delta=.01)

    def test_adjacent_track_is_not_silently_selected(self):
        a,b = rail_scene(width=1.5),rail_scene(width=3.2)
        u = self.observe(cloud(np.vstack([a.xyz_L,b.xyz_L])),None,self.cfg)
        self.assertEqual(u.mode,'ambiguous_track')
        self.assertIsNone(u.model)

    def test_missing_pose_holds_snapshot(self):
        from rsview_centerline.clearance.track import TrackTracker
        tracker = TrackTracker(self.cfg)
        self.assertEqual(tracker.update(rail_scene(),None).mode,'observed_dual')
        u = tracker.update(cloud([],time=1.1,sequence=1),None)
        self.assertEqual(u.mode,'held_snapshot')
        self.assertIsNone(u.model)
        self.assertIsNotNone(u.held_model)

    def test_single_and_dual_occlusion_reacquire(self):
        from rsview_centerline.clearance.track import TrackTracker
        class IdentityPoses:
            def sample(self,t,available_until_s):
                return PoseSample(t,np.eye(4),'device:test',(0.,10.),available_until_s,'analytic_test',True)
        tracker,poses = TrackTracker(self.cfg),IdentityPoses()
        full,single = rail_scene(),rail_scene(one=True)
        modes = []
        for i,p in enumerate((full.xyz_L,single.xyz_L,[],full.xyz_L)):
            u = tracker.update(cloud(p,time=1.+i*.1,sequence=i),poses)
            modes.append(u.mode)
            if i in (1,2):
                self.assertIsNone(u.model.observed_gauge_m)
        self.assertEqual(modes,['observed_dual','estimated_single','predicted_track','observed_dual'])

    def test_history_budget_is_not_prediction_lifetime(self):
        from rsview_centerline.clearance.track import TrackTracker
        class IdentityPoses:
            def sample(self,t,available_until_s):
                return PoseSample(t,np.eye(4),'device:test',(0.,10.),available_until_s,'analytic_test',True)
        tracker,poses = TrackTracker(self.cfg),IdentityPoses()
        tracker.update(rail_scene(),poses)
        for i in range(1,11):
            u = tracker.update(cloud([],time=1.+i*.1,sequence=i),poses)
        self.assertEqual(u.mode,'predicted_track')
        self.assertLessEqual(len(tracker.history),6)
        self.assertAlmostEqual(u.model.ref_time_s-u.model.last_observed_s,1.)

    def test_future_or_invalid_pose_must_hold_not_propagate(self):
        from rsview_centerline.clearance.track import TrackTracker
        class FuturePoses:
            def sample(self,t,available_until_s):
                return PoseSample(t,np.eye(4),'device:test',(0.,10.),available_until_s+1.,'analytic_test',True)
        tracker = TrackTracker(self.cfg)
        tracker.update(rail_scene(),FuturePoses())
        u = tracker.update(cloud([],time=1.1,sequence=1),FuturePoses())
        self.assertEqual(u.mode,'held_snapshot')

    def test_same_side_strips_cannot_invent_centerline(self):
        f = rail_scene()
        p = f.xyz_L.copy()
        rail = p[:,0] > -.52
        p[rail,1] += 1.5
        self.assertIsNone(self.observe(cloud(p),None,self.cfg).model)

    def test_curved_sections_follow_observed_midpoints(self):
        f = rail_scene(length=3.)
        p = f.xyz_L.copy();rail = p[:,0] > -.52
        p[rail,1] += .025*(p[rail,2]-1.5)**2
        u = self.observe(cloud(p),None,self.cfg)
        self.assertEqual(u.mode,'observed_dual')
        self.assertGreater(len(u.model.segments),2)
        for s in u.model.segments:
            for point in (s.start_L,s.end_L):
                self.assertAlmostEqual(point[1],.025*(point[2]-1.5)**2,delta=.018)

    def test_reacquired_dual_corrects_historical_side_offset(self):
        from rsview_centerline.clearance.track import TrackTracker
        tracker = TrackTracker(self.cfg)
        first = rail_scene();shifted = first.xyz_L.copy();shifted[:,1] += .06
        tracker.update(cloud(shifted),None)
        u = tracker.update(replace(first,ref_time_s=1.1,sequence=1,scan_span_s=(1.05,1.15)),None)
        self.assertEqual(u.mode,'observed_dual')
        self.assertAlmostEqual(u.model.segments[0].start_L[1],0.,delta=.01)

    def _identity_tracker(self):
        from rsview_centerline.clearance.track import TrackTracker
        class Poses:
            def sample(self,t,available_until_s):
                return PoseSample(t,np.eye(4),'device:test',(0.,10.),available_until_s,'analytic_test',True)
        tracker,poses=TrackTracker(self.cfg),Poses()
        tracker.update(rail_scene(),poses)
        return tracker,poses

    def test_history_cannot_suppress_still_comparable_rail_identities(self):
        tracker,poses=self._identity_tracker()
        full=rail_scene();ground=full.xyz_L[full.xyz_L[:,0]<-.52]
        one=rail_scene(one=True).xyz_L
        left=one[one[:,0]>-.52]
        competing=np.vstack([ground,left+[0,.35,0],left+[0,-.35,0],left+[0,1.5,0]])
        update=tracker.update(cloud(competing,time=1.1,sequence=1),poses)
        self.assertEqual(update.mode,'ambiguous_track')
        self.assertIsNone(update.model)

    def test_history_can_still_disambiguate_distant_competing_pairs(self):
        tracker,poses=self._identity_tracker()
        current=np.vstack([rail_scene().xyz_L,rail_scene(width=3.2).xyz_L])
        update=tracker.update(cloud(current,time=1.1,sequence=1),poses)
        self.assertEqual(update.mode,'observed_dual')
        self.assertAlmostEqual(update.model.observed_gauge_m,1.5,delta=.01)

    def test_unrelated_single_strip_cannot_move_historical_centerline(self):
        tracker,poses=self._identity_tracker()
        current=rail_scene(one=True).xyz_L.copy()
        current[current[:,0]>-.52,1]+=3.
        update=tracker.update(cloud(current,time=1.1,sequence=1),poses)
        self.assertEqual(update.mode,'predicted_track')
        self.assertAlmostEqual(update.model.segments[0].start_L[1],0.,delta=.01)
        self.assertAlmostEqual(update.model.last_observed_s,1.)

    def test_single_strip_outside_observed_stations_cannot_correct_old_support(self):
        tracker,poses=self._identity_tracker()
        current=rail_scene(one=True).xyz_L.copy()
        rails=current[:,0]>-.52
        current[rails,2]+=3.;current[rails,1]+=.3
        update=tracker.update(cloud(current,time=1.1,sequence=1),poses)
        self.assertEqual(update.mode,'predicted_track')
        self.assertAlmostEqual(update.model.segments[0].start_L[1],0.,delta=.01)

    def test_single_update_keeps_last_dual_observation_age(self):
        tracker,poses=self._identity_tracker()
        update=tracker.update(cloud(rail_scene(one=True).xyz_L,time=1.1,sequence=1),poses)
        self.assertEqual(update.mode,'estimated_single')
        self.assertAlmostEqual(update.model.last_observed_s,1.)

    def test_observed_support_resolves_slight_current_strip_ambiguity(self):
        tracker, poses = self._identity_tracker()
        full = rail_scene().xyz_L
        ground = full[full[:,0] < -.52]
        left = full[(full[:,0] > -.52) & (full[:,1] < 0)]
        right = full[(full[:,0] > -.52) & (full[:,1] > 0)]
        tracker.reset()
        tracker.update(cloud(np.vstack([ground,left+[0,-.055,0],right])),poses)
        current = np.vstack([ground,left+[0,-.055,0],left+[0,.055,0],right])
        update = tracker.update(cloud(current,time=1.1,sequence=1),poses)
        self.assertEqual(update.mode,'observed_dual')
        self.assertAlmostEqual(update.model.segments[0].start_L[1],-.0275,delta=.01)
        self.assertTrue(all(r.frame == 1 for s in update.model.segments for r in s.observation_refs))

    def test_slight_strip_ambiguity_without_pose_remains_ambiguous(self):
        from rsview_centerline.clearance.track import TrackTracker
        full = rail_scene().xyz_L
        ground = full[full[:,0] < -.52]
        left = full[(full[:,0] > -.52) & (full[:,1] < 0)]
        right = full[(full[:,0] > -.52) & (full[:,1] > 0)]
        tracker = TrackTracker(self.cfg)
        tracker.update(cloud(np.vstack([ground,left+[0,-.055,0],right])),None)
        update = tracker.update(cloud(np.vstack([ground,left+[0,-.055,0],
            left+[0,.055,0],right]),time=1.1,sequence=1),None)
        self.assertEqual(update.mode,'ambiguous_track')
        self.assertIsNone(update.model)

    def test_strong_current_dual_recaptures_after_wrong_wide_history(self):
        tracker, poses = self._identity_tracker()
        tracker.reset()
        tracker.update(rail_scene(width=3.2),poses)
        weak = rail_scene(width=3.2).xyz_L.copy()
        rail = weak[:,0] > -.52
        weak[rail,0] = -.49 + (weak[rail,0]+.50)*.25
        current = np.vstack([rail_scene().xyz_L,weak])
        update = tracker.update(cloud(current,time=1.1,sequence=1),poses)
        self.assertEqual(update.mode,'observed_dual')
        self.assertAlmostEqual(update.model.observed_gauge_m,1.5,delta=.01)

    def test_longer_distant_pair_does_not_replace_current_observed_identity(self):
        tracker, poses = self._identity_tracker()
        current = np.vstack([rail_scene().xyz_L,rail_scene(width=3.2,length=4.5).xyz_L])
        update = tracker.update(cloud(current,time=1.1,sequence=1),poses)
        self.assertEqual(update.mode,'observed_dual')
        self.assertAlmostEqual(update.model.observed_gauge_m,1.5,delta=.01)

    def test_history_without_station_overlap_cannot_choose_current_track(self):
        tracker, poses = self._identity_tracker()
        current = np.vstack([rail_scene().xyz_L,rail_scene(width=3.2).xyz_L])
        current[:,2] += 3.
        update = tracker.update(cloud(current,time=1.1,sequence=1),poses)
        self.assertEqual(update.mode,'ambiguous_track')
        self.assertIsNone(update.model)

    def test_pose_map_epoch_reset_invalidates_monotonic_scan_history(self):
        from rsview_centerline.clearance.track import TrackTracker
        class ResetPoses:
            def sample(self,t,available_until_s):
                return PoseSample(t,np.eye(4),'device:test',(0.,10.),available_until_s,
                    'analytic_test',True,{'clock_epoch': int(t >= 1.1)})
        tracker, poses = TrackTracker(self.cfg), ResetPoses()
        tracker.update(rail_scene(),poses)
        update = tracker.update(cloud([],time=1.1,sequence=1),poses)
        self.assertEqual(update.mode,'initializing')
        self.assertIsNone(update.model)
        self.assertIsNone(update.held_model)

    def test_pose_source_change_cannot_transform_previous_map(self):
        from rsview_centerline.clearance.track import TrackTracker
        class ChangedPoses:
            def sample(self,t,available_until_s):
                return PoseSample(t,np.eye(4),'device:test',(0.,10.),available_until_s,
                    'first_map' if t < 1.1 else 'different_map',True)
        tracker, poses = TrackTracker(self.cfg), ChangedPoses()
        tracker.update(rail_scene(),poses)
        update = tracker.update(cloud([],time=1.1,sequence=1),poses)
        self.assertEqual(update.mode,'initializing')
        self.assertIsNone(update.model)

    def test_prediction_transforms_only_finite_previous_support(self):
        from rsview_centerline.clearance.track import TrackTracker
        class MovingPoses:
            def sample(self,t,available_until_s):
                matrix = np.eye(4)
                matrix[:3,3] = [0.,2.*(t-1.),3.*(t-1.)]
                return PoseSample(t,matrix,'device:test',(0.,10.),available_until_s,'analytic_test',True)
        tracker, poses = TrackTracker(self.cfg), MovingPoses()
        original = tracker.update(rail_scene(),poses).model
        update = tracker.update(cloud([],time=1.1,sequence=1),poses)
        self.assertEqual(update.mode,'predicted_track')
        for before, after in zip(original.segments,update.model.segments):
            np.testing.assert_allclose(after.start_L,before.start_L+[0.,-.2,-.3],atol=1e-9)
            np.testing.assert_allclose(after.end_L,before.end_L+[0.,-.2,-.3],atol=1e-9)
        self.assertAlmostEqual(update.model.last_observed_s,1.)
        self.assertIsNone(update.model.observed_gauge_m)

    def test_voxel_representatives_preserve_native_return_and_cell_order(self):
        from rsview_centerline.clearance.track import _representatives
        rng = np.random.default_rng(92)
        points = rng.uniform(-5.,5.,(16000,3))
        points[1::5] = points[::5][:len(points[1::5])] + .00001
        _, indices = np.unique(np.floor(points/.06).astype(np.int64),axis=0,return_index=True)
        indices = indices[np.linspace(0,len(indices)-1,5000).astype(int)]
        np.testing.assert_array_equal(_representatives(points),points[indices])

    def test_voxel_representative_cost_is_lower_than_row_unique(self):
        from rsview_centerline.clearance.track import _representatives
        points = np.random.default_rng(94).uniform(-8.,8.,(40000,3))
        def row_unique():
            _, indices = np.unique(np.floor(points/.06).astype(np.int64),axis=0,return_index=True)
            indices = indices[np.linspace(0,len(indices)-1,5000).astype(int)]
            return points[indices]
        # Alternate warmed runs so both paths see the same machine conditions.
        # This budgets voxel grouping only, not native core/end-to-end latency.
        _representatives(points)
        row_unique()
        optimized, reference = [], []
        for _ in range(7):
            started = time.perf_counter()
            actual = _representatives(points)
            optimized.append(time.perf_counter()-started)
            started = time.perf_counter()
            expected = row_unique()
            reference.append(time.perf_counter()-started)
        np.testing.assert_array_equal(actual,expected)
        self.assertLess(float(np.median(optimized)),.75*float(np.median(reference)))




if __name__ == '__main__':
    unittest.main()
