"""Bounded old/new packet audit in the verified experimental world frame.

Measures display geometry jitter, not absolute physical accuracy. Original
native returns are independently deskewed again for selected source checks.
"""
import argparse
import json
from pathlib import Path
import sys
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[3]))
from rsview_centerline.clearance_overlay import PacketCache,dimension_endpoints
from rsview_centerline.clearance.native import read_native_frames,read_native_metadata
from rsview_centerline.clearance.motion import load_experimental_poses,deskew_frame,poses_for_frame,usable_pose


def inspect(folder,poses,native,start,end,audit=False,scope=None):
    cache=PacketCache(str(folder))
    frames=iter(read_native_frames(native,range(start,end+1)))
    previous,rows,raw_steps,dimension_steps={},[],[],[]
    sensor_negative,scope_violations,scope_boundary,empty,jumps,checked=[],[],[],[],[],0
    seen_ids=set();turnovers=0;longest_run=0;runs={}
    for frame in frames:
        packet=cache.get(frame.sequence)
        if packet is None:
            raise AssertionError('missing exact frame packet')
        source=poses_for_frame(poses,frame)
        pose=source.sample(frame.ref_time_s,frame.scan_span_s[1]) if source is not None else None
        if not usable_pose(pose,frame.ref_time_s,frame.clock_id,frame.scan_span_s[1]):
            raise AssertionError('comparison needs a verified current map pose')
        transform=lambda point:np.asarray(point)@pose.T_WL[:3,:3].T+pose.T_WL[:3,3]
        selected=packet['measurements'][:4]
        if not selected: empty.append(frame.sequence)
        # The approved ROI is a world half-space, not the moving sensor's Y sign.
        if any(m['point_L'][1]<0 for m in selected): sensor_negative.append(frame.sequence)
        identities=[m.get('display_id') or m.get('surface_id') or m['candidate_id'] for m in selected]
        if len(identities)!=len(set(identities)):
            raise AssertionError('duplicate selected region identity')
        if previous and identities:
            turnovers+=len(set(identities)-set(previous))
        seen_ids.update(identities)
        runs={identity:runs.get(identity,0)+1 for identity in identities}
        longest_run=max([longest_run]+list(runs.values()))
        corrected=deskew_frame(frame,poses) if audit else None
        current={}
        for identity,item in zip(identities,selected):
            endpoint,foot=dimension_endpoints(item)
            raw=transform(item['foot_L']);dimension=transform(foot)
            if abs(np.linalg.norm(np.asarray(endpoint)-foot)-item['distance_m'])>1e-8:
                raise AssertionError('annotation length does not equal current numeric distance')
            if item['source_frame']!=frame.sequence:
                raise AssertionError('old measurement claimed as current')
            if audit:
                for key,indexkey in (('point_L','source_index'),('observed_point_L','observed_source_index')):
                    np.testing.assert_allclose(item[key],corrected.xyz_L[item[indexkey]],rtol=0,atol=1e-10)
                checked+=1
                for key in ('point_L','observed_point_L'):
                    margin=float((transform(item[key])-np.asarray(scope['plane_origin_W']))@
                                 np.asarray(scope['keep_normal_W']))
                    if margin < -1e-9:
                        scope_violations.append(dict(frame=frame.sequence,identity=identity,point=key,margin_m=margin))
                    elif margin < .005:
                        scope_boundary.append(dict(frame=frame.sequence,identity=identity,point=key,margin_m=margin))
            if identity in previous:
                old=previous[identity]
                raw_step=float(np.linalg.norm(raw-old['raw']))
                dimension_step=float(np.linalg.norm(dimension-old['dimension']))
                raw_steps.append(raw_step);dimension_steps.append(dimension_step)
                if dimension_step>.3 and abs(item['distance_m']-old['distance'])<.1:
                    jumps.append(dict(frame=frame.sequence,identity=identity,
                        raw_foot_step_W_m=raw_step,dimension_foot_step_W_m=dimension_step))
            current[identity]=dict(raw=raw,dimension=dimension,distance=item['distance_m'])
        rows.append(dict(sequence=frame.sequence,mode=packet['mode'],selected_ids=identities,
                         distances_m=[m['distance_m'] for m in selected],count=len(selected)))
        previous=current
    stats=lambda values:dict(samples=len(values),median_m=float(np.median(values)) if values else None,
                            p95_m=float(np.percentile(values,95)) if values else None,
                            maximum_m=max(values) if values else None)
    return dict(frames=len(rows),sensor_negative_y_frames=sensor_negative,
                confirmed_scope_violations=scope_violations,near_scope_boundary=scope_boundary,empty_frames=empty,
                raw_foot_step_W=stats(raw_steps),dimension_foot_step_W=stats(dimension_steps),
                distinct_annotation_ids=len(seen_ids),annotation_entries_after_nonempty_frame=turnovers,
                longest_consecutive_annotation_run=longest_run,
                dimension_jumps=jumps,current_native_boundary_checks=checked,rows=rows)


def main():
    p=argparse.ArgumentParser(__doc__)
    p.add_argument('--old',type=Path,required=True);p.add_argument('--new',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--start',type=int,default=260);p.add_argument('--end',type=int,default=380)
    args=p.parse_args()
    if args.output.exists():raise FileExistsError('new report path required')
    root=Path(__file__).resolve().parents[2]
    native=root/'analysis/20261002_clearance/run-20261003-full-input-03/cart-frames'
    poses=load_experimental_poses(native.parent/'pose-work-03/cart-result-v5/registration.json',read_native_metadata(native))
    scope=json.loads((root/'confirmed_measurement_scope_1212121.json').read_text(encoding='utf-8'))
    old=inspect(args.old,poses,native,args.start,args.end)
    new=inspect(args.new,poses,native,args.start,args.end,audit=True,scope=scope)
    report=dict(old=old,new=new,absolute_accuracy_verified=False,
        note='Same-identity consecutive world-foot movement; IDs/selection differ, not a controlled accuracy comparison')
    args.output.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({key:{k:v for k,v in value.items() if k!='rows'} for key,value in (('old',old),('new',new))},indent=2))
    if new['confirmed_scope_violations']:raise AssertionError('confirmed opposite-world-half-space measurement survived')


if __name__=='__main__':main()
