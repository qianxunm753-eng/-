"""Bounded, read-only video inspection; never edits the input recording."""
import argparse
import json
from pathlib import Path


def main():
    import av
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    folder = Path(args.output)
    folder.mkdir(parents=True, exist_ok=False)
    container = av.open(args.input)
    stream = container.streams.video[0]
    duration = float(stream.duration * stream.time_base) if stream.duration else float(container.duration / av.time_base)
    wanted = [duration * fraction for fraction in (.02, .15, .3, .45, .6, .75, .9, .98)]
    records = []
    for frame in container.decode(stream):
        seconds = float(frame.pts * frame.time_base) if frame.pts is not None else float(frame.time or 0.)
        if len(records) < len(wanted) and seconds >= wanted[len(records)]:
            target = folder / ('view-%02d.png' % len(records))
            frame.to_image().save(target)
            records.append(dict(seconds=seconds, image=str(target)))
        if len(records) == len(wanted):
            break
    report = dict(duration_s=duration, width=stream.width, height=stream.height,
                  rate=str(stream.average_rate), frames=records)
    (folder / 'metadata.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report))
    container.close()


if __name__ == '__main__':
    main()
