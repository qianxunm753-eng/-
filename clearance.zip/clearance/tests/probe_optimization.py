"""Bounded native-input profiling/audit; no new cloud export or source mutation."""
import argparse
import cProfile
import hashlib
import json
from dataclasses import replace
from pathlib import Path
import pstats
import time

import numpy as np

from rsview_centerline.clearance.native import read_native_frames, read_native_metadata
from rsview_centerline.clearance.motion import load_experimental_poses
from rsview_centerline.clearance.protocol import measurement_model
from rsview_centerline.clearance.replay import ReplayEngine
from rsview_centerline.clearance.rsview_cache import build_packet, playback_config


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--frames', default='74,91,260,686')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError('new diagnostic filename required')
    root = Path(__file__).resolve().parents[2]
    source = Path.home()/'Desktop'/'1212121.pcap'
    native = root/'analysis/20261002_clearance/run-20261003-full-input-03/cart-frames'
    pose_path = native.parent/'pose-work-03/cart-result-v5/registration.json'
    with source.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    poses = load_experimental_poses(pose_path, read_native_metadata(native))
    cfg = playback_config()
    profiles, rows = cProfile.Profile(), []
    for number in map(int, args.frames.split(',')):
        engine = ReplayEngine(cfg, 'tracked', poses)
        for frame in read_native_frames(native, range(max(0, number-6), number+1)):
            frame = replace(frame, diagnostics=dict(frame.diagnostics, source_sha256=digest))
            if frame.sequence == number:
                profiles.enable()
            update, layers, results = engine.step(frame)
            profiles.disable()
        started = time.perf_counter()
        packet = build_packet(engine.measurement_frame, update, layers, results, cfg)
        packet_ms = (time.perf_counter()-started)*1000.
        model = measurement_model(update)
        by_id = {c.candidate_id: c for c in layers.candidates}
        selected = []
        if model is not None:
            segment = model.segments[0]
            tangent = segment.end_L-segment.start_L
            tangent /= np.linalg.norm(tangent)
            axes = np.column_stack((segment.across_L, tangent, segment.normal_L))
            for m in packet['measurements']:
                c = by_id[m['candidate_id']]
                p = engine.measurement_frame.xyz_L[c.point_indices]
                local = (p-segment.start_L)@axes
                selected.append(dict(m, bounds_L=[p.min(axis=0).tolist(), p.max(axis=0).tolist()],
                    bounds_track=[local.min(axis=0).tolist(), local.max(axis=0).tolist()],
                    height_quantiles=np.quantile(local[:,2], [0, .1, .5, .9, 1]).tolist(),
                    original_indices_sha256=hashlib.sha256(c.point_indices.tobytes()).hexdigest()))
        rows.append(dict(sequence=number, mode=update.mode, timings=engine.timings,
            packet_ms=packet_ms, layer_counts=layers.counts, selected=selected,
            background=packet['scene_diagnostics']))
    stats = pstats.Stats(profiles)
    functions = []
    for (filename, line, name), (primitive, calls, total, cumulative, _) in stats.stats.items():
        if 'rsview_centerline' in filename or cumulative > .05:
            functions.append(dict(file=filename, line=line, function=name, calls=calls,
                                  own_ms=1000*total, cumulative_ms=1000*cumulative))
    report = dict(source_sha256=digest, causal_prefix_scans=6, frames=rows,
                  functions=sorted(functions, key=lambda v: -v['cumulative_ms'])[:50])
    args.output.write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(dict(frames=[dict(sequence=r['sequence'], timings=r['timings'],
        visible=[(m['distance_m'],m['source_index'],m['bounds_track']) for m in r['selected'][:4]])
        for r in rows], functions=report['functions'][:16]), indent=2), flush=True)


if __name__ == '__main__':
    main()
