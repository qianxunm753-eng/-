"""Bounded track-only diagnostics from existing native exports; no XYZ copy."""
import argparse
from collections import Counter
import json
from pathlib import Path
import time

import numpy as np

from rsview_centerline.clearance.motion import deskew_frame, load_experimental_poses
from rsview_centerline.clearance.native import read_native_frames, read_native_metadata
from rsview_centerline.clearance.protocol import ClearanceConfig, json_value
from rsview_centerline.clearance.track import TrackTracker


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--frames', type=Path, required=True)
    parser.add_argument('--poses', type=Path, required=True)
    parser.add_argument('--start', type=int, default=0)
    parser.add_argument('--stop', type=int, default=686)
    parser.add_argument('--details', action='store_true')
    args = parser.parse_args()
    poses = load_experimental_poses(args.poses, read_native_metadata(args.frames))
    tracker = TrackTracker(ClearanceConfig())
    counts, failures, timings = Counter(), [], []
    watched = {238,239,243,246,247,251,265,266,273,280,283,285,288,293,295,298,389,598,599,601}
    sequences = set(range(args.start, args.stop+1))
    for native in read_native_frames(args.frames, sequences=sequences):
        frame = deskew_frame(native, poses)
        start = time.perf_counter()
        update = tracker.update(frame, poses)
        timings.append((time.perf_counter()-start)*1000.)
        counts[update.mode] += 1
        if update.model is None:
            failures.append([frame.sequence, update.mode])
        if args.details and (frame.sequence in watched or update.mode == 'ambiguous_track'):
            d = update.model.diagnostics if update.model else update.diagnostics
            compact = {key: d[key] for key in ('pair_scores', 'selected_pair_score',
                'alternative_pair_scores', 'pair_association', 'history_association',
                'reason') if key in d}
            for key in ('pair_scores', 'alternative_pair_scores'):
                if key in compact:
                    compact[key] = compact[key][:4]
            if update.mode == 'ambiguous_track' and frame.sequence in watched:
                compact['strips'] = [{key: strip[key] for key in ('y','low','high',
                    'vertical_span_m','residual_p95_m','sections')} for strip in d.get('strip_candidates', [])[:3]]
            print(json.dumps({'frame': frame.sequence, 'mode': update.mode,
                              'diagnostics': json_value(compact)}, allow_nan=False), flush=True)
        if frame.sequence % 100 == 0:
            print(json.dumps({'processed': frame.sequence+1, 'counts': dict(counts)}), flush=True)
    print(json.dumps({'range': [args.start,args.stop], 'counts': dict(counts), 'failures': failures,
        'track_ms': {'median': float(np.median(timings)), 'p95': float(np.percentile(timings,95)),
                     'max': float(max(timings))}}, allow_nan=False), flush=True)


if __name__ == '__main__':
    main()
