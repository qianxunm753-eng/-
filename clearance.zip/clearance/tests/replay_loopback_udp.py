"""Validation only: pace original PCAP UDP payloads to private loopback ports."""
import argparse
import json
import socket
import time
from pathlib import Path

from rsview_centerline.rail_centerline import PcapPoseIndex


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', required=True)
    parser.add_argument('--report', required=True)
    parser.add_argument('--duration', type=float, default=18.)
    args = parser.parse_args()
    first = None
    start = time.monotonic()
    counts = {6699:0, 7788:0}
    ports = {6699:16699, 7788:17788}
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sender:
        for stamp, port, payload in PcapPoseIndex._udp_packets(args.source):
            if port not in ports:
                continue
            if first is None:
                first = stamp
            elapsed = stamp-first
            if elapsed > args.duration:
                break
            delay = start+elapsed-time.monotonic()
            if delay > 0:
                time.sleep(delay)
            sender.sendto(payload, ('127.0.0.1', ports[port]))
            counts[port] += 1
    Path(args.report).write_text(json.dumps(dict(source=args.source, destination='127.0.0.1',
        ports=ports, packets=counts, wall_seconds=time.monotonic()-start,
        source_modified=False, physical_lidar_test=False), indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
