# -*- coding: utf-8 -*-
"""Owned hidden RSView smoke test of the original 22222.pcap route."""
import json
import os
import tempfile
import traceback
from PythonQt import QtCore, QtGui
import rsview.applogic as logic


def run():
    report = {'error': None, 'input': '22222.pcap'}
    folder = None
    factories = {}
    try:
        from clearance_native import patch_recording_decoder,prepare_pcap_reader
        # Same verified Airy/6699/7788 fixture as the original rail recording;
        # only the owned probe's getter inputs, never device/persistent settings.
        factories=patch_recording_decoder(logic)
        logic.chooseCalibrationFile = lambda unused: True
        logic.networkConfigPcap = lambda unused: True
        folder = tempfile.mkdtemp(prefix='rsview-legacy-probe-')
        pointer = os.path.join(folder, 'input_path.log')
        with open(pointer, 'wb') as stream:
            stream.write(os.path.join(os.path.expanduser('~'), 'Desktop', '22222.pcap'))
        logic.openPCAP(pointer)
        logic.stop()
        reader = logic.app.reader
        steps=prepare_pcap_reader(reader)
        for step in steps[:11]:
            reader.UpdatePipeline(float(step))
        logic.app.scene.AnimationTime = 10.
        QtGui.QApplication.processEvents()
        logic.onTimeChanged()
        overlay = logic.app.railOverlay
        report['overlay_type'] = type(overlay).__name__
        report['frame'] = int(logic.getTimeKeeper().getTime())
        report['fresh_result'] = overlay.last_result is not None
        report['line_visible'] = bool(overlay.representation.Visibility)
        report['reader_frames']=len(steps)
        report['sensor_type']=str(logic.app.curLidarType)
        if report['overlay_type'] != 'VtkRailOverlay' or not report['fresh_result']:
            raise RuntimeError('Original rail overlay route failed')
    except Exception:
        report['error'] = traceback.format_exc()
    finally:
        for name,factory in factories.items():
            setattr(logic,name,factory)
        path = os.environ['RSVIEW_LEGACY_REPORT'].decode('mbcs')
        with open(path, 'wb') as stream:
            stream.write(json.dumps(report, indent=2).encode('utf-8'))
        if folder:
            try:
                os.remove(os.path.join(folder, 'input_path.log'))
                os.rmdir(folder)
            except OSError:
                pass
        QtGui.QApplication.instance().quit()


timer = QtCore.QTimer()
timer.setSingleShot(True)
timer.connect('timeout()', run)
timer.start(1000)
