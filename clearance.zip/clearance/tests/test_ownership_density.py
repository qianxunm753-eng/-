"""Density/native order must not turn one shared footprint into two devices."""
import unittest
import numpy as np

from rsview_centerline.clearance.protocol import Candidate, ClearanceConfig, SceneLayers, TrackUpdate
from rsview_centerline.clearance.objects import refine_objects
from rsview_centerline.clearance.tests.fixtures import cloud, line_track


class OwnershipDensityTests(unittest.TestCase):
    def fixture(self):
        # Same 30cm footprint, two vertically separated visible parts.
        # Raw return density concentrates at opposite ends in the two parts.
        footprint = [[2.+x, 1.+y] for x in (0., .02) for y in np.linspace(0., .3, 31)]
        lower = [[2., 1., .2]]*600 + [[x,y,.2] for x,y in footprint]
        upper = [[2., 1.3, 1.]]*600 + [[x,y,1.] for x,y in footprint]
        frame = cloud(lower+upper)
        split = len(lower)
        candidates = tuple(Candidate('part%d'%i,np.array(g),np.array(g),1.,1.,{})
            for i,g in enumerate((range(split),range(split,len(frame.xyz_L)))))
        layers = SceneLayers({'object':np.arange(len(frame.xyz_L))},candidates,{}, {})
        return frame,layers

    def test_spatial_ownership_is_not_weighted_by_duplicate_return_density(self):
        frame,layers=self.fixture()
        cfg=ClearanceConfig(spatial_object_ownership=True)
        result=refine_objects(frame,TrackUpdate('observed_dual',line_track()),layers,cfg)
        self.assertEqual(len(result.candidates),1,
                         'identical observed footprints were split by native-order sampling')
        np.testing.assert_array_equal(result.candidates[0].point_indices,np.arange(len(frame.xyz_L)))

    def test_neighboring_objects_are_not_merged_by_spatial_sampling(self):
        frame,layers=self.fixture()
        split=len(layers.candidates[0].point_indices)
        frame.xyz_L[split:,1]+=.7
        result=refine_objects(frame,TrackUpdate('observed_dual',line_track()),layers,
                              ClearanceConfig(spatial_object_ownership=True))
        self.assertEqual(len(result.candidates),2)

    def test_ownership_preserves_current_nearest_native_return(self):
        from rsview_centerline.clearance.measure import measure_candidates
        frame,layers=self.fixture()
        # The rare true minimum must survive spatial representative sampling.
        frame.xyz_L[-1,0]=1.98
        cfg=ClearanceConfig(spatial_object_ownership=True)
        track=TrackUpdate('observed_dual',line_track())
        result=refine_objects(frame,track,layers,cfg)
        measured=measure_candidates(frame,track,result,cfg)
        self.assertEqual(len(measured),1)
        self.assertAlmostEqual(measured[0].observed_min_distance_m,1.98)
        self.assertEqual(measured[0].observed_evidence.point_ref.index,len(frame.xyz_L)-1)

    def test_ownership_is_stable_under_native_point_reordering(self):
        from dataclasses import replace
        frame,layers=self.fixture()
        cfg=ClearanceConfig(spatial_object_ownership=True)
        expected=refine_objects(frame,TrackUpdate('observed_dual',line_track()),layers,cfg)
        for seed in (7,91):
            permutation=np.random.default_rng(seed).permutation(len(frame.xyz_L))
            inverse=np.argsort(permutation)
            moved=replace(frame,xyz_L=frame.xyz_L[permutation],
                          refs=tuple(frame.refs[int(i)] for i in permutation))
            current=replace(layers,candidates=tuple(replace(c,point_indices=inverse[c.point_indices],
                supported_indices=inverse[c.supported_indices]) for c in layers.candidates))
            actual=refine_objects(moved,TrackUpdate('observed_dual',line_track()),current,cfg)
            self.assertEqual(len(actual.candidates),len(expected.candidates))
            self.assertEqual(set(moved.refs[int(i)] for i in actual.candidates[0].point_indices),set(frame.refs))

    def test_legacy_ownership_keeps_existing_route(self):
        frame,layers=self.fixture()
        result=refine_objects(frame,TrackUpdate('observed_dual',line_track()),layers,ClearanceConfig())
        self.assertEqual(len(result.candidates),2)


if __name__=='__main__':
    unittest.main()
