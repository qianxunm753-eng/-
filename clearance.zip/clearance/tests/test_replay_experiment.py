"""Replay scope and scan-row grouping must never change the live preset."""
from dataclasses import replace
import os
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import numpy as np

from rsview_centerline import clearance_native
from rsview_centerline.clearance.protocol import ClearanceConfig, TrackUpdate
from rsview_centerline.clearance.tests.fixtures import cloud, line_track
from rsview_centerline.clearance.scene import extract_scene
from rsview_centerline.clearance.objects import refine_objects
from rsview_centerline.clearance.measure import measure_candidates


class ReplayExperimentTests(unittest.TestCase):
    def config(self, **changes):
        try:
            return replace(ClearanceConfig(), above_rail_measurement_only=True,
                           scanline_object_proposals=True, **changes)
        except TypeError as error:
            self.fail('replay-only measurement behavior is missing: '+str(error))

    def test_native_recorded_constructor_selects_experiment_but_live_does_not(self):
        from rsview_centerline.clearance.tests.test_native_online import NativeCloud
        from rsview_centerline.clearance.tests.test_live_clearance import Label
        class Reader:
            def GetClientSideObject(self): return self
            def GetOutput(self): return NativeCloud([(2., 1., .5)], [1.])
            def SetNumberOfTrailingFrames(self, value): self.trailing = value
        class Host:
            def __init__(self, **settings): self.settings = settings
            def close(self): pass
        class Timer:
            def connect(self, *args): pass
            def start(self, value): pass
        qt = SimpleNamespace(QtCore=SimpleNamespace(QTimer=Timer))
        with patch.dict(os.environ, {'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':'1'}), \
             patch.dict('sys.modules', {'PythonQt':qt}), \
             patch.object(clearance_native, 'ClearanceProcess', Host), \
             patch.object(clearance_native.VtkClearanceOverlay, '__init__', lambda *a, **k: None):
            recorded = clearance_native.VtkOnlineClearanceOverlay(
                None, None, None, Label(), '333.pcap', Reader(), source_mode='recorded_pcap')
            live = clearance_native.VtkOnlineClearanceOverlay(
                None, None, None, Label(), None, Reader(), source_mode='live')
        self.assertTrue(recorded.host.settings['config'].get('above_rail_measurement_only'))
        self.assertTrue(recorded.host.settings['config'].get('scanline_object_proposals'))
        self.assertFalse(live.host.settings['config'].get('above_rail_measurement_only', False))
        self.assertEqual(live.host.settings['config'], clearance_native.live_measurement_config())

    def test_baseline_switch_restores_original_recorded_config(self):
        self.assertTrue(hasattr(clearance_native, 'recorded_measurement_config'))
        with patch.dict(os.environ, {'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':'0'}):
            self.assertEqual(clearance_native.recorded_measurement_config(),
                             clearance_native.live_measurement_config())

    def test_live_engine_rejects_accidentally_supplied_replay_features(self):
        from rsview_centerline.clearance.online import OnlineEngine
        for feature in ('above_rail_measurement_only', 'scanline_object_proposals'):
            with self.subTest(feature=feature), self.assertRaisesRegex(ValueError, 'replay-only'):
                OnlineEngine({feature:True}, source_mode='live')

    def evaluate(self, frame, config, model=None):
        track = TrackUpdate('observed_dual', model or line_track())
        layers = extract_scene(frame, track, [], config)
        layers = refine_objects(frame, track, layers, config)
        return layers, measure_candidates(frame, track, layers, config)

    def test_below_rail_nearest_return_is_context_not_measurement(self):
        frame = cloud([[1., 1., -.10], [1.02, 1., -.10],
                       [2., 1., .5], [2.02, 1., .5]])
        before = frame.xyz_L.copy()
        layers, results = self.evaluate(frame, self.config())
        self.assertEqual(sorted(np.concatenate([c.point_indices for c in layers.candidates]).tolist()), [2,3])
        self.assertEqual(layers.indices['below_rail_scope'].tolist(), [0,1])
        self.assertEqual(layers.indices['object'].tolist(), [0,1,2,3])
        self.assertEqual(min(r.observed_min_distance_m for r in results), 2.)
        np.testing.assert_array_equal(frame.xyz_L, before)
        old_layers, old_results = self.evaluate(frame, ClearanceConfig())
        self.assertEqual(sum(len(c.point_indices) for c in old_layers.candidates), 4)
        self.assertEqual(min(r.observed_min_distance_m for r in old_results), 1.)

    def test_measurement_defensively_rejects_below_scope_in_external_layers(self):
        frame = cloud([[1., 1., -.1], [1.02, 1., -.1], [2., 1., .5], [2.02, 1., .5]])
        track = TrackUpdate('observed_dual', line_track())
        layers = extract_scene(frame, track, [], ClearanceConfig())
        results = measure_candidates(frame, track, layers, self.config())
        self.assertEqual([r.observed_min_distance_m for r in results if r.observed_min_distance_m is not None], [2.])

    def test_scope_uses_local_rail_plane_not_sensor_z(self):
        angle = np.deg2rad(30.)
        rotation = np.array([[np.cos(angle),0.,np.sin(angle)], [0.,1.,0.],
                             [-np.sin(angle),0.,np.cos(angle)]])
        base = line_track()
        segment = base.segments[0]
        model = replace(base, segments=(replace(segment,
            start_L=rotation@segment.start_L, end_L=rotation@segment.end_L,
            left_endpoints_L=segment.left_endpoints_L@rotation.T,
            right_endpoints_L=segment.right_endpoints_L@rotation.T,
            normal_L=rotation@segment.normal_L, across_L=rotation@segment.across_L),))
        frame = cloud(np.array([[1.,1.,-.1], [1.02,1.,-.1], [2.,1.,.5], [2.02,1.,.5]])@rotation.T)
        self.assertTrue((frame.xyz_L[:,2] < 0).all())
        layers, results = self.evaluate(frame, self.config(), model)
        self.assertEqual(layers.indices['below_rail_scope'].tolist(), [0,1])
        self.assertAlmostEqual(min(r.observed_min_distance_m for r in results), 2.)

    def test_real_five_mm_high_target_is_not_removed_by_a_minimum_height_gate(self):
        layers, results = self.evaluate(cloud([[2.,1.,.005], [2.02,1.,.005]]), self.config())
        self.assertEqual(sum(len(c.point_indices) for c in layers.candidates), 2)
        self.assertEqual(results[0].observed_min_distance_m, 2.)

    def test_native_experiment_does_not_keep_the_old_three_point_five_m_height_ceiling(self):
        with patch.dict(os.environ, {'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':'1'}):
            config = ClearanceConfig(**clearance_native.recorded_measurement_config())
        frame = cloud([[2.,1.,3.7], [2.02,1.,3.7]])  # Both within the 5 m sensor sphere.
        layers, results = self.evaluate(frame, config)
        self.assertEqual(sum(len(c.point_indices) for c in layers.candidates), 2)
        self.assertEqual(results[0].observed_min_distance_m, 2.)

    def rows(self, x_shift=.018, gap=.14, rings=True):
        points = [[2., 1.+i*.02, .2] for i in range(5)]
        points += [[2.+x_shift, 1.+i*.02, .2+gap] for i in range(5)]
        frame = cloud(points)
        return replace(frame, rings=np.array([27]*5+[7]*5)) if rings else frame

    def test_small_cross_row_drift_groups_one_pole_without_changing_minimum(self):
        frame = self.rows()
        layers, results = self.evaluate(frame, self.config())
        self.assertEqual(len(layers.candidates), 1)
        self.assertEqual(layers.candidates[0].point_indices.tolist(), list(range(10)))
        self.assertEqual(results[0].observed_min_distance_m, 2.)
        self.assertEqual(results[0].observed_evidence.point_ref.index, 0)
        self.assertFalse(layers.candidates[0].diagnostics['semantic_identity_confirmed'])

    def test_merged_scanline_proposal_is_reported_as_scanline_not_native_connectivity(self):
        layers, unused = self.evaluate(self.rows(), self.config())
        self.assertEqual(len(layers.candidates), 1)
        self.assertEqual(layers.diagnostics['object_grouping'],
                         'current_scanline_and_bounded_geometric_proposals')

    def test_native_packet_retains_scanline_proof_count_for_field_audits(self):
        from rsview_centerline.clearance.rsview_cache import build_packet
        frame = self.rows()
        config = self.config()
        layers, results = self.evaluate(frame, config)
        packet = build_packet(frame, TrackUpdate('observed_dual', line_track()), layers, results, config)
        self.assertEqual(packet['scene_diagnostics'].get('scanline_proposal_pairs'), 1)

    def test_adjacent_poles_and_large_missing_vertical_spans_remain_separate(self):
        for frame in (self.rows(x_shift=.15), self.rows(gap=1.)):
            with self.subTest(points=frame.xyz_L.tolist()):
                layers, unused = self.evaluate(frame, self.config())
                self.assertEqual(len(layers.candidates), 2)

    def test_missing_ring_metadata_cannot_invent_scanline_connectivity(self):
        layers, unused = self.evaluate(self.rows(rings=False), self.config())
        self.assertEqual(len(layers.candidates), 2)

    def test_scanline_grouping_does_not_change_legacy_partition(self):
        layers, unused = self.evaluate(self.rows(), ClearanceConfig())
        self.assertEqual(len(layers.candidates), 2)


if __name__ == '__main__':
    unittest.main()
