"""The menu owns live-only state; PCAP and closed sources cannot enable it."""
import unittest
from types import SimpleNamespace
from unittest.mock import patch

try:
    from rsview_centerline import clearance_live
except ImportError:
    clearance_live = None


class Action:
    def __init__(self):
        self.enabled = False
        self.checked = False
    def setEnabled(self, enabled):
        self.enabled = bool(enabled)
    def setChecked(self, checked):
        self.checked = bool(checked)


class Label:
    def setText(self, text):
        self.text = text


class Sensor:
    def __init__(self):
        self.trailing = 17
    def GetClientSideObject(self):
        return self
    def SetNumberOfTrailingFrames(self, value):
        self.trailing = value
    def GetNumberOfTrailingFrames(self):
        return self.trailing


class Spin:
    def __init__(self):
        self.value = 17
        self.enabled = True
    def setValue(self, value):
        self.value = value
    def setEnabled(self, value):
        self.enabled = bool(value)


class Overlay:
    def __init__(self, sensor=None):
        self.reader = sensor
        self.closed = False
        self.running = None
    def close(self):
        self.closed = True
    def set_stream_running(self, running):
        self.running = bool(running)


class LiveMenuTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(clearance_live, 'live menu controller is not implemented')
        self.sensor = Sensor()
        self.action = Action()
        self.logic = SimpleNamespace(app=SimpleNamespace(sensor=self.sensor,
            curLidarType='RSAIRY', playing=True, railOverlay=Overlay(), statusLabel=Label(),
            numberOfTrailingFrames=17, trailingFramesSpinBox=Spin()),
            getSensor=lambda: self.logic.app.sensor)
        self.controller = clearance_live.LiveClearanceController(self.logic, self.action)

    def enable_native(self, logic):
        old = logic.app.railOverlay
        if old is not None:
            old.close()
        logic.app.railOverlay = Overlay(logic.getSensor())
        return logic.app.railOverlay

    def restore_rail(self, logic):
        logic.app.railOverlay = Overlay(logic.getSensor())
        return logic.app.railOverlay

    def enable(self):
        with patch.object(clearance_live, 'enable_live', self.enable_native):
            self.controller.toggle(True)

    def test_no_sensor_disables_menu_and_does_not_destroy_pcap_overlay(self):
        pcap_overlay = self.logic.app.railOverlay
        self.logic.app.sensor = None
        self.controller.source_ready()
        self.controller.toggle(True)
        self.assertFalse(self.action.enabled)
        self.assertFalse(self.action.checked)
        self.assertIs(self.logic.app.railOverlay, pcap_overlay)
        self.assertFalse(pcap_overlay.closed)

    def test_enabling_replaces_legacy_overlay_and_uses_current_sensor(self):
        old = self.logic.app.railOverlay
        self.controller.source_ready()
        self.enable()
        self.assertTrue(old.closed)
        self.assertTrue(self.action.checked)
        self.assertIs(self.logic.app.railOverlay.reader, self.sensor)
        self.assertTrue(self.logic.app.railOverlay.running)

    def test_enabling_while_paused_does_not_sample_stopped_stream(self):
        self.logic.app.playing = False
        self.enable()
        self.assertTrue(self.action.checked)
        self.assertFalse(self.logic.app.railOverlay.running)

    def test_stream_stop_and_start_are_forwarded_only_to_owned_overlay(self):
        self.enable()
        current = self.logic.app.railOverlay
        self.controller.stream_changed(False)
        self.assertFalse(current.running)
        self.controller.stream_changed(True)
        self.assertTrue(current.running)

    def test_disabling_restores_legacy_rail_on_same_live_sensor(self):
        self.enable()
        current = self.logic.app.railOverlay
        with patch.object(clearance_live, 'restore_live_rail', self.restore_rail):
            self.controller.toggle(False)
        self.assertTrue(current.closed)
        self.assertFalse(self.action.checked)
        self.assertIsNot(self.logic.app.railOverlay, current)
        self.assertIs(self.logic.app.railOverlay.reader, self.sensor)

    def test_source_close_clears_owned_overlay_without_starting_another_worker(self):
        self.enable()
        current = self.logic.app.railOverlay
        self.controller.source_closed()
        self.controller.source_closed()
        self.assertTrue(current.closed)
        self.assertIsNone(self.logic.app.railOverlay)
        self.assertFalse(self.action.checked)
        self.assertFalse(self.action.enabled)

    def test_failed_enable_rolls_back_menu_and_restores_legacy(self):
        def fail(logic):
            logic.app.railOverlay.close()
            logic.app.railOverlay = None
            raise RuntimeError('worker unavailable')
        with patch.object(clearance_live, 'enable_live', fail), \
                patch.object(clearance_live, 'restore_live_rail', self.restore_rail):
            self.controller.toggle(True)
        self.assertFalse(self.action.checked)
        self.assertIsNotNone(self.logic.app.railOverlay)
        self.assertIn('worker unavailable', self.logic.app.statusLabel.text)

    def test_unverified_lidar_model_cannot_enable_airys_measurement_path(self):
        self.logic.app.curLidarType = 'RS16'
        old = self.logic.app.railOverlay
        self.controller.source_ready()
        self.controller.toggle(True)
        self.assertFalse(self.action.enabled)
        self.assertFalse(old.closed)

    def test_failure_after_native_enable_closes_worker_and_rolls_back(self):
        created = []
        def fail_running(logic):
            overlay = self.enable_native(logic)
            created.append(overlay)
            def fail(unused):
                raise RuntimeError('resume failed')
            overlay.set_stream_running = fail
            return overlay
        with patch.object(clearance_live, 'enable_live', fail_running), \
                patch.object(clearance_live, 'restore_live_rail', self.restore_rail):
            self.controller.toggle(True)
        self.assertTrue(created[0].closed)
        self.assertIsNot(self.logic.app.railOverlay, created[0])
        self.assertIsNone(self.controller.overlay)
        self.assertFalse(self.action.checked)

    def test_replaced_sensor_restores_legacy_and_does_not_bind_old_overlay(self):
        self.enable()
        old = self.logic.app.railOverlay
        self.controller.source_closed()
        replacement = Sensor()
        self.logic.app.sensor = replacement
        with patch.object(clearance_live, 'restore_live_rail', self.restore_rail):
            self.controller.source_ready()
        self.assertTrue(old.closed)
        self.assertIsNotNone(self.logic.app.railOverlay)
        self.assertIs(self.logic.app.railOverlay.reader, replacement)
        self.assertTrue(self.action.enabled)
        self.assertFalse(self.action.checked)

    def test_single_scan_mode_is_visible_and_original_trailing_frames_are_restored(self):
        self.enable()
        self.assertEqual(self.sensor.trailing, 0)
        self.assertEqual(self.logic.app.trailingFramesSpinBox.value, 0)
        with patch.object(clearance_live, 'restore_live_rail', self.restore_rail):
            self.controller.toggle(False)
        self.assertEqual(self.sensor.trailing, 17)
        self.assertEqual(self.logic.app.trailingFramesSpinBox.value, 17)

    def test_native_ui_and_app_trailing_values_are_restored_independently(self):
        self.sensor.trailing = 3
        self.logic.app.numberOfTrailingFrames = 9
        self.enable()
        self.assertFalse(self.logic.app.trailingFramesSpinBox.enabled)
        with patch.object(clearance_live, 'restore_live_rail', self.restore_rail):
            self.controller.toggle(False)
        self.assertEqual(self.sensor.trailing, 3)
        self.assertEqual(self.logic.app.trailingFramesSpinBox.value, 17)
        self.assertEqual(self.logic.app.numberOfTrailingFrames, 9)
        self.assertTrue(self.logic.app.trailingFramesSpinBox.enabled)

    def test_close_failure_still_restores_settings_and_menu_without_aborting_disconnect(self):
        self.enable()
        def fail_close():
            raise RuntimeError('temp cleanup denied')
        self.controller.overlay.close = fail_close
        self.controller.source_closed()
        self.assertIsNone(self.logic.app.railOverlay)
        self.assertFalse(self.action.checked)
        self.assertFalse(self.action.enabled)
        self.assertEqual(self.sensor.trailing, 17)
        self.assertEqual(self.logic.app.trailingFramesSpinBox.value, 17)
        self.assertTrue(self.logic.app.trailingFramesSpinBox.enabled)
        self.assertIn('temp cleanup denied', self.logic.app.statusLabel.text)

    def test_unreadable_native_setting_is_preserved_not_guessed_from_ui(self):
        self.sensor.GetNumberOfTrailingFrames = None
        self.sensor.trailing = 3
        self.enable()
        self.assertEqual(self.sensor.trailing, 3)
        with patch.object(clearance_live, 'restore_live_rail', self.restore_rail):
            self.controller.toggle(False)
        self.assertEqual(self.sensor.trailing, 3)

    def test_disable_keeps_cleanup_warning_after_legacy_overlay_clears_status(self):
        self.enable()
        def fail_close():
            raise RuntimeError('persistent file lock')
        self.controller.overlay.close = fail_close
        def restore(logic):
            logic.app.statusLabel.setText('')
            return self.restore_rail(logic)
        with patch.object(clearance_live, 'restore_live_rail', restore):
            self.controller.toggle(False)
        self.assertIn('persistent file lock', self.logic.app.statusLabel.text)
        self.assertIn('persistent file lock', self.controller.last_cleanup_warning)


class LiveScanGateTests(unittest.TestCase):
    def setUp(self):
        from rsview_centerline import clearance_native
        self.assertTrue(hasattr(clearance_native, 'LiveScanGate'), 'live scan lifecycle gate is absent')
        self.gate = clearance_native.LiveScanGate(timeout_s=1.5)

    def test_duplicate_native_scan_cannot_become_a_new_live_measurement(self):
        self.gate.resume(now=10.)
        self.assertTrue(self.gate.observe((5., 5.1), now=10.1))
        self.assertFalse(self.gate.observe((5., 5.1), now=10.4))
        self.assertFalse(self.gate.stale(11.59))
        self.assertTrue(self.gate.stale(11.6))

    def test_paused_data_is_not_submitted_and_resume_waits_for_new_native_scan(self):
        self.gate.resume(now=10.)
        self.gate.observe((5., 5.1), now=10.1)
        self.gate.pause()
        self.assertFalse(self.gate.observe((5.1, 5.2), now=20.))
        self.gate.resume(now=20., baseline=(5.1, 5.2))
        self.assertFalse(self.gate.observe((5.1, 5.2), now=20.1))
        self.assertTrue(self.gate.observe((5.2, 5.3), now=20.2))

    def test_empty_stream_expires_even_before_first_measurement(self):
        self.gate.resume(now=10.)
        self.assertFalse(self.gate.observe(None, now=11.))
        self.assertFalse(self.gate.stale(11.49))
        self.assertTrue(self.gate.stale(11.5))


class WorkerCleanupTests(unittest.TestCase):
    def test_transient_windows_sharing_violation_is_retried_in_owned_directory(self):
        import os
        import tempfile
        from rsview_centerline import clearance_process
        directory = tempfile.mkdtemp(prefix='rsview-clearance-')
        real_remove = clearance_process.shutil.rmtree
        calls = []
        error = OSError('sharing violation')
        error.winerror = 32
        def remove(path):
            calls.append(path)
            if len(calls) == 1:
                raise error
            real_remove(path)
        host = clearance_process.ClearanceProcess.__new__(clearance_process.ClearanceProcess)
        host.__dict__.update(closed=False, pending=None, result=None, child=None,
            error_stream=SimpleNamespace(close=lambda: None), directory=directory)
        try:
            with patch.object(clearance_process.shutil, 'rmtree', remove):
                host.close()
            self.assertEqual(len(calls), 2)
            self.assertFalse(os.path.exists(directory))
        finally:
            if os.path.exists(directory):
                real_remove(directory)


class Actor:
    def __init__(self):
        self.visible = True
    def SetVisibility(self, visible):
        self.visible = bool(visible)


class Host:
    def __init__(self, **kwargs):
        self.closed = False
        self.epoch = 0
        self.current = None
        self.requests = []
    def close(self):
        self.closed = True
    def submit(self, request, payload_factory=None):
        if payload_factory is not None:
            request=payload_factory()
        self.requests.append(request)
        return True
    def poll(self):
        return None


class LiveNativeLifecycleTests(unittest.TestCase):
    def setUp(self):
        from rsview_centerline.clearance_native import VtkOnlineClearanceOverlay
        from rsview_centerline.clearance.tests.test_native_online import NativeCloud
        self.overlay = VtkOnlineClearanceOverlay.__new__(VtkOnlineClearanceOverlay)
        self.cloud = NativeCloud([(2., 1., .2)], [5.])
        sensor = SimpleNamespace(GetClientSideObject=lambda: sensor,
            GetOutput=lambda: self.cloud, UpdatePipeline=lambda *unused: None,
            UpdatePipelineInformation=lambda: None, TimestepValues=[])
        from rsview_centerline.clearance_native import LiveScanGate
        self.gate = LiveScanGate()
        self.gate.resume(now=10.)
        self.old_host = Host()
        self.overlay.__dict__.update(source_mode='live', closed=False, reader=sensor,
            live_gate=self.gate, host=self.old_host, live_stale=False,
            live_sequence=0, session='live:s', clock='device:s', live_span=None,
            pose_provider=None, last_input=None, requested_frame=None,
            input_error=None, current={'measurements': [{}]},
            last_result=dict(sequence=0, status='completed', measurements=[{}],
                device_time_s=4., session_id='live:s', clock_id='device:s', epoch=0,
                mode='observed_dual', motion_status='raw_current', timing_ms={'packet_total':1.}),
            worker_config={'sensor_max_range_m':5.},
            actors=[Actor()], labels=[], raw_rep=SimpleNamespace(Visibility=0),
            raw_visibility=1, status_label=Label(), view=None,
            smp=SimpleNamespace(Render=lambda view: None))

    def test_pause_discards_inflight_results_and_restores_raw_cloud(self):
        self.assertTrue(hasattr(self.overlay, 'set_stream_running'), 'native stream lifecycle is not wired')
        self.overlay.set_stream_running(False)
        self.assertTrue(self.old_host.closed)
        self.assertIsNone(self.overlay.host)
        self.assertIsNone(self.overlay.current)
        self.assertIsNone(self.overlay.last_result)
        self.assertEqual(self.overlay.raw_rep.Visibility, 1)
        self.assertFalse(self.overlay.actors[0].visible)
        self.overlay._timer_tick()
        self.assertEqual(self.old_host.requests, [])

    def test_resume_restarts_live_worker_without_recorded_pose_or_prior(self):
        self.assertTrue(hasattr(self.overlay, 'set_stream_running'), 'native stream lifecycle is not wired')
        self.overlay.set_stream_running(False)
        with patch('rsview_centerline.clearance_native.ClearanceProcess', Host):
            self.overlay.set_stream_running(True)
        self.assertIsNot(self.overlay.host, self.old_host)
        self.assertIsNone(self.overlay.current)
        self.assertEqual(self.gate.span, (5., 5.))
        self.assertEqual(self.overlay.host.requests, [])
        self.assertNotEqual(self.overlay.session, 'live:s')

    def test_live_timekeeper_update_does_not_look_up_pcap_scan_manifest(self):
        self.overlay.update(self.cloud, 77)
        self.assertIsNone(self.overlay.input_error)
        self.assertEqual(len(self.old_host.requests), 1)
        request = self.old_host.requests[0]
        self.assertEqual(request['sequence'], 0)
        self.assertEqual(request['device_time_s'], 5.)
        self.assertNotIn('source_sha256', request)

    def test_native_enable_baselines_existing_output_instead_of_reusing_it_as_new(self):
        from rsview_centerline import clearance_native
        class Timer:
            def connect(self, *unused):
                pass
            def start(self, unused):
                pass
        qt = SimpleNamespace(QtCore=SimpleNamespace(QTimer=Timer))
        sensor = self.overlay.reader
        sensor.SetNumberOfTrailingFrames = lambda unused: None
        with patch.dict('sys.modules', {'PythonQt':qt}), \
                patch.object(clearance_native, 'ClearanceProcess', Host), \
                patch.object(clearance_native.VtkClearanceOverlay, '__init__', lambda *a, **k: None):
            overlay = clearance_native.VtkOnlineClearanceOverlay(None, None, None, Label(),
                None, sensor, source_mode='live')
        self.assertEqual(overlay.live_gate.span, (5., 5.))
        self.assertFalse(overlay._accept_live(self.cloud, now=20.))
        self.assertEqual(overlay.host.requests, [])

        # Newly enabled LIVE workers must receive the role separation flag;
        # otherwise passing scientific tests never reaches the field UI.
        self.assertTrue(overlay.worker_config.get('rail_profile_roles', False))
        self.assertTrue(overlay.worker_config.get('spatial_object_ownership', False))
        self.assertTrue(overlay.worker_config.get('geometry_label_priority', False))

    def test_rejected_scan_cannot_spawn_repeated_workers(self):
        from rsview_centerline.clearance.tests.test_native_online import NativeCloud
        invalid = NativeCloud([(2., 1., .2)], [float('nan')])
        self.overlay.host = None
        with patch('rsview_centerline.clearance_native.ClearanceProcess', Host):
            with self.assertRaises(ValueError):
                self.overlay._accept_live(invalid, now=20.)
        self.assertIsNone(self.overlay.host)

    def test_worker_close_failure_cannot_skip_native_actor_cleanup(self):
        from rsview_centerline import clearance_native
        self.overlay.timer = SimpleNamespace(stop=lambda: None)
        def fail_close():
            raise RuntimeError('temp cleanup denied')
        self.old_host.close = fail_close
        with patch.object(clearance_native.VtkClearanceOverlay, 'close') as visual_close:
            with self.assertRaises(RuntimeError):
                self.overlay.close()
        visual_close.assert_called_once_with(self.overlay)
        self.assertIsNone(self.overlay.host)

    def test_worker_pause_cleanup_error_cannot_leave_stale_distance_visible(self):
        def fail_close():
            raise RuntimeError('temp cleanup denied')
        self.old_host.close = fail_close
        self.overlay.set_stream_running(False)
        self.assertIsNone(self.overlay.host)
        self.assertIsNone(self.overlay.current)
        self.assertIsNone(self.overlay.last_result)
        self.assertFalse(self.overlay.actors[0].visible)
        self.assertEqual(self.overlay.raw_rep.Visibility, 1)
        self.assertIn('temp cleanup denied', self.overlay.status_label.text)

    def test_slow_scan_copy_is_not_misclassified_as_disconnection_in_same_tick(self):
        from rsview_centerline import clearance_native
        # Actual Python2 native-buffer copies can take longer than the stale
        # timeout. A just-observed NEW scan must not clear its own submitted job.
        with patch.object(clearance_native, '_clock', side_effect=[10.1, 12.1]):
            self.overlay._timer_tick()
        self.assertFalse(self.overlay.live_stale)
        self.assertIs(self.overlay.host, self.old_host)
        self.assertEqual(len(self.old_host.requests), 1)

    def test_timer_reads_newest_native_scan_without_waiting_for_animation_callback(self):
        from rsview_centerline import clearance_native
        sensor = self.overlay.reader
        events = []
        sensor.UpdatePipelineInformation = lambda: (events.append('poll'),
            setattr(sensor, 'TimestepValues', [21., 22.]))
        def update(step=None):
            events.append(step)
            self.cloud.stamps.rows = [(6.,)] if step == 22. else [(5.,)]
        sensor.UpdatePipeline = update
        self.gate.resume(now=10., baseline=(5., 5.))
        with patch.object(clearance_native, '_clock', return_value=10.1):
            self.overlay._timer_tick()
        self.assertEqual(events, ['poll', 22.])
        self.assertEqual(len(self.old_host.requests), 1)
        self.assertEqual(self.old_host.requests[0]['device_time_s'], 6.)


if __name__ == '__main__':
    unittest.main()
