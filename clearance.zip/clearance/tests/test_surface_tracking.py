"""Surface identity must follow compensated geometry, not frame IDs or density."""
import unittest
from dataclasses import replace

import numpy as np

from rsview_centerline.clearance.protocol import ClearanceConfig, PoseSample, SceneLayers
from rsview_centerline.clearance.scene import extract_scene
from rsview_centerline.clearance.protocol import TrackUpdate
from rsview_centerline.clearance.tests.fixtures import cloud, line_track


def pose(frame, matrix=None):
    return PoseSample(frame.ref_time_s, np.eye(4) if matrix is None else matrix,
                      frame.clock_id, frame.scan_span_s, frame.scan_span_s[1], 'test_pose', True)


def layers(frame):
    update = TrackUpdate('observed_dual', replace(line_track(), ref_time_s=frame.ref_time_s))
    return extract_scene(frame, update, [], ClearanceConfig())


class SurfaceTrackingTests(unittest.TestCase):
    def test_sparse_visible_extreme_keeps_region_identity_despite_native_point_order(self):
        from rsview_centerline.clearance.scene import SurfaceTracker
        from rsview_centerline.clearance.protocol import Candidate
        tracker=SurfaceTracker(ClearanceConfig(display_balance_sides=True))
        points=np.tile([[2.,.1,.5]],(2000,1))
        points[777]=[2.,1.5,.5]  # Missed by the old 64 evenly spaced native indices.
        first=cloud(points)
        def one(frame):
            ids=np.arange(len(frame.xyz_L))
            return SceneLayers({'object':ids},(Candidate('surface',ids,ids,1.,1.),),{})
        observed=tracker.update(first,one(first),pose(first),line_track())
        partial=cloud([[2.,1.5,.5]],sequence=1,time=1.1)
        again=tracker.update(partial,one(partial),pose(partial),replace(line_track(),ref_time_s=1.1))
        self.assertEqual(again.candidates[0].diagnostics['display_id'],
                         observed.candidates[0].diagnostics['display_id'])
        self.assertEqual(again.candidates[0].point_indices.tolist(),[0])

    def test_display_identity_survives_skipped_results_without_extending_measurement_history(self):
        from rsview_centerline.clearance.scene import SurfaceTracker
        config=ClearanceConfig(history_seconds=.6,display_identity_seconds=1.2)
        tracker=SurfaceTracker(config)
        first=tracker._associate_display([self.description([[2.,1.,.5]],1.)],1.)
        # No current return means no annotation, even with a reserved identity.
        self.assertEqual(tracker._associate_display([],1.4),[])
        # Native midpoint jitter must not cause a full ID reset at .600014s.
        second=tracker._associate_display([self.description([[2.,1.,.5]],1.600014)],1.600014)
        self.assertEqual(first[0]['display_id'],second[0]['display_id'])
        self.assertEqual(config.history_seconds,.6)
        expired=tracker._associate_display([self.description([[2.,1.,.5]],3.)],3.)
        self.assertNotEqual(expired[0]['display_id'],second[0]['display_id'])

    def description(self, points, time):
        points=np.asarray(points,dtype=float)
        return dict(points=points,lower=points.min(axis=0),upper=points.max(axis=0),
            radius=.1,last_seen=time,layout_axis_W=np.array([0.,1.,0.]),
            layout_station_range_W=[float(points[:,1].min()),float(points[:,1].max())])

    def test_exclusive_current_bridge_support_prevents_false_partial_anchor_recapture(self):
        tracker=self.tracker()
        first=tracker._associate_display([
            self.description([[2.,y,.5] for y in np.linspace(0.,2.,41)],1.),
            self.description([[2.25,1.,.5]],1.)],1.)
        anchor=np.array(first[0]['display_anchor_W'])
        # The original centre is still observed, but in a mixed bridge. Its
        # real returns uniquely overlap the first parent, not the neighbour.
        current=tracker._associate_display([
            self.description([[2.,1.,.5],[2.25,1.,.5]],1.1),
            self.description([[2.,0.,.5]],1.1)],1.1)
        self.assertEqual(current[0]['display_event'],'ambiguous')
        self.assertEqual(current[1]['display_id'],first[0]['display_id'])
        np.testing.assert_allclose(current[1]['display_anchor_W'],anchor,atol=1e-10)
        # The bridge never becomes a historical region or a unique child.
        self.assertNotIn(current[0]['display_id'],tracker.display_regions)
        lost=tracker._associate_display([self.description([[2.,0.,.5]],1.2)],1.2)
        self.assertEqual(lost[0]['display_id'],first[0]['display_id'])
        # Neither the bridge's last return nor its layout support is held as
        # current evidence when that part is genuinely absent on the next scan.
        np.testing.assert_allclose(lost[0]['display_anchor_W'],[2.,0.,.5],atol=1e-10)

    def test_shared_current_bridge_point_cannot_hold_a_parent_anchor(self):
        tracker=self.tracker()
        first=tracker._associate_display([
            self.description([[2.,y,.5] for y in np.linspace(0.,2.,41)],1.),
            self.description([[2.15,1.,.5]],1.)],1.)
        current=tracker._associate_display([
            self.description([[2.075,1.,.5]],1.1),
            self.description([[2.,0.,.5]],1.1)],1.1)
        self.assertEqual(current[0]['display_event'],'ambiguous')
        self.assertEqual(current[1]['display_id'],first[0]['display_id'])
        np.testing.assert_allclose(current[1]['display_anchor_W'],[2.,0.,.5],atol=1e-10)

    def test_minority_parent_overlap_is_not_mistaken_for_exclusive_layout_support(self):
        tracker=self.tracker()
        first=tracker._associate_display([
            self.description([[2.,y,.5] for y in np.linspace(0.,2.,41)],1.),
            self.description([[2.5,.9,.5]],1.),
            self.description([[2.14,1.,.5]],1.)],1.)
        current=tracker._associate_display([
            self.description([[2.,.8,.5],[2.05,1.,.5],
                              [2.5,.86,.5],[2.5,.94,.5]],1.1),
            self.description([[2.,0.,.5]],1.1)],1.1)
        self.assertEqual(current[0]['display_event'],'ambiguous')
        self.assertEqual(current[1]['display_id'],first[0]['display_id'])
        # The small third parent covers only one quarter of the bridge, so it
        # is not a majority match. Its shared return at station1.0 must still
        # not hold the first parent's anchor. Exclusive support ends at.8.
        np.testing.assert_allclose(current[1]['display_anchor_W'],[2.,.8,.5],atol=1e-10)

    def test_station_recapture_takes_nearest_supported_station_not_partial_centroid(self):
        tracker=self.tracker()
        def description(points,time):
            points=np.asarray(points,dtype=float)
            return dict(points=points,lower=points.min(axis=0),upper=points.max(axis=0),
                radius=.05,last_seen=time,layout_axis_W=np.array([0.,1.,0.]),
                layout_station_range_W=[float(points[:,1].min()),float(points[:,1].max())])
        points=[[2.,y,.5] for y in np.linspace(0.,2.,81)]
        first=tracker._associate_display([description(points,1.)],1.)
        partial=[[2.,y,.5] for y in np.linspace(0.,.85,35)]
        second=tracker._associate_display([description(partial,1.1)],1.1)
        self.assertEqual(second[0]['display_id'],first[0]['display_id'])
        # The valid station nearest the previous1.0 is.85, not centroid.425.
        np.testing.assert_allclose(second[0]['display_anchor_W'],[2.,.85,.5],atol=1e-10)
        # Returning support does not snap the annotation back to an old centre.
        third=tracker._associate_display([description(points,1.2)],1.2)
        np.testing.assert_allclose(third[0]['display_anchor_W'],second[0]['display_anchor_W'],atol=1e-10)

    def test_update_uses_current_track_axis_for_partial_face_visibility(self):
        from rsview_centerline.clearance.protocol import Candidate
        tracker=self.tracker()
        first=cloud([[2.,y,z] for y in np.linspace(.1,1.9,41) for z in (.5,1.5)])
        def one_region(frame):
            indices=np.arange(len(frame.xyz_L))
            return SceneLayers({'object':indices},(Candidate('face',indices,indices,1.,1.),),{})
        a=tracker.update(first,one_region(first),pose(first),line_track())
        current=cloud([[2.,y,1.5] for y in list(np.linspace(.5,1.,21))+[1.5]],
                      sequence=1,time=1.1)
        b=tracker.update(current,one_region(current),pose(current),
                         replace(line_track(),ref_time_s=current.ref_time_s))
        self.assertEqual(a.candidates[0].diagnostics['display_id'],b.candidates[0].diagnostics['display_id'])
        np.testing.assert_allclose(b.candidates[0].diagnostics['display_anchor_L'],
                                   a.candidates[0].diagnostics['display_anchor_L'],atol=1e-10)

    def test_height_visibility_change_does_not_relocate_a_supported_track_station(self):
        tracker=self.tracker()
        def description(points,time):
            points=np.asarray(points,dtype=float)
            return dict(points=points,lower=points.min(axis=0),upper=points.max(axis=0),
                radius=.1,last_seen=time,layout_axis_W=np.array([0.,1.,0.]),
                layout_station_range_W=[float(points[:,1].min()),float(points[:,1].max())])
        points=[[2.,y,z] for y in np.linspace(0.,2.,41) for z in (0.,1.)]
        first=tracker._associate_display([description(points,1.)],1.)
        old_anchor=np.array(first[0]['display_anchor_W'])
        # Upper face only; the anchor station1.0 is still visibly supported.
        partial=[[2.,y,1.] for y in list(np.linspace(.5,1.,21))+[1.5]]
        second=tracker._associate_display([description(partial,1.1)],1.1)
        self.assertEqual(second[0]['display_id'],first[0]['display_id'])
        np.testing.assert_allclose(second[0]['display_anchor_W'],old_anchor,atol=1e-10)

    def test_bridge_refresh_survives_a_unique_child_in_the_same_scan(self):
        tracker=self.tracker()
        def description(points,time):
            points=np.asarray(points,dtype=float)
            return dict(points=points,lower=points.min(axis=0),upper=points.max(axis=0),
                        radius=.1,last_seen=time)
        first=tracker._associate_display([description([[0.,0.,0.],[1.,0.,0.]],1.),
                                         description([[.15,0.,0.]],1.)],1.)
        identity=first[0]['display_id']
        mixed=tracker._associate_display([description([[0.,0.,0.],[.15,0.,0.]],1.5),
                                         description([[1.,0.,0.]],1.5)],1.5)
        self.assertEqual(mixed[0]['display_event'],'ambiguous')
        self.assertEqual(mixed[1]['display_id'],identity)
        np.testing.assert_allclose(tracker.display_regions[identity]['point_times'],[1.5,1.5])
        again=tracker._associate_display([description([[0.,0.,0.]],1.7)],1.7)
        self.assertEqual(again[0]['display_id'],identity)

    def test_detached_display_anchor_recaptures_current_visible_region_instead_of_chasing_edge(self):
        tracker=self.tracker()
        first=cloud([[2.,y,.5] for y in np.linspace(.05,1.65,161)])
        a=tracker.update(first,layers(first),pose(first))
        partial=cloud([[2.,y,.5] for y in np.linspace(.05,.25,21)],sequence=1,time=1.1)
        b=tracker.update(partial,layers(partial),pose(partial))
        self.assertEqual(b.candidates[0].diagnostics['display_id'],a.candidates[0].diagnostics['display_id'])
        np.testing.assert_allclose(b.candidates[0].diagnostics['display_anchor_L'],[2.,.15,.5],atol=.02)
        np.testing.assert_array_equal(partial.xyz_L[:,1],np.linspace(.05,.25,21))

    def test_old_unseen_points_expire_even_while_other_part_of_region_is_visible(self):
        tracker=self.tracker()
        first=cloud([[2.,y,.5] for y in np.linspace(.05,1.65,161)])
        observed=tracker.update(first,layers(first),pose(first))
        identity=observed.candidates[0].diagnostics['display_id']
        for i in range(1,10):
            frame=cloud([[2.,y,.5] for y in np.linspace(.05,.25,21)],
                        sequence=i,time=1.+i*.1)
            tracker.update(frame,layers(frame),pose(frame))
        self.assertIn(identity,tracker.display_regions)
        self.assertLess(tracker.display_regions[identity]['upper'][1],.3)
        far=cloud([[2.,y,.5] for y in np.linspace(1.5,1.65,16)],sequence=10,time=2.)
        again=tracker.update(far,layers(far),pose(far))
        self.assertNotEqual(again.candidates[0].diagnostics['display_id'],identity)

    def test_annotation_reserves_identity_only_and_clears_it_with_the_pose_map(self):
        tracker=self.tracker()
        first=cloud([[2.,1.,.5]])
        a=tracker.update(first,layers(first),pose(first))
        identity=a.candidates[0].diagnostics['display_id']
        tracker.remember_annotations([dict(display_id=identity)])
        gap=cloud([],sequence=1,time=1.1)
        b=tracker.update(gap,layers(gap),pose(gap))
        tracker.remember_annotations([])
        self.assertEqual(b.candidates,())
        again=cloud(first.xyz_L,sequence=2,time=1.2)
        c=tracker.update(again,layers(again),pose(again))
        self.assertTrue(c.candidates[0].diagnostics['display_slot_reserved'])
        changed=cloud(first.xyz_L,sequence=3,time=1.3)
        d=tracker.update(changed,layers(changed),replace(pose(changed),source='other-map'))
        self.assertFalse(d.candidates[0].diagnostics['display_slot_reserved'])

    def test_dense_partial_visibility_does_not_forget_recent_region_extremes(self):
        tracker=self.tracker()
        first=cloud([[2.,y,.5] for y in np.linspace(.05,1.65,161)])
        a=tracker.update(first,layers(first),pose(first))
        islands=[[2.,y,.5] for start in (.05,.3,.55,.8) for y in np.linspace(start,start+.12,64)]
        for i in range(1,4):
            frame=cloud(islands,sequence=i,time=1.+i*.08)
            tracker.update(frame,layers(frame),pose(frame))
        again=cloud(islands+[[2.,y,.5] for y in np.linspace(1.35,1.65,61)],sequence=4,time=1.32)
        b=tracker.update(again,layers(again),pose(again))
        self.assertEqual({c.diagnostics['display_id'] for c in b.candidates},
                         {a.candidates[0].diagnostics['display_id']})

    def test_small_visible_islands_keep_display_region_without_large_old_overlap(self):
        tracker=self.tracker()
        first=cloud([[2.,.05+i*.04,.5] for i in range(41)])
        a=tracker.update(first,layers(first),pose(first))
        second=cloud([[2.,y,.5] for start in (.05,.55,1.05,1.55)
                      for y in (start,start+.04)],sequence=1,time=1.1)
        b=tracker.update(second,layers(second),pose(second))
        self.assertEqual(len(b.candidates),4)
        self.assertEqual({c.diagnostics['display_id'] for c in b.candidates},
                         {a.candidates[0].diagnostics['display_id']})

    def test_ambiguous_bridge_does_not_erase_two_established_display_regions(self):
        tracker=self.tracker()
        original=[[x,1.,.5] for x in (2.,2.05,2.10,2.15,2.30,2.35,2.40,2.45)]
        first=cloud(original)
        a=tracker.update(first,layers(first),pose(first))
        self.assertEqual(len(a.candidates),2)
        bridge=cloud([[2.+i*.05,1.,.5] for i in range(10)],sequence=1,time=1.1)
        b=tracker.update(bridge,layers(bridge),pose(bridge))
        self.assertEqual(len(b.candidates),1)
        old_ids=[c.diagnostics['display_id'] for c in a.candidates]
        self.assertNotIn(b.candidates[0].diagnostics['display_id'],old_ids)
        again=cloud(original,sequence=2,time=1.2)
        c=tracker.update(again,layers(again),pose(again))
        self.assertEqual([item.diagnostics['display_id'] for item in c.candidates],old_ids)

    def test_repeated_bridge_does_not_expire_still_observed_separate_regions(self):
        tracker=self.tracker()
        original=[[x,1.,.5] for x in (2.,2.05,2.10,2.15,2.30,2.35,2.40,2.45)]
        first=cloud(original)
        a=tracker.update(first,layers(first),pose(first))
        old_ids=[item.diagnostics['display_id'] for item in a.candidates]
        for i in range(1,12):
            bridge=cloud([[2.+j*.05,1.,.5] for j in range(10)],sequence=i,time=1.+i*.1)
            tracker.update(bridge,layers(bridge),pose(bridge))
        again=cloud(original,sequence=12,time=2.2)
        b=tracker.update(again,layers(again),pose(again))
        self.assertEqual([item.diagnostics['display_id'] for item in b.candidates],old_ids)

    def test_split_keeps_one_display_region_and_fixed_anchor_but_not_raw_surface_id(self):
        tracker = self.tracker()
        first = cloud([[2,1,.5],[2.05,1,.5],[2.10,1,.5],[2.15,1,.5]])
        a = tracker.update(first,layers(first),pose(first))
        second = cloud([[2,1,.5],[2.15,1,.5]],sequence=1,time=1.1)
        b = tracker.update(second,layers(second),pose(second))
        identity = a.candidates[0].diagnostics['display_id']
        self.assertEqual(len(b.candidates),2)
        for c in b.candidates:
            self.assertEqual(c.diagnostics['display_id'],identity)
            np.testing.assert_allclose(c.diagnostics['display_anchor_L'],
                                       a.candidates[0].diagnostics['display_anchor_L'])
            self.assertNotEqual(c.diagnostics['surface_id'],a.candidates[0].diagnostics['surface_id'])
        third = cloud(first.xyz_L,sequence=2,time=1.2)
        c = tracker.update(third,layers(third),pose(third))
        self.assertEqual(c.candidates[0].diagnostics['display_id'],identity)

    def test_display_anchor_reprojects_fixed_world_position_under_vehicle_motion(self):
        tracker = self.tracker()
        first = cloud([[2,1,.5],[2.01,1.01,.51]])
        a = tracker.update(first,layers(first),pose(first))
        matrix = np.eye(4); matrix[0,3] = 1.
        second = cloud(first.xyz_L-[1.,0.,0.],sequence=1,time=1.1)
        b = tracker.update(second,layers(second),pose(second,matrix))
        self.assertEqual(a.candidates[0].diagnostics['display_id'],b.candidates[0].diagnostics['display_id'])
        np.testing.assert_allclose(np.asarray(b.candidates[0].diagnostics['display_anchor_L'])+[1.,0.,0.],
                                   a.candidates[0].diagnostics['display_anchor_L'])

    def test_distinct_display_regions_are_not_joined_by_an_ambiguous_bridge(self):
        from rsview_centerline.clearance.protocol import Candidate
        tracker = self.tracker()
        first = cloud([[2,1,.5],[2.04,1,.5],[2.08,1,.5],[2.12,1,.5]])
        a_layers = SceneLayers({'object':np.arange(4)},tuple(
            Candidate(str(i),np.array(indices),np.array(indices),1.,1.)
            for i,indices in enumerate(([0,1],[2,3]))),{})
        a = tracker.update(first,a_layers,pose(first))
        second = cloud(first.xyz_L,sequence=1,time=1.1)
        b = tracker.update(second,layers(second),pose(second))
        old_ids = {c.diagnostics['display_id'] for c in a.candidates}
        self.assertEqual(len(old_ids),2)
        self.assertNotIn(b.candidates[0].diagnostics['display_id'],old_ids)
        self.assertEqual(b.candidates[0].diagnostics['display_association'],'ambiguous')

    def test_display_region_is_not_reused_after_pose_loss_or_map_change(self):
        tracker = self.tracker()
        first = cloud([[2,1,.5]])
        a = tracker.update(first,layers(first),pose(first))
        second = cloud(first.xyz_L,sequence=1,time=1.1)
        b = tracker.update(second,layers(second),None)
        self.assertIsNone(b.candidates[0].diagnostics.get('display_anchor_L'))
        third = cloud(first.xyz_L,sequence=2,time=1.2)
        c = tracker.update(third,layers(third),replace(pose(third),source='other-map'))
        self.assertNotEqual(a.candidates[0].diagnostics['display_id'],c.candidates[0].diagnostics['display_id'])

    def test_map_identity_change_does_not_reuse_a_surface_number(self):
        tracker = self.tracker()
        a = cloud([[2.,1.,.5]],sequence=0,time=1.)
        b = cloud([[2.,1.,.5]],sequence=1,time=1.1)
        first = tracker.update(a,layers(a),pose(a))
        second = tracker.update(b,layers(b),replace(pose(b),source='new-map',diagnostics={'clock_epoch':1}))
        self.assertNotEqual(first.candidates[0].diagnostics['surface_id'],
                            second.candidates[0].diagnostics['surface_id'])
        self.assertEqual(second.candidates[0].diagnostics['surface_observations'],1)

    def tracker(self):
        from rsview_centerline.clearance import scene
        self.assertTrue(hasattr(scene, 'SurfaceTracker'), 'stable compensated surface identities missing')
        return scene.SurfaceTracker(ClearanceConfig())

    def test_vehicle_translation_does_not_create_a_new_surface_identity(self):
        tracker = self.tracker()
        first = cloud([[2, 1, .5], [2.01, 1.01, .51]], sequence=0)
        a = tracker.update(first, layers(first), pose(first))
        second = cloud([[1, 1, .5], [1.01, 1.01, .51]], time=1.1, sequence=1)
        matrix = np.eye(4)
        matrix[0, 3] = 1.
        b = tracker.update(second, layers(second), pose(second, matrix))
        self.assertEqual(a.candidates[0].diagnostics['surface_id'], b.candidates[0].diagnostics['surface_id'])
        self.assertEqual(b.candidates[0].diagnostics['surface_observations'], 2)
        np.testing.assert_array_equal(b.candidates[0].point_indices, [0, 1])
        self.assertEqual(b.candidates[0].candidate_id, 'frame1-component0')

    def test_both_sides_remain_distinct_and_are_not_relabelled_by_density(self):
        tracker = self.tracker()
        first = cloud([[2, 1, .5], [2.01, 1.01, .51], [-2, 1, .5], [-2.01, 1.01, .51]])
        a = tracker.update(first, layers(first), pose(first))
        second = cloud([[2, 1, .5], [-2, 1, .5], [-2.01, 1.01, .51], [-2.02, 1.02, .52]],
                       sequence=1, time=1.1)
        b = tracker.update(second, layers(second), pose(second))
        self.assertEqual([c.diagnostics['surface_id'] for c in a.candidates],
                         [c.diagnostics['surface_id'] for c in b.candidates])
        self.assertNotEqual(b.candidates[0].diagnostics['surface_id'], b.candidates[1].diagnostics['surface_id'])

    def test_no_pose_does_not_claim_stationary_vehicle_or_keep_old_identity(self):
        tracker = self.tracker()
        first = cloud([[2, 1, .5]])
        a = tracker.update(first, layers(first), pose(first))
        second = cloud([[2, 1, .5]], sequence=1, time=1.1)
        b = tracker.update(second, layers(second), None)
        self.assertIsNone(b.candidates[0].diagnostics['surface_id'])
        third = cloud([[2, 1, .5]], sequence=2, time=1.2)
        c = tracker.update(third, layers(third), pose(third))
        self.assertNotEqual(a.candidates[0].diagnostics['surface_id'], c.candidates[0].diagnostics['surface_id'])

    def test_clock_reversal_does_not_match_into_old_map(self):
        tracker = self.tracker()
        first = cloud([[2, 1, .5]], sequence=10, time=2.)
        a = tracker.update(first, layers(first), pose(first))
        second = cloud([[2, 1, .5]], sequence=11, time=1.)
        b = tracker.update(second, layers(second), pose(second))
        self.assertNotEqual(a.candidates[0].diagnostics['surface_id'], b.candidates[0].diagnostics['surface_id'])
        self.assertEqual(b.candidates[0].diagnostics['surface_observations'], 1)

    def test_split_surface_reports_ambiguity_instead_of_reusing_one_id_twice(self):
        tracker = self.tracker()
        first = cloud([[2, 1, .5], [2.05, 1, .5], [2.10, 1, .5], [2.15, 1, .5]])
        a = tracker.update(first, layers(first), pose(first))
        second = cloud([[2, 1, .5], [2.15, 1, .5]], sequence=1, time=1.1)
        b = tracker.update(second, layers(second), pose(second))
        old_id = a.candidates[0].diagnostics['surface_id']
        self.assertEqual(len(b.candidates), 2)
        self.assertTrue(all(c.diagnostics['surface_id'] != old_id for c in b.candidates))
        self.assertTrue(all(c.diagnostics['surface_association'] == 'ambiguous' for c in b.candidates))

    def test_sparse_low_object_is_not_deleted_by_tracking(self):
        tracker = self.tracker()
        first = cloud([[3, 1, .03]])
        a = tracker.update(first, layers(first), pose(first))
        second = cloud([[3, 1, .03]], time=1.1, sequence=1)
        b = tracker.update(second, layers(second), pose(second))
        self.assertEqual(a.candidates[0].diagnostics['surface_id'], b.candidates[0].diagnostics['surface_id'])
        np.testing.assert_array_equal(b.candidates[0].point_indices, [0])

    def test_vehicle_rotation_keeps_identity_using_full_rigid_pose(self):
        tracker = self.tracker()
        first = cloud([[2,1,.5],[2.01,1.01,.51]])
        a = tracker.update(first,layers(first),pose(first))
        angle = np.deg2rad(20.)
        matrix = np.eye(4)
        matrix[:3,:3] = [[np.cos(angle),-np.sin(angle),0],
                          [np.sin(angle),np.cos(angle),0],[0,0,1]]
        points = first.xyz_L@matrix[:3,:3]
        second = cloud(points,time=1.1,sequence=1)
        b = tracker.update(second,layers(second),pose(second,matrix))
        self.assertEqual(a.candidates[0].diagnostics['surface_id'],b.candidates[0].diagnostics['surface_id'])

    def test_brief_occlusion_keeps_id_but_creates_no_held_measurement(self):
        tracker = self.tracker()
        first = cloud([[2,1,.5]])
        a = tracker.update(first,layers(first),pose(first))
        second = cloud([],time=1.1,sequence=1)
        b = tracker.update(second,layers(second),pose(second))
        self.assertEqual(b.candidates,())
        third = cloud([[2,1,.5]],time=1.2,sequence=2)
        c = tracker.update(third,layers(third),pose(third))
        self.assertEqual(a.candidates[0].diagnostics['surface_id'],c.candidates[0].diagnostics['surface_id'])
        self.assertEqual(c.candidates[0].diagnostics['surface_observations'],2)

    def test_expired_surface_does_not_inherit_identity_or_accumulated_support(self):
        tracker = self.tracker()
        first = cloud([[2,1,.5]])
        a = tracker.update(first,layers(first),pose(first))
        second = cloud([[2,1,.5]],time=2.,sequence=1)
        b = tracker.update(second,layers(second),pose(second))
        self.assertNotEqual(a.candidates[0].diagnostics['surface_id'],b.candidates[0].diagnostics['surface_id'])
        self.assertEqual(b.candidates[0].diagnostics['surface_observations'],1)

    def test_future_pose_cannot_confirm_surface_identity(self):
        tracker = self.tracker()
        first = cloud([[2,1,.5]])
        future = replace(pose(first),available_until_s=2.)
        result = tracker.update(first,layers(first),future)
        self.assertIsNone(result.candidates[0].diagnostics['surface_id'])


if __name__ == '__main__':
    unittest.main()
