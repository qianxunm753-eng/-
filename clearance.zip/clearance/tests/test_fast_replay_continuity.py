"""Known forward fast-play steps are not arbitrary paused seeks."""
from types import SimpleNamespace
import unittest
from rsview_centerline.clearance.tests import test_recorded_playback as _fixtures
from rsview_centerline import clearance_native


class FastReplayContinuityTests(unittest.TestCase):
    def overlay(self,playing=True,direction=2,seek=False,enabled=True):
        overlay=_fixtures.RecordedNativeTests().overlay()
        overlay.logic=SimpleNamespace(app=SimpleNamespace(playing=playing,playDirection=direction,seekPlay=seek))
        overlay.worker_config={'recorded_playback_continuity':enabled,'history_seconds':.6}
        return overlay

    def test_known_two_frame_fast_play_step_preserves_the_actual_clock_session(self):
        overlay=self.overlay()
        overlay._update_recorded(20,poll=False)
        session,clock=overlay.session,overlay.clock
        overlay._update_recorded(22,poll=False)
        self.assertEqual(overlay.session,session,'normal SDK two-frame fast-play step reset all motion/ID history')
        self.assertEqual(overlay.clock,clock)
        self.assertEqual(overlay.host.requests[-1][0]['sequence'],22)
        self.assertFalse(overlay.host.requests[-1][1])
        self.assertEqual(overlay.host.epoch,0)

    def test_actual_recorded_entry_connects_sdk_player_state_before_fast_frames(self):
        from unittest.mock import patch
        # Only native VTK/Qt construction is external. Keep the real recorded
        # entry, decoder identity checks, scheduling, and epoch policy intact.
        native=_fixtures.RecordedNativeTests().overlay()
        native.worker_config={'recorded_playback_continuity':True,'history_seconds':.6}
        app=SimpleNamespace(playing=True,playDirection=2,seekPlay=False,
            curLidarType='RSAIRY',railOverlay=None,mainView=None,statusLabel=native.status_label)
        logic=SimpleNamespace(app=app,smp=native.smp,vtk=native.vtk,
            getReader=lambda:native.reader,getReaderFileName=lambda:'input.pcap')
        with patch.object(clearance_native,'VtkOnlineClearanceOverlay',return_value=native):
            overlay=clearance_native.enable_recorded(logic)
        overlay._update_recorded(20,poll=False)
        session=overlay.session
        overlay._update_recorded(22,poll=False)
        self.assertEqual(overlay.session,session,'real recorded entry omitted SDK player state')
        self.assertEqual(overlay.host.epoch,0)
        self.assertEqual(overlay.host.requests[-1][0]['sequence'],22)

    def test_paused_two_frame_seek_still_changes_epoch(self):
        overlay=self.overlay(playing=False)
        overlay._update_recorded(20,poll=False)
        session=overlay.session
        overlay._update_recorded(22,poll=False)
        self.assertNotEqual(overlay.session,session)
        self.assertTrue(overlay.host.requests[-1][1])

    def test_mismatched_player_step_is_still_a_seek(self):
        overlay=self.overlay(direction=2)
        overlay._update_recorded(20,poll=False)
        session=overlay.session
        overlay._update_recorded(23,poll=False)
        self.assertNotEqual(overlay.session,session)

    def test_seek_button_mode_does_not_reuse_fast_play_history(self):
        overlay=self.overlay(seek=True)
        overlay._update_recorded(20,poll=False)
        session=overlay.session
        overlay._update_recorded(22,poll=False)
        self.assertNotEqual(overlay.session,session)

    def test_sdk_slow_modes_four_and_five_have_one_frame_steps(self):
        for direction in (4,5):
            with self.subTest(direction=direction):
                overlay=self.overlay(direction=direction)
                overlay._update_recorded(20,poll=False)
                session=overlay.session
                overlay._update_recorded(20+direction,poll=False)
                self.assertNotEqual(overlay.session,session)

    def test_disabled_route_keeps_the_old_seek_policy(self):
        overlay=self.overlay(enabled=False)
        overlay._update_recorded(20,poll=False)
        session=overlay.session
        overlay._update_recorded(22,poll=False)
        self.assertNotEqual(overlay.session,session)

    def test_known_three_frame_fast_step_is_bounded_and_preserves_session(self):
        overlay=self.overlay(direction=3)
        overlay._update_recorded(20,poll=False)
        session=overlay.session
        overlay._update_recorded(23,poll=False)
        self.assertEqual(overlay.session,session)

    def test_large_device_time_gap_resets_even_when_player_step_matches(self):
        gate=clearance_native.PlaybackScanGate(True,max_gap_s=.25)
        gate.observe(20,(10.,10.1),2)
        gate.observe(22,(10.4,10.5),2)
        self.assertTrue(gate.discontinuous)

    def test_clock_reversal_resets_even_when_fast_step_matches(self):
        gate=clearance_native.PlaybackScanGate(True)
        gate.observe(20,(10.,10.1),2)
        gate.observe(22,(9.,9.1),2)
        self.assertTrue(gate.discontinuous)

    def test_duplicate_current_scan_is_not_another_observation(self):
        gate=clearance_native.PlaybackScanGate(True)
        gate.observe(20,(10.,10.1),2)
        self.assertFalse(gate.observe(20,(10.,10.1),2))

    def test_known_fast_play_cannot_accept_an_old_decoded_frame(self):
        overlay=self.overlay()
        overlay._update_recorded(20,poll=False)
        stale=_fixtures.NativeCloud([(2.,1.,.2)],[12.])
        stale.GetInformation=lambda:_fixtures.Information(20.)
        overlay.reader.GetClientSideObject=lambda:SimpleNamespace(GetOutput=lambda:stale)
        count=len(overlay.host.requests)
        overlay._update_recorded(22,poll=False)
        self.assertIn('still decoding',overlay.input_error)
        self.assertEqual(len(overlay.host.requests),count)
        self.assertEqual(overlay.playback_gate.frame,20)
        self.assertIsNone(overlay.current)

    def test_explicit_preset_remains_replay_only(self):
        import os
        from unittest.mock import patch
        from rsview_centerline.clearance.online import OnlineEngine
        with patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':'v32'}):
            self.assertTrue(clearance_native.recorded_measurement_config().get('recorded_playback_continuity'))
            self.assertFalse(clearance_native.live_measurement_config().get('recorded_playback_continuity',False))
        with self.assertRaisesRegex(ValueError,'replay-only'):
            OnlineEngine({'recorded_playback_continuity':True},source_mode='live')


if __name__=='__main__':
    unittest.main()
