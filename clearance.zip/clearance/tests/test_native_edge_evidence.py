"""A bounded fitting sample cannot decide whether a real shared edge exists."""
from dataclasses import dataclass,replace
import unittest
import numpy as np
from rsview_centerline.clearance.objects import refine_objects
from rsview_centerline.clearance.measure import measure_candidates
from rsview_centerline.clearance.protocol import TrackUpdate
from rsview_centerline.clearance.tests.fixtures import cloud,line_track
from rsview_centerline.clearance.tests.test_instance_ownership import parts
from rsview_centerline.clearance.tests.test_current_instance_reconciliation import configuration as base_config


@dataclass(frozen=True)
class NativeEdgeConfig(type(base_config())):
    native_shared_edge_evidence: bool = True


def configuration(enabled=True):
    return NativeEdgeConfig(**dict(base_config().__dict__,native_shared_edge_evidence=enabled))


def scene(end_a=3.,start_z_b=.5):
    a=np.array([[2.,y,z] for y in np.arange(0.,end_a+.001,.02) for z in np.arange(.5,1.001,.02)])
    b=np.array([[x,3.,z] for x in np.arange(2.12,3.801,.02) for z in np.arange(start_z_b,start_z_b+.501,.02)])
    frame=cloud(np.vstack((a,b)))
    return frame,parts(frame,[np.arange(len(a)),np.arange(len(a),len(a)+len(b))])


class NativeEdgeEvidenceTests(unittest.TestCase):
    def test_real_common_edge_is_not_lost_when_fit_samples_omit_its_span(self):
        frame,layers=scene()
        track=TrackUpdate('observed_dual',line_track())
        result=refine_objects(frame,track,layers,configuration())
        self.assertEqual(len(result.candidates),1,'sampled corner omitted independently observed native edge span')
        np.testing.assert_array_equal(result.candidates[0].point_indices,np.arange(len(frame.xyz_L)))
        measured=measure_candidates(frame,track,result,configuration())
        self.assertEqual(measured[0].observed_min_distance_m,2.)
        self.assertEqual(measured[0].observed_evidence.point_ref.index,0)

    def test_v29_disabled_route_keeps_the_previous_bounded_fit_sample(self):
        frame,layers=scene()
        result=refine_objects(frame,TrackUpdate('observed_dual',line_track()),layers,configuration(False))
        self.assertEqual(len(result.candidates),2)

    def test_extrapolated_intersection_without_actual_near_edge_returns_never_merges(self):
        frame,layers=scene(end_a=2.7)
        result=refine_objects(frame,TrackUpdate('observed_dual',line_track()),layers,configuration())
        self.assertEqual(len(result.candidates),2)

    def test_disjoint_actual_edge_spans_cannot_merge(self):
        frame,layers=scene(start_z_b=1.4)
        result=refine_objects(frame,TrackUpdate('observed_dual',line_track()),layers,configuration())
        self.assertEqual(len(result.candidates),2)

    def test_temporal_only_native_edge_returns_cannot_supply_current_connection(self):
        frame,layers=scene()
        a=replace(layers.candidates[0],diagnostics={'support_neighbor_valid':
            np.zeros((len(layers.candidates[0].point_indices),1),dtype=bool)})
        result=refine_objects(frame,TrackUpdate('observed_dual',line_track()),
                              replace(layers,candidates=(a,layers.candidates[1])),configuration())
        self.assertEqual(len(result.candidates),2)

    def test_malformed_current_support_abstains_from_a_native_edge_proof(self):
        frame,layers=scene()
        a=replace(layers.candidates[0],diagnostics={'support_neighbor_valid':np.ones((1,1),dtype=bool)})
        result=refine_objects(frame,TrackUpdate('observed_dual',line_track()),
                              replace(layers,candidates=(a,layers.candidates[1])),configuration())
        self.assertEqual(len(result.candidates),2)

    def test_unsupported_middle_points_cannot_close_a_current_to_current_gap(self):
        frame,layers=scene()
        a,b=layers.candidates
        az=frame.xyz_L[a.point_indices,2]
        bz=frame.xyz_L[b.point_indices,2]
        a=replace(a,diagnostics={'support_neighbor_valid':((az<.55)|(az>.96))[:,None]})
        b=replace(b,diagnostics={'support_neighbor_valid':((bz>.69)&(bz<.82))[:,None]})
        result=refine_objects(frame,TrackUpdate('observed_dual',line_track()),
                              replace(layers,candidates=(a,b)),configuration())
        self.assertEqual(len(result.candidates),2,
                         'unsupported A middle returns closed the actual current-to-current gap')

    def test_native_pairwise_edges_still_require_complete_link_membership(self):
        frame,layers=scene()
        c=np.array([[x,y,1.12] for x in np.arange(2.12,3.601,.02) for y in np.arange(3.12,3.201,.02)])
        n=len(frame.xyz_L)
        combined=cloud(np.vstack((frame.xyz_L,c)))
        layers=parts(combined,[layers.candidates[0].point_indices,layers.candidates[1].point_indices,
                               np.arange(n,n+len(c))])
        result=refine_objects(combined,TrackUpdate('observed_dual',line_track()),layers,configuration())
        self.assertEqual(len(result.candidates),2,'observing A-B and B-C falsely invented A-C')
        self.assertEqual(result.diagnostics['current_ownership_links'],[])
        np.testing.assert_array_equal(np.sort(np.concatenate([x.point_indices for x in result.candidates])),
                                      np.arange(len(combined.xyz_L)))

    def test_explicit_replay_preset_and_independent_live_rejection(self):
        import os
        from unittest.mock import patch
        from rsview_centerline.clearance_native import recorded_measurement_config,live_measurement_config
        from rsview_centerline.clearance.online import OnlineEngine
        with patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':'v30'}):
            cfg=recorded_measurement_config()
            self.assertTrue(cfg.get('native_shared_edge_evidence'))
            self.assertFalse(live_measurement_config().get('native_shared_edge_evidence',False))
        with self.assertRaisesRegex(ValueError,'replay-only'):
            OnlineEngine({'native_shared_edge_evidence':True},source_mode='live')
        with self.assertRaisesRegex(ValueError,'qualified current surface'):
            OnlineEngine({'native_shared_edge_evidence':True},source_mode='recorded_pcap')


if __name__=='__main__':
    unittest.main()
