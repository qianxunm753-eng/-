# -*- coding: utf-8 -*-
"""Real VTK6 regression: native tuples/cells survive resize and buffer lifetime."""
import array
import gc
import json
import os
import traceback
from PythonQt import QtCore, QtGui
import rsview.applogic as logic


def run():
    report = {'error': None, 'checks': []}
    try:
        from clearance_overlay import VtkPointBuffer, _vtk_type
        data = _vtk_type(logic.vtk, 'vtkPolyData')()
        upload = VtkPointBuffer(logic.vtk, data, max_points=5)
        points_id = None
        for coordinates in ([1.,2.,3.,4.,5.,6.], [7.,8.,9.], [],
                            [1.,2.,3.,4.,5.,6.,7.,8.,9.]):
            expected = [tuple(coordinates[i:i+3]) for i in range(0,len(coordinates),3)]
            upload.update(array.array('f',coordinates))
            gc.collect()
            count = len(expected)
            report['latest'] = dict(expected=count, points=data.GetNumberOfPoints(),
                verts=data.GetNumberOfVerts(), cells=upload.cells.GetNumberOfCells(),
                id_tuples=upload.ids.GetNumberOfTuples(), float_tuples=upload.coordinates.GetNumberOfTuples())
            assert data.GetNumberOfPoints() == count, 'point count mismatch'
            assert data.GetNumberOfVerts() == count, 'vertex count mismatch'
            assert [tuple(data.GetPoint(i)) for i in range(count)] == expected
            for i in range(count):
                cell = data.GetCell(i)
                assert cell.GetNumberOfPoints() == 1 and cell.GetPointId(0) == i
            if points_id is None:
                points_id = data.GetPoints().__this__
            assert data.GetPoints().__this__ == points_id, 'geometry recreated for each frame'
            report['checks'].append(count)
        for values in ([1.,2.], [0.]*18):
            try:
                upload.update(array.array('f',values))
            except ValueError:
                pass
            else:
                raise AssertionError('malformed or oversized points accepted')
    except Exception:
        report['error'] = traceback.format_exc().decode('utf-8','replace')
    with open(os.environ['RSVIEW_BUFFER_REPORT'].decode('mbcs'), 'wb') as stream:
        stream.write(json.dumps(report,indent=2).encode('utf-8'))
    QtGui.QApplication.instance().quit()


timer = QtCore.QTimer()
timer.setSingleShot(True)
timer.connect('timeout()', run)
timer.start(1000)
