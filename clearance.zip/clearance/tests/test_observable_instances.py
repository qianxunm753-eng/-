"""Fragments retain ranges, but cannot certify a new instance by repetition."""
from dataclasses import dataclass,replace
import os
import unittest
from unittest.mock import patch
import numpy as np
from rsview_centerline import clearance_native
from rsview_centerline.clearance.scene import SurfaceTracker
from rsview_centerline.clearance.measure import measure_candidates
from rsview_centerline.clearance.rsview_cache import build_packet
from rsview_centerline.clearance.protocol import TrackUpdate
from rsview_centerline.clearance.tests.fixtures import cloud,line_track
from rsview_centerline.clearance.tests.test_history_owner_keys import OwnerConfig
from rsview_centerline.clearance.tests.test_instance_ownership import parts
from rsview_centerline.clearance.tests.test_surface_tracking import pose
from rsview_centerline.clearance.tests.test_history_instance_evidence import engine


@dataclass(frozen=True)
class ObservableConfig(OwnerConfig):
    observable_instance_seeding: bool = True
    stable_instance_labels: bool = True


def configuration(enabled=True):
    return ObservableConfig(observable_instance_seeding=enabled,qualified_instance_ownership=True,
        qualified_object_cores=True,current_instance_reconciliation=True,
        geometry_label_priority=True,display_balance_sides=True,spatial_object_ownership=True,
        temporal_object_proposals=True,local_terrain_validation=True,
        above_rail_measurement_only=True,display_identity_seconds=1.2)


def target_scene(points,ground_height=None,enclosing=True,time=1.,sequence=0):
    ground=[]
    if ground_height is not None:
        xs=np.linspace(1.5,2.5,21) if enclosing else np.linspace(1.2,1.7,11)
        ground=[[x,y,ground_height] for x in xs for y in np.linspace(.3,1.6,27)]
    frame=cloud(ground+list(points),time=time,sequence=sequence)
    ids=np.arange(len(ground),len(frame.xyz_L))
    layers=parts(frame,[ids])
    layers=replace(layers,indices=dict(layers.indices,ground=np.arange(len(ground)),object=ids))
    model=replace(line_track(time=time),diagnostics={'ground_plane':{'normal_L':[0.,0.,1.],'offset_m':0.}})
    return frame,layers,model


class ObservableInstanceTests(unittest.TestCase):
    def tracked(self,points,ground_height=None,enclosing=True,enabled=True):
        frame,layers,model=target_scene(points,ground_height,enclosing)
        tracker=SurfaceTracker(configuration(enabled))
        output=tracker.update(frame,layers,pose(frame),model)
        return tracker,frame,output,model

    def test_repeated_two_return_fragment_does_not_create_a_new_device_id(self):
        tracker=SurfaceTracker(configuration())
        for sequence in range(4):
            frame,layers,model=target_scene([[2.,.7,.4],[2.,.74,.4]],time=1.+sequence*.1,sequence=sequence)
            current=tracker.update(frame,layers,pose(frame),model)
            self.assertIsNone(current.candidates[0].diagnostics['object_id'],
                              'repeated two-return fragments certified their own new instance')
            self.assertEqual(len(tracker.display_regions),0)
            measured=measure_candidates(frame,TrackUpdate('observed_dual',model),current,configuration())
            self.assertEqual(measured[0].observed_min_distance_m,2.)
            self.assertEqual(measured[0].observed_evidence.point_ref.frame,sequence)

    def test_horizontal_residue_at_locally_observed_ground_cannot_seed_a_device(self):
        points=[[2.+x,.8+y,.04] for x in (0.,.04,.08) for y in (0.,.04,.08)]
        tracker,frame,layers,model=self.tracked(points,ground_height=.04)
        self.assertIsNone(layers.candidates[0].diagnostics['object_id'],
                          'a biased global height promoted the locally supported floor residue')
        self.assertEqual(len(tracker.display_regions),0)
        measured=measure_candidates(frame,TrackUpdate('observed_dual',model),layers,configuration())
        packet=build_packet(frame,TrackUpdate('observed_dual',model),layers,measured,configuration())
        self.assertEqual(packet['measurements'],[])
        self.assertTrue(packet['secondary_measurements'])
        self.assertEqual(packet['secondary_measurements'][0]['observed_min_distance_m'],2.)

    def test_horizontal_surface_without_enclosing_ground_keeps_unknown_range_not_a_new_id(self):
        points=[[2.+x,.8+y,.8] for x in (0.,.04,.08) for y in (0.,.04,.08)]
        tracker,frame,layers,model=self.tracked(points,ground_height=0.,enclosing=False)
        self.assertIsNone(layers.candidates[0].diagnostics['object_id'])
        np.testing.assert_array_equal(layers.candidates[0].point_indices,
            np.arange(len(frame.xyz_L)-len(points),len(frame.xyz_L)))

    def test_low_raised_plate_with_actual_terrain_support_survives_without_height_cutoff(self):
        points=[[2.+x,.8+y,.003] for x in (0.,.04,.08) for y in (0.,.04,.08)]
        tracker,frame,layers,model=self.tracked(points,ground_height=0.)
        self.assertEqual(layers.candidates[0].diagnostics['object_id'],'T1')
        self.assertEqual(len(tracker.display_regions),1)
        measured=measure_candidates(frame,TrackUpdate('observed_dual',model),layers,configuration())
        self.assertEqual(measured[0].observed_min_distance_m,2.)

    def test_vertical_sparse_line_over_enclosing_ground_remains_an_observed_object(self):
        points=[[2.,.8,z] for z in (.1,.15,.2,.25,.3,.35)]
        tracker,frame,layers,model=self.tracked(points,ground_height=0.)
        self.assertEqual(layers.candidates[0].diagnostics['object_id'],'T1')
        self.assertEqual(layers.candidates[0].point_indices.size,6)

    def test_one_unsupported_terrain_corner_cannot_be_hidden_by_native_point_order(self):
        from rsview_centerline.clearance.instance_evidence import instance_seed_evidence
        from rsview_centerline.clearance.rsview_cache import _CurrentGroundContext
        points=[[2.+x,.8+y,.003] for x in (0.,.04,.08) for y in (0.,.04,.08)]
        points += [[2.02,1.58,.003]]  # outside the actually enclosing terrain at this query
        frame,layers,model=target_scene(points,ground_height=0.)
        # Pin the supported terrain to a finite footprint ending at y=1.2.
        ground=layers.indices['ground']
        ground=ground[frame.xyz_L[ground,1]<=1.2]
        layers=replace(layers,indices=dict(layers.indices,ground=ground))
        context=_CurrentGroundContext(frame,layers,model,configuration())
        candidate=layers.candidates[0]
        for order in (candidate.point_indices,candidate.point_indices[::-1]):
            evidence=instance_seed_evidence(frame,candidate,order,np.array([0.,0.,1.]),configuration(),context)
            self.assertFalse(evidence['seed_allowed'],'a sampled/first return hid missing full-current terrain support')

    def test_sparse_nonregular_three_dimensional_surface_is_not_rejected_as_noise(self):
        points=[[2.,.6,.2],[2.1,.7,.3],[2.03,.9,.6],[2.15,.65,.7],
                [1.98,.95,.4],[2.2,.85,.25],[2.12,.75,.5],[2.01,.8,.8]]
        tracker,frame,layers,model=self.tracked(points)
        self.assertEqual(layers.candidates[0].diagnostics['object_id'],'T1')
        measured=measure_candidates(frame,TrackUpdate('observed_dual',model),layers,configuration())
        self.assertEqual(measured[0].observed_min_distance_m,1.98)
        self.assertEqual(measured[0].observed_evidence.point_ref,frame.refs[4])

    def test_partial_two_return_view_of_observed_body_keeps_its_id_and_current_minimum(self):
        tracker=SurfaceTracker(configuration())
        body=[[2.,y,z] for y in np.arange(.4,1.,.04) for z in np.arange(.2,1.2,.04)]
        frame,layers,model=target_scene(body)
        first=tracker.update(frame,layers,pose(frame),model)
        self.assertEqual(first.candidates[0].diagnostics['object_id'],'T1')
        current,layers,model=target_scene([[2.,.6,.5],[2.,.64,.5]],time=1.1,sequence=1)
        output=tracker.update(current,layers,pose(current),model)
        self.assertEqual(output.candidates[0].diagnostics['object_id'],'T1')
        measured=measure_candidates(current,TrackUpdate('observed_dual',model),output,configuration())
        self.assertEqual(measured[0].observed_evidence.point_ref.frame,1)

    def test_raw_observed_corner_can_match_body_when_geometry_is_too_small_to_seed(self):
        worker=engine(configuration())
        whole=np.array([[2.,y,z] for y in np.arange(.3,2.3,.02) for z in np.arange(.3,2.3,.02)])
        worker.step(cloud(whole))
        corner=[[2.,.3,2.26],[2.,.3,2.28],[2.,.32,2.28]]
        unused,layers,results=worker.step(cloud(corner,sequence=1,time=1.1))
        self.assertEqual(layers.candidates[0].diagnostics['object_id'],'T1',
                         'new-ID eligibility accidentally disabled current-supported raw ID matching')
        self.assertEqual(results[0].observed_evidence.point_ref.frame,1)
        self.assertEqual(len(worker.surface_tracker.display_regions),1)

    def test_duplicate_returns_cannot_fabricate_two_dimensional_instance_evidence(self):
        tracker,frame,layers,model=self.tracked([[2.,.7,.4]]*500+[[2.,.74,.4]]*500)
        self.assertIsNone(layers.candidates[0].diagnostics['object_id'])
        self.assertEqual(layers.candidates[0].point_indices.size,1000)

    def test_temporal_only_support_cannot_seed_even_a_large_visible_surface(self):
        points=[[2.,y,z] for y in (.4,.5,.6,.7,.8) for z in (.2,.3,.4,.5,.6)]
        frame,layers,model=target_scene(points)
        candidate=replace(layers.candidates[0],diagnostics={'support_neighbor_valid':np.zeros((len(points),1),bool)})
        layers=replace(layers,candidates=(candidate,))
        tracker=SurfaceTracker(configuration())
        output=tracker.update(frame,layers,pose(frame),model)
        self.assertIsNone(output.candidates[0].diagnostics['object_id'])

    def test_temporal_supported_tail_cannot_fabricate_independent_surface_spread(self):
        observed=[[2.,.8,z] for z in np.linspace(.2,1.4,61)]
        temporal=[[2.3,.95,z] for z in np.linspace(.3,.9,10)]
        frame,layers,model=target_scene(observed+temporal)
        validity=np.r_[np.ones(len(observed),bool),np.zeros(len(temporal),bool)][:,None]
        candidate=replace(layers.candidates[0],diagnostics={'support_neighbor_valid':validity})
        tracker=SurfaceTracker(configuration())
        output=tracker.update(frame,replace(layers,candidates=(candidate,)),pose(frame),model)
        self.assertIsNone(output.candidates[0].diagnostics['object_id'],
                          'unsupported tail supplied the second geometry axis to a current-supported line')
        self.assertEqual(len(output.candidates[0].point_indices),len(observed)+len(temporal))

    def test_unstructured_volume_without_current_surface_proof_remains_measurable_unconfirmed(self):
        points=np.random.default_rng(7).uniform([1.9,.7,.3],[2.1,.9,.5],size=(80,3))
        frame,layers,model=target_scene(points)
        candidate=replace(layers.candidates[0],diagnostics={'support_neighbor_valid':np.ones((len(points),1),bool)})
        tracker=SurfaceTracker(configuration())
        output=tracker.update(frame,replace(layers,candidates=(candidate,)),pose(frame),model)
        self.assertIsNone(output.candidates[0].diagnostics['object_id'],
                          'independent volume scatter was promoted without local surface observations')
        measured=measure_candidates(frame,TrackUpdate('observed_dual',model),output,configuration())
        self.assertAlmostEqual(measured[0].observed_min_distance_m,float(points[:,0].min()))
        self.assertEqual(output.candidates[0].point_indices.size,80)

    def test_terrain_cannot_upgrade_unstructured_current_volume(self):
        points=np.random.default_rng(7).uniform([1.9,.7,.3],[2.1,.9,.5],size=(80,3))
        frame,layers,model=target_scene(points,ground_height=0.)
        candidate=replace(layers.candidates[0],diagnostics={'support_neighbor_valid':np.ones((len(points),1),bool)})
        output=SurfaceTracker(configuration()).update(frame,replace(layers,candidates=(candidate,)),pose(frame),model)
        self.assertIsNone(output.candidates[0].diagnostics['object_id'])
        self.assertEqual(output.candidates[0].point_indices.size,80)

    def test_supported_core_cannot_hide_unraised_native_corner(self):
        points=[[2.+x,.8+y,.003] for x in (0.,.04,.08) for y in (0.,.04,.08)]+[[2.02,.85,0.]]
        frame,layers,model=target_scene(points,ground_height=0.)
        candidate=replace(layers.candidates[0],supported_indices=layers.candidates[0].point_indices[:-1],
                          diagnostics={'support_neighbor_valid':np.ones((len(points),1),bool)})
        output=SurfaceTracker(configuration()).update(frame,replace(layers,candidates=(candidate,)),pose(frame),model)
        self.assertIsNone(output.candidates[0].diagnostics['object_id'])
        self.assertEqual(output.candidates[0].point_indices.size,10)

    def test_new_id_eligibility_does_not_depend_on_native_order_within_cells(self):
        points=np.array([[2,.8001,.4001],[2,.8199,.4199],[2,.8399,.4001],
                         [2,.8201,.4199],[2,.8001,.4399],[2,.8199,.4201]])
        outcomes=[]
        for order in (np.arange(6),[1,0,3,2,5,4]):
            tracker,frame,layers,model=self.tracked(points[order])
            outcomes.append(layers.candidates[0].diagnostics['object_id'])
        self.assertEqual(outcomes[0],outcomes[1])

    def test_decoder_sparse_raised_plate_and_line_survive_without_dense_surface_threshold(self):
        for points in ([[2.+x,.8+y,.003] for x in (0.,.04,.08) for y in (0.,.04,.08)],
                       [[2.,.8,z] for z in (.1,.15,.2,.25,.3,.35)]):
            frame,layers,model=target_scene(points,ground_height=0.)
            candidate=replace(layers.candidates[0],diagnostics={'support_neighbor_valid':np.ones((len(points),1),bool)})
            output=SurfaceTracker(configuration()).update(frame,replace(layers,candidates=(candidate,)),pose(frame),model)
            self.assertEqual(output.candidates[0].diagnostics['object_id'],'T1')

    def test_batched_terrain_reuses_exact_patches_and_checks_every_native_return(self):
        from rsview_centerline.clearance.rsview_cache import _CurrentGroundContext
        points=np.array([[2.,.8,z] for z in np.linspace(.003,.5,2500)])
        frame,layers,model=target_scene(points,ground_height=0.)
        context=_CurrentGroundContext(frame,layers,model,configuration())
        self.assertTrue(hasattr(context,'raised_all'),'all-native terrain checks need an exact batched path')
        with patch.object(context,'_terrain_patch_model',wraps=context._terrain_patch_model) as fit:
            self.assertTrue(context.raised_all(points))
            self.assertEqual(fit.call_count,1,'identical XY query patches were refitted per return')
        self.assertFalse(context.raised_all(np.vstack([points,[[2.,.8,0.]]])))
        queries=np.array([[2.,.8,.003],[2.,.8,0.],[2.,1.58,.003],[2.,2.,.5]])
        np.testing.assert_array_equal(context.raised_many(queries),[context.raised(p) for p in queries])

    def test_dense_terrain_batch_uses_finite_two_dimensional_hulls_without_per_patch_qhull_io(self):
        from rsview_centerline.clearance.rsview_cache import _CurrentGroundContext
        points=np.array([[2.+x,.8+y,.003] for x in np.linspace(0,.2,12) for y in np.linspace(0,.2,12)])
        frame,layers,model=target_scene(points,ground_height=0.)
        context=_CurrentGroundContext(frame,layers,model,configuration())
        expected=np.array([context.raised(point) for point in points])
        with patch('rsview_centerline.clearance.rsview_cache.ConvexHull',side_effect=AssertionError('per-patch Qhull IO')):
            np.testing.assert_array_equal(context.raised_many(points),expected)

    def test_curved_current_surface_is_not_rejected_for_global_nonplanarity(self):
        points=[[2.+.15*np.cos(a),.8+.15*np.sin(a),z]
                for a in np.linspace(0.,2.*np.pi,49)[:-1] for z in np.arange(.2,1.,.025)]
        frame,layers,model=target_scene(points)
        candidate=replace(layers.candidates[0],diagnostics={'support_neighbor_valid':np.ones((len(points),1),bool)})
        tracker=SurfaceTracker(configuration())
        output=tracker.update(frame,replace(layers,candidates=(candidate,)),pose(frame),model)
        self.assertEqual(output.candidates[0].diagnostics['object_id'],'T1')
        self.assertEqual(len(output.candidates[0].point_indices),len(points))

    def test_unobservable_boundary_patches_are_not_counted_as_failed_surface_tests(self):
        points=np.array([[2.,y,z] for y in np.arange(.5,.9,.035) for z in np.arange(.2,.6,.035)])
        points[:,0]+=np.random.default_rng(31).normal(0,.01,len(points))
        points=np.vstack([points,[[2.,.93,z] for z in np.arange(.2,2.,.12)]])
        frame,layers,model=target_scene(points)
        candidate=replace(layers.candidates[0],diagnostics={'support_neighbor_valid':np.ones((len(points),1),bool)})
        output=SurfaceTracker(configuration()).update(frame,replace(layers,candidates=(candidate,)),pose(frame),model)
        self.assertEqual(output.candidates[0].diagnostics['object_id'],'T1',
                         'missing boundary observations were treated as negative surface measurements')
        evidence=output.candidates[0].diagnostics['instance_seed_evidence']
        self.assertGreaterEqual(evidence['current_testable_fraction'],.7)
        self.assertGreaterEqual(evidence['current_coherence_on_testable'],.7)
        self.assertLess(evidence['current_surface_fraction'],.7)
        measured=measure_candidates(frame,TrackUpdate('observed_dual',model),output,configuration())
        self.assertAlmostEqual(measured[0].observed_min_distance_m,float(points[:,0].min()))
        self.assertEqual(len(output.candidates[0].point_indices),len(points))

    def test_tiny_coherent_island_cannot_seed_a_mostly_untestable_cloud(self):
        body=[[2.,y,z] for y in np.arange(.5,.7,.025) for z in np.arange(.2,.4,.025)]
        scattered=[[2.,.8+(.12*(i%10)),.5+.12*(i//10)] for i in range(200)]
        frame,layers,model=target_scene(body+scattered)
        candidate=replace(layers.candidates[0],diagnostics={'support_neighbor_valid':np.ones((len(body)+len(scattered),1),bool)})
        output=SurfaceTracker(configuration()).update(frame,replace(layers,candidates=(candidate,)),pose(frame),model)
        self.assertIsNone(output.candidates[0].diagnostics['object_id'])

    def test_v25_route_is_unchanged_when_observability_is_disabled(self):
        tracker,frame,layers,model=self.tracked([[2.,.7,.4],[2.,.74,.4]],enabled=False)
        self.assertEqual(layers.candidates[0].diagnostics['object_id'],'T1')

    def test_v26_combines_replay_rules_but_is_not_enabled_in_live_or_default(self):
        with patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':'v26'}):
            cfg=clearance_native.recorded_measurement_config()
            self.assertTrue(cfg.get('observable_instance_seeding',False))
            self.assertTrue(cfg.get('stable_instance_labels',False))
            self.assertTrue(cfg.get('qualified_history_owner_keys',False))
        for variant in ('1','0','v21','v22','v23','v24','v25'):
            with patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':variant}):
                self.assertFalse(clearance_native.recorded_measurement_config().get('observable_instance_seeding',False))
        self.assertFalse(clearance_native.live_measurement_config().get('observable_instance_seeding',False))

    def test_live_rejects_each_new_replay_flag_without_other_replay_features(self):
        from rsview_centerline.clearance.online import OnlineEngine
        from rsview_centerline.clearance.protocol import ClearanceConfig
        for name in ('observable_instance_seeding','stable_instance_labels'):
            fields=dict((key,value) for key,value in ClearanceConfig().__dict__.items())
            fields[name]=True
            with self.subTest(flag=name),self.assertRaisesRegex(ValueError,'replay-only'):
                OnlineEngine(fields,source_mode='live')


if __name__ == '__main__':
    unittest.main()
