"""Current measurements may reorder; an instance's caption must not swap rows."""
from copy import deepcopy
from types import SimpleNamespace
import unittest
from rsview_centerline import clearance_overlay as ui


class Renderer:
    def SetWorldPoint(self,x,y,z,w):
        self.point=(x,y,z)
    def WorldToDisplay(self):
        pass
    def GetDisplayPoint(self):
        x,y,z=self.point
        return (100.*x,100.*y,z)
    def GetSize(self):
        return (800,600)


class Caption:
    def GetBoundingBox(self,renderer,bounds):
        bounds[:]=[0.,100.,0.,24.]
    def SetDisplayPosition(self,x,y):
        self.position=(x,y)


def item(identity,distance=2.):
    return dict(display_id=identity,candidate_id='fragment-'+identity,
        distance_m=distance,point_L=[distance,1.,.2],projected_L=[distance,1.,0.],foot_L=[0.,1.,0.],
        source_frame=4,source_index=1,source_time_s=1.4,uncertain=False)


def overlay(items,epoch=0):
    view=ui.VtkClearanceOverlay.__new__(ui.VtkClearanceOverlay)
    view.renderer=Renderer()
    view.labels=[Caption() for unused in range(8)]
    view.current=dict(measurements=items,stable_instance_labels=True,
        session_id='session',clock_id='clock',epoch=epoch,config_id='v26')
    return view


class StableCaptionTests(unittest.TestCase):
    def test_reordering_current_instances_does_not_swap_their_caption_rows(self):
        a,b=item('T1'),item('T2',2.01)
        view=overlay([a,b])
        view._position_labels()
        old={m['display_id']:c.position for m,c in zip(view.current['measurements'],view.labels)}
        view.current['measurements']=[b,a]
        view._position_labels()
        new={m['display_id']:c.position for m,c in zip(view.current['measurements'],view.labels)}
        self.assertEqual(new,old,'selection order moved the same instance to a different caption row')

    def test_current_distance_and_geometry_are_not_frozen_by_caption_stability(self):
        view=overlay([item('T1'),item('T2')])
        view._position_labels()
        updated=item('T1',1.98)
        updated['source_frame']=5
        updated['source_time_s']=1.5
        view.current['measurements']=[updated,item('T2')]
        current=deepcopy(view.current)
        view._position_labels()
        self.assertEqual(view.current,current)
        self.assertEqual(view.labels[0].position,(107,108))
        self.assertEqual(view.current['measurements'][0]['distance_m'],1.98)

    def test_replay_epoch_change_resets_caption_layout_even_if_ids_are_reused(self):
        view=overlay([item('T1'),item('T2')])
        view._position_labels()
        view.current.update(epoch=1,measurements=[item('T2'),item('T1')])
        view._position_labels()
        self.assertEqual(view.labels[0].position,(108,108))
        self.assertEqual(view.labels[1].position,(108,136))

    def test_layout_state_is_bounded_to_current_visible_instances(self):
        view=overlay([item('T1'),item('T2')])
        for generation in range(100):
            view.current['measurements']=[item('T%d'%(generation*8+i)) for i in range(8)]
            view._position_labels()
        self.assertLessEqual(len(view.instance_label_layout.offsets),8)
        self.assertLessEqual(len(view.instance_label_layout.order),8)

    def test_legacy_packets_keep_their_original_order_based_layout(self):
        view=overlay([item('T1'),item('T2')])
        view.current['stable_instance_labels']=False
        view._position_labels()
        view.current['measurements'].reverse()
        view._position_labels()
        self.assertEqual(view.labels[0].position,(108,108))
        self.assertEqual(view.labels[1].position,(108,136))


if __name__=='__main__':
    unittest.main()
