"""Window measurement truth and stationary-only publishing contracts."""
import importlib
import unittest
from dataclasses import replace
import numpy as np
from rsview_centerline.clearance.protocol import Candidate,SceneLayers,TrackUpdate,ClearanceConfig,PoseSample
from rsview_centerline.clearance.tests.fixtures import cloud,line_track
from rsview_centerline.clearance.stop_window import StopWindow
from rsview_centerline.clearance.tests.test_online import request

try:module=importlib.import_module('rsview_centerline.clearance.stop_fusion')
except ModuleNotFoundError:module=None


class KnownPoses:
    def __init__(self,speed=0.):self.speed=speed;self.frame=None;self.diagnostics={'usable':True,'map_epoch':1}
    def update(self,frame):self.frame=frame;return self
    def matrix(self):
        matrix=np.eye(4);matrix[2,3]=self.speed*self.frame.ref_time_s
        return matrix
    def sample(self,time_s,available_until_s):
        return PoseSample(time_s,self.matrix(),self.frame.clock_id,self.frame.scan_span_s,
            available_until_s,'explicit_test_poses',True,{'map_epoch':1,'independent_truth':False})
    def point_matrices(self,frame,times):return np.repeat(self.matrix()[None],len(times),axis=0)


class StopFusionTests(unittest.TestCase):
    def setUp(self):self.assertIsNotNone(module,'parking fusion engine not implemented')

    def test_window_distance_uses_every_raw_return_not_voxel_representative(self):
        window=StopWindow(voxel_m=.05)
        for sequence,x in enumerate((2.024,2.004,2.014)):
            window.add(cloud([[x,1.,.3]],sequence=sequence,time=1.+sequence*.1),np.eye(4))
        geometry=window.geometry()
        layers=SceneLayers({'object':np.array([0])},(Candidate('body',np.array([0]),np.array([0]),1.,1.2,{}),),{'object':1})
        track=TrackUpdate('observed_dual',line_track(time=1.2))
        results=module.measure_window(window,track,layers,ClearanceConfig())
        self.assertEqual(results[0].observed_min_distance_m,2.004)
        self.assertEqual(results[0].observed_evidence.point_ref.frame,1)
        self.assertEqual(results[0].observed_evidence.point_ref.index,0)

    def test_live_mode_cannot_enable_parking_experiment(self):
        with self.assertRaisesRegex(ValueError,'replay'):
            module.StopFusionEngine({'stop_window_fusion':True},source_mode='live')

    def test_duplicate_pause_does_not_advance_window_to_twenty(self):
        engine=module.StopFusionEngine({'stop_window_fusion':True},poses=KnownPoses())
        event=request(0,1.)
        for unused in range(25):packet=engine.process(event)
        self.assertLess(packet['stop_window']['scan_count'],20)
        self.assertFalse(packet['stop_window']['confirmed'])
        self.assertEqual(packet['measurements'],[])

    def test_moving_vehicle_cannot_publish_confirmed_window_distance(self):
        engine=module.StopFusionEngine({'stop_window_fusion':True},poses=KnownPoses(speed=.5))
        for sequence in range(25):packet=engine.process(request(sequence,1.+sequence*.1))
        self.assertFalse(packet['stop_window']['confirmed'])
        self.assertEqual(packet['measurements'],[])
        self.assertIn(packet['stop_window']['state'],('motion_detected','awaiting_stationary'))

    def test_ten_meter_preview_keeps_six_meter_returns_with_native_index(self):
        engine=module.StopFusionEngine({'stop_window_fusion':True},poses=KnownPoses())
        packet=engine.process(request(0,1.,xyz=np.array([[6.,0.,0.],[10.01,0.,0.]]),
            point_times=np.array([1.,1.]),rings=None))
        self.assertEqual(packet['retained_points'],1)
        self.assertEqual(packet['scope']['sensor_max_range_m'],10.)
        self.assertFalse(packet.get('current_scan_measurement',True))

    def test_first_stage_is_twenty_distinct_scans_not_arbitrary_small_count(self):
        engine=module.StopFusionEngine({'stop_window_fusion':True},poses=KnownPoses())
        for sequence in range(19):packet=engine.process(request(sequence,1.+sequence*.1))
        self.assertEqual(packet['stop_window']['stage_scans'],0)
        self.assertEqual(packet['measurements'],[])
        for sequence in range(19,22):packet=engine.process(request(sequence,1.+sequence*.1))
        self.assertEqual(packet['stop_window']['stage_scans'],20)
        self.assertEqual(packet['measurement_basis'],'stop_window')
        self.assertFalse(packet['stop_window']['confirmed'])

    def test_stationary_raised_box_has_raw_window_distance_after_two_stages(self):
        base=request()['xyz']
        box=np.array([[x,y,z] for x in np.linspace(-.25,.2,12)
            for y in (2.,2.3) for z in np.linspace(.8,1.3,12)])
        engine=module.StopFusionEngine({'stop_window_fusion':True,'qualified_object_cores':True,
            'surface_object_proposals':True,'geometry_label_priority':True},poses=KnownPoses())
        points=np.vstack([base,box])
        for sequence in range(40):
            packet=engine.process(request(sequence,1.+sequence*.1,xyz=points,point_times=np.full(len(points),1.+sequence*.1)))
        self.assertEqual(packet['stop_window']['stage_scans'],40)
        self.assertTrue(packet['measurements'],'stationary box lost in fused-scene measurement')
        nearest=min(packet['measurements'],key=lambda m:abs(m['distance_m']-2.))
        self.assertAlmostEqual(nearest['distance_m'],2.,delta=.04)
        self.assertTrue(packet['stop_window']['confirmed'])
        self.assertIn(nearest['source_frame'],packet['display_window_source_frames'])
        self.assertFalse(packet['current_scan_measurement'])

    def test_native_online_live_rejects_stop_window_flag_independently(self):
        from rsview_centerline.clearance.online import OnlineEngine
        with self.assertRaisesRegex(ValueError,'replay-only'):
            OnlineEngine({'stop_window_fusion':True},source_mode='live')

    def test_one_off_closer_return_cannot_inherit_support_from_old_voxel_points(self):
        window=StopWindow(voxel_m=.05)
        for sequence,x in enumerate((2.024,2.024,2.024,2.004)):
            window.add(cloud([[x,1.,.3]],sequence=sequence,time=1.+sequence*.1),np.eye(4))
        layers=SceneLayers({'object':np.array([0])},(Candidate('body',np.array([0]),np.array([0]),1.,1.3,{}),),{'object':1})
        result=module.measure_window(window,TrackUpdate('observed_dual',line_track(time=1.3)),layers,ClearanceConfig())[0]
        self.assertEqual(result.observed_min_distance_m,2.004)
        self.assertIsNone(result.supported_evidence,'one new near return borrowed unrelated voxel support')

    def test_conflicted_neighbor_returns_cannot_confirm_a_one_off_boundary(self):
        window=StopWindow(voxel_m=.05)
        for sequence in range(4):
            points=[[2.004 if sequence==0 else 2.024,1.,.3],[1.999,1.,.3]]
            window.add(cloud(points,sequence=sequence,time=1.+sequence*.1),np.eye(4))
        geometry=window.geometry()
        core=np.flatnonzero(geometry.xyz_L[:,0]>=2.)
        conflicted=np.flatnonzero(geometry.xyz_L[:,0]<2.)
        candidate=Candidate('body',np.arange(len(geometry.xyz_L)),core,1.,1.3,
            {'ambiguous_indices':conflicted})
        result=module.measure_window(window,TrackUpdate('observed_dual',line_track(time=1.3)),
            SceneLayers({},(candidate,),{}),ClearanceConfig())[0]
        self.assertEqual(result.observed_min_distance_m,1.999)
        self.assertIsNone(result.supported_evidence,'conflicted returns counted as independent support')

    def test_total_budget_includes_waiting_for_stationary_not_only_accepted_raw_scans(self):
        now=[0.]
        engine=module.StopFusionEngine({'stop_window_fusion':True},poses=KnownPoses(speed=.5),clock=lambda:now[0])
        engine.process(request(0,1.))
        now[0]=60.01
        packet=engine.process(request(1,1.1))
        self.assertEqual(packet['stop_window']['state'],'time_budget_exceeded')
        self.assertFalse(packet['stop_window']['confirmed'])
        self.assertEqual(packet['measurements'],[])

    def test_completed_window_still_invalidates_on_movement_after_wall_deadline(self):
        now=[0.];poses=KnownPoses()
        box=np.array([[x,y,z] for x in np.linspace(-.25,.2,12)
            for y in (2.,2.3) for z in np.linspace(.8,1.3,12)])
        points=np.vstack([request()['xyz'],box])
        engine=module.StopFusionEngine({'stop_window_fusion':True,'stop_window_stages':(20,40),
            'qualified_object_cores':True,'surface_object_proposals':True,
            'geometry_label_priority':True},poses=poses,clock=lambda:now[0])
        for sequence in range(40):
            packet=engine.process(request(sequence,1.+sequence*.1,xyz=points,
                point_times=np.full(len(points),1.+sequence*.1)))
        self.assertEqual(packet['stop_window']['state'],'complete')
        self.assertTrue(packet['stop_window']['confirmed'])
        now[0]=60.1;poses.speed=.5
        packet=engine.process(request(40,5.,xyz=points,point_times=np.full(len(points),5.)))
        self.assertFalse(packet['stop_window']['confirmed'],'completed geometry survived observed movement')
        self.assertEqual(packet['measurements'],[])
        self.assertEqual(packet['stop_window']['scan_count'],0)

    def test_last_unconfirmed_checkpoint_stops_capture_instead_of_collecting_unused_scans(self):
        engine=module.StopFusionEngine({'stop_window_fusion':True,'stop_window_stages':(20,)},poses=KnownPoses())
        for sequence in range(25):packet=engine.process(request(sequence,1.+sequence*.1))
        self.assertEqual(packet['stop_window']['scan_count'],20)
        self.assertEqual(packet['stop_window']['state'],'stage_limit_unconfirmed')
        self.assertFalse(packet['stop_window']['confirmed'])


if __name__=='__main__':unittest.main()
