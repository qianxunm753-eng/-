"""Explicit background membership must not become a one-side/height gate."""
from dataclasses import replace
import unittest
import numpy as np
from rsview_centerline.clearance.protocol import Candidate, SceneLayers, PoseSample
from rsview_centerline.clearance.tests.fixtures import cloud


class BackgroundTests(unittest.TestCase):
    def test_background_filter_does_not_expand_every_temporal_boundary_ref(self):
        from unittest.mock import patch
        from rsview_centerline.clearance.background import BackgroundReference
        from rsview_centerline.clearance.scene import TemporalSupport,extract_scene
        from rsview_centerline.clearance.protocol import ClearanceConfig,TrackUpdate,PointRef
        from rsview_centerline.clearance.tests.fixtures import line_track
        frame=replace(cloud([[2.,1.,1.],[2.01,1.,1.],[-2.,1.,.03],[-2.01,1.,.03]]),
            motion_status='deskewed_experimental',diagnostics={'source_sha256':'test-sha'})
        cfg=ClearanceConfig()
        layers=extract_scene(frame,TrackUpdate('observed_dual',line_track()),[],cfg)
        refs=tuple(PointRef(0,i,.9) for i in range(4))
        layers=replace(layers,candidates=tuple(replace(c,diagnostics=dict(c.diagnostics,
            temporal_support_refs=TemporalSupport(c.point_indices,c.point_indices,refs))) for c in layers.candidates))
        pose=PoseSample(1.,np.eye(4),'device:test',(.9,1.1),1.05,'test-pose',True,{'pose_map_id':'test-map'})
        reference=BackgroundReference(dict(format='clearance-confirmed-background-v1',session_id='test',
            clock_id='device:test',pose_source='test-pose',points_W=[[2.,1.,1.]],
            pose_map_id='test-map',source_sha256='test-sha',confirmation='user_confirmed_background'))
        with patch.object(TemporalSupport,'__getitem__',side_effect=AssertionError('eager boundary refs')):
            output=reference.update(frame,layers,pose,cfg)
        self.assertEqual(output.candidates[0].supported_indices.tolist(),[2,3])

    def test_same_pose_source_but_different_named_map_does_not_hide_current_object(self):
        from rsview_centerline.clearance.background import BackgroundReference
        frame=replace(cloud([[2.,1.,1.]]),motion_status='deskewed_experimental',
                      diagnostics={'source_sha256':'test-sha'})
        pose=PoseSample(1.,np.eye(4),'device:test',(.9,1.1),1.05,'test-pose',True,{'pose_map_id':'new-map'})
        reference=BackgroundReference(dict(format='clearance-confirmed-background-v1',session_id='test',
            clock_id='device:test',pose_source='test-pose',points_W=[[2.,1.,1.]],
            pose_map_id='old-map',source_sha256='test-sha',confirmation='user_confirmed_background'))
        layers=reference.update(frame,SceneLayers({'object':np.array([0])},
            (Candidate('one',np.array([0]),np.array([0]),1.,1.),),{}),pose)
        self.assertEqual(layers.indices['object'].tolist(),[0])

    def test_background_neighbor_filter_preserves_integer_native_support(self):
        from rsview_centerline.clearance.background import BackgroundReference
        from rsview_centerline.clearance.scene import extract_scene
        from rsview_centerline.clearance.measure import measure_candidates
        from rsview_centerline.clearance.protocol import ClearanceConfig,TrackUpdate
        from rsview_centerline.clearance.tests.fixtures import line_track
        frame=replace(cloud([[2.,1.,1.],[2.01,1.,1.],[-2.,1.,.5],[-2.01,1.,.5]]),motion_status='deskewed_experimental',diagnostics={'source_sha256':'test-sha'})
        update,cfg=TrackUpdate('observed_dual',line_track()),ClearanceConfig()
        layers=extract_scene(frame,update,[],cfg)
        pose=PoseSample(1.,np.eye(4),'device:test',(.9,1.1),1.05,'test-pose',True,{'pose_map_id':'test-map'})
        ref=BackgroundReference(dict(format='clearance-confirmed-background-v1',session_id='test',clock_id='device:test',
            pose_source='test-pose',points_W=[[2.,1.,1.]],confirmation='user_confirmed_background',source_sha256='test-sha',pose_map_id='test-map'))
        layers=ref.update(frame,layers,pose)
        self.assertEqual(layers.candidates[0].supported_indices.dtype.kind,'i')
        self.assertAlmostEqual(measure_candidates(frame,update,layers,cfg)[0].supported_min_distance_m,2.)

    def refine(self, points, reference, *, session='test', clock='device:test', pose=True):
        try:
            from rsview_centerline.clearance.background import BackgroundReference
        except ImportError as error:
            self.fail('explicit background membership missing: '+str(error))
        frame = replace(cloud(points), session_id=session, clock_id=clock, motion_status='deskewed_experimental',diagnostics={'source_sha256':'test-sha'})
        candidate = Candidate('mixed', np.arange(len(points)), np.arange(len(points)), 1., 1.)
        layers = SceneLayers({'object': np.arange(len(points)), 'ambiguous': np.array([],dtype=int)},
                             (candidate,), {'object':len(points)})
        sample = PoseSample(1., np.eye(4), clock, (.9,1.1), 1.05, 'test-pose', True,{'pose_map_id':'test-map'})
        document = dict(format='clearance-confirmed-background-v1', session_id='test', clock_id='device:test',
                        pose_source='test-pose', points_W=reference, confirmation='user_confirmed_background',source_sha256='test-sha',pose_map_id='test-map')
        return BackgroundReference(document).update(frame,layers,sample if pose else None)

    def test_only_confirmed_members_removed_low_unknown_object_survives(self):
        layers = self.refine([[2.,1.,1.],[2.01,1.,1.],[-2.,1.,.03]], [[2.,1.,1.]])
        np.testing.assert_array_equal(layers.indices['background'], [0,1])
        np.testing.assert_array_equal(layers.indices['object'], [2])
        self.assertEqual(layers.candidates[0].point_indices.tolist(), [2])

    def test_unknown_surface_on_same_side_survives(self):
        layers = self.refine([[2.,1.,1.],[2.,1.5,1.]], [[2.,1.,1.]])
        self.assertEqual(layers.indices['object'].tolist(), [1])

    def test_foreign_recording_and_missing_pose_do_not_apply_old_background(self):
        for kwargs in ({'session':'other'},{'clock':'other'},{'pose':False}):
            with self.subTest(**kwargs):
                layers = self.refine([[2.,1.,1.]], [[2.,1.,1.]], **kwargs)
                self.assertEqual(layers.indices['object'].tolist(), [0])

    def test_rotated_frame_uses_named_pose_not_sensor_fixed_box(self):
        from rsview_centerline.clearance.background import BackgroundReference
        frame = replace(cloud([[1.,-2.,1.],[1.,2.,.03]]), motion_status='deskewed_experimental',diagnostics={'source_sha256':'test-sha'})
        T = np.eye(4); T[:2,:2] = [[0.,-1.],[1.,0.]]
        pose = PoseSample(1.,T,'device:test',(.9,1.1),1.05,'test-pose',True,{'pose_map_id':'test-map'})
        ref = BackgroundReference(dict(format='clearance-confirmed-background-v1',session_id='test',
            clock_id='device:test',pose_source='test-pose',points_W=[[2.,1.,1.]],confirmation='user_confirmed_background',source_sha256='test-sha',pose_map_id='test-map'))
        candidate = Candidate('mixed',np.array([0,1]),np.array([0,1]),1.,1.)
        layers = ref.update(frame,SceneLayers({'object':np.array([0,1])},(candidate,),{}),pose)
        self.assertEqual(layers.indices['object'].tolist(),[1])


if __name__ == '__main__':
    unittest.main()
