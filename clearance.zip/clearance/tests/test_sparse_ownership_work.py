"""Sparse work pruning must preserve current evidence and complete-link rules."""
from dataclasses import replace
import unittest
from unittest.mock import patch
import numpy as np
from rsview_centerline.clearance.objects import refine_objects,qualified_core_indices
from rsview_centerline.clearance.measure import measure_candidates
from rsview_centerline.clearance.protocol import TrackUpdate
from rsview_centerline.clearance.tests.fixtures import cloud,line_track
from rsview_centerline.clearance.tests.test_instance_ownership import parts
from rsview_centerline.clearance.tests.test_current_instance_reconciliation import configuration,faces


class SparseOwnershipTests(unittest.TestCase):
    def test_current_qualified_cores_are_computed_once_without_losing_native_minima(self):
        a,b=faces()
        for with_history in (False,True):
            with self.subTest(with_history=with_history):
                frame=cloud(a+b)
                frame.xyz_L[0,0]=1.98
                layers=parts(frame,[np.arange(len(a)),np.arange(len(a),len(a)+len(b))])
                first=replace(layers.candidates[0],diagnostics=dict(
                    layers.candidates[0].diagnostics,ambiguous_indices=np.array([0])))
                layers=replace(layers,candidates=(first,layers.candidates[1]))
                old=cloud(a+b,sequence=-1,time=.9)
                old=replace(old,ref_time_s=frame.ref_time_s,motion_status='compensated_history',diagnostics={
                    'aligned_to_ref_time_s':frame.ref_time_s,
                    'object_proposal_labels':np.zeros(len(a)+len(b),dtype=int)})
                cfg=configuration()
                with patch('rsview_centerline.clearance.objects.qualified_core_indices',
                           wraps=qualified_core_indices) as qualified:
                    result=refine_objects(frame,TrackUpdate('observed_dual',line_track()),
                                          layers,cfg,[old] if with_history else [])
                self.assertEqual(len(result.candidates),1)
                measured=measure_candidates(frame,TrackUpdate('observed_dual',line_track()),result,cfg)
                self.assertAlmostEqual(measured[0].observed_min_distance_m,1.98)
                self.assertEqual(measured[0].observed_evidence.point_ref.index,0)
                self.assertIn('nearest_ambiguous_surface',measured[0].flags)
                self.assertEqual(qualified.call_count,len(layers.candidates),
                    'historical and current proof routes recomputed the same current qualified cores')

    def test_disjoint_current_objects_skip_quadratic_complete_link_index_work(self):
        points=[[x,y,.5] for x in np.arange(1.,2.41,.2) for y in np.arange(.1,1.91,.2)]
        frame=cloud(points)
        layers=parts(frame,[[i] for i in range(len(points))])
        # Real numerical operator, wrapped only to count this expensive work.
        # Results and original evidence are still produced by the real pipeline.
        with patch('numpy.ix_',wraps=np.ix_) as indexing:
            result=refine_objects(frame,TrackUpdate('observed_dual',line_track()),layers,configuration())
        self.assertEqual(len(result.candidates),len(points))
        self.assertEqual(result.diagnostics.get('current_ownership_links',[]),[])
        np.testing.assert_array_equal(np.concatenate([c.point_indices for c in result.candidates]),
                                      np.arange(len(points)))
        self.assertLess(indexing.call_count,len(points),
            'no possible current edge still created a full quadratic pair index workload')

    def test_one_proven_member_cannot_drag_an_unproven_group_member_into_a_link(self):
        a,b=faces()
        tail=[[2.,.26,.4],[2.,.27,.4]]
        points=a+tail+b
        frame=cloud(points)
        n=len(a);m=n+len(tail)
        layers=parts(frame,[np.arange(n),np.arange(n,m),np.arange(m,len(points))])
        old=cloud(points,sequence=-1,time=.9)
        old=replace(old,ref_time_s=1.,motion_status='compensated_history',diagnostics={
            'aligned_to_ref_time_s':1.,
            'object_proposal_labels':np.r_[np.zeros(m,dtype=int),np.ones(len(b),dtype=int)]})
        result=refine_objects(frame,TrackUpdate('observed_dual',line_track()),layers,configuration(),[old])
        self.assertEqual(len(result.candidates),2)
        self.assertEqual(result.diagnostics.get('current_ownership_links',[]),[],
            'one representative edge replaced the full cross-member proof requirement')
        np.testing.assert_array_equal(np.sort(np.concatenate([c.point_indices for c in result.candidates])),
                                      np.arange(len(points)))


if __name__=='__main__':
    unittest.main()
