"""Ground confirmation must interpolate actual support, never extrapolate it."""
import unittest
from dataclasses import dataclass,replace
import numpy as np

from rsview_centerline.clearance.protocol import ClearanceConfig,Candidate,SceneLayers,TrackUpdate
from rsview_centerline.clearance.rsview_cache import _CurrentGroundContext,build_packet
from rsview_centerline.clearance.measure import measure_candidates
from rsview_centerline.clearance.tests.fixtures import cloud,line_track


@dataclass(frozen=True)
class SupportConfig(ClearanceConfig):
    local_terrain_validation: bool = True


class LocalGroundSupportTests(unittest.TestCase):
    def scene(self,lower=False,enclosing=False):
        x,y=np.meshgrid(np.linspace(1.7,2.3,7) if enclosing else np.linspace(1.5,1.9,7),
                        np.linspace(.6,1.4,7))
        z=-.2 if lower else 0.
        ground=np.column_stack((x.ravel(),y.ravel(),np.full(x.size,z)))
        target=[[2.+x,1.+y,z+.05] for x in (0.,.02,.04) for y in (0.,.02,.04)]
        frame=cloud(np.vstack((ground,target)))
        idx=np.arange(len(ground),len(frame.xyz_L))
        candidate=Candidate('surface',idx,idx,1.,1.)
        layers=SceneLayers({'ground':np.arange(len(ground)),'object':idx},(candidate,),{}, {})
        model=replace(line_track(),diagnostics={'ground_plane':{'normal_L':[0.,0.,1.],'offset_m':0.}})
        return frame,TrackUpdate('observed_dual',model),layers

    def test_one_sided_terrain_cannot_certify_a_raised_boundary_outside_footprint(self):
        frame,track,layers=self.scene()
        context=_CurrentGroundContext(frame,layers,track.model,SupportConfig())
        self.assertFalse(context.raised(frame.xyz_L[-9]),'one-sided terrain plane was extrapolated')

    def test_target_with_enclosing_2d_ground_support_remains_raised(self):
        frame,track,layers=self.scene(enclosing=True)
        context=_CurrentGroundContext(frame,layers,track.model,SupportConfig())
        self.assertTrue(context.raised(frame.xyz_L[-9]))

    def test_lower_unmodelled_surface_outside_ground_support_keeps_secondary_provenance(self):
        frame,track,layers=self.scene(lower=True)
        cfg=SupportConfig(geometry_label_priority=True)
        results=measure_candidates(frame,track,layers,cfg)
        packet=build_packet(frame,track,layers,results,cfg)
        self.assertEqual(packet['measurements'],[],'extrapolation falsely promoted a lower surface')
        self.assertEqual(len(results),1)
        item=packet['secondary_measurements'][0]
        self.assertEqual(item['source_index'],49)
        self.assertEqual(item['source_time_s'],1.)
        self.assertAlmostEqual(item['observed_min_distance_m'],2.)

    def test_5cm_target_above_enclosing_lower_ground_preserves_raw_boundary(self):
        frame,track,layers=self.scene(lower=True,enclosing=True)
        cfg=SupportConfig(geometry_label_priority=True)
        packet=build_packet(frame,track,layers,measure_candidates(frame,track,layers,cfg),cfg)
        self.assertEqual(len(packet['measurements']),1)
        self.assertAlmostEqual(packet['measurements'][0]['distance_m'],2.)
        self.assertEqual(packet['measurements'][0]['source_index'],49)

    def test_default_off_configuration_keeps_previous_ground_gate(self):
        frame,track,layers=self.scene()
        self.assertTrue(_CurrentGroundContext(frame,layers,track.model,ClearanceConfig()).raised(frame.xyz_L[-9]))

    def test_dense_one_side_cannot_hide_sparse_enclosing_ground_in_same_radius(self):
        ground=[[x,y,-.2] for x in (1.8,1.85,1.9,1.95) for y in (.9,.95,1.,1.05,1.1)]
        ground += [[2.3,y,-.2] for y in (.9,1.,1.1)]
        target=[[2.+x,1.+y,-.15] for x in (0.,.02,.04) for y in (0.,.02,.04)]
        frame=cloud(ground+target)
        ids=np.arange(len(ground),len(frame.xyz_L))
        layers=SceneLayers({'ground':np.arange(len(ground)),'object':ids},
            (Candidate('target',ids,ids,1.,1.),),{}, {})
        model=replace(line_track(),diagnostics={'ground_plane':{'normal_L':[0.,0.,1.],'offset_m':0.}})
        track=TrackUpdate('observed_dual',model)
        cfg=SupportConfig(geometry_label_priority=True)
        context=_CurrentGroundContext(frame,layers,model,cfg)
        self.assertTrue(context.raised(frame.xyz_L[len(ground)]),
                        'nearest-k density discarded sparse valid ground on the other side')
        packet=build_packet(frame,track,layers,measure_candidates(frame,track,layers,cfg),cfg)
        self.assertEqual(len(packet['measurements']),1)
        self.assertEqual(packet['measurements'][0]['source_index'],len(ground))

    def test_footprint_support_is_rigid_transform_invariant(self):
        from rsview_centerline.clearance.track import transform_track
        rotation=np.array([[0.,0.,-1.],[0.,1.,0.],[1.,0.,0.]])
        offset=np.array([.3,-.2,.4])
        transform=np.eye(4);transform[:3,:3]=rotation;transform[:3,3]=offset
        for enclosing in (False,True):
            frame,track,layers=self.scene(enclosing=enclosing)
            moved=replace(frame,xyz_L=frame.xyz_L@rotation.T+offset)
            model=transform_track(track.model,moved,transform)
            actual=_CurrentGroundContext(moved,layers,model,SupportConfig()).raised(moved.xyz_L[-9])
            self.assertEqual(actual,enclosing)


if __name__=='__main__':
    unittest.main()
