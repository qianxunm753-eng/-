"""Small causal association trace, not a raw point-cloud export or live test."""
import argparse
from dataclasses import replace
import hashlib
import json
from pathlib import Path

import numpy as np

from rsview_centerline.clearance.native import read_native_frames, read_native_metadata
from rsview_centerline.clearance.motion import load_experimental_poses
from rsview_centerline.clearance.protocol import json_value
from rsview_centerline.clearance.replay import ReplayEngine
from rsview_centerline.clearance.rsview_cache import playback_config, build_packet


def run(root, output, start=495, end=528):
    if output.exists():
        raise FileExistsError('new diagnostic path required')
    native = root/'cart-frames'
    manifest = json.loads((native/'manifest.json').read_text(encoding='utf-8-sig'))
    with Path(manifest['input']).open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    poses = load_experimental_poses(root/'pose-work-03/cart-result-v5/registration.json',
                                    read_native_metadata(native))
    engine = ReplayEngine(playback_config(), 'tracked', poses)
    associate = engine.surface_tracker._associate_display
    records = []
    sequence = None
    targets = {'T16965', 'T19042', 'T14347'}

    def traced(descriptions, time_s):
        if sequence < start:
            return associate(descriptions, time_s)
        # Keep only the recent representative geometry used for matching.
        old = {}
        for key, item in engine.surface_tracker.display_regions.items():
            keep = time_s-item['point_times'] <= engine.config.history_seconds+1e-9
            if time_s-item['last_seen'] <= engine.config.history_seconds+1e-9 and keep.any():
                points = item['points'][keep]
                old[key] = dict(item, points=points, point_times=item['point_times'][keep],
                                lower=points.min(axis=0), upper=points.max(axis=0))
        matches = []
        for current in descriptions:
            parents = []
            for key, past in old.items():
                radius = max(current['radius'], past['radius'])
                separation = np.maximum(0., np.maximum(current['lower']-past['upper'],
                                                       past['lower']-current['upper']))
                if np.linalg.norm(separation) > radius:
                    continue
                distances = np.linalg.norm(current['points'][:, None]-past['points'][None], axis=2)
                if (distances.min(axis=1) <= radius).mean() >= .5:
                    parents.append(key)
            matches.append(parents)
        assignments = associate(descriptions, time_s)
        indices = [i for i, parents in enumerate(matches) if targets.intersection(parents)]
        keys = set(key for i in indices for key in matches[i])
        records.append(dict(sequence=sequence, time_s=time_s, old={k: old[k] for k in keys},
            descriptions=[dict(index=i, parents=matches[i], geometry=descriptions[i],
                               assignment=assignments[i]) for i in indices]))
        return assignments

    engine.surface_tracker._associate_display = traced
    for frame in read_native_frames(native, range(end+1)):
        sequence = frame.sequence
        frame = replace(frame, diagnostics=dict(frame.diagnostics, source_sha256=digest))
        update, layers, results = engine.step(frame)
        packet = build_packet(engine.measurement_frame, update, layers, results, engine.config,
                              selection=engine.surface_tracker)
        if sequence >= start:
            records[-1]['measurements'] = packet['measurements']
            records[-1]['centerline'] = packet['centerline']
            records[-1]['T_WL'] = poses.sample(frame.ref_time_s, frame.scan_span_s[1]).T_WL
        if sequence % 50 == 0:
            print('causal frame %d / %d' % (sequence, end), flush=True)
    with Path(manifest['input']).open('rb') as stream:
        after = hashlib.file_digest(stream, 'sha256').hexdigest()
    assert digest == after, 'original PCAP changed'
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(json_value(dict(source_sha256=digest, source_unchanged=True,
        causal_frames=end+1, records=records)), allow_nan=False), encoding='utf-8')
    print('trace saved: %d frames, %d bytes' % (len(records), output.stat().st_size), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--start', type=int, default=495)
    parser.add_argument('--end', type=int, default=528)
    args = parser.parse_args()
    run(args.input, args.output, args.start, args.end)
