"""Tests for the isolated trackside clearance core."""
