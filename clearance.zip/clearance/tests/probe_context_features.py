"""Current-scan context connectivity probe; no cloud copies or future frames."""
from pathlib import Path
import json
import numpy as np
from rsview_centerline.clearance.native import read_native_frames, read_native_metadata
from rsview_centerline.clearance.motion import load_experimental_poses
from rsview_centerline.clearance.replay import ReplayEngine
from rsview_centerline.clearance.rsview_cache import playback_config
from rsview_centerline.clearance.scene import _components


def main():
    root = Path(__file__).resolve().parents[2]/'analysis/20261002_clearance/run-20261003-full-input-03'
    frames = root/'cart-frames'
    poses = load_experimental_poses(root/'pose-work-03/cart-result-v5/registration.json', read_native_metadata(frames))
    engine = ReplayEngine(playback_config(), 'tracked', poses)
    update, layers, results = engine.step(next(read_native_frames(frames, {686})))
    current = engine.measurement_frame
    segment = update.model.segments[0]
    tangent = segment.end_L-segment.start_L
    tangent /= np.linalg.norm(tangent)
    axes = np.column_stack([segment.across_L, tangent, segment.normal_L])
    points = current.xyz_L
    coords = (points-segment.start_L)@axes
    plane = update.model.diagnostics['ground_plane']
    distance = np.abs(points@plane['normal_L']-plane['offset_m'])
    valid = np.isfinite(points).all(axis=1)&(np.linalg.norm(points,axis=1)>.2)&(np.linalg.norm(points,axis=1)<12.)
    valid &= (distance>.08)&(coords[:,2]>-.3)&(coords[:,2]<4.5)
    indices = np.flatnonzero(valid)
    components = _components(points[indices], indices, current, engine.config)
    summaries = []
    for candidate in sorted(components, key=lambda c:-len(c.point_indices))[:14]:
        c = coords[candidate.point_indices]
        summaries.append(dict(points=len(c),bounds=np.stack([c.min(axis=0),c.max(axis=0)]).round(3).tolist(),
            inside_5m=int((np.linalg.norm(points[candidate.point_indices],axis=1)<=5.).sum()),
            known_nearest_indices=[i for i in (33621,27381,20083,61352) if i in candidate.point_indices]))
    print(json.dumps(dict(frame=686,context=summaries),indent=2))


if __name__ == '__main__':
    main()
