"""Exact local p90 must not invoke a per-row nanpercentile loop."""
import unittest
import os
from unittest.mock import patch
import numpy as np
from rsview_centerline.clearance.instance_evidence import _current_surface_metrics,_local_residual_p90
from rsview_centerline.clearance.protocol import ClearanceConfig


class SurfaceQuantileWorkTests(unittest.TestCase):
    def test_dense_native_plane_keeps_all_surface_evidence_without_rowwise_percentile(self):
        points=np.array([[2.,y,z] for y in np.arange(.3,.501,.01) for z in np.arange(.3,.501,.01)])
        with patch('numpy.nanpercentile',wraps=np.nanpercentile) as rowwise:
            evidence=_current_surface_metrics(points,ClearanceConfig())
        self.assertEqual(evidence,dict(current_surface_fraction=1.,
            current_testable_fraction=1.,current_coherence_on_testable=1.))
        self.assertEqual(rowwise.call_count,0,'local evidence still invokes the per-row Python quantile path')

    def test_sparse_rank_deficient_native_line_still_has_no_testable_plane(self):
        points=np.array([[2.,y,.5] for y in np.arange(.3,.501,.01)])
        self.assertEqual(_current_surface_metrics(points,ClearanceConfig()),
            dict(current_surface_fraction=0.,current_testable_fraction=0.,current_coherence_on_testable=0.))

    def test_variable_neighborhoods_use_linear_interpolation_not_nearest_rank(self):
        residual=np.array([[0.,1.,np.nan,np.nan],[1.,2.,3.,np.nan],[.012,.012,.012,.012]])
        np.testing.assert_array_equal(_local_residual_p90(residual,[2,3,4]),[.9,2.8,.012])

    def test_boundary_and_mixed_neighbor_counts_match_numpy_bit_for_bit(self):
        rng=np.random.default_rng(2917)
        residual=rng.uniform(0.,.03,(2000,12))
        counts=rng.integers(1,13,len(residual))
        residual[np.arange(12)[None,:]>=counts[:,None]]=np.nan
        # Exact numerical threshold neighbors must not cross the eligibility
        # boundary because of a different interpolation ordering.
        residual[:3]=np.array([np.nextafter(.012,0.),.012,np.nextafter(.012,1.)])[:,None]
        counts[:3]=12
        expected=np.nanpercentile(residual,90,axis=1)
        actual=_local_residual_p90(residual,counts)
        np.testing.assert_array_equal(actual,expected)
        np.testing.assert_array_equal(actual<=.012,expected<=.012)

    def test_exact_patch_p90_is_invariant_to_native_neighbor_order(self):
        residual=np.array([[.03,.01,np.nan,.02],[np.nan,.012,np.nan,np.nan]])
        a=_local_residual_p90(residual,[3,1])
        b=_local_residual_p90(residual[:,[2,0,3,1]],[3,1])
        np.testing.assert_array_equal(a,b)

    def test_explicit_replay_preset_changes_no_scope_or_ownership_settings(self):
        from rsview_centerline.clearance_native import recorded_measurement_config,live_measurement_config
        with patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':'v28'}):
            before=recorded_measurement_config()
        with patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':'v29'}):
            after=recorded_measurement_config()
            live=live_measurement_config()
        self.assertNotEqual(before['config_id'],after['config_id'])
        self.assertEqual({k:v for k,v in before.items() if k!='config_id'},
                         {k:v for k,v in after.items() if k!='config_id'})
        self.assertFalse(live.get('observable_instance_seeding',False))


if __name__=='__main__':
    unittest.main()
