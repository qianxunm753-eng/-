"""Field regressions: sparse opposite-side results must not vanish in UI slots."""
import array
import unittest
from types import SimpleNamespace

from rsview_centerline import clearance_overlay as ui


def item(index,side='right',points=100):
    x=-2. if side=='left' else 2.
    return dict(display_id='T%d'%index,side=side,point_count=points,display_observations=1,
        uncertain=False,flags=[],distance_m=2.,point_L=[x,index*.1,.5],
        projected_L=[x,index*.1,0.],foot_L=[0.,index*.1,0.],source_index=index,
        source_frame=0,source_time_s=1.,observed_min_distance_m=2.,
        observed_source_index=index,observed_point_L=[x,index*.1,.5],raw_near_warning=False)


class FieldSelectionTests(unittest.TestCase):
    def test_geometry_qualified_near_region_is_not_displaced_by_dense_far_background(self):
        near=dict(item(1,'left',120),distance_m=2.2,
                  selection_quality={'occupied_cells':20,'role':'observed_surface'})
        far=dict(item(2,'left',20000),distance_m=4.3,display_slot_reserved=True,
                 selection_quality={'occupied_cells':400,'role':'observed_surface'})
        self.assertEqual(ui.select_display_measurements([far,near],1)[0]['source_index'],1,
                         'dense or reserved far background dominated a supported near region')

    def test_reserved_ambiguous_region_cannot_override_current_evidence_quality(self):
        near=dict(item(1,'left',80),distance_m=2.2,
                  selection_quality={'occupied_cells':20,'role':'observed_surface'})
        weak=dict(item(2,'left',20000),distance_m=1.,display_slot_reserved=True,
                  uncertain=True,flags=['nearest_ambiguous_surface'],
                  selection_quality={'occupied_cells':400,'role':'observed_surface'})
        self.assertEqual(ui.select_display_measurements([weak,near],1)[0]['source_index'],1)

    def test_valid_supported_boundary_is_not_hidden_by_an_isolated_raw_near_warning(self):
        near=dict(item(1,'left',120),distance_m=2.2,uncertain=True,
                  flags=['nearest_return_without_support'],raw_near_warning=True,
                  selection_quality={'occupied_cells':20,'role':'observed_surface','boundary_supported':True})
        far=dict(item(2,'left',20000),distance_m=4.3,
                 selection_quality={'occupied_cells':400,'role':'observed_surface','boundary_supported':True})
        self.assertEqual(ui.select_display_measurements([far,near],1)[0]['source_index'],1)
        self.assertTrue(near['uncertain'], 'annotation priority must not erase the raw warning')

    def test_mostly_unknown_region_does_not_get_priority_from_some_supported_returns(self):
        known=dict(item(1,'left',100),distance_m=2.2,
                   selection_quality={'occupied_cells':30,'boundary_supported':True,'ambiguity_fraction':.02})
        mixed=dict(item(2,'left',2000),distance_m=.5,uncertain=True,
                   selection_quality={'occupied_cells':300,'boundary_supported':True,'ambiguity_fraction':.8})
        self.assertEqual(ui.select_display_measurements([mixed,known],1)[0]['source_index'],1)

    def test_large_raw_supported_boundary_gap_remains_secondary(self):
        known=dict(item(1,'left',100),distance_m=2.2,
                   selection_quality={'occupied_cells':30,'boundary_supported':True,'ambiguity_fraction':.02})
        mixed=dict(item(2,'left',2000),distance_m=.6,uncertain=True,
                   selection_quality={'occupied_cells':300,'boundary_supported':True,'ambiguity_fraction':.2,
                                      'boundary_gap_m':.3,'neighbor_radius_m':.07})
        self.assertEqual(ui.select_display_measurements([mixed,known],1)[0]['source_index'],1)

    def test_unknown_regions_do_not_fill_unused_primary_label_slots(self):
        weak=dict(item(2,'left',2000),distance_m=.5,uncertain=True,
                  selection_quality={'occupied_cells':300,'boundary_supported':True,'ambiguity_fraction':.8})
        self.assertEqual(ui.select_display_measurements([weak],8,balance_sides=True),[],
                         'unused slots forced unresolved regions into primary dimensions')

    def select(self,items,limit=8):
        self.assertTrue(hasattr(ui,'select_display_measurements'),
                        'global density sorting still lets one side consume every slot')
        return ui.select_display_measurements(items,limit,balance_sides=True)

    def test_sparse_opposite_side_keeps_current_measurements_without_fixed_side_quota(self):
        inputs=[item(i,'right',1000-i) for i in range(12)]+[item(20,'left',10),item(21,'left',8)]
        before=[dict(m) for m in inputs]
        shown=self.select(inputs)
        self.assertEqual(len(shown),8)
        self.assertEqual(sum(m['side']=='left' for m in shown),2)
        self.assertEqual(sum(m['side']=='right' for m in shown),6)
        self.assertEqual({m['source_index'] for m in shown if m['side']=='left'},{20,21})
        self.assertEqual(inputs,before)

    def test_one_side_only_uses_available_slots_without_inventing_other_side(self):
        shown=self.select([item(i,'left',100-i) for i in range(10)])
        self.assertEqual([m['source_index'] for m in shown],list(range(8)))

    def test_missing_current_region_does_not_reappear_from_reserved_identity(self):
        inputs=[dict(item(1),display_slot_reserved=True)]
        self.assertEqual([m['source_index'] for m in self.select(inputs)],[1])
        self.assertEqual(self.select([]),[])

    def test_single_slot_preserves_best_evidence_instead_of_forcing_a_side(self):
        strong=item(1,'right',100)
        weak=dict(item(2,'left',1),uncertain=True,flags=['nearest_ambiguous_surface'])
        self.assertEqual(self.select([weak,strong],1)[0]['source_index'],1)


class Actor:
    def SetVisibility(self,value):
        self.visible=bool(value)
    def GetProperty(self):
        return self
    def SetColor(self,*value):
        self.color=value
    def SetInput(self,value):
        self.text=value


class Line:
    def SetPoint1(self,*point):
        self.endpoint=point
    def SetPoint2(self,*point):
        self.foot=point
    def Update(self):
        pass


class Upload:
    def update(self,values):
        self.values=list(values)


class NativeDisplayTests(unittest.TestCase):
    def overlay(self):
        overlay=ui.VtkClearanceOverlay.__new__(ui.VtkClearanceOverlay)
        overlay.current=overlay.last_result=None
        overlay.raw_rep=SimpleNamespace(Visibility=1)
        overlay.raw_visibility=1
        overlay.cloud_actors={}
        overlay.boundary_actors=[(Upload(),Actor()),(Upload(),Actor())]
        overlay.raw_boundary_actor=(Upload(),Actor())
        overlay.center_lines=[]
        overlay.measure_lines=[(Line(),Actor()) for _ in range(8)]
        overlay.labels=[Actor() for _ in range(8)]
        overlay.status_label=SimpleNamespace(setText=lambda text:None)
        overlay.smp=SimpleNamespace(Render=lambda view:None)
        overlay.view=None
        overlay._position_labels=lambda:None
        return overlay

    def packet(self,**changes):
        return dict(sequence=0,mode='observed_dual',candidate_count=8,centerline=[],clouds={},
                    measurements=[item(i,'left' if i%2 else 'right') for i in range(8)],**changes)

    def test_live_packet_displays_all_eight_lines_and_actual_boundary_markers(self):
        overlay=self.overlay()
        packet=self.packet(display_limit=8)
        overlay.display_packet(packet)
        self.assertEqual(len(overlay.current['measurements']),8,
                         'worker returns eight but native display silently truncates to four')
        self.assertEqual(sum(actor.visible for _,actor in overlay.measure_lines),8)
        self.assertEqual(len(overlay.boundary_actors[0][0].values),24)
        for actual,expected in zip(overlay.measure_lines[7][0].endpoint,(-2.,.7,0.)):
            self.assertAlmostEqual(actual,expected,places=10)
        self.assertEqual(packet['measurements'][7]['source_index'],7)

    def test_legacy_packet_keeps_old_four_line_layout(self):
        overlay=self.overlay()
        overlay.display_packet(self.packet())
        self.assertEqual(len(overlay.current['measurements']),4)
        self.assertEqual(sum(actor.visible for _,actor in overlay.measure_lines),4)

    def test_invalid_display_budget_is_not_silently_accepted(self):
        with self.assertRaises(ValueError):
            self.overlay().display_packet(self.packet(display_limit=9))


if __name__=='__main__':
    unittest.main()
