"""Current geometry must be checked even before a usable relative pose exists."""
from dataclasses import dataclass,replace
import os
import unittest
from unittest.mock import patch
import numpy as np
from rsview_centerline import clearance_native
from rsview_centerline.clearance.scene import SurfaceTracker
from rsview_centerline.clearance.measure import measure_candidates
from rsview_centerline.clearance.protocol import TrackUpdate
from rsview_centerline.clearance.rsview_cache import build_packet
from rsview_centerline.clearance.tests.test_observable_instances import ObservableConfig,configuration,target_scene
from rsview_centerline.clearance.tests.test_surface_tracking import pose


@dataclass(frozen=True)
class GatingConfig(ObservableConfig):
    current_observation_gating: bool = True


def gating_config(enabled=True):
    base=configuration()
    return GatingConfig(**dict(base.__dict__,current_observation_gating=enabled))


def packet_for(points,ground_height=None,enabled=True):
    frame,layers,model=target_scene(points,ground_height=ground_height)
    model=replace(model,diagnostics=dict(model.diagnostics,measurement_flags=['relative_motion_unavailable']))
    cfg=gating_config(enabled)
    tracker=SurfaceTracker(cfg)
    output=tracker.update(frame,layers,None,model)
    results=measure_candidates(frame,TrackUpdate('observed_dual',model),output,cfg)
    return frame,output,results,build_packet(frame,TrackUpdate('observed_dual',model),output,results,cfg),tracker


class UncompensatedObservationTests(unittest.TestCase):
    def test_two_return_fragment_does_not_bypass_geometry_at_pose_startup(self):
        frame,layers,results,packet,tracker=packet_for([[2.,.7,.4],[2.,.74,.4]])
        self.assertEqual(packet['measurements'],[],
                         'unavailable pose bypassed current independent-surface qualification')
        self.assertEqual(len(packet['secondary_measurements']),1)
        self.assertEqual(packet['secondary_measurements'][0]['observed_min_distance_m'],2.)
        self.assertEqual(packet['secondary_measurements'][0]['source_frame'],frame.sequence)
        self.assertEqual(results[0].observed_min_distance_m,2.)
        self.assertEqual(len(tracker.display_regions),0)
        np.testing.assert_array_equal(layers.candidates[0].point_indices,[0,1])

    def test_current_observed_surface_keeps_provisional_range_without_inventing_a_map_id(self):
        points=[[2.,y,z] for y in np.arange(.4,.8,.025) for z in np.arange(.2,.8,.025)]
        frame,layers,results,packet,tracker=packet_for(points)
        self.assertEqual(len(packet['measurements']),1)
        self.assertEqual(packet['measurements'][0]['observed_min_distance_m'],2.)
        self.assertIsNone(packet['measurements'][0]['object_id'])
        self.assertIn('object_identity_pending',packet['measurements'][0]['flags'])
        self.assertIn('relative_motion_unavailable',packet['measurements'][0]['flags'])
        self.assertTrue(layers.candidates[0].diagnostics.get('instance_seed_evidence',{}).get('seed_allowed',False),
                        'pose startup never evaluated actual current geometry')
        self.assertEqual(tracker.display_regions,{})

    def test_locally_observed_floor_is_not_a_startup_dimension(self):
        points=[[2.+x,.8+y,.04] for x in (0.,.04,.08) for y in (0.,.04,.08)]
        frame,layers,results,packet,tracker=packet_for(points,ground_height=.04)
        self.assertEqual(packet['measurements'],[])
        self.assertEqual(packet['secondary_measurements'][0]['observed_min_distance_m'],2.)
        self.assertEqual(len(layers.candidates[0].point_indices),9)

    def test_disabled_gate_preserves_v26_startup_behavior(self):
        frame,layers,results,packet,tracker=packet_for([[2.,.7,.4],[2.,.74,.4]],enabled=False)
        self.assertEqual(len(packet['measurements']),1)
        self.assertIsNone(packet['measurements'][0]['object_id'])

    def test_startup_respects_decoder_support_and_qualified_core_abstention(self):
        points=[[2.,y,z] for y in np.arange(.4,.8,.025) for z in np.arange(.2,.8,.025)]
        frame,layers,model=target_scene(points)
        original=layers.candidates[0]
        cases=[('current',{'support_neighbor_valid':np.ones((len(points),1),bool)},original.supported_indices,1),
               ('temporal_only',{'support_neighbor_valid':np.zeros((len(points),1),bool)},original.supported_indices,0),
               ('malformed',{'support_neighbor_valid':np.ones((len(points)-1,1),bool)},original.supported_indices,0),
               ('two_supported',{},original.supported_indices[:2],0),
               ('unknown_ground',{'point_role':'unknown_ground'},original.supported_indices,0),
               ('ambiguous_core',{'ambiguous_indices':original.point_indices[:int(.8*len(points))]},original.supported_indices,0)]
        for name,diagnostics,supported,expected in cases:
            with self.subTest(case=name):
                candidate=replace(original,diagnostics=diagnostics,supported_indices=supported)
                tracker=SurfaceTracker(gating_config())
                current=tracker.update(frame,replace(layers,candidates=(candidate,)),None,model)
                results=measure_candidates(frame,TrackUpdate('observed_dual',model),current,gating_config())
                packet=build_packet(frame,TrackUpdate('observed_dual',model),current,results,gating_config())
                self.assertEqual(len(packet['measurements']),expected)
                self.assertEqual(results[0].observed_min_distance_m,2.)
                self.assertIsNone(current.candidates[0].diagnostics['object_id'])
                np.testing.assert_array_equal(current.candidates[0].point_indices,original.point_indices)
                np.testing.assert_array_equal(current.candidates[0].supported_indices,supported)
                self.assertEqual(tracker.display_regions,{})

    def test_recorded_gate_requires_its_current_geometry_dependencies(self):
        from rsview_centerline.clearance.online import OnlineEngine
        with self.assertRaisesRegex(ValueError,'requires'):
            OnlineEngine({'current_observation_gating':True},source_mode='recorded_pcap')

    def test_loss_of_pose_does_not_reuse_a_previously_confirmed_id_or_distance(self):
        cfg=gating_config()
        tracker=SurfaceTracker(cfg)
        body=[[2.,y,z] for y in np.arange(.4,.8,.025) for z in np.arange(.2,.8,.025)]
        first,layers,model=target_scene(body)
        self.assertEqual(tracker.update(first,layers,pose(first),model).candidates[0].diagnostics['object_id'],'T1')
        frame,layers,model=target_scene([[1.98,.6,.4],[1.98,.64,.4]],time=1.1,sequence=1)
        current=tracker.update(frame,layers,None,model)
        results=measure_candidates(frame,TrackUpdate('observed_dual',model),current,cfg)
        packet=build_packet(frame,TrackUpdate('observed_dual',model),current,results,cfg)
        self.assertEqual(packet['measurements'],[])
        self.assertEqual(packet['secondary_measurements'][0]['observed_min_distance_m'],1.98)
        self.assertIsNone(packet['secondary_measurements'][0]['object_id'])
        self.assertEqual(results[0].observed_evidence.point_ref.frame,1)
        self.assertEqual(tracker.display_regions,{})

    def test_v27_is_explicit_and_live_rejects_the_new_flag_independently(self):
        with patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':'v27'}):
            self.assertTrue(clearance_native.recorded_measurement_config().get('current_observation_gating',False))
        for variant in ('1','v26','v25','0'):
            with patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':variant}):
                self.assertFalse(clearance_native.recorded_measurement_config().get('current_observation_gating',False))
        self.assertFalse(clearance_native.live_measurement_config().get('current_observation_gating',False))
        from rsview_centerline.clearance.online import OnlineEngine
        with self.assertRaisesRegex(ValueError,'replay-only'):
            OnlineEngine({'current_observation_gating':True},source_mode='live')


if __name__=='__main__':
    unittest.main()
