"""Small live-engine profile from existing native scans; never exports clouds."""
import argparse
import cProfile
import json
from pathlib import Path
import pstats
import time

import numpy as np

from rsview_centerline.clearance.native import read_native_frames
from rsview_centerline.clearance.online import OnlineEngine


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--frames', default='74,91,260,261,262')
    parser.add_argument('--motion', action='store_true')
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError('Use a new report name')
    folder = Path(__file__).resolve().parents[2]/'analysis/20261002_clearance/run-20261003-full-input-03/cart-frames'
    engine = OnlineEngine(dict(config_id='live-profile', sensor_max_range_m=5.,
                              measurement_height_range_m=(-.3,3.5),live_motion_estimation=args.motion))
    profiler = cProfile.Profile()
    rows = []
    for frame in read_native_frames(folder, list(map(int, args.frames.split(',')))):
        request = dict(sequence=frame.sequence, device_time_s=frame.ref_time_s,
            session_id=frame.session_id, clock_id=frame.clock_id, xyz=frame.xyz_L,
            point_times=np.array([r.time_s for r in frame.refs]), rings=frame.rings,
            scan_span_s=frame.scan_span_s)
        profiler.enable()
        started = time.perf_counter()
        packet = engine.process(request)
        elapsed = (time.perf_counter()-started)*1000.
        profiler.disable()
        rows.append(dict(sequence=frame.sequence, input_points=len(frame.xyz_L),
            elapsed_ms=elapsed, timings=packet['timing_ms'], mode=packet['mode'],
            pose_scope=packet['pose_scope'], motion_status=packet['motion_status'],
            relative_pose=packet.get('relative_pose_diagnostics'),
            distances=[dict(distance_m=m['distance_m'],source_index=m['source_index'],
                            source_frame=m['source_frame'],display_id=m['display_id'],
                            display_observations=m['display_observations']) for m in packet['measurements']]))
    stats = pstats.Stats(profiler)
    functions = [dict(file=filename,line=line,function=name,calls=calls,
                      own_ms=own*1000.,cumulative_ms=cumulative*1000.)
        for (filename,line,name),(_,calls,own,cumulative,_) in stats.stats.items()]
    report = dict(frames=rows, functions=sorted([r for r in functions if
            'rsview_centerline' in r['file'] or r['own_ms']>100.],key=lambda r:-r['cumulative_ms'])[:50],
                  physical_test=False,absolute_accuracy_verified=False)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(dict(report=str(args.output),frames=[dict(sequence=r['sequence'],
        elapsed_ms=round(r['elapsed_ms'],1),mode=r['mode'],motion_status=r['motion_status'])
        for r in rows],functions=report['functions'][:8]),indent=2))


if __name__ == '__main__':
    main()
