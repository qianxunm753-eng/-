"""Read-only scene probe. Prints bounded summaries; exports no point cloud."""
import argparse
import json
from pathlib import Path

import numpy as np

from rsview_centerline.clearance.native import read_native_frames, read_native_metadata
from rsview_centerline.clearance.motion import load_experimental_poses
from rsview_centerline.clearance.protocol import measurement_model
from rsview_centerline.clearance.replay import ReplayEngine
from rsview_centerline.clearance.rsview_cache import playback_config, build_packet


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--frame', type=int, default=686)
    parser.add_argument('--warmup', type=int, default=6)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]/'analysis'/'20261002_clearance'
    inputs = root/'run-20261003-full-input-03'
    native = inputs/'cart-frames'
    poses = load_experimental_poses(inputs/'pose-work-03'/'cart-result-v5'/'registration.json',
                                   read_native_metadata(native))
    engine = ReplayEngine(playback_config(), 'tracked', poses)
    timings, identities = [], []
    for frame in read_native_frames(native, range(max(0, args.frame-args.warmup), args.frame+1)):
        update, layers, results = engine.step(frame)
        timings.append(engine.timings)
        packet = build_packet(engine.measurement_frame,update,layers,results,engine.config)
        identities.append(dict(frame=frame.sequence,visible=[dict(distance_m=m['distance_m'],
            surface_id=m['surface_id'],observations=m['surface_observations'],
            association=m['surface_association'],point_count=m['point_count']) for m in packet['measurements'][:4]]))
    model = measurement_model(update)
    if model is None:
        print(json.dumps({'frame': frame.sequence, 'mode': update.mode}))
        return
    segment = model.segments[0]
    tangent = segment.end_L-segment.start_L
    tangent /= np.linalg.norm(tangent)
    axes = np.column_stack([segment.across_L, tangent, segment.normal_L])
    results = {r.candidate_id: r for r in results}
    summaries = []
    for candidate in sorted(layers.candidates, key=lambda c: -len(c.point_indices))[:12]:
        points = engine.measurement_frame.xyz_L[candidate.point_indices]
        coordinates = (points-segment.start_L)@axes
        covariance = np.cov(points, rowvar=False) if len(points)>1 else np.zeros((3, 3))
        eigenvalues = np.linalg.eigvalsh(covariance)
        result = results[candidate.candidate_id]
        summaries.append(dict(candidate=candidate.candidate_id, points=len(points),
            distance=result.observed_min_distance_m, flags=result.flags,
            surface_id=candidate.diagnostics.get('surface_id'),
            surface_observations=candidate.diagnostics.get('surface_observations'),
            bounds_track=np.stack([coordinates.min(axis=0), coordinates.max(axis=0)]).round(4).tolist(),
            eigenvalues=eigenvalues.round(6).tolist(),
            raw_height_quantiles=np.quantile(coordinates[:, 2], [0, .1, .5, .9, 1]).round(4).tolist()))
    print(json.dumps({'frame': frame.sequence, 'mode': update.mode, 'layers': layers.counts,
                      'timing_median_ms':{k:float(np.median([t[k] for t in timings])) for k in timings[0]},
                      'visible_history':identities,
                      'ground_plane': model.diagnostics.get('ground_plane'), 'candidates': summaries}, indent=2))


if __name__ == '__main__':
    main()
