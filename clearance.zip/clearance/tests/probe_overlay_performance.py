# -*- coding: utf-8 -*-
"""Owned native RSView overlay benchmark, also probes its VTK buffer API."""
import array
import json
import os
import struct
import time
import traceback
from PythonQt import QtCore, QtGui
import rsview.applogic as logic


def run():
    report = {'error': None, 'frames': []}
    try:
        from clearance_overlay import VtkClearanceOverlay, PacketCache, _vtk_type
        root = os.path.dirname(logic._rail_centerline_path)
        with open(os.path.join(root, 'clearance_overlay_config.json'), 'rb') as stream:
            folder = json.load(stream)['cache_folder']
        reader = logic.smp.Sphere()
        logic.smp.Show(reader, logic.app.mainView)
        overlay = VtkClearanceOverlay(logic.smp, logic.vtk, logic.app.mainView,
            logic.app.statusLabel, 'unused.pcap', reader, packet_cache=PacketCache(folder))
        # The old wrapper must accept these actual Python 2 buffer owners.
        values = array.array('f', [1., 2., 3., 4., 5., 6.])
        floats = _vtk_type(logic.vtk, 'vtkFloatArray')()
        floats.SetNumberOfComponents(3)
        floats.SetVoidArray(values, len(values), 1)
        ids = _vtk_type(logic.vtk, 'vtkIdTypeArray')()
        connectivity = struct.pack('=qqqq' if ids.GetDataTypeSize() == 8 else '=iiii', 1, 0, 1, 1)
        ids.SetVoidArray(connectivity, 4, 1)
        cells = _vtk_type(logic.vtk, 'vtkCellArray')()
        cells.SetCells(2, ids)
        report['buffer_api'] = dict(tuple=list(floats.GetTuple3(1)), cells=cells.GetNumberOfCells(),
                                    id_bytes=ids.GetDataTypeSize())
        class LegacyPointBuffer(object):
            def __init__(self,data): self.data=data
            def update(self,coordinates):
                points = _vtk_type(logic.vtk,'vtkPoints')()
                cells = _vtk_type(logic.vtk,'vtkCellArray')()
                for i in range(len(coordinates)//3):
                    points.InsertNextPoint(*coordinates[i*3:i*3+3])
                    cells.InsertNextCell(1)
                    cells.InsertCellPoint(i)
                self.data.SetPoints(points)
                self.data.SetVerts(cells)
                self.data.Modified()
        optimized = overlay.point_buffers.copy()
        legacy = {name:LegacyPointBuffer(data) for name,(data,actor) in overlay.cloud_actors.items()}
        for number in (74, 91, 260, 686):
            packet = overlay.cache.get(number)
            elapsed = {'legacy':[],'batch':[]}
            for kind,buffers in (('legacy',legacy),('batch',optimized),('batch',optimized),('legacy',legacy)):
                overlay.point_buffers = buffers
                # Restoring point/vertex attachment lets both paths use the
                # same actors, camera, packets and buffer sizes in one process.
                if kind == 'batch':
                    for upload in buffers.values():
                        upload.data.SetPoints(upload.points)
                        upload.data.SetVerts(upload.cells)
                for iteration in range(8):
                    started = time.time()
                    overlay.display_packet(packet)
                    if iteration >= 2:
                        elapsed[kind].append((time.time()-started)*1000.)
            elapsed = {kind:sorted(values) for kind,values in elapsed.items()}
            report['frames'].append(dict(sequence=number, point_count=sum(
                v['count'] for v in packet['clouds'].values()),
                medians_ms={kind:values[len(values)//2] for kind,values in elapsed.items()},
                maxima_ms={kind:max(values) for kind,values in elapsed.items()},
                geometry=getattr(overlay,'last_display_timings',None)))
        overlay.close()
    except Exception:
        report['error'] = traceback.format_exc().decode('utf-8', 'replace')
    with open(os.environ['RSVIEW_OVERLAY_REPORT'].decode('mbcs'), 'wb') as stream:
        stream.write(json.dumps(report,indent=2).encode('utf-8'))
    QtGui.QApplication.instance().quit()


timer = QtCore.QTimer()
timer.setSingleShot(True)
timer.connect('timeout()', run)
timer.start(1000)
