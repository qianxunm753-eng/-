import tempfile
from pathlib import Path
import unittest
from dataclasses import replace
import numpy as np
import json
from rsview_centerline.clearance.protocol import ClearanceConfig,PoseSample
from rsview_centerline.clearance.tests.fixtures import cloud
from rsview_centerline.clearance.tests.test_track import rail_scene


class ReplayTests(unittest.TestCase):
    def test_pose_map_reset_clears_object_temporal_support_and_surface_identity(self):
        from rsview_centerline.clearance.replay import ReplayEngine
        from rsview_centerline.clearance.protocol import TrackUpdate
        from rsview_centerline.clearance.tests.fixtures import line_track
        class Poses:
            def sample(self,t,available_until_s):
                return PoseSample(t,np.eye(4),'device:test',(t,t),t,
                    'map-A' if t < 1.05 else 'map-B',True,
                    {'clock_epoch':0 if t < 1.05 else 1})
        engine = ReplayEngine(ClearanceConfig(),'tracked',Poses(),
            observer=lambda f:TrackUpdate('observed_dual',replace(line_track(),ref_time_s=f.ref_time_s)))
        a = cloud([[2.,1.,.5],[2.01,1.01,.51]], time=1., sequence=0)
        b = cloud([[2.,1.,.5]], time=1.1, sequence=1)
        _, first, _ = engine.step(a)
        _, second, _ = engine.step(b)
        self.assertEqual(second.candidates[0].supported_indices.tolist(), [])
        self.assertEqual(second.candidates[0].diagnostics['surface_observations'], 1)
        self.assertNotEqual(first.candidates[0].diagnostics['surface_id'],
                            second.candidates[0].diagnostics['surface_id'])

    def test_engine_associates_surfaces_without_averaging_current_measurement(self):
        from rsview_centerline.clearance.replay import ReplayEngine
        from rsview_centerline.clearance.protocol import TrackUpdate
        from rsview_centerline.clearance.tests.fixtures import line_track
        class Poses:
            def sample(self,t,available_until_s):
                matrix = np.eye(4)
                matrix[0,3] = 10.*(t-1.)
                return PoseSample(t,matrix,'device:test',(0.,10.),available_until_s,'analytic_test',True)
        engine = ReplayEngine(ClearanceConfig(),'tracked',Poses(),
            observer=lambda f: TrackUpdate('observed_dual',line_track(time=f.ref_time_s)))
        _,first,a = engine.step(cloud([[2.,1.,.5],[2.01,1.01,.51]]))
        _,second,b = engine.step(cloud([[1.,1.,.5],[1.01,1.01,.51]],time=1.1,sequence=1))
        self.assertIn('surface_id',second.candidates[0].diagnostics)
        self.assertEqual(first.candidates[0].diagnostics['surface_id'],
                         second.candidates[0].diagnostics['surface_id'])
        self.assertEqual(second.candidates[0].diagnostics['surface_observations'],2)
        self.assertAlmostEqual(a[0].observed_min_distance_m,2.)
        self.assertAlmostEqual(b[0].observed_min_distance_m,1.)
        self.assertEqual(b[0].observed_evidence.point_ref.frame,1)

    def test_engine_does_not_associate_raw_scan_when_point_time_is_missing(self):
        from rsview_centerline.clearance.replay import ReplayEngine
        from rsview_centerline.clearance.protocol import TrackUpdate
        from rsview_centerline.clearance.tests.fixtures import line_track
        class Poses:
            def sample(self,t,available_until_s):
                return PoseSample(t,np.eye(4),'device:test',(0.,10.),available_until_s,'analytic_test',True)
        engine = ReplayEngine(ClearanceConfig(),'tracked',Poses(),
            observer=lambda f: TrackUpdate('observed_dual',line_track(time=f.ref_time_s)))
        _,scene,_ = engine.step(cloud([[2.,1.,.5]],times=False))
        self.assertEqual(engine.measurement_frame.motion_status,'raw')
        self.assertIn('surface_id',scene.candidates[0].diagnostics)
        self.assertIsNone(scene.candidates[0].diagnostics['surface_id'])

    def test_tracked_engine_propagates_supported_geometry_not_held_picture(self):
        from rsview_centerline.clearance.replay import ReplayEngine
        class Poses:
            def sample(self,t,available_until_s):
                return PoseSample(t,np.eye(4),'device:test',(0.,10.),available_until_s,'analytic_test',True)
        engine = ReplayEngine(ClearanceConfig(),'tracked',Poses())
        track,scene,results = engine.step(rail_scene())
        self.assertEqual(track.mode,'observed_dual')
        track,scene,results = engine.step(cloud([[2,1,1]],time=1.1,sequence=1))
        self.assertEqual(track.mode,'predicted_track')
        self.assertTrue(any(r.observed_min_distance_m is not None for r in results))

    def test_time_reversal_discards_previous_rail_identity(self):
        from rsview_centerline.clearance.replay import ReplayEngine
        engine = ReplayEngine(ClearanceConfig(),'tracked',None)
        engine.step(rail_scene())
        track,_,_ = engine.step(cloud([],time=.9,sequence=0))
        self.assertEqual(track.mode,'initializing')

    def test_invalid_mode_is_rejected(self):
        from rsview_centerline.clearance.replay import ReplayEngine
        with self.assertRaises(ValueError):
            ReplayEngine(ClearanceConfig(),'pretend_realtime',None)

    def test_future_input_does_not_change_prefix_results(self):
        from rsview_centerline.clearance.replay import ReplayEngine
        frames = [rail_scene(),cloud([[2,1,1]],time=1.1,sequence=1)]
        def prefix(sequence):
            engine = ReplayEngine(ClearanceConfig(),'single_frame',None)
            outputs = []
            for f in sequence:
                track,_,results = engine.step(f)
                outputs.append((track.mode,[r.observed_min_distance_m for r in results]))
            return outputs
        a = prefix(frames)
        b = prefix(frames+[cloud([],time=1.2,sequence=2)])
        self.assertEqual(a,b[:2])

    def test_latest_queue_records_overwritten_frames_and_has_one_pending(self):
        from rsview_centerline.clearance.paced import LatestPending
        pending = LatestPending()
        pending.offer(0)
        self.assertEqual(pending.take(),0)
        for seq in (2,4,6):
            pending.offer(seq)
        self.assertEqual(pending.skipped,[2,4])
        self.assertEqual(pending.take(),6)
        self.assertIsNone(pending.take())

    def test_paced_trigger_uses_actual_device_dt(self):
        from rsview_centerline.clearance.paced import DeviceTrigger
        trigger = DeviceTrigger(.2)
        self.assertEqual([i for i,t in enumerate((1.,1.1,1.2,1.3,1.4)) if trigger.due(t)],[0,2,4])
        self.assertTrue(trigger.due(.5))  # backwards device clock starts a new epoch

    def test_real_worker_paced_smoke_accounts_for_every_native_scan(self):
        from rsview_centerline.clearance.paced import run_paced
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory);native=root/'native';native.mkdir()
            rows=[]
            for i in range(3):
                xyz=np.array([[2.,1.,1.]],dtype='<f8');stamps=np.array([1.+i*.1],dtype='<f8')
                xyz.tofile(native/('xyz%d.bin'%i));stamps.tofile(native/('time%d.bin'%i))
                rows.append({'frame':i,'step':i,'timestamp_range':[float(stamps[0]),float(stamps[0])],
                    'xyz':{'dtype':'double','components':3,'tuples':1,'file':'xyz%d.bin'%i},
                    'attributes':{'timestamp':{'dtype':'double','components':1,'tuples':1,'file':'time%d.bin'%i}}})
            (native/'manifest.json').write_text(json.dumps({'frames':rows,'input':'analytic','native_frame_count':3}))
            report=run_paced(native,ClearanceConfig(),None,root/'run','single_frame')
            self.assertEqual(report['input_frames'],3)
            self.assertGreaterEqual(report['consumed_frames'],1)
            logs=[json.loads(s) for s in (root/'run/frames.jsonl').read_text().splitlines()]
            self.assertEqual([r['sequence'] for r in logs],[0,1,2])
            self.assertFalse(report['live_0_2s_verified'])
            with self.assertRaises(FileExistsError):
                run_paced(native,ClearanceConfig(),None,root/'run','single_frame')

    def test_real_paced_clock_reset_preserves_arrival_spacing_and_result_age(self):
        from rsview_centerline.clearance.paced import run_paced
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);native=root/'native';native.mkdir();rows=[]
            for i,t in enumerate((100.,100.1,100.2,0.,.1,.2,.3)):
                np.array([[2.,1.,1.]],dtype='<f8').tofile(native/('xyz%d.bin'%i))
                np.array([t],dtype='<f8').tofile(native/('time%d.bin'%i))
                rows.append({'frame':i,'step':i,'timestamp_range':[t,t],
                    'xyz':{'dtype':'double','components':3,'tuples':1,'file':'xyz%d.bin'%i},
                    'attributes':{'timestamp':{'dtype':'double','components':1,'tuples':1,'file':'time%d.bin'%i}}})
            (native/'manifest.json').write_text(json.dumps({'frames':rows,'input':'reset-test','native_frame_count':7}))
            report=run_paced(native,ClearanceConfig(),None,root/'run','single_frame')
            logs=[json.loads(s) for s in (root/'run/frames.jsonl').read_text().splitlines()]
            ages=[r['result_age_s'] for r in logs if r['consumed']]
            self.assertLess(max(ages),2.)  # Not 100 s from subtracting an old device-time origin.
            self.assertGreaterEqual(report['wall_s'],.55)  # The new epoch must not arrive in one burst.
            np.testing.assert_allclose([r['playback_elapsed_s'] for r in logs],
                                       [0.,.1,.2,.3,.4,.5,.6],atol=1e-9)
            self.assertEqual([r['device_time_s'] for r in logs],[100.,100.1,100.2,0.,.1,.2,.3])
            self.assertEqual([r['clock_epoch'] for r in logs],[0,0,0,1,1,1,1])

    def test_replay_logs_ground_confirmation_uncertainty_used_for_exclusion(self):
        from rsview_centerline.clearance.replay import run_replay
        from rsview_centerline.clearance.protocol import TrackUpdate
        from rsview_centerline.clearance.tests.fixtures import line_track
        track=replace(line_track(),diagnostics={'ground_plane':{'normal_L':[0,0,1],'offset_m':-.1}})
        frame=cloud([[x,y,-.1] for x in np.linspace(1.9,2.3,5) for y in np.linspace(.8,1.2,5)])
        with tempfile.TemporaryDirectory() as directory:
            output=Path(directory)/'run'
            run_replay([frame],ClearanceConfig(),output=output,previews=(),
                       observer=lambda f:TrackUpdate('observed_dual',track))
            row=json.loads((output/'frames.jsonl').read_text())
        self.assertIn('scene_diagnostics',row)
        self.assertLess(row['scene_diagnostics']['ground_confirmation']['confirmation_band_m'],.003)



if __name__ == '__main__':
    unittest.main()
