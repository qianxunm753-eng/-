"""Causal original-PCAP ground regression; small numerical reports only."""
import argparse
from dataclasses import replace
import hashlib
import json
from pathlib import Path

from rsview_centerline.clearance.native import read_native_frames,read_native_metadata
from rsview_centerline.clearance.motion import load_experimental_poses
from rsview_centerline.clearance.replay import ReplayEngine
from rsview_centerline.clearance.rsview_cache import playback_config,build_packet

SOURCE_SHA='88e53b2835febf5a35346e9dd02379894c530672277ab4ae7f45215766f04960'


def run(root,output,end=45):
    native=root/'cart-frames'
    metadata=json.loads((native/'manifest.json').read_text(encoding='utf-8-sig'))
    pcap=Path(metadata['input'])
    with pcap.open('rb') as stream:
        before=hashlib.file_digest(stream,'sha256').hexdigest()
    assert before==SOURCE_SHA,'input is not the approved experimental recording'
    poses=load_experimental_poses(root/'pose-work-03/cart-result-v5/registration.json',
                                 read_native_metadata(native))
    engine=ReplayEngine(playback_config(),'tracked',poses)
    records=[]
    checked=False
    for frame in read_native_frames(native,range(end+1)):
        frame=replace(frame,diagnostics=dict(frame.diagnostics,source_sha256=SOURCE_SHA))
        track,layers,results=engine.step(frame)
        packet=build_packet(engine.measurement_frame,track,layers,results,engine.config,
                            selection=engine.surface_tracker)
        if frame.sequence<35:
            continue
        records.append(dict(frame=frame.sequence,counts=layers.counts,
            ground_confirmation=layers.diagnostics['ground_confirmation'],
            visible=[dict(display_id=m['display_id'],distance_m=m['distance_m'],
                          source_index=m['source_index']) for m in packet['measurements'][:4]]))
        if frame.sequence==40:
            print(json.dumps(records[-1],allow_nan=False),flush=True)
            # Screenshot-confirmed outer ground. The previous v14 selected
            # index 67710 as T1979 / 2.977524 m, even in a full causal replay.
            assert 67710 in layers.indices['ground'],'screenshot ground is still a candidate'
            assert 67710 not in layers.indices['object']
            assert not any(m['source_index']==67710 for m in packet['measurements'])
            protected={66679:2.208313571917394,65534:2.1532754807974874,
                       65440:2.181804414289322}
            selected={m['source_index']:m for m in packet['measurements'][:4]}
            for index,distance in protected.items():
                assert index in selected,'a protected real device lost its measurement'
                assert abs(selected[index]['distance_m']-distance)<1e-10,'true device minimum changed'
            assert len(packet['_display']['ground'])>0,'ground display was removed'
            checked=True
        if frame.sequence==45:
            print(json.dumps(records[-1],allow_nan=False),flush=True)
            assert 67710 in layers.indices['ground'],'same ground re-entered measurement at frame 45'
    assert checked,'frame 40 not checked'
    with pcap.open('rb') as stream:
        after=hashlib.file_digest(stream,'sha256').hexdigest()
    assert before==after,'original PCAP changed'
    report=dict(source_sha256=before,source_sha256_after=after,source_unchanged=True,
                causal_frames=end+1,ground_40_passed=True,ground_45_passed=end>=45,records=records)
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='records'},allow_nan=False),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(__doc__)
    parser.add_argument('--input',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--end',type=int,default=45)
    args=parser.parse_args()
    run(args.input,args.output,args.end)
