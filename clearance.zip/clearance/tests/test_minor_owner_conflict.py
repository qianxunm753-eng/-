"""A majority parent cannot consume a real minority owner's current returns."""
import unittest
from dataclasses import replace
import numpy as np
from rsview_centerline.clearance.scene import SurfaceTracker,extract_scene
from rsview_centerline.clearance.objects import refine_objects
from rsview_centerline.clearance.measure import measure_candidates
from rsview_centerline.clearance.rsview_cache import build_packet
from rsview_centerline.clearance.protocol import TrackUpdate
from rsview_centerline.clearance.tests.fixtures import cloud,line_track
from rsview_centerline.clearance.tests.test_current_instance_reconciliation import configuration
from rsview_centerline.clearance.tests.test_surface_tracking import pose
from rsview_centerline.clearance.tests.test_instance_ownership import parts


class MinorityOwnerTests(unittest.TestCase):
    def test_dense_conflict_cannot_contribute_a_false_exclusive_reconciliation_witness(self):
        cfg=configuration()
        points=np.array([[2.,y,z] for y in np.arange(.3,2.3,.02) for z in np.arange(.3,2.3,.02)])
        distance=np.linalg.norm(points-points[12*100+12],axis=1)
        majority=points[distance>.2];minority=points[distance<=.025]
        corner=np.array([[x,2.38,z] for x in (2.04,2.08,2.12,2.16) for z in np.arange(.3,2.3,.02)])
        first=cloud(np.concatenate((majority,minority,corner)))
        n=len(majority);m=n+len(minority)
        seeded=parts(first,[np.arange(n),np.arange(n,m),np.arange(m,len(first.xyz_L))])
        tracker=SurfaceTracker(cfg)
        model=line_track(end=(0.,3.,0.))
        tracker.update(first,seeded,pose(first),model)
        for i in (1,2):
            frame=cloud(np.concatenate((points,corner)),sequence=i,time=1.+i*.1)
            track=TrackUpdate('observed_dual',replace(model,ref_time_s=frame.ref_time_s))
            history=replace(first,ref_time_s=frame.ref_time_s,motion_status='compensated_history',diagnostics={
                'aligned_to_ref_time_s':frame.ref_time_s,
                'object_proposal_labels':np.r_[np.zeros(n,dtype=int),np.ones(m-n,dtype=int),
                    np.full(len(corner),2,dtype=int)]})
            layers=refine_objects(frame,track,extract_scene(frame,track,[],cfg),cfg,[history])
            self.assertEqual(len(layers.candidates),2)
            self.assertTrue(layers.diagnostics['current_ownership_links'])
            tracker.update(frame,layers,pose(frame),track.model)
            self.assertEqual(tracker.current_link_witnesses,{},
                'sampled reconciliation bypassed the full current competing-owner check')
            self.assertEqual(len(tracker.display_regions),3)

    def test_current_owner_warning_cannot_coalesce_into_an_identified_surface(self):
        cfg=configuration()
        lower_a=[[2.,y,z] for y in np.arange(.5,.701,.02) for z in np.arange(.3,.501,.02)]
        lower_b=[[2.,y,z] for y in (.84,.86,.88,.9) for z in np.arange(.3,.501,.02)]
        for x in (2.02,1.98):
            with self.subTest(upper_x=x):
                upper=[[x,y,z] for y in np.arange(.5,.901,.02) for z in np.arange(.9,1.101,.02)]
                tracker=SurfaceTracker(cfg)
                first=cloud(lower_a+lower_b+upper)
                track=TrackUpdate('observed_dual',line_track())
                tracker.update(first,extract_scene(first,track,[],cfg),pose(first),track.model)
                bridge=[[2.,y,z] for y in np.arange(.72,.821,.02) for z in np.arange(.3,.501,.02)]
                frame=cloud(lower_a+lower_b+upper+bridge,sequence=1,time=1.1)
                track=TrackUpdate('observed_dual',line_track(time=1.1))
                layers=tracker.update(frame,extract_scene(frame,track,[],cfg),pose(frame),track.model)
                packet=build_packet(frame,track,layers,measure_candidates(frame,track,layers,cfg),cfg)
                warnings=[m for m in packet['measurements'] if 'ambiguous_object_ownership' in m['flags']]
                self.assertEqual(len(warnings),1,'current warning was hidden behind another surface annotation')
                self.assertIsNone(warnings[0]['object_id'])
                self.assertIsNone(warnings[0]['display_id'],'annotation coalescing restored a historical identity')
                self.assertTrue(warnings[0]['uncertain'])
                self.assertAlmostEqual(warnings[0]['distance_m'],2.)

    def test_continuously_visible_connected_face_keeps_current_warning_distance_without_false_identity(self):
        cfg=configuration()
        a=[[2.,y,z] for y in np.arange(.3,.701,.02) for z in np.arange(.3,.501,.02)]
        b=[[2.,y,z] for y in (1.,1.02,1.04) for z in np.arange(.3,.501,.02)]
        bridge=[[2.,y,z] for y in np.arange(.72,1.,.02) for z in np.arange(.3,.501,.02)]
        tracker=SurfaceTracker(cfg)
        first=cloud(a+b)
        track=TrackUpdate('observed_dual',line_track())
        tracker.update(first,extract_scene(first,track,[],cfg),pose(first),track.model)
        for i in range(1,16):
            frame=cloud(a+b+bridge,sequence=i,time=1.+i*.1)
            track=TrackUpdate('observed_dual',line_track(time=frame.ref_time_s))
            current=tracker.update(frame,extract_scene(frame,track,[],cfg),pose(frame),track.model)
            measured=measure_candidates(frame,track,current,cfg)
            packet=build_packet(frame,track,current,measured,cfg)
            self.assertEqual(len(packet['measurements']),1,
                'continuous supported current geometry lost its numeric warning during an identity conflict')
            item=packet['measurements'][0]
            self.assertTrue(item['uncertain'])
            self.assertIsNone(item.get('object_id'))
            self.assertIsNone(item.get('display_id'))
            self.assertIn('ambiguous_object_ownership',item['flags'])
            self.assertIn('object_identity_pending',item['flags'])
            self.assertAlmostEqual(item['distance_m'],2.)
            self.assertEqual(item['source_frame'],i)
            self.assertEqual(item['source_time_s'],frame.ref_time_s)
            self.assertEqual(len(tracker.display_regions),2)

    def test_dense_current_core_cannot_hide_a_minority_owner_in_display_sampling(self):
        cfg=configuration()
        points=np.array([[2.,y,z] for y in np.arange(.3,2.3,.02) for z in np.arange(.3,2.3,.02)])
        center=points[12*100+12]
        distances=np.linalg.norm(points-center,axis=1)
        first=cloud(np.concatenate((points[distances>.2],points[distances<=.025])))
        track=TrackUpdate('observed_dual',line_track())
        tracker=SurfaceTracker(cfg)
        layers=refine_objects(first,track,extract_scene(first,track,[],cfg),cfg)
        self.assertEqual(len(layers.candidates),2)
        seeded=tracker.update(first,layers,pose(first),track.model)
        old_ids={c.diagnostics['object_id'] for c in seeded.candidates}
        minority_id=seeded.candidates[1].diagnostics['object_id']
        frame=cloud(points,sequence=1,time=1.1)
        current_track=TrackUpdate('observed_dual',line_track(time=1.1))
        layers=refine_objects(frame,current_track,extract_scene(frame,current_track,[],cfg),cfg)
        self.assertEqual(len(layers.candidates),1)
        result=tracker.update(frame,layers,pose(frame),current_track.model)
        self.assertEqual(result.candidates[0].diagnostics['object_association'],'ambiguous',
            'representative budget hid actual minority qualified core returns')
        self.assertEqual(set(tracker.display_regions),old_ids)
        self.assertEqual(tracker.display_regions[minority_id]['last_seen'],1.1,
            'actual minority support was found but not refreshed from the full current core')
        self.assertLessEqual(max(len(r['points']) for r in tracker.display_regions.values()),1024)

    def test_minority_bridge_does_not_refresh_unseen_parent_points_at_a_larger_radius(self):
        tracker=SurfaceTracker(configuration())
        def description(ys,radius):
            points=np.array([[2.,y,.5] for y in ys])
            return dict(points=points,lower=points.min(0),upper=points.max(0),
                        radius=radius,last_seen=1.,can_seed=True)
        a=description(np.arange(.1,.501,.02),.05)
        b=description([1.,1.1],.2)
        initial=tracker._associate_display([a,b],1.)
        minority_id=initial[1]['display_id']
        mixed=description(list(np.arange(.1,.501,.02))+[1.],.05)
        result=tracker._associate_display([mixed],1.1)
        self.assertEqual(result[0]['display_event'],'ambiguous')
        stored=tracker.display_regions[minority_id]
        unseen=np.flatnonzero(np.isclose(stored['points'][:,1],1.1))
        self.assertEqual(len(unseen),1)
        self.assertEqual(stored['point_times'][unseen[0]],1.,
            'a larger historical radius refreshed a return that did not support current ownership')

    def test_native_bridge_with_minority_owner_does_not_inherit_majority_identity_or_pollute_map(self):
        cfg=configuration()
        a=[[2.,y,.5] for y in np.arange(.3,.701,.02)]
        b=[[1.98,y,.5] for y in (1.,1.02,1.04)]
        first=cloud(a+b)
        first_track=TrackUpdate('observed_dual',line_track())
        tracker=SurfaceTracker(cfg)
        initial=tracker.update(first,extract_scene(first,first_track,[],cfg),pose(first),first_track.model)
        self.assertEqual(len(initial.candidates),2)
        old_ids={c.diagnostics['object_id'] for c in initial.candidates}
        self.assertEqual(len(old_ids),2)
        snapshots={key:value['points'].copy() for key,value in tracker.display_regions.items()}
        wire=[[2.,y,.5] for y in np.arange(.72,1.,.02)]
        frame=cloud(a+b+wire,sequence=1,time=1.1)
        track=TrackUpdate('observed_dual',line_track(time=1.1))
        layers=extract_scene(frame,track,[],cfg)
        self.assertEqual(len(layers.candidates),1,'fixture did not make a native connected bridge')
        result=tracker.update(frame,layers,pose(frame),track.model)
        self.assertEqual(result.candidates[0].diagnostics['object_association'],'ambiguous',
            'real minority region was ignored by the majority match fraction')
        self.assertNotIn(result.candidates[0].diagnostics['object_id'],old_ids)
        self.assertEqual(set(tracker.display_regions),old_ids)
        for key,points in snapshots.items():
            np.testing.assert_array_equal(tracker.display_regions[key]['points'],points,
                'a mixed bridge contaminated the old local object map')
        measured=measure_candidates(frame,track,result,cfg)
        self.assertAlmostEqual(measured[0].observed_min_distance_m,1.98)
        self.assertEqual(measured[0].observed_evidence.point_ref.frame,1)
        packet=build_packet(frame,track,result,measured,cfg)
        self.assertEqual(len(packet['measurements']),1)
        self.assertTrue(packet['measurements'][0]['uncertain'])
        self.assertIsNone(packet['measurements'][0]['object_id'])
        self.assertIsNone(packet['measurements'][0]['display_id'])
        self.assertIn('ambiguous_object_ownership',packet['measurements'][0]['flags'])
        self.assertEqual(packet['secondary_measurements'][0]['reason'],'ambiguous_object_ownership')
        self.assertAlmostEqual(packet['secondary_measurements'][0]['observed_min_distance_m'],1.98)
        np.testing.assert_array_equal(result.candidates[0].point_indices,np.arange(len(frame.xyz_L)))


if __name__=='__main__':
    unittest.main()
