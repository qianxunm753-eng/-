"""Catches boundary loss, stale geometry and evidence/label disagreement."""
from dataclasses import replace
import json
import unittest
import numpy as np
from rsview_centerline.clearance.protocol import Candidate, SceneLayers, TrackUpdate, ClearanceConfig, result_to_dict
from rsview_centerline.clearance.tests.fixtures import cloud, line_track


class MeasureTests(unittest.TestCase):
    def test_ground_ambiguous_raw_boundary_not_used_as_supported_object_boundary(self):
        frame = cloud([[1.2, 1., .01], [2., 1., .5], [2.01, 1.01, .5]])
        candidate = Candidate('box', np.array([0, 1, 2]), np.array([0, 1, 2]), 1., 1.,
                              {'ambiguous_indices': np.array([0])})
        result = self.measure(frame, TrackUpdate('observed_dual', line_track()),
                              SceneLayers({}, (candidate,), {}), self.cfg)[0]
        self.assertAlmostEqual(result.observed_min_distance_m, 1.2)
        self.assertAlmostEqual(result.supported_min_distance_m, 2.)
        self.assertEqual(result.supported_evidence.point_ref.index, 1)
        self.assertIn('nearest_ambiguous_surface', result.flags)

    def setUp(self):
        try:
            from rsview_centerline.clearance.measure import measure_candidates
        except ImportError as exc:
            self.fail('measurement feature missing: '+str(exc))
        self.measure = measure_candidates
        self.cfg = ClearanceConfig()

    def result(self, points, supported, track=None):
        frame = cloud(points)
        c = Candidate('box', np.arange(len(points)), np.asarray(supported, dtype=int), 1., 1.)
        layers = SceneLayers({}, (c,), {'object': len(points)})
        return self.measure(frame, track or TrackUpdate('observed_dual', line_track()), layers, self.cfg)[0]

    def test_isolated_near_return_not_hidden(self):
        r = self.result([[1.2, 1, 1], [2, 1, 1], [2.01, 1.01, 1]], [1, 2])
        self.assertAlmostEqual(r.observed_min_distance_m, 1.2)
        self.assertAlmostEqual(r.supported_min_distance_m, 2.)
        self.assertEqual(r.observed_evidence.point_ref.index, 0)
        self.assertIn('nearest_return_without_support', r.flags)

    def test_real_protrusion_is_not_averaged(self):
        r = self.result([[2, 1, 1], [1.8, 1, 1], [1.81, 1.01, 1]], [0, 1, 2])
        self.assertAlmostEqual(r.supported_min_distance_m, 1.8)
        self.assertEqual(r.supported_evidence.point_ref.index, 1)

    def test_no_support_produces_null_not_zero(self):
        r = self.result([[1.8, 1, 1]], [])
        self.assertIsNone(r.supported_min_distance_m)
        self.assertIsNone(r.supported_evidence)
        self.assertIsNone(json.loads(json.dumps(result_to_dict(r), allow_nan=False))['supported_min_distance_m'])

    def test_partial_and_outside_track_support(self):
        r = self.result([[2, 1, 1], [1.8, 3, 1]], [0, 1])
        self.assertAlmostEqual(r.observed_min_distance_m, 2.)
        self.assertIn('partial_track_support', r.flags)
        outside = self.result([[1.8, 3, 1]], [0])
        self.assertIsNone(outside.observed_min_distance_m)
        self.assertIn('outside_track_support', outside.flags)

    def test_held_model_cannot_measure_current_cloud(self):
        r = self.result([[2, 1, 1]], [0], TrackUpdate('held_snapshot', held_model=line_track()))
        self.assertIsNone(r.observed_min_distance_m)
        self.assertIn('held_snapshot', r.flags)

    def test_initializing_or_ambiguous_update_cannot_relabel_old_model_as_fresh(self):
        for mode in ('initializing','ambiguous_track'):
            r=self.result([[2,1,1]],[0],TrackUpdate(mode,model=line_track()))
            self.assertIsNone(r.observed_min_distance_m)

    def test_line_and_label_come_from_one_result(self):
        r = self.result([[1.8, 1, 4]], [0])
        e = r.observed_evidence
        self.assertAlmostEqual(np.linalg.norm(e.projected_L-e.foot_L), 1.8)
        self.assertAlmostEqual(r.observed_min_distance_m, 1.8)
        np.testing.assert_allclose(e.point_L, [1.8, 1, 4])

    def test_voxel_display_cannot_change_minimum(self):
        a = self.result([[1.8, 1, 1], [2, 1, 1]], [0, 1])
        self.cfg = replace(self.cfg, display_voxel_m=.5)
        b = self.result([[1.8, 1, 1], [2, 1, 1]], [0, 1])
        self.assertEqual(a.observed_min_distance_m, b.observed_min_distance_m)

    def test_foreign_clock_and_future_track_rejected(self):
        for model in (replace(line_track(), clock_id='receive-time'), replace(line_track(), ref_time_s=1.1)):
            with self.assertRaises(ValueError):
                self.result([[2, 1, 1]], [0], TrackUpdate('observed_dual', model))

    def test_supported_set_must_belong_to_candidate(self):
        with self.assertRaises(ValueError):
            self.result([[2, 1, 1]], [12])

    def test_multiple_candidates_keep_their_own_minimum_and_ref(self):
        f = cloud([[3,1,1],[2.8,1,1],[-2,1,1],[-1.9,1,1]])
        candidates = (Candidate('a',np.array([0,1]),np.array([0,1]),1.,1.),
                      Candidate('b',np.array([2,3]),np.array([2,3]),1.,1.))
        r = self.measure(f,TrackUpdate('observed_dual',line_track()),
                         SceneLayers({},candidates,{}),self.cfg)
        self.assertEqual([x.observed_evidence.point_ref.index for x in r],[1,3])
        np.testing.assert_allclose([x.observed_min_distance_m for x in r],[2.8,1.9])


if __name__ == '__main__':
    unittest.main()
