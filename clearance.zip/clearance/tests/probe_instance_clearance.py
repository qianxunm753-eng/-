# -*- coding: utf-8 -*-
"""Owned native 333 replay around user-reported frames; no raw cloud export."""
import json
import math
import os
import shutil
import tempfile
import time
import traceback
import hashlib
from PythonQt import QtCore, QtGui
import rsview.applogic as logic

report_path = os.environ['RSVIEW_INSTANCE_REPORT'].decode('mbcs')
state = dict(error=None, snapshots=[], checks={}, physical_truth_available=False,
    requested_targets=[52,129], stage='starting')
frames = list(range(44,53))+list(range(121,130))
if os.environ.get('RSVIEW_INSTANCE_FRAMES'):
    frames=[int(x) for x in json.loads(os.environ['RSVIEW_INSTANCE_FRAMES'])]
    state['requested_targets']=[frames[len(frames)//2-1],frames[-1]]
source = os.environ.get('RSVIEW_INSTANCE_SOURCE',os.path.join(os.environ['USERPROFILE'],'Desktop','333.pcap'))
if isinstance(source, str):
    source=source.decode('mbcs')
state['source']=source
folder = tempfile.mkdtemp(prefix='rsview-instance-probe-')
factories = {}
timer = overlay = None
started = time.time()
position = 0
playback_step=int(os.environ.get('RSVIEW_INSTANCE_PLAYBACK_STEP','0'))
if playback_step not in (0,2,3):
    raise ValueError('owned probe supports only SDK forward fast modes 2/3')


def camera(packet):
    if not packet['centerline'] or not packet['measurements']:
        return
    def unit(values):
        size=math.sqrt(sum(v*v for v in values))
        return [v/size for v in values]
    a,b=packet['centerline'][0]
    tangent=unit([v-u for u,v in zip(a,b)])
    m=packet['measurements'][0]
    across=unit([v-u for u,v in zip(m['foot_L'],m['projected_L'])])
    normal=unit([tangent[1]*across[2]-tangent[2]*across[1],
        tangent[2]*across[0]-tangent[0]*across[2],tangent[0]*across[1]-tangent[1]*across[0]])
    if normal[0]>0:
        normal=[-v for v in normal]
    points=[p for pair in packet['centerline'] for p in pair]
    for item in packet['measurements']:
        points.extend((item['point_L'],item['foot_L']))
    focal=[(min(p[i] for p in points)+max(p[i] for p in points))*.5 for i in range(3)]
    native=logic.app.mainView.GetRenderer().GetActiveCamera()
    native.SetFocalPoint(*focal)
    native.SetPosition(*[c+9.*n for c,n in zip(focal,normal)])
    native.SetViewUp(*tangent)
    native.ParallelProjectionOn()
    native.SetParallelScale(4.5)
    logic.smp.Render(logic.app.mainView)


def finish():
    if timer is not None:
        timer.stop()
    # Preserve test evidence BEFORE the user-deferred native close/C5 path.
    # A hung close must not erase evidence about whether replay/expiry worked.
    with open(report_path[:-5]+'-checkpoint.json','wb') as stream:
        stream.write(json.dumps(state,indent=2).encode('utf-8'))
    try:
        if playback_step:
            # Only this owned instance was given controlled player state. No
            # SDK animation timer was started; requests were allowed to settle.
            logic.app.playing=False
        if os.environ.get('RSVIEW_INSTANCE_DIRECT_WINDOW_CLOSE')=='1':
            state['direct_window_close_with_active_source']=logic.getReader() is not None and overlay is not None
            logic.getMainWindow().close()
            state['direct_window_close_returned']=True
        else:
            logic.close()
    except Exception:
        state['cleanup_error']=traceback.format_exc().decode('mbcs','replace')
    for name, factory in factories.items():
        setattr(logic,name,factory)
    for name in ('input_path.log','tmp.log','input.log'):
        path=os.path.join(folder,name)
        if os.path.isfile(path):
            os.remove(path)
    os.rmdir(folder)
    with open(report_path,'wb') as stream:
        stream.write(json.dumps(state,indent=2).encode('utf-8'))
    if os.environ.get('RSVIEW_INSTANCE_DIRECT_WINDOW_CLOSE')!='1':
        QtGui.QApplication.instance().quit()


def select():
    frame=frames[position]
    if playback_step:
        logic.app.playing=True
        logic.app.seekPlay=False
        logic.app.playDirection=playback_step
    logic.app.scene.AnimationTime=float(frame)
    logic.onTimeChanged()
    state['waiting']=frame


def tick():
    global position
    try:
        if time.time()-started>100.:
            raise AssertionError('target replay timeout at '+str(state.get('waiting')))
        packet=overlay.poll()
        if packet and packet.get('status')=='failed':
            raise AssertionError(packet.get('error'))
        if position==len(frames):
            if not packet or packet['stop_window']['state']!='time_budget_exceeded':return
            if packet['stop_window']['scan_count']!=state['idle_initial_scans']:
                raise AssertionError('pause invented additional accepted scans')
            if packet['stop_window']['confirmed']:
                raise AssertionError('expired paused window is still confirmed')
            state['idle_expiry_check']=dict(stop_window=packet['stop_window'],
                status=unicode(logic.app.statusLabel.text),source_sequence=packet['sequence'])
            state['stage']='completed'
            finish()
            return
        if not packet or not packet.get('current_source') or packet['sequence']!=frames[position]:
            return
        state['checks']['current_native_identity']=packet['sequence']==int(logic.getTimeKeeper().getTime())
        row=dict(sequence=packet['sequence'],epoch=packet['epoch'],mode=packet['mode'],
            motion_status=packet['motion_status'],measurements=packet['measurements'],
            secondary_measurements=packet['secondary_measurements'],
            scene_diagnostics=packet['scene_diagnostics'],timing_ms=packet['timing_ms'],
            relative_pose_diagnostics=packet['relative_pose_diagnostics'],status=unicode(logic.app.statusLabel.text))
        row.update(motion_translation_model=packet.get('motion_translation_model'),
            motion_curve_check_error_m=packet.get('motion_curve_check_error_m'))
        row.update(current_source=packet.get('current_source'),session=overlay.session,
            gate_discontinuous=overlay.playback_gate.discontinuous,
            controlled_playback_step=playback_step,device_span=overlay.playback_gate.span)
        if packet.get('stop_window') is not None:
            row.update(stop_window=dict(packet['stop_window']),measurement_basis=packet.get('measurement_basis'),
                current_scan_measurement=packet.get('current_scan_measurement'),retained_points=packet.get('retained_points'))
        if packet.get('fusion') is not None:
            row.update(fusion=dict(packet['fusion']),measurement_basis=packet.get('measurement_basis'),
                clouds=dict((name,entry['count']) for name,entry in packet['clouds'].items()))
        state['snapshots'].append(row)
        if packet['sequence'] in state['requested_targets']:
            if packet.get('fusion'):
                overlay.renderer.ResetCamera()
                logic.smp.Render(logic.app.mainView)
            else:camera(packet)
            image_path=os.path.join(folder,'snapshot.png')
            logic.smp.WriteImage(image_path,logic.app.mainView)
            shutil.move(image_path,report_path[:-5]+'-frame'+str(packet['sequence'])+'.png')
            if packet.get('fusion'):
                native_camera=overlay.renderer.GetActiveCamera()
                before=(tuple(native_camera.GetPosition()),tuple(native_camera.GetFocalPoint()))
                controller.single_view(True)
                logic.smp.WriteImage(image_path,logic.app.mainView)
                shutil.move(image_path,report_path[:-5]+'-single-frame'+str(packet['sequence'])+'.png')
                after=(tuple(native_camera.GetPosition()),tuple(native_camera.GetFocalPoint()))
                state['checks']['image_switch_preserves_camera']=before==after
                controller.single_view(False)
                if os.environ.get('RSVIEW_INSTANCE_DISPLAY_CHECK')=='1':
                    display_checks(packet,native_camera,image_path,before)
                if os.environ.get('RSVIEW_INSTANCE_IMAGE_FUSION')=='1' and packet.get('fusion',{}).get('clean_preview_available'):
                    original_frames=list(packet['fusion']['source_frames'])
                    raw_count=packet['_image_pairs']['fused']['object']['count']
                    controller.clean_view(True)
                    logic.smp.WriteImage(image_path,logic.app.mainView)
                    shutil.move(image_path,report_path[:-5]+'-clean-frame'+str(packet['sequence'])+'.png')
                    clean_count=overlay.last_result['clouds']['object']['count']
                    after=(tuple(native_camera.GetPosition()),tuple(native_camera.GetFocalPoint()))
                    if before!=after:raise AssertionError('clean display changed paired camera')
                    state['checks']['clean_switch_preserves_camera']=True
                    state['checks']['clean_preview_is_subset']=clean_count<=raw_count
                    controller.single_view(True)
                    if overlay.last_result['clouds'] is not overlay.last_result['_image_pairs']['clean_single']:
                        raise AssertionError('clean/single switch did not select the paired single')
                    controller.single_view(False);controller.clean_view(False)
                    if overlay.last_result['clouds']['object']['count']!=raw_count:
                        raise AssertionError('disabling clean preview failed to restore original cloud')
                    if packet['fusion']['source_frames']!=original_frames:
                        raise AssertionError('display toggle changed accepted scan identities')
                    state['checks']['clean_switch_restores_raw_pair']=True
        position+=1
        if position==len(frames):
            if os.environ.get('RSVIEW_INSTANCE_STOP_IDLE_CHECK')=='1':
                state['idle_initial_scans']=packet['stop_window']['scan_count']
                state['stage']='waiting_real_pause_expiry'
                return
            state['stage']='completed'
            finish()
        else:
            select()
    except Exception:
        state['error']=traceback.format_exc().decode('mbcs','replace')
        finish()


def display_checks(packet,native_camera,image_path,before):
    pair=packet['_image_pairs'];original=hashlib.sha256(pair['fused']['object']['data']).hexdigest()
    appearance=overlay.image_appearance
    def capture(suffix):
        logic.smp.WriteImage(image_path,logic.app.mainView)
        shutil.move(image_path,report_path[:-5]+suffix+'-frame'+str(packet['sequence'])+'.png')
    def coordinates_match():
        from clearance_native import _packed
        appearance.calculator.Update()
        output=appearance.calculator.GetOutput()
        if output.GetNumberOfPoints()!=packet['clouds']['object']['count']:
            raise AssertionError('view depth altered point count')
        packed=_packed(output.GetPoints().GetData(),3,output.GetNumberOfPoints())
        if packed['data']!=packet['clouds']['object']['data']:
            raise AssertionError('view depth changed actual coordinates')
    overlay.set_image_display_settings(False,2.,None);capture('-mono')
    overlay.set_image_display_settings(True,2.,None);coordinates_match();capture('-depth')
    range_fused=appearance.snapshot()['depth_range']
    controller.single_view(True)
    if appearance.snapshot()['depth_range']!=range_fused:raise AssertionError('single/fused use different color ranges')
    capture('-single-depth');controller.single_view(False)
    native_camera.Azimuth(90.);logic.smp.Render(logic.app.mainView);coordinates_match();capture('-depth-side')
    side=appearance.snapshot()
    native_camera.SetPosition(*before[0]);native_camera.SetFocalPoint(*before[1])
    bounds=appearance.bounds
    roi=tuple((bounds[i]+bounds[i+1])*.5+(-.75 if j==0 else .75)*(bounds[i+1]-bounds[i])*.5
        for i in (0,2,4) for j in (0,1))
    overlay.set_image_display_settings(True,1.,roi);coordinates_match();capture('-depth-roi')
    if overlay.cloud_actors['object'][1].GetMapper().GetNumberOfClippingPlanes()!=6:
        raise AssertionError('display ROI lacks six render-only planes')
    overlay.set_image_display_settings(True,2.,None)
    if overlay.cloud_actors['object'][1].GetMapper().GetNumberOfClippingPlanes()!=0:
        raise AssertionError('display ROI was not removed')
    if hashlib.sha256(pair['fused']['object']['data']).hexdigest()!=original:
        raise AssertionError('appearance mutated the paired XYZ buffer')
    state['checks']['depth_color_shared_pair_range']=True
    state['checks']['depth_rotation_keeps_coordinates']=True
    state['checks']['display_roi_restores_geometry']=True
    state['display_snapshot']=dict(front_depth_range=range_fused,side=side,
        final=appearance.snapshot(),raw_buffer_sha256=original)
    # Exercise the actual dialog in this owned process. Rejecting it must not
    # change any settings; a timer closes only this explicitly named dialog.
    dialog_timer=QtCore.QTimer();dialog_timer.setSingleShot(True)
    def reject_dialog():
        dialog=logic.getMainWindow().findChild('QDialog','imageDisplayOptionsDialog')
        if dialog is None:raise AssertionError('display settings dialog not present')
        state['checks']['display_settings_dialog_opened']=True;dialog.reject()
    dialog_timer.connect('timeout()',reject_dialog);dialog_timer.start(200)
    timer.stop()
    try:controller.display_options()
    finally:
        dialog_timer.stop();dialog_timer.disconnect('timeout()',reject_dialog);timer.start(100)


def start():
    global factories,timer,overlay,controller
    try:
        from clearance_native import patch_recording_decoder,prepare_pcap_reader
        if os.environ.get('RSVIEW_MOTION_BASELINE')=='1':
            import clearance_native
            baseline=clearance_native.live_measurement_config()
            baseline.update(adaptive_motion_compensation=False,config_id='rsview-current-instance-beta-v18')
            clearance_native.live_measurement_config=lambda:dict(baseline)
        if os.environ.get('RSVIEW_INSTANCE_BASELINE')=='1':
            import clearance_native
            baseline=clearance_native.live_measurement_config()
            baseline.update(current_instance_reconciliation=False,config_id='rsview-qualified-instance-beta-v17')
            clearance_native.live_measurement_config=lambda:dict(baseline)
        factories=patch_recording_decoder(logic)
        logic.chooseCalibrationFile=lambda unused:True
        logic.networkConfigPcap=lambda unused:True
        pointer=os.path.join(folder,'input_path.log')
        with open(pointer,'wb') as stream:
            stream.write(source.encode('mbcs'))
        logic.openPCAP(pointer)
        logic.stop()
        prepare_pcap_reader(logic.getReader())
        logic.app.scene.UpdateAnimationUsingDataTimeSteps()
        logic.updateSliderTimeRange()
        select()
        selected_controller=(logic.app.imageFusionController if os.environ.get('RSVIEW_INSTANCE_IMAGE_FUSION')=='1' else
            logic.app.stopClearanceController if os.environ.get('RSVIEW_INSTANCE_STOP_WINDOW')=='1' else logic.app.clearanceController)
        controller=selected_controller
        selected_controller.action.trigger()
        overlay=selected_controller.overlay
        if overlay is None:
            raise AssertionError('native clearance menu did not enable: '+unicode(logic.app.statusLabel.text))
        state['config']=dict(overlay.worker_config)
        if os.environ.get('RSVIEW_INSTANCE_STOP_WINDOW')=='1':
            if not overlay.worker_config.get('stop_window_fusion'):
                raise AssertionError('parking action created wrong current-scan worker')
            state['native_scope_dialog']=logic.vvCropDistReturnsDialog(logic.getMainWindow()).GetCropDistReturns()
            state['normal_controller_inactive']=logic.app.clearanceController.overlay is None
        state['stage']='running'
        timer=QtCore.QTimer()
        timer.connect('timeout()',tick)
        timer.start(100)
    except Exception:
        state['error']=traceback.format_exc().decode('mbcs','replace')
        finish()


start_timer=QtCore.QTimer()
start_timer.setSingleShot(True)
start_timer.connect('timeout()',start)
start_timer.start(1000)
