"""Past raw observations are not automatically qualified object evidence."""
from dataclasses import dataclass, replace
import os
import unittest
from unittest.mock import patch
import numpy as np
from rsview_centerline import clearance_native
from rsview_centerline.clearance.protocol import ClearanceConfig, PoseSample, TrackUpdate
from rsview_centerline.clearance.replay import ReplayEngine
from rsview_centerline.clearance.motion import deskew_frame, transform_history
from rsview_centerline.clearance.objects import _historical_owners
from rsview_centerline.clearance.scene import SurfaceTracker
from rsview_centerline.clearance.tests.test_instance_ownership import parts
from rsview_centerline.clearance.tests.fixtures import cloud, line_track


@dataclass(frozen=True)
class HistoryConfig(ClearanceConfig):
    qualified_history_reconciliation: bool = True


def configuration(enabled=True):
    return HistoryConfig(qualified_history_reconciliation=enabled,
        temporal_object_proposals=True,qualified_object_cores=True,
        qualified_instance_ownership=True,current_instance_reconciliation=True,
        spatial_object_ownership=True,surface_object_proposals=True,
        display_balance_sides=True,geometry_label_priority=True,
        display_identity_seconds=1.2,above_rail_measurement_only=True)


class AnalyticPoses:
    def sample(self,time,available_until_s):
        return PoseSample(time,np.eye(4),'device:test',(0.,10.),available_until_s,'analytic_test',True)


def engine(cfg=None):
    return ReplayEngine(cfg or configuration(),'tracked',AnalyticPoses(),
        observer=lambda f:TrackUpdate('observed_dual',line_track(end=(0.,3.,0.),time=f.ref_time_s)))


def face():
    return [[2.,y,z] for y in np.arange(.3,.701,.02) for z in np.arange(.3,.501,.02)]


class HistoryEvidenceTests(unittest.TestCase):
    def records(self,worker):
        return worker.object_history[-1].diagnostics.get('object_proposal_evidence',[])

    def test_one_observation_is_tentative_not_a_qualified_history_donor(self):
        worker = engine()
        worker.step(cloud(face()))
        records = self.records(worker)
        self.assertEqual(len(records),1,'history lost the qualification/provenance record')
        self.assertEqual(records[0]['state'],'tentative')
        self.assertEqual(records[0]['source_frame'],0)
        self.assertEqual(records[0]['source_time_s'],1.)

    def test_second_independent_current_observation_qualifies_its_own_geometry(self):
        worker = engine()
        worker.step(cloud(face()))
        worker.step(cloud(face(),sequence=1,time=1.1))
        records = self.records(worker)
        self.assertEqual(len(records),1,'qualified history evidence was not recorded')
        self.assertEqual(records[0]['state'],'qualified')
        self.assertEqual(records[0]['geometry_frame'],1)
        self.assertEqual(records[0]['proof_time_s'],1.1)
        self.assertAlmostEqual(records[0]['valid_until_s'],1.7)
        self.assertEqual(records[0]['object_id'],'T1')

    def test_connected_bridge_remains_measurable_but_cannot_donate_identity_proof(self):
        a = face()
        b = [[2.,y,z] for y in (1.,1.02,1.04) for z in np.arange(.3,.501,.02)]
        bridge = [[2.,y,z] for y in np.arange(.72,1.,.02) for z in np.arange(.3,.501,.02)]
        worker = engine()
        worker.step(cloud(a+b))
        track,layers,results = worker.step(cloud(a+b+bridge,sequence=1,time=1.1))
        self.assertEqual(len(layers.candidates),1,'fixture must create a real native bridge')
        self.assertEqual(layers.candidates[0].diagnostics['object_association'],'ambiguous')
        records = self.records(worker)
        self.assertEqual(len(records),1,'conflicted raw geometry must retain its explicit status')
        self.assertEqual(records[0]['state'],'conflicted')
        self.assertAlmostEqual(results[0].observed_min_distance_m,2.)
        self.assertEqual(results[0].observed_evidence.point_ref.frame,1)

    def test_disabled_path_preserves_legacy_history_metadata(self):
        worker = engine(configuration(False))
        worker.step(cloud(face()))
        self.assertNotIn('object_proposal_evidence',worker.object_history[-1].diagnostics)
        self.assertTrue((worker.object_history[-1].diagnostics['object_proposal_labels']>=0).all())

    def test_native_explicit_v23_only_enables_qualified_history_rule(self):
        with patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':'v23'}):
            cfg = clearance_native.recorded_measurement_config()
            self.assertTrue(cfg.get('qualified_history_reconciliation',False))
            self.assertFalse(cfg.get('body_fragment_proposals',False))
        with patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':'1'}):
            self.assertFalse(clearance_native.recorded_measurement_config().get('qualified_history_reconciliation',False))

    def test_live_rejects_the_history_experiment_even_without_other_replay_flags(self):
        from rsview_centerline.clearance.online import OnlineEngine
        with self.assertRaisesRegex(ValueError,'replay-only'):
            OnlineEngine(HistoryConfig(),source_mode='live')

    def history_fixture(self,conflicted=False):
        worker = engine()
        a = face()
        b = [[2.,y,z] for y in (1.,1.02,1.04) for z in np.arange(.3,.501,.02)] if conflicted else []
        worker.step(cloud(a+b))
        bridge = [[2.,y,z] for y in np.arange(.72,1.,.02) for z in np.arange(.3,.501,.02)] if conflicted else []
        worker.step(cloud(a+b+bridge,sequence=1,time=1.1))
        current = deskew_frame(cloud(a+b,sequence=2,time=1.2),AnalyticPoses())
        groups = ([np.arange(len(a)),np.arange(len(a),len(a)+len(b))] if conflicted else
                  [np.flatnonzero(current.xyz_L[:,1]<.41),np.flatnonzero(current.xyz_L[:,1]>.59)])
        candidates = parts(current,groups).candidates
        aligned = transform_history(worker.object_history,current,AnalyticPoses(),configuration(),include_current=False)
        return current,candidates,aligned

    def test_compensation_preserves_record_source_and_status_without_copying_current_evidence(self):
        unused,unused,aligned = self.history_fixture()
        records = aligned.diagnostics.get('object_proposal_evidence',[])
        self.assertEqual([r['source_frame'] for r in records],[0,1])
        self.assertEqual([r['state'] for r in records],['tentative','qualified'])
        self.assertTrue(all(ref.frame<2 for ref in aligned.refs))

    def test_conflicted_native_history_cannot_propose_one_owner_for_two_current_parts(self):
        current,candidates,aligned = self.history_fixture(True)
        owners,unused = _historical_owners(current,candidates,[aligned],configuration())
        self.assertEqual(owners,[None,None],'unresolved bridge became a historical identity witness')
        legacy,unused = _historical_owners(current,candidates,[aligned],configuration(False))
        self.assertTrue(all(parent is not None for parent in legacy))

    def test_qualified_raw_history_still_proposes_the_same_real_owner(self):
        current,candidates,aligned = self.history_fixture()
        owners,unused = _historical_owners(current,candidates,[aligned],configuration())
        self.assertTrue(all(parent is not None for parent in owners))
        self.assertEqual(owners[0],owners[1])
        self.assertEqual(owners[0][:2],(1,0))

    def test_missing_evidence_metadata_is_not_treated_as_qualified(self):
        current,candidates,aligned = self.history_fixture()
        diagnostic = dict(aligned.diagnostics)
        diagnostic.pop('object_proposal_evidence',None)
        owners,unused = _historical_owners(current,candidates,[replace(aligned,diagnostics=diagnostic)],configuration())
        self.assertEqual(owners,[None,None])

    def test_expired_or_future_or_inherited_records_cannot_renew_qualification(self):
        current,candidates,aligned = self.history_fixture()
        for changed in ({'valid_until_s':1.19},{'geometry_frame':2},
                        {'independent_geometry':False},{'proof_time_s':1.}):
            with self.subTest(changed=changed):
                records = aligned.diagnostics.get('object_proposal_evidence',[])
                altered = [dict(r,**changed) if r['source_frame']==1 else dict(r) for r in records]
                diagnostic = dict(aligned.diagnostics,object_proposal_evidence=altered)
                owners,unused = _historical_owners(current,candidates,[replace(aligned,diagnostics=diagnostic)],configuration())
                self.assertEqual(owners,[None,None],'invalid provenance renewed an old proof')

    def test_malformed_origin_metadata_abstains_without_reinterpreting_native_points(self):
        current,candidates,aligned = self.history_fixture()
        diagnostic = dict(aligned.diagnostics,object_proposal_origin_time_s=['invalid']*len(aligned.xyz_L))
        malformed = replace(aligned,diagnostics=diagnostic)
        from rsview_centerline.clearance.history_evidence import qualified_history_instances
        try:
            instances = qualified_history_instances(current,[malformed],configuration())
            owners,unused = _historical_owners(current,candidates,[malformed],configuration())
        except (TypeError,ValueError) as error:
            self.fail('malformed ownership metadata escaped the abstention guard: %s' % error)
        self.assertEqual(instances,[])
        self.assertEqual(owners,[None,None])
        np.testing.assert_array_equal(malformed.xyz_L,aligned.xyz_L)


class HistoryReconciliationTests(unittest.TestCase):
    def test_insufficient_joint_return_support_defers_merge_before_mutating_old_ids(self):
        tracker = SurfaceTracker(configuration())
        def description(points):
            points = np.asarray(points,dtype=float)
            return dict(points=points,lower=points.min(0),upper=points.max(0),radius=.05,can_seed=True,last_seen=1.)
        points = np.array([[2.,i*.2,.5] for i in range(10)])
        tracker._associate_display([description(points[:1]),description(points[1:2])],1.)
        old_ids = set(tracker.display_regions)
        subsets = ([0,1,2,3,4,5,6],[0,1,2,3,7,8,9])
        donors = [dict(state='qualified',independent_geometry=True,source_frame=i,geometry_frame=i,
            source_time_s=1.+i*.1,object_id='observed-whole',points_W=points[rows],radius_m=.05)
            for i,rows in enumerate(subsets)]
        whole = description(points)
        current = tracker._associate_display([whole],1.2,ownership_points=[points],history_instances=donors)
        self.assertEqual(tracker.last_history_reconciliation_count,0,
                         '70 percent per scan is only 40 percent jointly supported; merge would immediately lose the owner')
        self.assertEqual(set(tracker.display_regions),old_ids)
        self.assertEqual(current[0]['display_event'],'ambiguous')

    def test_wider_alias_part_is_not_lost_by_narrow_aggregate_spatial_prefilter(self):
        tracker = SurfaceTracker(configuration())
        def description(points,radius):
            points = np.asarray(points,dtype=float)
            return dict(points=points,lower=points.min(0),upper=points.max(0),radius=radius,can_seed=True,last_seen=1.)
        a = description([[2.,y,.5] for y in (0.,.02,.04)],.065)
        b = description([[2.,y,.5] for y in (1.,1.02,1.04)],.10)
        tracker._associate_display([a,b],1.)
        whole = description([[2.,y,.5] for y in np.arange(0.,1.05,.02)],.065)
        donors = [dict(state='qualified',independent_geometry=True,source_frame=i,geometry_frame=i,
            source_time_s=1.+i*.1,object_id='observed-whole',points_W=whole['points'],radius_m=.1)
            for i in (0,1)]
        merged = tracker._associate_display([whole],1.2,ownership_points=[whole['points']],history_instances=donors)
        self.assertEqual(len(tracker.display_regions),1)
        partial = description([[2.08,y,.5] for y in (1.,1.02,1.04)],.1)
        current = tracker._associate_display([partial],1.3,ownership_points=[partial['points']])
        self.assertEqual(current[0]['display_id'],merged[0]['display_id'],
                         'narrow aggregate search skipped actual wider alias support')

    def dense_history(self):
        worker = engine()
        points = np.array([[2.,y,z] for y in np.arange(.3,2.3,.02) for z in np.arange(.3,2.3,.02)])
        for sequence in range(3):
            worker.step(cloud(points,sequence=sequence,time=1.+sequence*.1))
        # A genuine corner observed in all three full native scans is lost by
        # the bounded identity representative map. Literal points are retained
        # in the causal raw history, so they can explain the later duplicate.
        patch_points = np.array([[2.,.3,2.26],[2.,.3,2.28],[2.,.32,2.28]])
        unused,layers,unused = worker.step(cloud(patch_points,sequence=3,time=1.3))
        self.assertEqual(layers.candidates[0].diagnostics['object_id'],'T2')
        self.assertEqual(len(worker.surface_tracker.display_regions),2)
        return worker,points,patch_points

    def test_two_qualified_past_scans_explain_every_old_region_and_reconcile_real_current_face(self):
        worker,points,unused = self.dense_history()
        unused,layers,results = worker.step(cloud(points,sequence=4,time=1.4))
        self.assertEqual(len(worker.surface_tracker.display_regions),1,
                         'earlier raw whole-face observations failed to resolve the duplicate map IDs')
        self.assertEqual(layers.candidates[0].diagnostics['object_id'],'T1')
        self.assertTrue(layers.candidates[0].diagnostics['object_identity_reconciled'])
        self.assertEqual(results[0].observed_min_distance_m,2.)
        self.assertEqual(results[0].observed_evidence.point_ref.frame,4)
        self.assertEqual(len(layers.candidates[0].point_indices),len(points))

    def test_reconciled_corner_keeps_its_owner_without_lifting_the_representative_budget(self):
        worker,points,patch_points = self.dense_history()
        worker.step(cloud(points,sequence=4,time=1.4))
        unused,layers,results = worker.step(cloud(patch_points,sequence=5,time=1.5))
        self.assertEqual(layers.candidates[0].diagnostics['object_id'],'T1',
                         'bounded sampling immediately spawned the same old corner again')
        self.assertLessEqual(max(len(r['points']) for r in worker.surface_tracker.display_regions.values()),1024)
        self.assertEqual(results[0].observed_evidence.point_ref.frame,5)

    def test_one_qualified_source_cannot_be_reused_as_two_independent_scans(self):
        worker,points,unused = self.dense_history()
        worker.object_history = [f for f in worker.object_history if f.sequence in (2,3)]
        unused,layers,unused = worker.step(cloud(points,sequence=4,time=1.4))
        self.assertEqual(len(worker.surface_tracker.display_regions),2)
        self.assertEqual(layers.candidates[0].diagnostics['object_association'],'ambiguous')

    def test_expired_raw_proof_cannot_reconcile_still_reserved_display_ids(self):
        worker,points,unused = self.dense_history()
        unused,layers,unused = worker.step(cloud(points,sequence=4,time=2.))
        self.assertEqual(len(worker.surface_tracker.display_regions),2)
        self.assertEqual(layers.candidates[0].diagnostics['object_association'],'ambiguous')

    def test_repeated_unqualified_bridge_never_becomes_a_self_confirmed_instance(self):
        a = face()
        b = [[2.,y,z] for y in (1.,1.02,1.04) for z in np.arange(.3,.501,.02)]
        bridge = [[2.,y,z] for y in np.arange(.72,1.,.02) for z in np.arange(.3,.501,.02)]
        worker = engine()
        worker.step(cloud(a+b))
        for sequence in range(1,9):
            unused,layers,results = worker.step(cloud(a+b+bridge,sequence=sequence,time=1.+sequence*.1))
            self.assertEqual(len(worker.surface_tracker.display_regions),2)
            self.assertEqual(layers.candidates[0].diagnostics['object_association'],'ambiguous')
            self.assertEqual(results[0].observed_evidence.point_ref.frame,sequence)

    def test_two_body_donors_cannot_erase_a_small_unexplained_foreground_owner(self):
        worker = engine()
        points = np.array([[2.,y,z] for y in np.arange(.3,2.3,.02) for z in np.arange(.3,2.3,.02)])
        for sequence in range(3):
            worker.step(cloud(points,sequence=sequence,time=1.+sequence*.1))
        corner = [[2.,.3,2.26],[2.,.3,2.28],[2.,.32,2.28]]
        foreign = [[1.8,.3,2.26],[1.8,.3,2.28],[1.8,.32,2.28]]
        worker.step(cloud(corner+foreign,sequence=3,time=1.3))
        self.assertEqual(len(worker.surface_tracker.display_regions),3)
        bridge = [[x,.3,2.28] for x in np.arange(1.82,2.,.02)]
        unused,layers,results = worker.step(cloud(points.tolist()+foreign+bridge,sequence=4,time=1.4))
        self.assertEqual(len(layers.candidates),1,'fixture must reach the complete current native-core check')
        self.assertEqual(len(worker.surface_tracker.display_regions),3,
                         'qualified majority body scans erased an unexplained minority owner')
        self.assertEqual(layers.candidates[0].diagnostics['object_association'],'ambiguous')
        self.assertEqual(results[0].observed_min_distance_m,1.8)
        self.assertEqual(results[0].observed_evidence.point_ref.frame,4)


if __name__ == '__main__':
    unittest.main()
