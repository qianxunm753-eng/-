"""Reliable cores may propose ownership; full native minima remain unchanged."""
from dataclasses import dataclass,replace
import unittest
import numpy as np

from rsview_centerline.clearance.protocol import ClearanceConfig,Candidate,SceneLayers,TrackUpdate
from rsview_centerline.clearance.tests.fixtures import cloud,line_track
from rsview_centerline.clearance.objects import refine_objects
from rsview_centerline.clearance.measure import measure_candidates


@dataclass(frozen=True)
class CoreConfig(ClearanceConfig):
    qualified_object_cores: bool = True


class QualifiedCoreTests(unittest.TestCase):
    def corner(self,ambiguous_fraction='small'):
        a=[[2.,y,z] for y in (.3,.4,.5,.6) for z in np.arange(.2,.81,.04)]
        b=[[x,.7,z] for x in (2.04,2.08,2.12,2.16) for z in np.arange(.2,.81,.04)]
        frame=cloud(a+b)
        groups=(np.arange(len(a)),np.arange(len(a),len(a)+len(b)))
        candidates=[]
        for i,ids in enumerate(groups):
            ambiguous=ids[:1] if ambiguous_fraction=='small' else ids[:int(len(ids)*.7)]
            candidates.append(Candidate('part%d'%i,ids,ids,1.,1.,dict(
                ambiguous_indices=ambiguous,flags=('ambiguous_surface',))))
        layers=SceneLayers({'object':np.arange(len(frame.xyz_L)),
                           'ambiguous':np.concatenate([c.diagnostics['ambiguous_indices'] for c in candidates])},
                           tuple(candidates),{}, {})
        return frame,TrackUpdate('observed_dual',line_track()),layers

    def test_small_ambiguous_base_does_not_disqualify_both_observed_corner_faces(self):
        frame,track,layers=self.corner()
        result=refine_objects(frame,track,layers,CoreConfig(surface_object_proposals=True))
        self.assertEqual(len(result.candidates),1,'one uncertain point rejected the entire reliable face')
        np.testing.assert_array_equal(result.candidates[0].point_indices,np.arange(len(frame.xyz_L)))
        self.assertEqual(len(result.candidates[0].diagnostics['ambiguous_indices']),2)

    def test_sparse_good_core_cannot_approve_a_mostly_unknown_region(self):
        frame,track,layers=self.corner('large')
        result=refine_objects(frame,track,layers,CoreConfig(surface_object_proposals=True))
        self.assertEqual(len(result.candidates),2)

    def test_native_ambiguous_minimum_and_warning_are_not_erased_by_core_grouping(self):
        frame,track,layers=self.corner()
        frame.xyz_L[0,0]=1.98
        result=refine_objects(frame,track,layers,CoreConfig(surface_object_proposals=True))
        self.assertEqual(len(result.candidates),1)
        measured=measure_candidates(frame,track,result,CoreConfig(surface_object_proposals=True))
        self.assertAlmostEqual(measured[0].observed_min_distance_m,1.98)
        self.assertAlmostEqual(measured[0].supported_min_distance_m,2.)
        self.assertEqual(measured[0].observed_evidence.point_ref.index,0)
        self.assertIn('nearest_ambiguous_surface',measured[0].flags)

    def test_whole_unknown_roles_do_not_gain_object_proposals(self):
        for role in ('unknown_ground','unknown_track'):
            frame,track,layers=self.corner()
            first=replace(layers.candidates[0],diagnostics=dict(layers.candidates[0].diagnostics,point_role=role))
            layers=replace(layers,candidates=(first,layers.candidates[1]))
            self.assertEqual(len(refine_objects(frame,track,layers,CoreConfig(surface_object_proposals=True)).candidates),2)

    def test_default_off_core_route_retains_previous_rejection(self):
        frame,track,layers=self.corner()
        self.assertEqual(len(refine_objects(frame,track,layers,ClearanceConfig(surface_object_proposals=True)).candidates),2)

    def test_mostly_unknown_core_cannot_enter_legacy_vertical_grouping_route(self):
        parts=[[[2.+x,1.+y,z] for x in (0.,.02,.04) for y in (0.,.02,.04)] for z in (.2,1.)]
        frame=cloud(parts[0]+parts[1])
        candidates=tuple(Candidate('p%d'%i,np.arange(i*9,(i+1)*9),np.arange(i*9,(i+1)*9),1.,1.,
            {'ambiguous_indices':np.arange(i*9,i*9+7)}) for i in range(2))
        layers=SceneLayers({'object':np.arange(18)},candidates,{}, {})
        result=refine_objects(frame,TrackUpdate('observed_dual',line_track()),layers,
                              CoreConfig(spatial_object_ownership=True))
        self.assertEqual(len(result.candidates),2,'old footprint path bypassed qualified-core rejection')

    def test_historical_owner_can_use_core_without_assigning_ambiguous_boundary(self):
        from rsview_centerline.clearance.tests.test_role_instance_refinement import TemporalProposalTests
        frame,track,layers,previous=TemporalProposalTests().scene()
        first=replace(layers.candidates[0],diagnostics={'ambiguous_indices':np.array([0])})
        layers=replace(layers,candidates=(first,layers.candidates[1]))
        cfg=CoreConfig(temporal_object_proposals=True)
        actual=refine_objects(frame,track,layers,cfg,[previous])
        self.assertEqual(len(actual.candidates),1)
        self.assertIn(0,actual.candidates[0].diagnostics['ambiguous_indices'])
        self.assertFalse(actual.candidates[0].diagnostics.get('semantic_identity_confirmed',False))
        self.assertEqual(len(refine_objects(frame,track,layers,
            ClearanceConfig(temporal_object_proposals=True),[previous]).candidates),2)

    def test_competing_owner_at_ambiguous_native_point_still_blocks_core_grouping(self):
        from rsview_centerline.clearance.tests.test_role_instance_refinement import TemporalProposalTests
        frame,track,layers,previous=TemporalProposalTests().scene()
        frame.xyz_L[0,0]=1.98
        first=replace(layers.candidates[0],diagnostics={'ambiguous_indices':np.array([0])})
        layers=replace(layers,candidates=(first,layers.candidates[1]))
        from rsview_centerline.clearance.protocol import PointRef
        previous=replace(previous,xyz_L=np.r_[previous.xyz_L,frame.xyz_L[[0]]],
            refs=previous.refs+(PointRef(0,999,1.),),diagnostics=dict(previous.diagnostics,
                object_proposal_labels=np.r_[previous.diagnostics['object_proposal_labels'],1]))
        self.assertEqual(len(refine_objects(frame,track,layers,
            CoreConfig(temporal_object_proposals=True),[previous]).candidates),2)

    def test_replay_only_donates_reliable_native_core_labels(self):
        from unittest.mock import patch
        from rsview_centerline.clearance.replay import ReplayEngine
        from rsview_centerline.clearance.scene import extract_scene
        from rsview_centerline.clearance.tests.test_motion import Analytic
        frame,unused,layers=self.corner()
        # Inject one known uncertain return at the scene boundary; all actual
        # extraction, motion, ownership, measurement and history consumers run.
        def labelled(frame,track,history,cfg):
            actual=extract_scene(frame,track,history,cfg)
            candidates=tuple(replace(c,diagnostics=dict(c.diagnostics,
                ambiguous_indices=np.array([0],dtype=int) if 0 in c.point_indices else np.empty(0,dtype=int)))
                for c in actual.candidates)
            return replace(actual,candidates=candidates)
        cfg=CoreConfig(temporal_object_proposals=True,surface_object_proposals=True)
        engine=ReplayEngine(cfg,'tracked',Analytic(),
            observer=lambda f:TrackUpdate('observed_dual',line_track(time=f.ref_time_s)))
        with patch('rsview_centerline.clearance.replay.extract_scene',side_effect=labelled):
            engine.step(frame)
        history=engine.object_history[-1]
        labels=history.diagnostics['object_proposal_labels']
        lookup={r.index:i for i,r in enumerate(history.refs)}
        self.assertEqual(labels[lookup[0]],-1,'uncertain return inherited core ownership')
        self.assertGreaterEqual(labels[lookup[1]],0,'reliable face still lost all history ownership')

    def test_ambiguous_duplicate_density_cannot_disqualify_a_large_reliable_footprint(self):
        frame,track,layers=self.corner()
        extra=np.repeat(frame.xyz_L[[0]],600,axis=0)
        bigger=cloud(np.r_[frame.xyz_L,extra])
        duplicate_ids=np.arange(len(frame.xyz_L),len(bigger.xyz_L))
        first=replace(layers.candidates[0],point_indices=np.r_[layers.candidates[0].point_indices,duplicate_ids],
            supported_indices=np.r_[layers.candidates[0].supported_indices,duplicate_ids],
            diagnostics=dict(layers.candidates[0].diagnostics,ambiguous_indices=np.r_[0,duplicate_ids]))
        actual=replace(layers,candidates=(first,layers.candidates[1]))
        result=refine_objects(bigger,track,actual,CoreConfig(surface_object_proposals=True))
        self.assertEqual(len(result.candidates),1)
        self.assertEqual(len(result.candidates[0].point_indices),len(bigger.xyz_L))

    def test_duplicate_unknown_density_cannot_hide_radius_edge_history_competitor(self):
        from rsview_centerline.clearance.tests.test_role_instance_refinement import TemporalProposalTests
        from rsview_centerline.clearance.protocol import PointRef
        frame,track,layers,previous=TemporalProposalTests().scene()
        previous=replace(previous,xyz_L=np.r_[previous.xyz_L,[[1.93485,.3,.5]]],
            refs=previous.refs+(PointRef(0,999,1.),),diagnostics=dict(previous.diagnostics,
                object_proposal_labels=np.r_[previous.diagnostics['object_proposal_labels'],1]))
        for duplicates in (0,600):
            bigger=cloud(np.r_[frame.xyz_L,np.repeat(frame.xyz_L[[0]],duplicates,axis=0)],
                         sequence=1,time=1.1)
            extra=np.arange(len(frame.xyz_L),len(bigger.xyz_L))
            first=replace(layers.candidates[0],point_indices=np.r_[layers.candidates[0].point_indices,extra],
                supported_indices=np.r_[layers.candidates[0].supported_indices,extra],
                diagnostics={'ambiguous_indices':np.r_[0,extra]})
            current=replace(layers,candidates=(first,layers.candidates[1]))
            with self.subTest(duplicates=duplicates):
                self.assertEqual(len(refine_objects(bigger,track,current,
                    CoreConfig(temporal_object_proposals=True),[previous]).candidates),2,
                    'duplicate density shrank conflict search and hid another owner')

    def test_current_proposal_radius_does_not_depend_on_excluded_unknown_density(self):
        frame,track,layers=self.corner()
        frame.xyz_L[layers.candidates[1].point_indices,1]=.723
        for duplicates in (0,600):
            bigger=cloud(np.r_[frame.xyz_L,np.repeat(frame.xyz_L[[0]],duplicates,axis=0)])
            extra=np.arange(len(frame.xyz_L),len(bigger.xyz_L))
            first=replace(layers.candidates[0],point_indices=np.r_[layers.candidates[0].point_indices,extra],
                supported_indices=np.r_[layers.candidates[0].supported_indices,extra],
                diagnostics={'ambiguous_indices':np.r_[0,extra]})
            current=replace(layers,candidates=(first,layers.candidates[1]))
            with self.subTest(duplicates=duplicates):
                self.assertEqual(len(refine_objects(bigger,track,current,
                    CoreConfig(surface_object_proposals=True)).candidates),1)


if __name__=='__main__':
    unittest.main()
