"""Real rail cross-sections must not become equipment; nearby objects survive."""
import unittest
from dataclasses import replace

import numpy as np

from rsview_centerline.clearance.protocol import ClearanceConfig, TrackUpdate, Candidate, SceneLayers
from rsview_centerline.clearance.scene import extract_scene
from rsview_centerline.clearance.tests.fixtures import cloud, line_track


def profile_scene():
    # Hand-labelled geometry in a gravity-aligned frame. Head at 17 cm,
    # web on the axis, wider foot at 2 cm; no standard rail shape is required.
    rails = []
    for station in np.arange(.2, 2.9, .1):
        for side in (-1., 1.):
            for height, offsets in ((.02, (-.06, 0., .06)),
                                    (.06, (0.,)), (.10, (0.,)),
                                    (.14, (-.025, 0., .025)),
                                    (.17, (-.025, 0., .025))):
                rails.extend([[side*.72+offset, station, height] for offset in offsets])
    rails = np.asarray(rails)
    x, y = np.meshgrid(np.linspace(-1.2, 1.2, 29), np.linspace(.1, 2.9, 29))
    ground = np.column_stack((x.ravel(), y.ravel(), np.zeros(x.size)))
    model = line_track(start=(0., 0., .17), end=(0., 3., .17), gauge=1.44)
    model = replace(model, diagnostics={'ground_plane': {'normal_L': [0., 0., 1.],
                                                        'offset_m': 0.}})
    return rails, ground, model


class RailRoleTests(unittest.TestCase):
    def setUp(self):
        self.config = ClearanceConfig(rail_profile_roles=True)

    def test_only_rails_and_ground_produce_no_primary_equipment_dimensions(self):
        rails, ground, model = profile_scene()
        frame = cloud(np.vstack((rails, ground)))
        layers = extract_scene(frame, TrackUpdate('observed_dual', model), [], self.config)
        self.assertEqual(np.intersect1d(np.arange(len(rails)), layers.indices['object']).size, 0,
                         'rail web/foot returns leaked into equipment candidates')
        from rsview_centerline.clearance.measure import measure_candidates
        results = measure_candidates(frame, TrackUpdate('observed_dual', model), layers, self.config)
        self.assertTrue(all(r.supported_min_distance_m is None for r in results))
        from rsview_centerline.clearance.rsview_cache import build_packet
        packet = build_packet(frame, TrackUpdate('observed_dual', model), layers, results, self.config)
        self.assertEqual(packet['measurements'], [],
                         'unresolved on-ground fragments filled primary equipment dimensions')
        self.assertEqual(len(layers.indices['roi']), len(frame.xyz_L))
        self.assertTrue(np.isin(np.arange(len(rails)), layers.indices['rails']).all())

    def test_near_foot_and_5cm_above_head_objects_keep_original_returns(self):
        rails, ground, model = profile_scene()
        ground[:,2] = np.random.default_rng(31).uniform(-.004, .004, len(ground))
        # A real 3-cm-tall surface only 10 cm inward from the rail axis;
        # a 5-cm-high target on the rail. Both are protected, not a 0.8m cutoff.
        near = [[-.62, y, z] for y in (1.1, 1.12, 1.14) for z in (.03, .06)]
        atop = [[.72+x, y, .22] for x in (-.01, .01) for y in (1.3, 1.32, 1.34)]
        frame = cloud(np.vstack((rails, ground, near, atop)))
        layers = extract_scene(frame, TrackUpdate('observed_dual', model), [], self.config)
        protected = np.arange(len(rails)+len(ground), len(frame.xyz_L))
        self.assertTrue(np.isin(protected, layers.indices['object']).all())
        self.assertFalse(np.isin(protected, layers.indices['rails']).any())
        from rsview_centerline.clearance.measure import measure_candidates
        from rsview_centerline.clearance.rsview_cache import build_packet
        track = TrackUpdate('observed_dual', model)
        packet = build_packet(frame, track, layers,
                              measure_candidates(frame, track, layers, self.config), self.config)
        visible = {m['source_index'] for m in packet['measurements']}
        self.assertTrue(visible & set(protected[:len(near)]), 'true low object lost its uncertain dimension')
        self.assertTrue(visible & set(protected[len(near):]), '5cm atop-rail target lost its dimension')

    def test_isolated_near_rail_bulge_is_not_confirmed_as_rail(self):
        rails, ground, model = profile_scene()
        obstacle = [[-.675, y, .09] for y in (1.21, 1.23, 1.25)]
        frame = cloud(np.vstack((rails, ground, obstacle)))
        layers = extract_scene(frame, TrackUpdate('observed_dual', model), [], self.config)
        protected = np.arange(len(rails)+len(ground), len(frame.xyz_L))
        self.assertTrue(np.isin(protected, layers.indices['object']).all())
        self.assertFalse(np.isin(protected, layers.indices['rails']).any())

    def test_unknown_track_fragment_is_not_a_primary_equipment_dimension(self):
        from rsview_centerline.clearance.measure import measure_candidates
        from rsview_centerline.clearance.rsview_cache import build_packet
        rails, unused_ground, model = profile_scene()
        obstacle = [[-.675, y, .09] for y in (1.21, 1.23, 1.25)]
        frame = cloud(np.vstack((rails, obstacle)))
        track = TrackUpdate('observed_dual', model)
        layers = extract_scene(frame, track, [], self.config)
        results = measure_candidates(frame, track, layers, self.config)
        packet = build_packet(frame, track, layers, results, self.config)
        self.assertEqual(packet['measurements'], [],
                         'unknown rail-adjacent fragment occupied an equipment label')
        self.assertTrue(results, 'uncertain observations must remain in the calculation layer')
        self.assertEqual(len(packet['_display']['ambiguous']), len(obstacle))

    def test_profile_does_not_extend_rail_roles_beyond_finite_track_support(self):
        rails, ground, model = profile_scene()
        target = [[-.72, 3.1+y, .10] for y in (0., .01, .02)]
        frame = cloud(np.vstack((rails, ground, target)))
        layers = extract_scene(frame, TrackUpdate('observed_dual', model), [], self.config)
        protected = np.arange(len(rails)+len(ground), len(frame.xyz_L))
        self.assertTrue(np.isin(protected, layers.indices['object']).all())

    def test_duplicate_returns_cannot_confirm_an_isolated_cross_section(self):
        rails, ground, model = profile_scene()
        target = np.repeat([[-.675, 1.23, .09]], 100, axis=0)
        frame = cloud(np.vstack((rails, ground, target)))
        layers = extract_scene(frame, TrackUpdate('observed_dual', model), [], self.config)
        protected = np.arange(len(rails)+len(ground), len(frame.xyz_L))
        self.assertFalse(np.isin(protected, layers.indices['rails']).any())

    def test_rail_role_uses_centerline_station_support_on_cross_sloped_rails(self):
        _, _, model = profile_scene()
        segment = model.segments[0]
        left, right = segment.left_endpoints_L.copy(), segment.right_endpoints_L.copy()
        left[1, 2] -= .12
        right[1, 2] += .12
        model = replace(model, segments=(replace(segment, left_endpoints_L=left,
                                                right_endpoints_L=right),))
        # The centerline supports y=.001. Projection onto the tilted rail
        # tangent alone moves this lower web point behind its start endpoint.
        points = [[.72, y, .17+.04*y-.08] for y in (.001, .501, 1.001, 1.501)]
        frame = cloud(points)
        layers = extract_scene(frame, TrackUpdate('observed_dual', model), [], self.config)
        self.assertTrue(np.isin(np.arange(4), layers.indices['rails']).all(),
                        'valid centerline station lost to rail-only 3D tangent projection')

    def test_visible_head_above_percentile_reference_needs_repeated_profile_support(self):
        rails, ground, model = profile_scene()
        # The fitted line uses an upper percentile, not the literal maximum.
        # A repeated observed head 3 cm above it is still rail geometry.
        head = [[.72, y, .20] for y in (.3, .8, 1.3, 1.8, 2.3)]
        isolated = [[-.71, 1.2, .20], [-.71, 1.21, .20]]
        frame = cloud(np.vstack((rails, ground, head, isolated)))
        layers = extract_scene(frame, TrackUpdate('observed_dual', model), [], self.config)
        start = len(rails)+len(ground)
        self.assertTrue(np.isin(np.arange(start, start+5), layers.indices['rails']).all())
        self.assertTrue(np.isin(np.arange(start+5, start+7), layers.indices['object']).all())

    def test_object_refinement_cannot_rejoin_unknown_ground_to_raised_surface(self):
        from rsview_centerline.clearance.objects import refine_objects
        ground = [[2.+x, .3+y, 0.] for x in (0., .02) for y in (0., .02)]
        raised = [[2.+x, .3+y, .12] for x in (0., .02) for y in (0., .02)]
        frame = cloud(ground+raised)
        first = Candidate('unknown-ground', np.arange(4), np.arange(4), 1., 1.,
                          {'point_role':'unknown_ground', 'ambiguous_indices':np.arange(4)})
        second = Candidate('raised-object', np.arange(4,8), np.arange(4,8), 1., 1., {})
        layers = SceneLayers({'object':np.arange(8)}, (first, second), {'object':8}, {})
        result = refine_objects(frame, TrackUpdate('observed_dual', line_track()), layers, self.config)
        self.assertEqual(len(result.candidates), 2, 'role separation was undone by footprint merging')
        np.testing.assert_array_equal(result.candidates[1].point_indices, np.arange(4,8))

    def test_measured_noise_margin_does_not_promote_ground_band_edge_to_equipment(self):
        from rsview_centerline.clearance.measure import measure_candidates
        from rsview_centerline.clearance.rsview_cache import build_packet
        _, ground, model = profile_scene()
        ground[:,2] = np.random.default_rng(31).uniform(-.004, .004, len(ground))
        edge = [[2., y, -.084] for y in (.6, .62, .64)]
        frame = cloud(np.vstack((ground, edge)))
        track = TrackUpdate('observed_dual', model)
        layers = extract_scene(frame, track, [], self.config)
        results = measure_candidates(frame, track, layers, self.config)
        protected = np.arange(len(ground), len(frame.xyz_L))
        self.assertTrue(np.isin(protected, layers.indices['unknown_ground_structure']).all(),
                        'a 4mm threshold crossing falsely confirmed equipment')
        self.assertTrue(np.isin(protected, layers.indices['object']).all(), 'uncertain returns were deleted')
        packet = build_packet(frame, track, layers, results, self.config)
        self.assertFalse({m['source_index'] for m in packet['measurements']} & set(protected))

    def test_rail_head_noise_margin_is_unknown_not_confirmed_or_deleted(self):
        rails, ground, model = profile_scene()
        ground[:,2] = np.random.default_rng(31).uniform(-.004, .004, len(ground))
        edge = [[.72, y, .211] for y in (.3, .8, 1.3, 1.8, 2.3)]
        frame = cloud(np.vstack((rails, ground, edge)))
        layers = extract_scene(frame, TrackUpdate('observed_dual', model), [], self.config)
        protected = np.arange(len(rails)+len(ground), len(frame.xyz_L))
        self.assertTrue(np.isin(protected, layers.indices['unknown_track_structure']).all())
        self.assertFalse(np.isin(protected, layers.indices['rails']).any(), 'uncertainty became rail identity')
        self.assertTrue(np.isin(protected, layers.indices['object']).all())

    def test_rail_fitting_input_indices_are_not_a_semantic_exclusion_mask(self):
        rails, ground, model = profile_scene()
        target = [[-.62, 1.4, .05], [-.62, 1.42, .05]]
        frame = cloud(np.vstack((rails, ground, target)))
        protected = np.arange(len(rails)+len(ground), len(frame.xyz_L))
        # Broad strip input can include a target; old source indices can also
        # be from another scan after propagation. Neither proves rail identity.
        model = replace(model, mode='predicted_track', diagnostics=dict(model.diagnostics,
                        rail_source_indices=protected))
        layers = extract_scene(frame, TrackUpdate('predicted_track', model), [], self.config)
        self.assertTrue(np.isin(protected, layers.indices['object']).all())

    def test_profile_roles_are_rotation_invariant(self):
        rails, ground, model = profile_scene()
        rotation = np.array([[0., 0., -1.], [0., 1., 0.], [1., 0., 0.]])
        translation = np.array([.3, -.2, .4])
        from rsview_centerline.clearance.track import transform_track
        transform = np.eye(4)
        transform[:3, :3], transform[:3, 3] = rotation, translation
        frame = cloud(np.vstack((rails, ground))@rotation.T+translation)
        model = transform_track(model, frame, transform)
        layers = extract_scene(frame, TrackUpdate('predicted_track', model), [], self.config)
        self.assertEqual(np.intersect1d(np.arange(len(rails)), layers.indices['object']).size, 0)
        self.assertTrue(np.isin(np.arange(len(rails)), layers.indices['rails']).all())

    def test_legacy_extraction_is_not_silently_changed(self):
        rails, ground, model = profile_scene()
        layers = extract_scene(cloud(np.vstack((rails, ground))),
                               TrackUpdate('observed_dual', model), [], ClearanceConfig())
        self.assertGreater(len(layers.indices['object']), 0)


if __name__ == '__main__':
    unittest.main()
