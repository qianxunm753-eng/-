"""An explicitly labeled legacy comparison must still obey the new geometry."""
import json
import tempfile
from pathlib import Path
import unittest
import numpy as np
from rsview_centerline.clearance.protocol import ClearanceConfig, TrackUpdate
from rsview_centerline.clearance.tests.fixtures import cloud, line_track


class BaselineReplayTests(unittest.TestCase):
    def test_legacy_adapter_does_not_use_nominal_gauge(self):
        from rsview_centerline.clearance.baseline import adapt_legacy_measurement
        f = cloud([[3,1,1]])
        result = {'endpoints': [[0,0,0], [0,2,0]], 'gauge': 1.7,
                  'left_point': [-.85,1,0], 'right_point': [.85,1,0],
                  'quality_warnings': ['test-warning']}
        update = adapt_legacy_measurement(f, result, ([0,0,1], -.1))
        self.assertAlmostEqual(update.model.observed_gauge_m, 1.7)
        self.assertEqual(update.model.diagnostics['quality_warnings'], ['test-warning'])
        np.testing.assert_allclose(update.model.segments[0].left_endpoints_L[0], [-.85,0,0])
        self.assertEqual(update.model.diagnostics['observer'], 'legacy_single_frame_baseline')

    def test_replay_counts_failure_frames_and_never_overwrites(self):
        from rsview_centerline.clearance.replay import run_replay
        frames = [cloud([[2,1,1],[2.01,1,1]], sequence=7),
                  cloud([], time=1.1, sequence=8)]
        def observer(frame):
            if not len(frame.xyz_L):
                return TrackUpdate('initializing', diagnostics={'reason': 'empty'})
            return TrackUpdate('observed_dual', line_track(time=frame.ref_time_s))
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary)/'run'
            report = run_replay(frames, ClearanceConfig(), output=output, observer=observer,
                                previews=(7,))
            self.assertEqual(report['input_frames'], 2)
            self.assertEqual(report['fresh_distance_frames'], 1)
            rows = [json.loads(s) for s in (output/'frames.jsonl').read_text().splitlines()]
            self.assertEqual([r['sequence'] for r in rows], [7,8])
            self.assertEqual(rows[1]['mode'], 'initializing')
            self.assertTrue((output/'preview-7.png').exists())
            with self.assertRaises(FileExistsError):
                run_replay(frames, ClearanceConfig(), output=output, observer=observer)


if __name__ == '__main__':
    unittest.main()
