"""Replay the actual embedded packet selector without large point exports."""
import argparse
import json
import math
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
from rsview_centerline.clearance_overlay import PacketCache


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--folder', required=True)
    parser.add_argument('--start', type=int, default=260)
    parser.add_argument('--end', type=int, default=380)
    parser.add_argument('--output', required=True)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    cache = PacketCache(args.folder)
    rows, jumps, unexpected = [], [], []
    previous = {}
    for number in range(args.start, args.end + 1):
        packet = cache.get(number)
        if packet is None:
            continue
        current = packet['measurements'][:4]
        left = [m for m in current if m['point_L'][1] > 0.]
        right = [m for m in current if m['point_L'][1] < 0.]
        # This recording's non-target side was explicitly identified by the
        # user. This is a diagnostic expectation, not a generic runtime mask.
        if right:
            unexpected.append(number)
        for item in current:
            identity = item.get('surface_id', item['candidate_id'])
            if identity in previous:
                old = previous[identity]
                step = math.sqrt(sum((a-b)**2 for a,b in zip(old['foot_L'], item['foot_L'])))
                if step > .3 and abs(item['distance_m']-old['distance_m']) < .1:
                    jumps.append(dict(frame=number, identity=identity, foot_step_m=step,
                                      distance_step_m=item['distance_m']-old['distance_m']))
        rows.append(dict(sequence=number, mode=packet['mode'], left_count=len(left),
            right_count=len(right), selected=[dict(identity=m.get('surface_id'),
                distance_m=m['distance_m'], point_L=m['point_L'], foot_L=m['foot_L'])
                for m in current]))
        previous = {m.get('surface_id',m['candidate_id']):m for m in current}
    report = dict(rows=rows, unexpected_side_frames=unexpected,
                  nearest_anchor_jumps=jumps, total_frames=len(rows))
    output = Path(args.output)
    if output.exists():
        raise ValueError('Refusing to replace a diagnostic report')
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(dict(total_frames=len(rows), unexpected_side_frames=len(unexpected),
        nearest_anchor_jumps=len(jumps), first_frames=rows[:3], jumps=jumps[:5])))
    if args.check and unexpected:
        raise AssertionError('Confirmed non-target side still consumes visible distance slots in %d frames' % len(unexpected))


if __name__ == '__main__':
    main()
