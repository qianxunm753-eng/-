# -*- coding: utf-8 -*-
"""Owned real-PCAP RSView continuous overlay probe; no new raw exports."""
import hashlib
import json
import math
import os
import shutil
import tempfile
import time
import traceback
from PythonQt import QtCore,QtGui
import rsview.applogic as logic

start_frame=int(os.environ.get('RSVIEW_PRESENTATION_START','260'))
end_frame=int(os.environ.get('RSVIEW_PRESENTATION_END','380'))
if start_frame<0 or end_frame<start_frame:
    raise ValueError('invalid continuous probe range')
screens=set((start_frame,(start_frame+end_frame)//2,end_frame))
state={'rows':[],'error':None,'number':start_frame}
timer=None
report_path=os.environ['RSVIEW_PRESENTATION_REPORT'].decode('mbcs')
cache_folder=os.environ['RSVIEW_PRESENTATION_CACHE'].decode('mbcs')


def finish():
    if timer is not None:
        timer.stop()
    if state.get('overlay') is not None:
        state['overlay'].close()
    with open(report_path,'wb') as stream:
        stream.write(json.dumps(dict(error=state['error'],source_sha256=state.get('source_sha256'),
            rows=state['rows'],cache=cache_folder,calculation='offline_precomputed',
            live_0_2s_verified=False),indent=2).encode('utf-8'))
    QtGui.QApplication.instance().quit()


def unit(values):
    length=math.sqrt(sum(v*v for v in values))
    return [v/length for v in values]


def camera_for(packet):
    if not packet['measurements'] or not packet['centerline']:
        return
    a,b=packet['centerline'][0]
    t=unit([v-u for u,v in zip(a,b)])
    item=packet['measurements'][0]
    s=unit([v-u for u,v in zip(item['foot_L'],item['projected_L'])])
    n=unit([t[1]*s[2]-t[2]*s[1],t[2]*s[0]-t[0]*s[2],t[0]*s[1]-t[1]*s[0]])
    if sum(v*(p-q) for v,p,q in zip(n,item['point_L'],item['projected_L']))<0:
        n=[-v for v in n]
    # This is an owned validation camera, not the user's saved view. Frame
    # the full finite reference and selected boundaries; centring on its first
    # short segment cut the devices off the top of the audit screenshots.
    points=[p for pair in packet['centerline'] for p in pair]
    for selected in packet['measurements'][:4]:
        points.extend((selected['point_L'],selected['foot_L']))
    focal=[(min(p[i] for p in points)+max(p[i] for p in points))*.5 for i in range(3)]
    camera=logic.app.mainView.GetRenderer().GetActiveCamera()
    camera.SetFocalPoint(*focal)
    camera.SetPosition(*[c+v*6-u*4-w*3 for c,v,u,w in zip(focal,n,t,s)])
    camera.SetViewUp(*n)
    camera.ParallelProjectionOn()
    camera.SetParallelScale(4.5)


def tick():
    try:
        from clearance_overlay import dimension_endpoints
        number=state['number']
        reader=state['reader']
        reader.UpdatePipeline(float(state['steps'][number]))
        logic.app.scene.AnimationTime=float(state['steps'][number])
        logic.onTimeChanged()
        overlay=state['overlay']
        packet=overlay.last_result
        if packet is None or packet['sequence']!=number:
            raise AssertionError('continuous playback selected another result frame')
        selected=overlay.current['measurements']
        raw_points=reader.GetClientSideObject().GetOutput().GetNumberOfPoints()
        identities=[m.get('display_id') for m in selected if m.get('display_id')]
        if len(identities)!=len(set(identities)):
            raise AssertionError('one observed region occupies multiple annotations')
        for i,item in enumerate(selected):
            source,actor=overlay.measure_lines[i]
            endpoint,foot=dimension_endpoints(item)
            if not actor.GetVisibility():
                raise AssertionError('current annotation actor hidden')
            if any(abs(a-b)>1e-8 for point,expected in ((source.GetPoint1(),endpoint),(source.GetPoint2(),foot))
                   for a,b in zip(point,expected)):
                raise AssertionError('native actor differs from stable dimension geometry')
            length=math.sqrt(sum((a-b)**2 for a,b in zip(source.GetPoint1(),source.GetPoint2())))
            if abs(length-item['distance_m'])>1e-8:
                raise AssertionError('dimension length differs from unsmoothed current distance')
            if item['source_frame']!=number or not 0<=item['source_index']<raw_points:
                raise AssertionError('boundary provenance not current native scan')
            for (upload,unused_actor),key in zip(overlay.boundary_actors,('point_L','foot_L')):
                if any(abs(a-b)>1e-6 for a,b in zip(upload.data.GetPoint(i),item[key])):
                    raise AssertionError('true boundary marker was replaced by dimension endpoint')
        for source,actor in overlay.measure_lines[len(selected):]:
            if actor.GetVisibility():
                raise AssertionError('stale annotation survived current object loss')
        for name in ('ground','background'):
            entry=packet['clouds'].get(name)
            if entry and entry['count'] and not overlay.cloud_actors[name][1].GetVisibility():
                raise AssertionError('context points hidden')
        state['rows'].append(dict(sequence=number,mode=packet['mode'],selected=selected,
            scene_diagnostics=packet.get('scene_diagnostics',{}),display_timing_ms=overlay.last_display_timings,
            native_line_count=sum(actor.GetVisibility() for source,actor in overlay.measure_lines),
            native_point_count=raw_points,labels=[label.GetInput() for label in overlay.labels if label.GetVisibility()]))
        if number in screens:
            if number==start_frame:
                camera_for(packet)
            descriptor,temporary_image=tempfile.mkstemp(suffix='.png')
            os.close(descriptor)
            logic.smp.WriteImage(temporary_image,view=logic.app.mainView)
            image_path=os.path.splitext(report_path)[0]+'-%d.png'%number
            if os.path.exists(image_path):
                raise AssertionError('refusing to overwrite native screenshot')
            shutil.move(temporary_image,image_path)
            state['rows'][-1]['image']=image_path
        state['number']+=1
        if state['number']>end_frame:
            finish()
    except Exception:
        state['error']=traceback.format_exc()
        finish()


def begin():
    global timer
    factories={}
    folder=None
    choose,network=logic.chooseCalibrationFile,logic.networkConfigPcap
    try:
        from clearance_native import patch_recording_decoder,prepare_pcap_reader
        from clearance_overlay import PacketCache
        if os.path.exists(report_path):
            raise AssertionError('new report path required')
        path=os.path.join(os.path.expanduser('~'),'Desktop','1212121.pcap')
        digest=hashlib.sha256()
        with open(path,'rb') as stream:
            while True:
                block=stream.read(1024*1024)
                if not block: break
                digest.update(block)
        state['source_sha256']=digest.hexdigest()
        if state['source_sha256']!='88e53b2835febf5a35346e9dd02379894c530672277ab4ae7f45215766f04960':
            raise AssertionError('native input source changed')
        factories=patch_recording_decoder(logic)
        logic.chooseCalibrationFile=lambda unused:True
        logic.networkConfigPcap=lambda unused:True
        folder=tempfile.mkdtemp(prefix='rsview-presentation-')
        pointer=os.path.join(folder,'input_path.log')
        with open(pointer,'wb') as stream: stream.write(path)
        logic.openPCAP(pointer)
        logic.stop()
        logic.app.tempTimer.stop()
        reader=logic.app.reader
        steps=prepare_pcap_reader(reader)
        for step in steps[:7]: reader.UpdatePipeline(float(step))
        overlay=logic.app.railOverlay
        if overlay is None:
            raise AssertionError('actual native overlay missing')
        overlay.cache=PacketCache(cache_folder)
        overlay.last_processed_frame=None
        state.update(reader=reader,steps=steps,overlay=overlay)
        logic.app.scene.UpdateAnimationUsingDataTimeSteps()
        logic.updateSliderTimeRange()
        timer=QtCore.QTimer()
        timer.connect('timeout()',tick)
        timer.start(100)
    except Exception:
        state['error']=traceback.format_exc()
        finish()
    finally:
        logic.chooseCalibrationFile,logic.networkConfigPcap=choose,network
        for name,factory in factories.items(): setattr(logic,name,factory)
        if folder:
            try:
                os.remove(os.path.join(folder,'input_path.log')); os.rmdir(folder)
            except OSError: pass


starter=QtCore.QTimer()
starter.setSingleShot(True)
starter.connect('timeout()',begin)
starter.start(1000)
