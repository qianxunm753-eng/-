# -*- coding: utf-8 -*-
"""Native PCAP menu/play/pause/seek/restore integration, in an owned window."""
import json
import math
import os
import shutil
import tempfile
import time
import traceback
from PythonQt import QtCore, QtGui
import rsview.applogic as logic

report_path = os.environ['RSVIEW_RECORDED_REPORT'].decode('mbcs')
state = dict(error=None, checks={}, stage='starting', packets=[],
    physical_lidar_test=False, absolute_accuracy_verified=False)
folder = tempfile.mkdtemp(prefix='rsview-recorded-check-')
factories = {}
timer = None
overlay = None
started = time.time()


def check(name, condition):
    state['checks'][name] = bool(condition)
    if not condition:
        raise AssertionError(name)


def open_recording(name):
    from clearance_native import prepare_pcap_reader
    pointer = os.path.join(folder, 'input_path.log')
    with open(pointer, 'wb') as stream:
        stream.write(os.path.join(os.path.expanduser('~'), 'Desktop', name))
    logic.openPCAP(pointer)
    logic.stop()
    steps = prepare_pcap_reader(logic.getReader())
    logic.app.scene.UpdateAnimationUsingDataTimeSteps()
    logic.updateSliderTimeRange()
    return steps


def select(frame):
    logic.app.scene.AnimationTime = float(frame)
    logic.onTimeChanged()
    state['waiting_frame'] = frame
    state['stage_started'] = time.time()


def record_packet(packet):
    check('ordinary_recorded_source', packet['source_mode'] == 'recorded_pcap')
    check('not_precomputed', packet['calculation'] == 'online_current_cloud')
    check('not_recorded_trajectory', packet['pose_scope'] == 'live_lidar_relative_experimental')
    check('no_absolute_accuracy_claim', packet['absolute_accuracy_verified'] is False)
    check('no_background_mask', overlay.worker_config['confirmed_background_path'] is None)
    check('no_world_scope_prior', overlay.worker_config['confirmed_measurement_scope_path'] is None)
    check('v16_ground_gate', overlay.worker_config['local_terrain_validation'] is True)
    check('v16_reliable_core', overlay.worker_config['qualified_object_cores'] is True)
    check('result_matches_selected_frame', packet['sequence'] == int(logic.getTimeKeeper().getTime()))
    check('current_result_identity', packet['current_source'])
    data = logic.getReader().GetClientSideObject().GetOutput()
    stamps = data.GetPointData().GetArray('timestamp')
    span = list(stamps.GetRange())
    check('native_current_scan_not_trailing_cloud', span[1]-span[0] < .15)
    check('device_time_not_animation_frame', abs(packet['device_time_s']-sum(span)/2.) < 1e-6)
    check('native_frame_is_selected', data.GetInformation().Get(logic.vtk.vtkDataObject.DATA_TIME_STEP()) == packet['sequence'])
    for item, (line, actor) in zip(overlay.current['measurements'], overlay.measure_lines):
        a, b = line.GetPoint1(), line.GetPoint2()
        length = math.sqrt(sum((u-v)**2 for u, v in zip(a, b)))
        check('native_line_matches_distance', abs(length-item['distance_m']) < 1e-8)
        check('native_selected_index_current_frame', item['source_frame'] == packet['sequence'])
        check('native_selected_index_exists', 0 <= item['source_index'] < data.GetNumberOfPoints())
        check('original_selected_timestamp', abs(stamps.GetTuple1(item['source_index'])-item['source_time_s']) < 1e-6)
        check('selected_distance_point_within_5m', sum(v*v for v in item['point_L']) <= 25.+1e-8)
    state['packets'].append(dict(sequence=packet['sequence'], epoch=packet['epoch'],
        session=packet['session_id'], mode=packet['mode'], motion_status=packet['motion_status'],
        relative_pose_diagnostics=packet['relative_pose_diagnostics'],
        measurements=packet['measurements'], device_span=span,
        status=unicode(logic.app.statusLabel.text), timing_ms=packet['timing_ms']))


def screenshot():
    packet = overlay.current
    if packet and packet['centerline'] and packet['measurements']:
        def unit(v):
            size = math.sqrt(sum(x*x for x in v))
            return [x/size for x in v]
        a, b = packet['centerline'][0]
        tangent = unit([y-x for x, y in zip(a, b)])
        item = packet['measurements'][0]
        across = unit([x-y for x, y in zip(item['projected_L'], item['foot_L'])])
        normal = unit([tangent[1]*across[2]-tangent[2]*across[1],
            tangent[2]*across[0]-tangent[0]*across[2], tangent[0]*across[1]-tangent[1]*across[0]])
        if normal[0] > 0:
            normal = [-v for v in normal]
        points = [p for pair in packet['centerline'] for p in pair]
        for selected in packet['measurements']:
            points.extend((selected['point_L'], selected['foot_L']))
        focal = [(min(p[i] for p in points)+max(p[i] for p in points))*.5 for i in range(3)]
        camera = logic.app.mainView.GetRenderer().GetActiveCamera()
        camera.SetFocalPoint(*focal)
        camera.SetPosition(*[c+n*9. for c, n in zip(focal, normal)])
        camera.SetViewUp(*tangent)
        camera.ParallelProjectionOn()
        camera.SetParallelScale(4.5)
        logic.smp.Render(logic.app.mainView)
    # This embedded VTK writer accepts ASCII paths only. Render to our owned
    # temporary file, then move that small screenshot via Python's Unicode FS.
    image_path = os.path.join(folder, 'recorded.png')
    logic.smp.WriteImage(image_path, logic.app.mainView)
    shutil.move(image_path, report_path[:-5]+'.png')


def finish():
    if timer is not None:
        timer.stop()
    try:
        logic.close()
    except Exception:
        state['cleanup_error'] = traceback.format_exc()
    for name, factory in factories.items():
        setattr(logic, name, factory)
    for name in ('input_path.log', 'tmp.log', 'input.log'):
        path = os.path.join(folder, name)
        if os.path.isfile(path):
            os.remove(path)
    os.rmdir(folder)
    with open(report_path, 'wb') as stream:
        stream.write(json.dumps(state, indent=2).encode('utf-8'))
    QtGui.QApplication.instance().quit()


def tick():
    global overlay
    try:
        if time.time()-started > 110.:
            raise AssertionError('native recorded probe timeout: '+state['stage'])
        controller = logic.app.clearanceController
        packet = overlay.poll()
        if packet and packet.get('status') == 'failed':
            raise AssertionError(packet.get('error'))
        if state['stage'] == 'playing':
            if time.time()-state['stage_started'] < 2.:
                return
            old_session = overlay.session
            select(220)
            check('seek_while_playing_keeps_player_running', logic.app.playing)
            check('playing_seek_changes_session', overlay.session != old_session)
            state['stage'] = 'seek_while_playing'
            state['seek_snapshot_visible'] = False
            return
        if state['stage'] == 'seek_while_playing':
            if overlay.last_result and overlay.last_result.get('sequence', -1) >= 220:
                state['seek_snapshot_visible'] = True
            if time.time()-state['stage_started'] < 2.:
                return
            check('playing_seek_can_show_new_segment_snapshot', state['seek_snapshot_visible'])
            logic.stop()
            state['stage'] = 'paused_after_play'
            state['waiting_frame'] = int(logic.getTimeKeeper().getTime())
            state['stage_started'] = time.time()
            check('native_playback_advanced', state['waiting_frame'] > 153)
            return
        if state['stage'] == 'pause_hold':
            if time.time()-state['stage_started'] < 1.:
                return
            check('pause_retains_selected_packet', overlay.last_result is not None and
                  overlay.last_result['sequence'] == state['waiting_frame'])
            old_session, old_epoch = overlay.session, overlay.host.epoch
            select(300)
            state['stage'] = 'forward_seek'
            check('forward_seek_changes_session', overlay.session != old_session)
            check('forward_seek_changes_epoch', overlay.host.epoch > old_epoch)
            check('forward_seek_does_not_show_old_frame', overlay.last_result is None or overlay.last_result['sequence'] == 300)
            return
        if not packet or packet.get('status') != 'completed' or not packet.get('current_source'):
            return
        if packet['sequence'] != state['waiting_frame']:
            return
        record_packet(packet)
        stage = state['stage']
        if stage == 'first_paused':
            check('paused_initial_frame_calculated', not logic.app.playing)
            check('initial_current_measurements_present', bool(packet['measurements']))
            select(151)
            state['stage'] = 'sequential_151'
        elif stage in ('sequential_151', 'sequential_152'):
            next_frame = packet['sequence']+1
            select(next_frame)
            state['stage'] = 'sequential_'+str(next_frame)
        elif stage == 'sequential_153':
            check('adjacent_frames_keep_session', packet['session_id'] == state['packets'][0]['session'])
            state['worker_config'] = dict(overlay.worker_config)
            screenshot()
            logic.play()
            state['stage'], state['stage_started'] = 'playing', time.time()
        elif stage == 'paused_after_play':
            check('pause_does_not_close_pcap_worker', overlay.host is not None and not overlay.host.closed)
            state['stage'], state['stage_started'] = 'pause_hold', time.time()
        elif stage == 'forward_seek':
            old_session, old_epoch = overlay.session, overlay.host.epoch
            select(150)
            state['stage'] = 'backward_seek'
            check('backward_seek_changes_session', overlay.session != old_session)
            check('backward_seek_changes_epoch', overlay.host.epoch > old_epoch)
        elif stage == 'backward_seek':
            check('seek_starts_without_invented_deskew', packet['motion_status'] == 'raw')
            select(state['last_frame'])
            state['stage'] = 'eof'
        elif stage == 'eof':
            check('end_frame_calculated_while_paused', not logic.app.playing)
            old_host, old_overlay = overlay.host, overlay
            controller.action.trigger()
            check('disable_closes_worker', old_host.closed and old_overlay.closed)
            check('disable_restores_raw333_view', logic.app.railOverlay is None)
            check('disable_restores_tf', int(logic.app.trailingFramesSpinBox.value) == 8 and
                  int(logic.getReader().NumberOfTrailingFrames) == 8)
            check('disable_restores_tf_control', logic.app.trailingFramesSpinBox.enabled)
            controller.action.trigger()
            overlay = controller.overlay
            old_host = overlay.host
            steps = open_recording('22222.pcap')
            check('file_switch_closes_old_worker', old_host.closed)
            check('new_file_not_auto_enabled', not controller.action.checked)
            check('new_file_keeps_legacy_overlay', type(logic.app.railOverlay).__name__ == 'VtkRailOverlay')
            check('new_airys_pcap_menu_available', controller.action.enabled)
            select(10)
            controller.action.trigger()
            overlay = controller.overlay
            state['stage'] = 'legacy_recorded_enabled'
        elif stage == 'legacy_recorded_enabled':
            controller.action.trigger()
            check('legacy_route_restored_on_disable', type(logic.app.railOverlay).__name__ == 'VtkRailOverlay')
            check('legacy_centerline_visible', bool(logic.app.railOverlay.representation.Visibility))
            check('legacy_tf32_restored', int(logic.app.trailingFramesSpinBox.value) == 32)
            state['stage'] = 'completed'
            finish()
    except Exception:
        state['error'] = traceback.format_exc()
        finish()


def start():
    global factories, overlay, timer
    try:
        from clearance_native import patch_recording_decoder
        factories = patch_recording_decoder(logic)
        logic.chooseCalibrationFile = lambda unused: True
        logic.networkConfigPcap = lambda unused: True
        steps = open_recording('333.pcap')
        state['last_frame'] = int(steps[-1])
        controller = logic.app.clearanceController
        check('pcap_menu_available', controller.action.enabled)
        check('pcap_opt_in_only', not controller.action.checked and logic.app.railOverlay is None)
        logic.app.trailingFramesSpinBox.setValue(8)
        select(150)
        controller.action.trigger()
        overlay = controller.overlay
        check('ordinary_pcap_overlay_enabled', overlay is logic.app.railOverlay and controller.action.checked)
        check('tf_single_scan_locked', logic.app.trailingFramesSpinBox.value == 0 and
              not logic.app.trailingFramesSpinBox.enabled and logic.getReader().NumberOfTrailingFrames == 0)
        state['stage'] = 'first_paused'
        timer = QtCore.QTimer()
        timer.connect('timeout()', tick)
        timer.start(100)
    except Exception:
        state['error'] = traceback.format_exc()
        finish()


start_timer = QtCore.QTimer()
start_timer.setSingleShot(True)
start_timer.connect('timeout()', start)
start_timer.start(1000)
