"""Measured rail-plane uncertainty cannot become a confirmed above-rail object."""
from dataclasses import dataclass,replace
import unittest
import numpy as np
from rsview_centerline.clearance.scene import extract_scene,SurfaceTracker
from rsview_centerline.clearance.measure import measure_candidates
from rsview_centerline.clearance.rsview_cache import build_packet
from rsview_centerline.clearance.protocol import TrackUpdate
from rsview_centerline.clearance.tests.fixtures import cloud,line_track
from rsview_centerline.clearance.tests.test_observable_instances import configuration as base_config
from rsview_centerline.clearance.tests.test_surface_tracking import pose


@dataclass(frozen=True)
class RailScopeConfig(type(base_config())):
    above_rail_uncertainty: bool = True
    rail_profile_roles: bool = True


def configuration(enabled=True):
    return RailScopeConfig(**dict(base_config().__dict__,above_rail_uncertainty=enabled,rail_profile_roles=True))


def fixture(height=.006,noise=.004):
    rng=np.random.default_rng(813)
    ground=np.array([[x,y,-.17+rng.normal(0.,noise)]
        for x in np.arange(-2.5,2.51,.1) for y in np.arange(0.,2.01,.1)])
    target=np.array([[2.+x,.8+y,height] for x in (0.,.02,.04) for y in (0.,.02,.04)])
    frame=cloud(np.vstack((ground,target)))
    model=replace(line_track(),diagnostics={'ground_plane':{'normal_L':[0.,0.,1.],'offset_m':-.17}})
    return frame,TrackUpdate('observed_dual',model),np.arange(len(ground),len(frame.xyz_L))


class RailScopeUncertaintyTests(unittest.TestCase):
    def test_noise_band_keeps_raw_near_plane_range_but_not_a_confirmed_dimension(self):
        cfg=configuration()
        frame,track,target=fixture()
        original=frame.xyz_L.copy()
        layers=extract_scene(frame,track,[],cfg)
        candidate=next(c for c in layers.candidates if np.intersect1d(c.point_indices,target).size)
        self.assertEqual(candidate.diagnostics.get('point_role'),'unknown_rail_scope',
                         'noise-band return was asserted to be an above-rail target')
        np.testing.assert_array_equal(candidate.point_indices,target)
        layers=SurfaceTracker(cfg).update(frame,layers,pose(frame),track.model)
        results=measure_candidates(frame,track,layers,cfg)
        packet=build_packet(frame,track,layers,results,cfg)
        self.assertEqual(packet['measurements'],[])
        raw=next(m for m in packet['secondary_measurements'] if m['observed_source_index'] in target)
        self.assertEqual(raw['reason'],'unconfirmed_above_rail_scope')
        self.assertEqual(raw['observed_min_distance_m'],2.)
        self.assertEqual(raw['source_frame'],0)
        np.testing.assert_array_equal(frame.xyz_L,original)

    def test_clean_three_mm_plate_has_no_fixed_minimum_height_rejection(self):
        frame,track,target=fixture(height=.003,noise=0.)
        cfg=configuration()
        layers=extract_scene(frame,track,[],cfg)
        candidate=next(c for c in layers.candidates if np.intersect1d(c.point_indices,target).size)
        self.assertIsNone(candidate.diagnostics.get('point_role'))
        layers=SurfaceTracker(cfg).update(frame,layers,pose(frame),track.model)
        packet=build_packet(frame,track,layers,measure_candidates(frame,track,layers,cfg),cfg)
        self.assertEqual(len(packet['measurements']),1)
        self.assertEqual(packet['measurements'][0]['distance_m'],2.)

    def test_clear_above_rail_surface_is_not_suppressed_by_noisy_ground(self):
        frame,track,target=fixture(height=.08)
        cfg=configuration()
        layers=extract_scene(frame,track,[],cfg)
        self.assertFalse(len(layers.indices.get('uncertain_rail_scope',[])))
        candidate=next(c for c in layers.candidates if np.intersect1d(c.point_indices,target).size)
        self.assertIsNone(candidate.diagnostics.get('point_role'))

    def test_disabled_route_retains_the_previous_positive_height_policy(self):
        frame,track,target=fixture()
        cfg=configuration(False)
        layers=extract_scene(frame,track,[],cfg)
        candidate=next(c for c in layers.candidates if np.intersect1d(c.point_indices,target).size)
        self.assertIsNone(candidate.diagnostics.get('point_role'))
        self.assertFalse(len(layers.indices.get('uncertain_rail_scope',[])))

    def test_no_current_track_cannot_manufacture_a_rail_scope_band(self):
        frame,unused,target=fixture()
        layers=extract_scene(frame,TrackUpdate('initializing',None),[],configuration())
        self.assertFalse(len(layers.indices.get('uncertain_rail_scope',[])))
        self.assertFalse(any(c.diagnostics.get('point_role')=='unknown_rail_scope' for c in layers.candidates))

    def test_partial_body_keeps_the_actual_closer_uncertain_native_return(self):
        frame,track,target=fixture()
        xyz=frame.xyz_L.copy()
        xyz[target,0]-=.02
        upper=np.array([[2.,y,z] for y in np.arange(.8,.881,.02) for z in np.arange(.24,.321,.02)])
        stalk=np.array([[2.,.8,z] for z in np.arange(.02,.241,.02)])
        frame=cloud(np.vstack((xyz,stalk,upper)))
        cfg=configuration()
        layers=extract_scene(frame,track,[],cfg)
        candidate=next(c for c in layers.candidates if np.intersect1d(c.point_indices,target).size)
        self.assertIsNone(candidate.diagnostics.get('point_role'))
        self.assertTrue(np.isin(target,candidate.point_indices).all())
        self.assertEqual(candidate.diagnostics['rail_scope_uncertain_count'],len(target))
        results=measure_candidates(frame,track,layers,cfg)
        result=next(r for r in results if r.candidate_id==candidate.candidate_id)
        self.assertEqual(result.observed_min_distance_m,1.98)
        self.assertIn(result.observed_evidence.point_ref.index,target)
        self.assertIn('nearest_ambiguous_surface',result.flags)

    def test_scope_band_is_track_relative_not_sensor_z(self):
        angle=.8
        rotation=np.array([[np.cos(angle),0.,np.sin(angle)],[0.,1.,0.],[-np.sin(angle),0.,np.cos(angle)]])
        frame,track,target=fixture()
        moved=replace(frame,xyz_L=frame.xyz_L@rotation.T)
        segments=tuple(replace(s,start_L=rotation@s.start_L,end_L=rotation@s.end_L,
            left_endpoints_L=s.left_endpoints_L@rotation.T,right_endpoints_L=s.right_endpoints_L@rotation.T,
            normal_L=rotation@s.normal_L,across_L=rotation@s.across_L) for s in track.model.segments)
        model=replace(track.model,segments=segments,diagnostics={'ground_plane':{
            'normal_L':(rotation@np.array([0.,0.,1.])).tolist(),'offset_m':-.17}})
        layers=extract_scene(moved,TrackUpdate('observed_dual',model),[],configuration())
        candidate=next(c for c in layers.candidates if np.intersect1d(c.point_indices,target).size)
        self.assertEqual(candidate.diagnostics.get('point_role'),'unknown_rail_scope')
        np.testing.assert_array_equal(candidate.point_indices,target)

    def test_explicit_replay_preset_and_live_guard(self):
        import os
        from unittest.mock import patch
        from rsview_centerline.clearance_native import recorded_measurement_config,live_measurement_config
        from rsview_centerline.clearance.online import OnlineEngine
        with patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':'v31'}):
            self.assertTrue(recorded_measurement_config().get('above_rail_uncertainty'))
            self.assertFalse(live_measurement_config().get('above_rail_uncertainty',False))
        with self.assertRaisesRegex(ValueError,'replay-only'):
            OnlineEngine({'above_rail_uncertainty':True},source_mode='live')
        with self.assertRaisesRegex(ValueError,'qualified rail-plane measurement scope'):
            OnlineEngine({'above_rail_uncertainty':True},source_mode='recorded_pcap')


if __name__=='__main__':
    unittest.main()
