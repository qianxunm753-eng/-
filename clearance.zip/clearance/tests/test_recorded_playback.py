"""Recorded Airy playback must share live calculation, not recording priors."""
import unittest
import sys
import time
from types import SimpleNamespace
from unittest.mock import patch
from collections import deque

from rsview_centerline import clearance_live
from rsview_centerline.clearance.tests.test_live_clearance import Action, Label, Sensor, Spin, Overlay, Actor
from rsview_centerline import clearance_native
from rsview_centerline.clearance.tests.test_online import request
from rsview_centerline.clearance.tests.test_native_online import NativeCloud


class RecordedMenuTests(unittest.TestCase):
    def logic(self, filename='333.pcap', model='RSAIRY'):
        reader = Sensor()
        return SimpleNamespace(app=SimpleNamespace(sensor=None, reader=reader,
            curLidarType=model, playing=False, railOverlay=None, statusLabel=Label(),
            numberOfTrailingFrames=17, trailingFramesSpinBox=Spin()),
            getSensor=lambda: None, getReader=lambda: reader,
            getReaderFileName=lambda: filename)

    def test_airys_pcap_menu_is_available_without_replacing_original_view(self):
        logic, action = self.logic(), Action()
        controller = clearance_live.LiveClearanceController(logic, action)
        self.assertTrue(action.enabled)
        self.assertFalse(action.checked)
        self.assertIsNone(logic.app.railOverlay)

    def test_bin_and_other_lidar_models_cannot_enter_airys_pcap_path(self):
        for filename, model in [('333.bin', 'RSAIRY'), ('333.pcap', 'RS16')]:
            with self.subTest(filename=filename, model=model):
                logic, action = self.logic(filename, model), Action()
                clearance_live.LiveClearanceController(logic, action)
                self.assertFalse(action.enabled)

    def test_enabling_paused_pcap_replaces_view_and_restores_trailing_on_exit(self):
        self.assertTrue(hasattr(clearance_live, 'enable_recorded'), 'PCAP entry is missing')
        logic, action = self.logic(), Action()
        logic.app.railOverlay = Overlay()
        old = logic.app.railOverlay
        controller = clearance_live.LiveClearanceController(logic, action)
        def enable(native_logic):
            native_logic.app.railOverlay.close()
            native_logic.app.railOverlay = Overlay(native_logic.getReader())
            return native_logic.app.railOverlay
        with patch.object(clearance_live, 'enable_recorded', enable):
            controller.toggle(True)
        self.assertTrue(action.checked)
        self.assertTrue(old.closed)
        self.assertIs(controller.overlay.reader, logic.getReader())
        self.assertEqual(logic.getReader().trailing, 0)
        self.assertFalse(logic.app.trailingFramesSpinBox.enabled)
        controller.toggle(False)
        self.assertEqual(logic.getReader().trailing, 17)
        self.assertEqual(logic.app.trailingFramesSpinBox.value, 17)
        self.assertFalse(action.checked)
        self.assertTrue(action.enabled)
        self.assertIsNone(controller.overlay)

    def test_getterless_mismatched_proxy_is_not_guessed_as_native_setting(self):
        logic, action = self.logic(), Action()
        reader = logic.getReader()
        reader.GetNumberOfTrailingFrames = None
        reader.NumberOfTrailingFrames = 0
        controller = clearance_live.LiveClearanceController(logic, action)
        controller.toggle(True)
        self.assertFalse(action.checked)
        self.assertEqual(reader.trailing, 17)
        self.assertEqual(logic.app.numberOfTrailingFrames, 17)
        self.assertIn('reopen', logic.app.statusLabel.text)

    def test_reducing_trailing_invalidates_cached_multi_frame_output(self):
        class CachedReader(Sensor):
            span = (12., 12.9)
            def Modified(self):
                self.span = None
            def UpdatePipeline(self, frame):
                if self.span is None:
                    self.span = (12., 12.+.1*(self.trailing+1))
        logic, action = self.logic(), Action()
        reader = CachedReader()
        reader.trailing = 8
        logic.getReader = lambda: reader
        controller = clearance_live.LiveClearanceController(logic, action)
        controller._save_trailing()
        reader.UpdatePipeline(20)
        self.assertEqual(reader.span, (12., 12.1))
        controller._restore_trailing()

    def test_disable_clears_old_distance_status_for_raw_recording(self):
        logic, action = self.logic(), Action()
        controller = clearance_live.LiveClearanceController(logic, action)
        controller.overlay = logic.app.railOverlay = Overlay()
        logic.app.statusLabel.setText('PCAP REPLAY | CURRENT SCAN | 3 distances')
        controller.toggle(False)
        self.assertNotIn('3 distances', logic.app.statusLabel.text)

    def test_disable_refreshes_paused_legacy_overlay_without_user_stepping(self):
        logic, action = self.logic('22222.pcap'), Action()
        legacy = Overlay()
        legacy.visible = False
        logic.onTimeChanged = lambda: setattr(logic.app.railOverlay, 'visible', True)
        controller = clearance_live.LiveClearanceController(logic, action)
        controller.overlay = logic.app.railOverlay = Overlay()
        def restore(native_logic):
            native_logic.app.railOverlay = legacy
        with patch.object(clearance_live, 'restore_pcap_rail', restore):
            controller.toggle(False)
        self.assertTrue(legacy.visible)


class PlaybackContinuityTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue(hasattr(clearance_native, 'PlaybackScanGate'),
                        'recorded frame continuity gate is absent')
        self.gate = clearance_native.PlaybackScanGate()

    def test_same_frame_is_not_new_evidence_but_next_frame_keeps_history(self):
        self.assertTrue(self.gate.observe(20, (10., 10.1)))
        self.assertFalse(self.gate.discontinuous)
        self.assertFalse(self.gate.observe(20, (10., 10.1)))
        self.assertTrue(self.gate.observe(21, (10.1, 10.2)))
        self.assertFalse(self.gate.discontinuous)

    def test_forward_seek_and_backward_seek_invalidate_temporal_history(self):
        self.gate.observe(20, (10., 10.1))
        self.gate.observe(28, (10.8, 10.9))
        self.assertTrue(self.gate.discontinuous)
        self.gate.observe(21, (10.1, 10.2))
        self.assertTrue(self.gate.discontinuous)

    def test_same_frame_with_changed_device_time_is_new_source_not_duplicate(self):
        self.gate.observe(20, (10., 10.1))
        self.assertTrue(self.gate.observe(20, (90., 90.1)))
        self.assertTrue(self.gate.discontinuous)

    def test_device_clock_reversal_invalidates_even_adjacent_frame_numbers(self):
        self.gate.observe(20, (10., 10.1))
        self.gate.observe(21, (9., 9.1))
        self.assertTrue(self.gate.discontinuous)


class RecordedEngineTests(unittest.TestCase):
    def test_playback_defaults_cannot_load_recording_specific_masks(self):
        from rsview_centerline.clearance.online import OnlineEngine
        try:
            engine = OnlineEngine(source_mode='recorded_pcap')
        except ValueError as error:
            self.fail('ordinary PCAP calculation mode is missing: '+str(error))
        self.assertIsNone(engine.config.confirmed_background_path)
        self.assertIsNone(engine.config.confirmed_measurement_scope_path)

    def test_same_current_cloud_has_identical_live_and_recorded_geometry(self):
        from rsview_centerline.clearance.online import OnlineEngine
        self.assertTrue(hasattr(clearance_native, 'live_measurement_config'),
                        'live and PCAP must use one shared measurement preset')
        config = clearance_native.live_measurement_config()
        live = OnlineEngine(config, source_mode='live')
        recorded = OnlineEngine(config, source_mode='recorded_pcap')
        for seq, stamp in [(20, 10.), (21, 10.2)]:
            a, b = live.process(request(seq, stamp)), recorded.process(request(seq, stamp))
            self.assertEqual(a['centerline'], b['centerline'])
            self.assertEqual(a['measurements'], b['measurements'])
            self.assertEqual(a['motion_status'], b['motion_status'])
            self.assertEqual(b['source_mode'], 'recorded_pcap')
            self.assertFalse(b['absolute_accuracy_verified'])

    def test_recorded_mode_cannot_read_experimental_pose_file(self):
        from rsview_centerline.clearance.online import OnlineEngine
        with self.assertRaisesRegex(ValueError, 'recorded poses require'):
            OnlineEngine(source_mode='recorded_pcap', experimental_pose_path='unused.json')

    def test_actual_playback_worker_drops_inflight_previous_seek_session(self):
        from rsview_centerline.clearance_process import ClearanceProcess
        try:
            host = ClearanceProcess(python=sys.executable, source_mode='recorded_pcap',
                                    config={'live_motion_estimation': True})
        except ValueError as error:
            self.fail('recorded PCAP worker mode is missing: '+str(error))
        try:
            host.submit(request(20, 10., session_id='pcap:one', clock_id='pcap:clock1'))
            host.submit(request(90, 17., session_id='pcap:seek', clock_id='pcap:clock2'))
            until = time.monotonic()+15.
            packet = None
            while time.monotonic() < until:
                packet = host.poll()
                if packet is not None:
                    break
                time.sleep(.005)
            self.assertIsNotNone(packet)
            self.assertEqual(packet['status'], 'completed')
            self.assertEqual((packet['sequence'], packet['session_id'], packet['epoch']),
                             (90, 'pcap:seek', 1))
            self.assertEqual(packet['source_mode'], 'recorded_pcap')
            self.assertTrue(packet['current_source'])
        finally:
            host.close()


class Information:
    def __init__(self, step):
        self.step = step
    def Has(self, key):
        return self.step is not None
    def Get(self, key):
        return self.step


VTK = SimpleNamespace(vtkDataObject=SimpleNamespace(DATA_TIME_STEP=lambda: 'time_step'))


class NativeReader(Sensor):
    def __init__(self):
        super().__init__()
        self.decoded_step = None
    def UpdatePipeline(self, step):
        self.step = step if self.decoded_step is None else self.decoded_step
    def GetOutput(self):
        cloud = NativeCloud([(2., 1., .2)], [10.+self.step*.1])
        cloud.GetInformation = lambda: Information(self.step)
        return cloud


class PlaybackHost:
    def __init__(self):
        self.epoch = 0
        self.current = self.packet = None
        self.requests = []
    def submit(self, identity, force=False, payload_factory=None):
        if self.current and identity['session_id'] != self.current['session_id']:
            self.epoch += 1
        self.current = dict(identity, epoch=self.epoch)
        self.requests.append((identity, force))
        if payload_factory is not None:
            payload_factory()
        return True
    def poll(self):
        packet, self.packet = self.packet, None
        return packet


class RecordedNativeTests(unittest.TestCase):
    def overlay(self):
        overlay = clearance_native.VtkOnlineClearanceOverlay.__new__(
            clearance_native.VtkOnlineClearanceOverlay)
        overlay.__dict__.update(source_mode='recorded_pcap', closed=False, vtk=VTK,
            reader=NativeReader(), playback_gate=clearance_native.PlaybackScanGate(),
            session='pcap:one', clock='pcap:clock1', host=PlaybackHost(),
            last_input=None, requested_frame=None, last_input_at=None, idle_flush_frame=None,
            input_error=None, current={'measurements': [{}]}, last_result={'sequence': 19},
            raw_rep=SimpleNamespace(Visibility=0), raw_visibility=1,
            actors=[Actor()], labels=[], smp=SimpleNamespace(Render=lambda view: None),
            view=None, status_label=Label())
        return overlay

    def test_previous_decoded_frame_cannot_be_labelled_as_requested_frame(self):
        self.assertTrue(hasattr(clearance_native, 'recorded_request'), 'decoded frame guard is missing')
        cloud = NativeCloud([(2., 1., .2)], [10.])
        cloud.GetInformation = lambda: Information(20.)
        with self.assertRaisesRegex(ValueError, 'still decoding'):
            clearance_native.recorded_request(cloud, 28, 'pcap:s', 'clock', VTK)
        payload = clearance_native.recorded_request(cloud, 20, 'pcap:s', 'clock', VTK)
        self.assertEqual(payload['sequence'], 20)
        self.assertEqual(payload['scan_span_s'], (10., 10.))

    def test_forward_seek_clears_actors_and_submits_new_session_immediately(self):
        overlay = self.overlay()
        overlay.update(None, 20)
        session = overlay.session
        overlay.update(None, 28)
        self.assertNotEqual(overlay.session, session)
        self.assertIsNone(overlay.current)
        self.assertIsNone(overlay.last_result)
        self.assertFalse(overlay.actors[0].visible)
        self.assertEqual(overlay.raw_rep.Visibility, 1)
        self.assertEqual(overlay.host.requests[-1][0]['sequence'], 28)
        self.assertTrue(overlay.host.requests[-1][1])

    def test_paused_frame_is_flushed_once_with_original_device_timestamp(self):
        overlay = self.overlay()
        with patch.object(clearance_native.time, 'time', return_value=100.):
            overlay.update(None, 20)
        with patch.object(clearance_native.time, 'time', return_value=100.3):
            overlay.poll()
            overlay.poll()
        self.assertEqual(len(overlay.host.requests), 2)
        self.assertEqual(overlay.host.requests[-1][0]['device_time_s'], 12.)
        self.assertEqual(overlay.host.requests[-1][0]['sequence'], 20)
        self.assertTrue(overlay.host.requests[-1][1])

    def test_decode_failure_hides_old_geometry_and_late_packet_is_not_displayed(self):
        overlay = self.overlay()
        overlay.reader.decoded_step = 20
        overlay.requested_frame = 28
        overlay.host.packet = dict(status='completed', _display={}, sequence=20)
        with patch.object(overlay, 'display_packet') as display:
            overlay.update(None, 28)
        self.assertIsNone(overlay.current)
        self.assertFalse(overlay.actors[0].visible)
        self.assertFalse(display.called)
        self.assertIn('still decoding', overlay.input_error)

    def test_paused_decode_retry_accepts_only_the_requested_frame_when_ready(self):
        overlay = self.overlay()
        overlay.reader.decoded_step = 20
        overlay.update(None, 28)
        self.assertIsNotNone(overlay.input_error)
        overlay.reader.decoded_step = None
        overlay.poll()
        self.assertIsNone(overlay.input_error)
        self.assertEqual(overlay.last_input, 28)
        self.assertEqual(overlay.host.requests[-1][0]['sequence'], 28)

    def test_transient_submit_failure_does_not_commit_unsubmitted_frame(self):
        overlay = self.overlay()
        submit = overlay.host.submit
        failed = [False]
        def once(identity, **kwargs):
            if not failed[0]:
                failed[0] = True
                raise ValueError('native packing not ready')
            return submit(identity, **kwargs)
        overlay.host.submit = once
        overlay.update(None, 20)
        overlay.poll()
        self.assertIsNone(overlay.input_error)
        self.assertEqual(overlay.last_input, 20)
        self.assertEqual(len(overlay.host.requests), 1)
        self.assertEqual(overlay.host.requests[0][0]['sequence'], 20)

    def test_actual_host_retries_payload_failure_after_current_identity_changed(self):
        from rsview_centerline.clearance_process import ClearanceProcess
        host = ClearanceProcess.__new__(ClearanceProcess)
        host.__dict__.update(closed=False, failed=False, current=None, next_time=None,
            last_queued=None, pending=None, result=None, running=None, epoch=0,
            max_points=2000000, period_s=.2, events=deque(), pending_replacements=0,
            _pump=lambda: None, _dispatch=lambda: None)
        overlay = self.overlay()
        overlay.host = host
        overlay.update(None, 20)
        overlay.update(None, 21)  # Genuine cadence skip; not a packing error.
        original = clearance_native.recorded_request
        failed = [False]
        def once(*args):
            if not failed[0]:
                failed[0] = True
                raise ValueError('native packing not ready')
            return original(*args)
        with patch.object(clearance_native, 'recorded_request', once):
            overlay.update(None, 22)
        self.assertIsNone(overlay.input_error)
        self.assertEqual(host.pending['sequence'], 22)
        self.assertEqual(host.last_queued['sequence'], 22)

    def test_actual_dispatch_retains_paused_request_after_transient_ipc_write_error(self):
        from rsview_centerline import clearance_process
        host = clearance_process.ClearanceProcess(python=sys.executable, source_mode='recorded_pcap')
        overlay = self.overlay()
        overlay.host = host
        original = clearance_process._write
        failed = [False]
        def once(path, value):
            if path.endswith('request.pkl') and not failed[0]:
                failed[0] = True
                raise OSError('transient request write failure')
            return original(path, value)
        try:
            with patch.object(clearance_process, '_write', once):
                overlay.update(None, 20)
            self.assertTrue(host.running is not None or host.pending is not None)
            until = time.monotonic()+15.
            packet = None
            while time.monotonic() < until:
                packet = host.poll()
                if packet is not None:
                    break
                time.sleep(.005)
            self.assertIsNotNone(packet)
            self.assertEqual(packet['status'], 'completed')
            self.assertEqual(packet['sequence'], 20)
            self.assertTrue(packet['current_source'])
        finally:
            host.close()

    def test_recovered_copy_does_not_reinstate_late_old_snapshot(self):
        from rsview_centerline.clearance_process import ClearanceProcess
        host = ClearanceProcess.__new__(ClearanceProcess)
        host.__dict__.update(closed=False, failed=False, current=None, next_time=None,
            last_queued=None, pending=None, result=None, running=None, epoch=0,
            max_points=2000000, period_s=.2, events=deque(), pending_replacements=0,
            _pump=lambda: None, _dispatch=lambda: None)
        overlay = self.overlay()
        overlay.host = host
        overlay.update(None, 20)
        old = dict(host.current, status='completed', _display={}, measurements=[])
        overlay.update(None, 21)
        host.result = old
        original = clearance_native.recorded_request
        failed = [False]
        def once(*args):
            if not failed[0]:
                failed[0] = True
                raise ValueError('native packing not ready')
            return original(*args)
        with patch.object(clearance_native, 'recorded_request', once), \
                patch.object(overlay, 'display_packet') as display:
            overlay.update(None, 22)
        self.assertFalse(display.called)
        self.assertIsNone(overlay.last_result)
        self.assertIsNone(overlay.current)

    def test_persistent_ipc_write_error_is_visible_without_stale_geometry(self):
        from rsview_centerline import clearance_process
        host = clearance_process.ClearanceProcess(python=sys.executable, source_mode='recorded_pcap')
        overlay = self.overlay()
        overlay.host = host
        try:
            with patch.object(clearance_process, '_write', side_effect=OSError('request write denied')):
                try:
                    overlay.update(None, 20)
                except OSError as error:
                    self.fail('PCAP poll leaked IPC error instead of reporting it: '+str(error))
            self.assertIsNone(overlay.current)
            self.assertIsNone(overlay.last_result)
            self.assertIsNotNone(overlay.input_error)
            self.assertIn('request write denied', overlay.input_error)
            self.assertIn('PCAP INPUT ERROR', overlay.status_label.text)
        finally:
            host.close()

    def test_playing_after_seek_can_display_new_segment_delayed_snapshot(self):
        overlay = self.overlay()
        overlay.update(None, 20)
        overlay.update(None, 28)
        packet = dict(overlay.host.current, status='completed', _display={}, measurements=[])
        overlay.update(None, 29)
        packet['current_source'] = False
        overlay.host.packet = packet
        with patch.object(overlay, 'display_packet') as display:
            overlay.poll()
        self.assertTrue(display.called)


if __name__ == '__main__':
    unittest.main()
