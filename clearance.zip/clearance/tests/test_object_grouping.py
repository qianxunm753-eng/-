"""Regression scenes for dense scan strips and object-level native boundaries."""
from dataclasses import replace
import unittest
import numpy as np
from unittest.mock import patch
from scipy.spatial import cKDTree

from rsview_centerline.clearance.protocol import Candidate, SceneLayers, TrackUpdate, ClearanceConfig
from rsview_centerline.clearance.scene import extract_scene
from rsview_centerline.clearance.tests.fixtures import cloud, line_track


class ObjectGroupingTests(unittest.TestCase):
    def test_dense_single_cell_does_not_materialize_quadratic_native_pairs(self):
        import rsview_centerline.clearance.scene as scene
        point_counts = []
        class Tree:
            def __init__(self,points):
                self.points, self.tree = points,cKDTree(points)
            def __getattr__(self,key):
                return getattr(self.tree,key)
            def query_pairs(self,*args,**kwargs):
                point_counts.append(len(self.points))
                return self.tree.query_pairs(*args,**kwargs)
        frame = cloud([[2.+i*1e-7,1.,.5] for i in range(1000)])
        with patch.object(scene,'cKDTree',Tree):
            layers=extract_scene(frame,TrackUpdate('observed_dual',line_track()),[],ClearanceConfig())
        self.assertEqual(len(layers.candidates),1)
        self.assertLessEqual(max(point_counts,default=0),10)

    def test_component_partition_matches_exact_native_radius_graph(self):
        from scipy.sparse import coo_matrix
        from scipy.sparse.csgraph import connected_components
        rng=np.random.default_rng(23)
        points=rng.uniform([1.9,.9,.4],[2.3,1.3,.8],(300,3))
        cfg=ClearanceConfig()
        frame=cloud(points)
        layers=extract_scene(frame,TrackUpdate('observed_dual',line_track()),[],cfg)
        radii=cfg.neighbor_base_m+cfg.neighbor_angle_rad*np.linalg.norm(points,axis=1)
        edges=cKDTree(points).query_pairs(float(radii.max()),output_type='ndarray')
        edges=edges[np.linalg.norm(points[edges[:,0]]-points[edges[:,1]],axis=1)<=np.minimum(radii[edges[:,0]],radii[edges[:,1]])]
        graph=coo_matrix((np.ones(len(edges)),(edges[:,0],edges[:,1])),shape=(len(points),len(points)))
        _,labels=connected_components(graph,directed=False)
        expected={frozenset(np.flatnonzero(labels==label)) for label in np.unique(labels)}
        self.assertEqual({frozenset(c.point_indices) for c in layers.candidates},expected)

    def test_voxel_representatives_cannot_drop_a_native_boundary_connection(self):
        frame = cloud([[x, 1., .5] for x in
                       (1.987084926, 2.008178937, 2.077460969, 2.056366958)])
        layers = extract_scene(frame, TrackUpdate('observed_dual',line_track()), [], ClearanceConfig())
        self.assertEqual(len(layers.candidates), 1)
        np.testing.assert_array_equal(layers.candidates[0].point_indices, np.arange(4))

    def test_dense_scan_rows_connect_across_real_neighbor_gap(self):
        # Twelve nearest returns all lie on the same dense row. A real .04 m
        # cross-row connection must not be omitted because of that density.
        frame = cloud([[2., 1.+i*.002, z] for z in (.5, .54) for i in range(80)])
        layers = extract_scene(frame, TrackUpdate('observed_dual', line_track()), [], ClearanceConfig())
        self.assertEqual(len(layers.candidates), 1)
        np.testing.assert_array_equal(np.sort(layers.candidates[0].point_indices), np.arange(160))

    def refine(self, points, groups, supported=None):
        try:
            from rsview_centerline.clearance.objects import refine_objects
        except ImportError as error:
            self.fail('object ownership refinement missing: '+str(error))
        frame = cloud(points)
        candidates = tuple(Candidate('part%d' % i, np.array(g), np.array(g if supported is None else
            [j for j in g if j in supported]), 1., 1., {}) for i, g in enumerate(groups))
        indices = np.arange(len(points))
        layers = SceneLayers({'object': indices, 'ambiguous': np.array([], dtype=int)}, candidates, {})
        return frame, refine_objects(frame, TrackUpdate('observed_dual', line_track()), layers, ClearanceConfig())

    def test_vertically_separated_parts_share_observed_footprint(self):
        frame, layers = self.refine([[2., 1., .2], [2.02, 1.02, .22],
                                    [2., 1., 1.], [2.02, 1.02, 1.02]], [[0, 1], [2, 3]])
        self.assertEqual(len(layers.candidates), 1)
        np.testing.assert_array_equal(layers.candidates[0].point_indices, [0, 1, 2, 3])
        self.assertEqual(layers.candidates[0].diagnostics['member_fragment_ids'], ['part0', 'part1'])

    def test_adjacent_same_side_objects_without_footprint_overlap_remain_separate(self):
        _, layers = self.refine([[2., 1., .2], [2.02, 1.02, .22],
                                [2., 1.3, 1.], [2.02, 1.32, 1.02]], [[0, 1], [2, 3]])
        self.assertEqual(len(layers.candidates), 2)

    def test_overlapping_boxes_do_not_merge_without_vertical_separation(self):
        _, layers = self.refine([[2., 1., .2], [2.04, 1.04, 1.],
                                [2.03, 1.03, .2], [2.07, 1.07, 1.]], [[0, 1], [2, 3]])
        self.assertEqual(len(layers.candidates), 2)

    def test_low_singleton_and_opposite_side_are_not_deleted(self):
        _, layers = self.refine([[2., 1., .03], [-2., 1., 1.]], [[0], [1]])
        self.assertEqual(len(layers.candidates), 2)
        self.assertEqual(sum(len(c.point_indices) for c in layers.candidates), 2)

    def test_group_minimum_uses_original_return_not_group_center(self):
        from rsview_centerline.clearance.measure import measure_candidates
        frame, layers = self.refine([[2., 1., .2], [2.02, 1.02, .22],
                                    [1.98, 1., 1.], [2.02, 1.02, 1.02]], [[0, 1], [2, 3]])
        result = measure_candidates(frame, TrackUpdate('observed_dual', line_track()), layers, ClearanceConfig())
        self.assertEqual(len(result), 1)
        self.assertAlmostEqual(result[0].observed_min_distance_m, 1.98)
        self.assertEqual(result[0].observed_evidence.point_ref.index, 2)

    def test_initialization_does_not_invent_track_footprints(self):
        try:
            from rsview_centerline.clearance.objects import refine_objects
        except ImportError as error:
            self.fail('object ownership refinement missing: '+str(error))
        frame = cloud([[2., 1., .2], [2., 1., 1.]])
        candidates = tuple(Candidate('p%d' % i, np.array([i]), np.array([i]), 1., 1.) for i in range(2))
        layers = SceneLayers({'object': np.array([0, 1])}, candidates, {})
        refined = refine_objects(frame, TrackUpdate('initializing'), layers, ClearanceConfig())
        self.assertEqual(len(refined.candidates), 2)


if __name__ == '__main__':
    unittest.main()
