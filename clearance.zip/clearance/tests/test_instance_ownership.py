"""Qualified object lineage must not be confused with supported distance."""
from dataclasses import dataclass, replace
import unittest
import numpy as np

from rsview_centerline.clearance.protocol import ClearanceConfig, Candidate, SceneLayers, TrackUpdate
from rsview_centerline.clearance.scene import SurfaceTracker
from rsview_centerline.clearance.measure import measure_candidates
from rsview_centerline.clearance.rsview_cache import build_packet
from rsview_centerline.clearance.tests.fixtures import cloud, line_track
from rsview_centerline.clearance.tests.test_surface_tracking import pose


@dataclass(frozen=True)
class InstanceConfig(ClearanceConfig):
    qualified_instance_ownership: bool = True


def parts(frame, groups, roles=()):
    candidates=[]
    for i, indices in enumerate(groups):
        indices=np.asarray(indices,dtype=int)
        diag={'point_role':roles[i]} if roles else {}
        candidates.append(Candidate('part%d'%i,indices,indices,frame.ref_time_s,frame.ref_time_s,diag))
    return SceneLayers({'object':np.arange(len(frame.xyz_L))},tuple(candidates),{}, {})


class InstanceTrackingTests(unittest.TestCase):
    def config(self):
        return InstanceConfig(qualified_object_cores=True,spatial_object_ownership=True,
            display_balance_sides=True,geometry_label_priority=True)

    def test_unknown_role_cannot_create_competing_object_history(self):
        tracker=SurfaceTracker(self.config())
        frame=cloud([[2.,y,.5] for y in np.linspace(.5,.9,9)]+[[2.03,y,.5] for y in np.linspace(.5,.9,9)])
        original=parts(frame,[np.arange(9),np.arange(9,18)],('object','unknown_ground'))
        a=tracker.update(frame,original,pose(frame),line_track())
        self.assertIsNone(a.candidates[1].diagnostics['display_id'])
        current=cloud(frame.xyz_L[:9],sequence=1,time=1.1)
        b=tracker.update(current,parts(current,[np.arange(9)],('object',)),pose(current),line_track(time=1.1))
        self.assertEqual(b.candidates[0].diagnostics['display_id'],a.candidates[0].diagnostics['display_id'])
        self.assertEqual(b.candidates[0].diagnostics['display_association'],'matched')

    def test_reliable_core_association_cannot_be_stolen_by_ambiguous_tail(self):
        tracker=SurfaceTracker(self.config())
        first=cloud([[2.,y,.5] for y in np.linspace(.5,.9,9)]+[[2.13,y,.5] for y in np.linspace(.5,.9,9)])
        a=tracker.update(first,parts(first,[np.arange(9),np.arange(9,18)]),pose(first),line_track())
        current=cloud(first.xyz_L[:9].tolist()+[[2.13,.7,.5]],sequence=1,time=1.1)
        candidate=replace(parts(current,[np.arange(10)]).candidates[0],
                          diagnostics={'ambiguous_indices':np.array([9])})
        layers=SceneLayers({'object':np.arange(10),'ambiguous':np.array([9])},(candidate,),{}, {})
        b=tracker.update(current,layers,pose(current),line_track(time=1.1))
        self.assertEqual(b.candidates[0].diagnostics['display_id'],a.candidates[0].diagnostics['display_id'])
        np.testing.assert_array_equal(b.candidates[0].point_indices,np.arange(10))

    def test_mutually_overlapping_historical_aliases_share_one_lineage(self):
        tracker=SurfaceTracker(self.config())
        first=cloud([[2.,y,.5] for y in np.linspace(.5,.9,9)]+[[2.015,y,.5] for y in np.linspace(.5,.9,9)])
        a=tracker.update(first,parts(first,[np.arange(9),np.arange(9,18)]),pose(first),line_track())
        old_ids={c.diagnostics['display_id'] for c in a.candidates}
        current=cloud(first.xyz_L[:9],sequence=1,time=1.1)
        b=tracker.update(current,parts(current,[np.arange(9)]),pose(current),line_track(time=1.1))
        self.assertIn(b.candidates[0].diagnostics['display_id'],old_ids)
        self.assertEqual(b.candidates[0].diagnostics['display_association'],'matched')
        self.assertEqual(len(tracker.display_regions),1)

    def test_adjacent_distinct_objects_do_not_merge_by_equal_distance(self):
        tracker=SurfaceTracker(self.config())
        first=cloud([[2.,y,.5] for y in (.5,.54,.58)]+[[2.,y,.5] for y in (1.,1.04,1.08)])
        a=tracker.update(first,parts(first,[np.arange(3),np.arange(3,6)]),pose(first),line_track())
        second=cloud(first.xyz_L,sequence=1,time=1.1)
        b=tracker.update(second,parts(second,[np.arange(3),np.arange(3,6)]),pose(second),line_track(time=1.1))
        self.assertEqual(len({c.diagnostics['display_id'] for c in b.candidates}),2)
        self.assertEqual([c.diagnostics['display_id'] for c in a.candidates],
                         [c.diagnostics['display_id'] for c in b.candidates])

    def test_alias_merging_is_complete_link_not_transitive_bridge(self):
        tracker=SurfaceTracker(self.config())
        xyz=[[x,y,.5] for x in (2.,2.055,2.11) for y in np.linspace(.5,.9,9)]
        first=cloud(xyz)
        tracker.update(first,parts(first,[np.arange(9),np.arange(9,18),np.arange(18,27)]),pose(first),line_track())
        second=cloud(xyz,sequence=1,time=1.1)
        tracker.update(second,parts(second,[np.arange(9),np.arange(9,18),np.arange(18,27)]),pose(second),line_track(time=1.1))
        self.assertGreaterEqual(len(tracker.display_regions),2,'a bridge merged distinct end regions')

    def test_alias_constraints_survive_repeated_updates_without_new_observations(self):
        tracker=SurfaceTracker(self.config())
        descriptions=[]
        for shift in (0.,.055,.11):
            points=np.array([[2.+shift+x,y,.5] for x in np.linspace(0.,.1,11) for y in (.5,.52,.54)])
            descriptions.append(dict(points=points,lower=points.min(0),upper=points.max(0),
                                     radius=.07,last_seen=1.))
        tracker._associate_display(descriptions,1.)
        tracker._associate_display([],1.1)
        self.assertEqual(len(tracker.display_regions),2)
        tracker._associate_display([],1.2)
        self.assertEqual(len(tracker.display_regions),2,'merged history became a transitive bridge')

    def test_temporal_only_return_cannot_seed_a_new_object(self):
        tracker=SurfaceTracker(self.config())
        frame=cloud([[2.,.7,.5]])
        layer=parts(frame,[np.array([0])])
        candidate=replace(layer.candidates[0],diagnostics={'support_neighbor_valid':np.array([[False]])})
        result=tracker.update(frame,replace(layer,candidates=(candidate,)),pose(frame),line_track())
        self.assertIsNone(result.candidates[0].diagnostics['display_id'])
        self.assertEqual(tracker.display_regions,{})

    def test_temporal_only_current_subset_can_match_an_observed_object(self):
        tracker=SurfaceTracker(self.config())
        first=cloud([[2.,y,.5] for y in (.5,.6,.7,.8,.9)])
        a=tracker.update(first,parts(first,[np.arange(5)]),pose(first),line_track())
        current=cloud([[2.,.7,.5]],sequence=1,time=1.1)
        layer=parts(current,[np.array([0])])
        candidate=replace(layer.candidates[0],diagnostics={'support_neighbor_valid':np.array([[False]])})
        result=tracker.update(current,replace(layer,candidates=(candidate,)),pose(current),line_track(time=1.1))
        self.assertEqual(result.candidates[0].diagnostics['object_id'],a.candidates[0].diagnostics['object_id'])

    def test_far_history_radius_cannot_confirm_an_incompatible_current_return(self):
        tracker=SurfaceTracker(self.config())
        first=cloud([[4.5,y,.5] for y in (.5,.6,.7)])
        a=tracker.update(first,parts(first,[np.arange(3)]),pose(first),line_track())
        current=cloud([[.59,y,.5] for y in (.5,.6,.7)],sequence=1,time=1.1)
        matrix=np.eye(4);matrix[0,3]=4.
        b=tracker.update(current,parts(current,[np.arange(3)]),pose(current,matrix),line_track(time=1.1))
        self.assertNotEqual(b.candidates[0].diagnostics['object_id'],a.candidates[0].diagnostics['object_id'])

    def aliased_parent_fixture(self):
        tracker=SurfaceTracker(self.config())
        def region(name, xs, radius, constituents=False):
            points=np.array([[x,0.,.5] for x in xs])
            value=dict(id=name,points=points,lower=points.min(0),upper=points.max(0),
                radius=radius,last_seen=1.,first_seen=1.,observations=1,
                anchor_W=points.mean(0),point_times=np.ones(len(points)))
            if constituents:
                value['alias_parts']=[dict(points=points[i:i+1],point_times=np.ones(1),radius=radius)
                                      for i in range(len(points))]
            return value
        tracker.display_regions={'P':region('P',[2.05,2.15],.07,True),
                                 'D':region('D',[1.93,2.04],.03)}
        def description(xs):
            points=np.array([[x,0.,.5] for x in xs])
            return dict(points=points,lower=points.min(0),upper=points.max(0),radius=.07,last_seen=1.1)
        return tracker,description([1.93,2.04,2.10]),description([2.15])

    def test_alias_refresh_uses_each_ambiguous_descriptions_own_masks(self):
        tracker,bridge,unique=self.aliased_parent_fixture()
        try:
            observed=tracker._associate_display([bridge,unique],1.1)
        except (IndexError,KeyError) as error:
            self.fail('another description mask was reused: '+str(error))
        self.assertEqual(observed[0]['display_event'],'ambiguous')
        self.assertEqual(observed[1]['display_id'],'P')
        self.assertTrue(all(np.all(part['point_times']==1.1) for part in tracker.display_regions['P']['alias_parts']))

    def test_unique_child_does_not_erase_exclusive_alias_refresh(self):
        tracker,bridge,unique=self.aliased_parent_fixture()
        tracker._associate_display([unique,bridge],1.1)
        self.assertTrue(all(np.all(part['point_times']==1.1) for part in tracker.display_regions['P']['alias_parts']),
                        'unique update erased a current exclusive bridge refresh')

    def test_equivalent_alias_constraints_do_not_grow_with_repeated_copies(self):
        tracker=SurfaceTracker(self.config())
        points=np.array([[2.,y,.5] for y in (.5,.6,.7)])
        description=dict(points=points,lower=points.min(0),upper=points.max(0),radius=.07,last_seen=1.)
        tracker._associate_display([description],1.)
        for i in range(12):
            now=1.+i*.1
            duplicate=dict(tracker.display_regions[next(iter(tracker.display_regions))])
            duplicate['id']='copy%d'%i
            duplicate.pop('alias_parts',None)
            duplicate['points']=duplicate['points'].copy()
            duplicate['point_times']=duplicate['point_times'].copy()
            tracker.display_regions[duplicate['id']]=duplicate
            tracker._associate_display([dict(description,last_seen=now)],now)
        region=next(iter(tracker.display_regions.values()))
        self.assertEqual(len(tracker.display_regions),1)
        self.assertEqual(len(region.get('alias_parts',())),1)

    def test_alias_constraint_budget_refuses_merge_instead_of_dropping_evidence(self):
        tracker=SurfaceTracker(replace(self.config(),history_max_scans=1))
        descriptions=[]
        for shift in np.arange(5)*.001:
            points=np.array([[2.+shift,y,.5] for y in (.5,.6,.7)])
            descriptions.append(dict(points=points,lower=points.min(0),upper=points.max(0),radius=.07,last_seen=1.))
        tracker._associate_display(descriptions,1.)
        tracker._associate_display([],1.1)
        self.assertGreater(len(tracker.display_regions),1)
        self.assertTrue(all(len(r.get('alias_parts',()))<=4 for r in tracker.display_regions.values()))

    def test_known_split_object_shares_one_id_and_keeps_new_nearer_return(self):
        tracker=SurfaceTracker(self.config())
        first=cloud([[2.,y,.5] for y in np.linspace(.5,1.4,22)])
        a=tracker.update(first,parts(first,[np.arange(22)]),pose(first),line_track())
        current=cloud([[2.,y,.5] for y in (.5,.55,.6)]+[[1.98,y,.5] for y in (1.3,1.35,1.4)],sequence=1,time=1.1)
        track=TrackUpdate('observed_dual',line_track(time=1.1))
        b=tracker.update(current,parts(current,[np.arange(3),np.arange(3,6)]),pose(current),track.model)
        self.assertEqual({c.diagnostics['object_id'] for c in b.candidates},
                         {a.candidates[0].diagnostics['object_id']})
        packet=build_packet(current,track,b,measure_candidates(current,track,b,self.config()),self.config())
        self.assertEqual(len(packet['measurements']),1)
        self.assertAlmostEqual(packet['measurements'][0]['distance_m'],1.98)
        self.assertEqual(packet['measurements'][0]['source_index'],3)
        self.assertEqual(packet['measurements'][0]['source_frame'],1)

    def test_compensated_translation_keeps_local_object_lineage(self):
        tracker=SurfaceTracker(self.config())
        first=cloud([[2.,y,.5] for y in (.5,.6,.7)])
        a=tracker.update(first,parts(first,[np.arange(3)]),pose(first),line_track())
        translation=np.array([.2,.1,0.])
        current=cloud(first.xyz_L-translation,sequence=1,time=1.1)
        matrix=np.eye(4);matrix[:3,3]=translation
        b=tracker.update(current,parts(current,[np.arange(3)]),pose(current,matrix),line_track(time=1.1))
        self.assertEqual(b.candidates[0].diagnostics['object_id'],a.candidates[0].diagnostics['object_id'])
        np.testing.assert_array_equal(b.candidates[0].point_indices,np.arange(3))

    def test_changed_session_cannot_reuse_previous_object_identity(self):
        tracker=SurfaceTracker(self.config())
        first=cloud([[2.,y,.5] for y in (.5,.6,.7)])
        a=tracker.update(first,parts(first,[np.arange(3)]),pose(first),line_track())
        current=cloud(first.xyz_L,sequence=1,time=1.1,session='replacement')
        b=tracker.update(current,parts(current,[np.arange(3)]),pose(current),line_track(time=1.1))
        self.assertNotEqual(b.candidates[0].diagnostics['object_id'],a.candidates[0].diagnostics['object_id'])

    def test_expired_history_does_not_hold_missing_object_lineage(self):
        tracker=SurfaceTracker(self.config())
        first=cloud([[2.,y,.5] for y in (.5,.6,.7)])
        a=tracker.update(first,parts(first,[np.arange(3)]),pose(first),line_track())
        current=cloud(first.xyz_L,sequence=1,time=3.)
        b=tracker.update(current,parts(current,[np.arange(3)]),pose(current),line_track(time=3.))
        self.assertNotEqual(b.candidates[0].diagnostics['object_id'],a.candidates[0].diagnostics['object_id'])

    def test_object_geometry_reports_independent_observed_spatial_variances(self):
        tracker=SurfaceTracker(self.config())
        frame=cloud([[2.,y,z] for y in (.5,.6,.7) for z in (.3,.4,.5)])
        result=tracker.update(frame,parts(frame,[np.arange(9)]),pose(frame),line_track())
        values=result.candidates[0].diagnostics.get('object_spatial_variances')
        self.assertIsNotNone(values)
        self.assertAlmostEqual(values[0],0.)
        self.assertGreater(values[1],.001)

    def test_low_current_object_is_not_rejected_by_size_or_clearance(self):
        tracker=SurfaceTracker(self.config())
        first=cloud([[.75,y,.05] for y in (.5,.6,.7)])
        tracker.update(first,parts(first,[np.arange(3)]),pose(first),line_track())
        current=cloud(first.xyz_L,sequence=1,time=1.1)
        track=TrackUpdate('observed_dual',line_track(time=1.1))
        b=tracker.update(current,parts(current,[np.arange(3)]),pose(current),track.model)
        packet=build_packet(current,track,b,measure_candidates(current,track,b,self.config()),self.config())
        self.assertEqual(len(packet['measurements']),1)
        self.assertAlmostEqual(packet['measurements'][0]['distance_m'],.75)


class InstancePacketTests(unittest.TestCase):
    def test_native_live_and_recorded_preset_enable_the_ownership_gate(self):
        from rsview_centerline.clearance_native import live_measurement_config
        self.assertTrue(live_measurement_config().get('qualified_instance_ownership',False))

    def fixture(self, association='ambiguous',config=None):
        config=config or InstanceConfig(geometry_label_priority=True)
        frame=cloud([[2.,y,.5] for y in (.5,.6,.7,.8)])
        layers=parts(frame,[np.arange(4)])
        diag=dict(display_id='T9',display_association=association,display_observations=3,
                  object_id='T9',object_association=association,object_ownership='single_observed_component')
        layers=replace(layers,candidates=(replace(layers.candidates[0],diagnostics=diag),))
        track=TrackUpdate('observed_dual',line_track())
        results=measure_candidates(frame,track,layers,config)
        return frame,track,layers,results,config

    def test_ambiguous_membership_cannot_be_promoted_by_supported_boundary(self):
        frame,track,layers,results,config=self.fixture()
        packet=build_packet(frame,track,layers,results,config)
        self.assertEqual(packet['measurements'],[])
        self.assertEqual(packet['secondary_measurements'][0]['reason'],'ambiguous_object_ownership')
        self.assertAlmostEqual(packet['secondary_measurements'][0]['observed_min_distance_m'],2.)
        self.assertEqual(packet['secondary_measurements'][0]['source_frame'],0)
        self.assertEqual(packet['secondary_measurements'][0]['source_time_s'],1.)
        self.assertEqual(len(packet['_display']['ambiguous']),4)

    def test_matched_object_keeps_current_minimum_not_historical_or_average(self):
        frame,track,layers,results,config=self.fixture('matched')
        packet=build_packet(frame,track,layers,results,config)
        self.assertEqual(len(packet['measurements']),1)
        self.assertAlmostEqual(packet['measurements'][0]['distance_m'],2.)
        self.assertEqual(packet['measurements'][0].get('object_id'),'T9')
        self.assertEqual(packet['measurements'][0]['source_index'],0)

    def test_default_off_preserves_existing_region_annotations(self):
        frame,track,layers,results,config=self.fixture(config=ClearanceConfig(geometry_label_priority=True))
        self.assertEqual(len(build_packet(frame,track,layers,results,config)['measurements']),1)

    def test_first_observation_is_provisional_not_confirmed_object(self):
        frame,track,layers,results,config=self.fixture('new')
        packet=build_packet(frame,track,layers,results,config)
        self.assertTrue(packet['measurements'][0]['uncertain'])
        self.assertIn('object_identity_pending',packet['measurements'][0]['flags'])

    def test_pending_farther_member_survives_annotation_coalescing(self):
        config=InstanceConfig(geometry_label_priority=True)
        frame=cloud([[2.,y,.5] for y in (.5,.6,.7,.8)]+[[2.03,y,.5] for y in (.5,.6,.7,.8)])
        layer=parts(frame,[np.arange(4),np.arange(4,8)])
        candidates=tuple(replace(c,diagnostics={'display_id':'T%d'%i,'object_id':'T%d'%i,
            'display_association':state,'object_association':state})
            for i,(c,state) in enumerate(zip(layer.candidates,('matched','new'))))
        layer=replace(layer,candidates=candidates)
        track=TrackUpdate('observed_dual',line_track())
        packet=build_packet(frame,track,layer,measure_candidates(frame,track,layer,config),config)
        self.assertEqual(len(packet['measurements']),1)
        self.assertTrue(packet['measurements'][0]['uncertain'])
        self.assertIn('object_identity_pending',packet['measurements'][0]['flags'])
