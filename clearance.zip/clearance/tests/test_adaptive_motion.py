"""Wheel-independent causal deskew: numerical fixtures, not field accuracy."""
from dataclasses import replace
import unittest
import numpy as np

from rsview_centerline.clearance.motion import LiveLidarPoses, deskew_frame
from rsview_centerline.clearance.protocol import CloudFrame, PointRef
from rsview_centerline.clearance.tests.test_live_motion import corner,frame


def matrix(x):
    result=np.eye(4)
    result[0,3]=x
    return result


def accelerating_rows(times=(1.,1.1,1.2,1.3)):
    # Hand-defined x(t)=0.2*(t-1)+(t-1)^2, current x(1.3)=0.15.
    return [dict(sequence=i,time=t,start=t-.05,end=t+.05,
        matrix=matrix(.2*(t-1.)+(t-1.)**2),usable=True,rank=6)
        for i,t in enumerate(times)]


def accelerating_scan():
    # Returns from the same static world point x=2 at t=1.25,1.30,1.35.
    xyz=np.array([[1.8875,.5,.5],[1.85,.5,.5],[1.8075,.5,.5]])
    refs=tuple(PointRef(3,i,t) for i,t in enumerate((1.25,1.3,1.35)))
    return CloudFrame('adaptive',3,1.3,'lidar-adaptive',xyz,refs,None,(1.25,1.35))


class AdaptiveDeskewTests(unittest.TestCase):
    def provider(self,rows=None):
        tracker=LiveLidarPoses()
        tracker.adaptive=True  # Same live provider; existing path currently ignores this.
        tracker.rows=accelerating_rows() if rows is None else rows
        return tracker._poses(accelerating_scan())

    def test_observed_acceleration_removes_within_scan_translation_spread(self):
        original=accelerating_scan()
        result=deskew_frame(original,self.provider())
        np.testing.assert_allclose(result.xyz_L[:,0],[1.85,1.85,1.85],atol=1e-10,
            err_msg='recent two-pose constant velocity leaves an acceleration trail')
        self.assertEqual(result.refs,original.refs)
        np.testing.assert_array_equal(original.xyz_L,accelerating_scan().xyz_L)

    def test_nonuniform_knot_times_use_real_seconds_not_sequence_spacing(self):
        result=deskew_frame(accelerating_scan(),self.provider(accelerating_rows((1.,1.07,1.2,1.3))))
        np.testing.assert_allclose(result.xyz_L[:,0],[1.85,1.85,1.85],atol=1e-10)

    def test_skipped_scan_cadence_can_use_supported_acceleration_without_wheel_speed(self):
        tracker=LiveLidarPoses(adaptive=True)
        tracker.rows=accelerating_rows((1.,1.2,1.7,2.3))
        scan=CloudFrame('adaptive',3,2.3,'lidar-adaptive',
            np.array([[.1875,.5,.5],[.05,.5,.5],[-.0925,.5,.5]]),
            tuple(PointRef(3,i,t) for i,t in enumerate((2.25,2.3,2.35))),None,(2.25,2.35))
        result=deskew_frame(scan,tracker._poses(scan))
        np.testing.assert_allclose(result.xyz_L[:,0],[.05,.05,.05],atol=1e-10,
            err_msg='slow accepted cadence rejected a still-supported causal motion interval')

    def test_individual_stale_gap_cannot_be_hidden_in_a_three_second_window(self):
        provider=self.provider(accelerating_rows((0.,1.1,1.2,1.3))).for_frame(accelerating_scan())
        self.assertAlmostEqual(provider.sample(1.35,1.35).T_WL[0,3],.185)

    def test_reference_pose_and_point_matrices_share_one_causal_curve(self):
        provider=self.provider().for_frame(accelerating_scan())
        poses=provider.point_matrices(accelerating_scan(),np.array([1.25,1.3,1.35]))
        np.testing.assert_allclose(poses[:,0,3],[.1125,.15,.1925],atol=1e-10)
        for i,t in enumerate((1.25,1.3,1.35)):
            np.testing.assert_allclose(provider.sample(t,1.35).T_WL,poses[i],atol=1e-10)

    def test_future_pose_cannot_change_current_acceleration_compensation(self):
        rows=accelerating_rows()+[dict(sequence=4,time=1.5,start=1.45,end=1.55,
            matrix=matrix(9.),usable=True,rank=6)]
        result=deskew_frame(accelerating_scan(),self.provider(rows))
        np.testing.assert_allclose(result.xyz_L[:,0],[1.85,1.85,1.85],atol=1e-10)

    def test_inconsistent_older_knot_rejects_acceleration_not_current_pose(self):
        rows=accelerating_rows()
        rows[0]=dict(rows[0],matrix=matrix(.4))
        provider=self.provider(rows).for_frame(accelerating_scan())
        self.assertAlmostEqual(provider.sample(1.35,1.35).T_WL[0,3],.185)
        self.assertAlmostEqual(provider.sample(1.3,1.35).T_WL[0,3],.15)

    def test_two_knots_keep_the_existing_observed_velocity_model(self):
        provider=self.provider(accelerating_rows()[2:]).for_frame(accelerating_scan())
        self.assertAlmostEqual(provider.sample(1.35,1.35).T_WL[0,3],.185)

    def test_legacy_provider_keeps_existing_interpolation(self):
        tracker=LiveLidarPoses()
        tracker.rows=accelerating_rows()
        result=deskew_frame(accelerating_scan(),tracker._poses(accelerating_scan()))
        np.testing.assert_allclose(result.xyz_L[:,0],[1.8525,1.85,1.8425],atol=1e-10)

    def test_clustered_knots_cannot_extrapolate_acceleration_across_a_long_scan(self):
        times=(1.,1.001,1.002,1.003)
        rows=[dict(sequence=i,time=t,start=t-.05,end=t+.05,
            matrix=matrix(500.*(t-1.)**2),usable=True,rank=6) for i,t in enumerate(times)]
        tracker=LiveLidarPoses(adaptive=True)
        tracker.rows=rows
        scan=replace(accelerating_scan(),ref_time_s=1.003,scan_span_s=(.953,1.053))
        poses=tracker._poses(scan).for_frame(scan)
        self.assertAlmostEqual(poses.sample(1.053,1.053).T_WL[0,3],.1295,places=8,
            msg='short observed knots produced an unsupported metre-scale curve extension')

    def test_large_curve_correction_requires_more_than_a_good_older_knot_fit(self):
        rows=[dict(sequence=i,time=t,start=t-.05,end=t+.05,
            matrix=matrix(500.*(t-1.)**2),usable=True,rank=6)
            for i,t in enumerate((1.,1.1,1.2,1.3))]
        tracker=LiveLidarPoses(adaptive=True)
        tracker.rows=rows
        poses=tracker._poses(accelerating_scan()).for_frame(accelerating_scan())
        self.assertAlmostEqual(poses.sample(1.35,1.35).T_WL[0,3],57.5,places=8,
            msg='curve exceeded the geometric correction trust scale')


class AdaptiveMapTests(unittest.TestCase):
    def tracker(self):
        tracker=LiveLidarPoses()
        tracker.adaptive=True
        return tracker

    def test_small_observed_motion_reuses_map_without_losing_current_pose(self):
        tracker=self.tracker()
        world=corner()
        tracker.update(frame(world,0,1.))
        tracker.update(frame(world,1,1.1))
        poses=tracker.update(frame(world-[0.,0.,.01],2,1.2))
        self.assertTrue(tracker.diagnostics.get('map_cache_hit',False),
            'unchanged local map neighborhoods were recomputed')
        np.testing.assert_allclose(poses.sample(1.2,1.25).T_WL[:3,3],[0.,0.,.01],atol=.005)

    def test_actual_motion_invalidates_reused_map(self):
        tracker=self.tracker()
        world=corner()
        for sequence,t,z in ((0,1.,0.),(1,1.1,0.),(2,1.2,.01),(3,1.3,.2),(4,1.4,.22)):
            poses=tracker.update(frame(world-[0.,0.,z],sequence,t))
        self.assertFalse(tracker.diagnostics.get('map_cache_hit',False))
        np.testing.assert_allclose(poses.sample(1.4,1.45).T_WL[:3,3],[0.,0.,.22],atol=.012)

    def test_stationary_map_refreshes_after_observed_time_budget(self):
        tracker=self.tracker()
        world=corner()
        for sequence,t in enumerate((1.,1.1,1.2,1.5,1.6)):
            tracker.update(frame(world,sequence,t))
        self.assertFalse(tracker.diagnostics.get('map_cache_hit',False))
        self.assertTrue(tracker.diagnostics['usable'])

    def test_clock_reset_cannot_reuse_geometry_from_previous_map(self):
        tracker=self.tracker()
        world=corner()
        for sequence,t in ((0,1.),(1,1.1),(2,1.2)):
            tracker.update(frame(world,sequence,t))
        tracker.update(frame(world,0,.5))
        tracker.update(frame(world,1,.6))
        self.assertFalse(tracker.diagnostics.get('map_cache_hit',False))

    def test_online_configuration_reaches_wheel_independent_motion_provider(self):
        from rsview_centerline.clearance.online import OnlineEngine
        from rsview_centerline.clearance.protocol import ClearanceConfig
        from dataclasses import dataclass
        @dataclass(frozen=True)
        class Config(ClearanceConfig):
            adaptive_motion_compensation: bool = True
        engine=OnlineEngine(Config(live_motion_estimation=True))
        engine._reset(0)
        self.assertTrue(getattr(engine.live_poses,'adaptive',False))

    def test_native_live_and_replay_preset_enable_adaptive_motion(self):
        from rsview_centerline.clearance_native import live_measurement_config
        self.assertTrue(live_measurement_config().get('adaptive_motion_compensation',False))


if __name__=='__main__':
    unittest.main()
