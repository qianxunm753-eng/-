"""Raw historical returns support matching, not object confirmation or distance."""
from dataclasses import asdict, dataclass, replace
import os
import unittest
from unittest.mock import patch
import numpy as np
from rsview_centerline import clearance_native
from rsview_centerline.clearance.history_evidence import qualified_history_instances
from rsview_centerline.clearance.motion import deskew_frame, transform_history
from rsview_centerline.clearance.scene import SurfaceTracker
from rsview_centerline.clearance.tests.fixtures import cloud
from rsview_centerline.clearance.tests.test_history_instance_evidence import (
    HistoryConfig, configuration as history_config, engine, face, AnalyticPoses)


@dataclass(frozen=True)
class RawConfig(HistoryConfig):
    raw_history_identity_support: bool = True


def configuration(enabled=True):
    return RawConfig(**dict(asdict(history_config()),raw_history_identity_support=enabled))


def description(points, radius=.05, can_seed=True):
    points = np.asarray(points,dtype=float).reshape(-1,3)
    return dict(points=points,lower=points.min(0),upper=points.max(0),radius=radius,
                can_seed=can_seed,last_seen=1.)


def raw_part(identity, points, radius=.05):
    # This lower-level seam consumes records already validated in replay.py.
    return dict(object_id=identity,points_W=np.asarray(points,dtype=float),radius_m=radius,
                state='tentative',source_frame=0,source_time_s=1.,independent_geometry=True)


class RawIdentityTests(unittest.TestCase):
    def dense_cold_start(self, enabled):
        worker = engine(configuration(enabled))
        whole = np.array([[2.,y,z] for y in np.arange(.3,2.3,.02)
                          for z in np.arange(.3,2.3,.02)])
        corner = np.array([[2.,.3,2.26],[2.,.3,2.28],[2.,.32,2.28]])
        worker.step(cloud(whole))
        return worker,whole,corner

    def test_cold_start_corner_reuses_observed_id_before_qualification_deadlock(self):
        worker,whole,corner = self.dense_cold_start(True)
        unused,layers,results = worker.step(cloud(corner,sequence=1,time=1.1))
        self.assertEqual(layers.candidates[0].diagnostics['object_id'],'T1',
                         'observed raw corner was lost solely to the representative budget')
        self.assertEqual(len(worker.surface_tracker.display_regions),1)
        self.assertEqual(layers.diagnostics['raw_history_identity_matches'],1)
        self.assertEqual(layers.diagnostics['qualified_history_instances'],0,
                         'one tentative raw scan must not count as qualified confirmation')
        self.assertEqual(results[0].observed_evidence.point_ref.frame,1)
        self.assertEqual(results[0].observed_min_distance_m,2.)
        unused,layers,results = worker.step(cloud(whole,sequence=2,time=1.2))
        self.assertEqual(layers.candidates[0].diagnostics['object_id'],'T1')
        self.assertEqual(len(worker.surface_tracker.display_regions),1)
        self.assertEqual(results[0].observed_evidence.point_ref.frame,2)
        self.assertLessEqual(len(worker.surface_tracker.display_regions['T1']['points']),1024)

    def test_disabled_mode_retains_v23_cold_start_behavior(self):
        worker,whole,corner = self.dense_cold_start(False)
        unused,layers,unused = worker.step(cloud(corner,sequence=1,time=1.1))
        self.assertEqual(layers.candidates[0].diagnostics['object_id'],'T2')
        self.assertNotIn('raw_history_identity_matches',layers.diagnostics)
        unused,layers,unused = worker.step(cloud(whole,sequence=2,time=1.2))
        self.assertEqual(layers.candidates[0].diagnostics['object_association'],'ambiguous')

    def history_fixture(self):
        cfg = configuration()
        worker = engine(cfg)
        worker.step(cloud(face()))
        current = deskew_frame(cloud(face(),sequence=1,time=1.1),AnalyticPoses())
        past = transform_history(worker.object_history,current,AnalyticPoses(),cfg,include_current=False)
        return cfg,current,past

    def raw_instances(self, current, past, cfg):
        from rsview_centerline.clearance.history_evidence import raw_history_identity_instances
        return raw_history_identity_instances(current,[past],cfg)

    def test_tentative_source_can_match_but_not_confirm_and_preserves_original_refs(self):
        cfg,current,past = self.history_fixture()
        raw = self.raw_instances(current,past,cfg)
        self.assertEqual(len(raw),1)
        self.assertEqual(raw[0]['state'],'tentative')
        self.assertEqual(raw[0]['object_id'],'T1')
        self.assertEqual(raw[0]['refs'],past.refs)
        np.testing.assert_array_equal(raw[0]['points_L'],past.xyz_L)
        self.assertEqual(qualified_history_instances(current,[past],cfg),[])

    def test_inconsistent_qualified_state_cannot_weaken_the_two_observation_rule(self):
        cfg,current,past = self.history_fixture()
        record = past.diagnostics['object_proposal_evidence'][0]
        altered = replace(past,diagnostics=dict(past.diagnostics,
            object_proposal_evidence=[dict(record,state='qualified',observations=1)]))
        self.assertFalse(self.raw_instances(current,altered,cfg),
                         'state-only filtering could promote a single observation to confirmation')

    def test_raw_matching_does_not_promote_inconsistent_donors_to_reconciliation(self):
        from rsview_centerline.clearance.tests.test_history_instance_evidence import HistoryReconciliationTests
        worker,whole,unused = HistoryReconciliationTests().dense_history()
        worker.config = replace(worker.config,raw_history_identity_support=True)
        worker.surface_tracker.config = worker.config
        worker.object_history = [replace(frame,diagnostics=dict(frame.diagnostics,
            object_proposal_evidence=[dict(record,observations=1)
                for record in frame.diagnostics.get('object_proposal_evidence',())]))
            for frame in worker.object_history]
        unused,layers,results = worker.step(cloud(whole,sequence=4,time=1.4))
        self.assertEqual(len(worker.surface_tracker.display_regions),2,
                         'invalid single-observation qualified donors collapsed competing IDs')
        self.assertEqual(layers.diagnostics['history_reconciled_region_groups'],0)
        self.assertEqual(layers.diagnostics['qualified_history_instances'],0)
        self.assertEqual(layers.candidates[0].diagnostics['object_association'],'ambiguous')
        self.assertEqual(results[0].observed_evidence.point_ref.frame,4)

    def test_unsafe_source_records_abstain_without_changing_native_returns(self):
        cfg,current,past = self.history_fixture()
        changes = ({'state':'conflicted'},{'state':'inherited'},{'state':'unresolved'},
                   {'observations':0},{'object_id':None},{'valid_until_s':1.09},
                   {'valid_until_s':2.},{'independent_geometry':False},{'geometry_frame':1},
                   {'source_frame':1},{'source_time_s':1.2},{'proof_time_s':.9},
                   {'session_id':'other'},{'clock_id':'other'},{'radius_m':float('nan')})
        record = past.diagnostics['object_proposal_evidence'][0]
        for change in changes:
            with self.subTest(change=change):
                altered = replace(past,diagnostics=dict(past.diagnostics,
                    object_proposal_evidence=[dict(record,**change)]))
                self.assertEqual(self.raw_instances(current,altered,cfg),[])
                np.testing.assert_array_equal(altered.xyz_L,past.xyz_L)

    def test_missing_malformed_duplicate_or_stale_raw_evidence_abstains(self):
        cfg,current,past = self.history_fixture()
        diagnostic = dict(past.diagnostics)
        diagnostic.pop('object_proposal_evidence')
        for case_index,altered in enumerate((replace(past,diagnostics=diagnostic),
                replace(past,diagnostics=dict(past.diagnostics,object_proposal_origin_time_s=['bad']*len(past.refs))),
                replace(past,diagnostics=dict(past.diagnostics,
                    object_proposal_evidence=past.diagnostics['object_proposal_evidence']*2)),
                replace(past,refs=tuple(replace(ref,time_s=.1) for ref in past.refs)),
                replace(past,session_id='another'),replace(past,clock_id='another'))):
            with self.subTest(case_index=case_index):
                self.assertEqual(self.raw_instances(current,altered,cfg),[])

    def test_raw_matching_keeps_smaller_source_radius_and_does_not_persist_old_points(self):
        tracker = SurfaceTracker(configuration())
        seeded = description([[2.,0.,.5]])
        tracker._associate_display([seeded],1.)
        raw = [raw_part('T1',[[2.,1.,.5]],.05)]
        outside = description([[2.06,1.,.5]],.1)
        current = tracker._associate_display([outside],1.1,ownership_points=[outside['points']],
                                              raw_identity_instances=raw)
        self.assertEqual(current[0]['display_event'],'new','raw source radius was enlarged')
        old = tracker.display_regions['T1']
        np.testing.assert_array_equal(old['points'],seeded['points'])
        np.testing.assert_array_equal(old['point_times'],[1.])
        self.assertEqual(old['last_seen'],1.)

    def test_raw_matching_does_not_refresh_unseen_old_returns(self):
        tracker = SurfaceTracker(configuration())
        tracker._associate_display([description([[2.,0.,.5]])],1.)
        observed = description([[2.02,1.,.5]])
        result = tracker._associate_display([observed],1.1,ownership_points=[observed['points']],
            raw_identity_instances=[raw_part('T1',[[2.,1.,.5]])])
        self.assertEqual(result[0]['display_id'],'T1')
        stored = tracker.display_regions['T1']
        self.assertFalse(np.any(np.all(stored['points']==[2.,1.,.5],axis=1)),
                         'old raw return was copied into the current persistent map')
        original = np.flatnonzero(np.all(stored['points']==[2.,0.,.5],axis=1))
        self.assertEqual(stored['point_times'][original[0]],1.)

    def test_temporal_only_current_core_cannot_gain_raw_positive_matching(self):
        tracker = SurfaceTracker(configuration())
        tracker._associate_display([description([[2.,0.,.5]])],1.)
        current = description([[2.,1.,.5]],can_seed=False)
        result = tracker._associate_display([current],1.1,ownership_points=[current['points']],
            raw_identity_instances=[raw_part('T1',current['points'])])
        self.assertIsNone(result[0]['display_id'])
        self.assertEqual(result[0]['display_event'],'temporal_only_unowned')
        self.assertEqual(tracker.display_regions['T1']['last_seen'],1.)

    def test_full_core_checks_small_raw_competitor_even_when_sample_omits_it(self):
        tracker = SurfaceTracker(configuration())
        majority = np.array([[2.,y,.5] for y in np.arange(.3,.7,.02)])
        minority = np.array([[1.8,.3,.5],[1.8,.3,.52],[1.8,.32,.52]])
        tracker._associate_display([description(majority),description([[1.8,2.5,.5]])],1.)
        old_ids = set(tracker.display_regions)
        sample = description(majority)
        result = tracker._associate_display([sample],1.1,
            ownership_points=[np.concatenate([majority,minority])],
            raw_identity_instances=[raw_part('T2',minority)])
        self.assertEqual(result[0]['display_event'],'ambiguous')
        self.assertEqual(set(tracker.display_regions),old_ids,'raw support erased a competitor')
        self.assertEqual(tracker.last_raw_identity_match_count,0)

    def test_raw_identity_with_no_active_region_cannot_resurrect_a_retired_id(self):
        tracker = SurfaceTracker(configuration())
        current = description([[2.,1.,.5]])
        result = tracker._associate_display([current],1.1,ownership_points=[current['points']],
            raw_identity_instances=[raw_part('T999',current['points'])])
        self.assertEqual(result[0]['display_id'],'T1')
        self.assertEqual(result[0]['display_event'],'new')

    def test_bridge_between_distinct_known_devices_stays_conflicted(self):
        worker = engine(configuration())
        a = face()
        b = [[2.,y,z] for y in (1.,1.02,1.04) for z in np.arange(.3,.501,.02)]
        wire = [[2.,y,z] for y in np.arange(.72,1.,.02) for z in np.arange(.3,.501,.02)]
        worker.step(cloud(a+b))
        for sequence in (1,2,3):
            unused,layers,results = worker.step(cloud(a+b+wire,sequence=sequence,time=1.+sequence*.1))
            self.assertEqual(layers.candidates[0].diagnostics['object_association'],'ambiguous')
            self.assertEqual(len(worker.surface_tracker.display_regions),2)
            self.assertEqual(results[0].observed_evidence.point_ref.frame,sequence)
            self.assertEqual(worker.object_history[-1].diagnostics['object_proposal_evidence'][0]['state'],'conflicted')

    def test_native_v24_is_explicit_and_other_modes_do_not_enable_raw_support(self):
        with patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':'v24'}):
            cfg = clearance_native.recorded_measurement_config()
            self.assertTrue(cfg.get('raw_history_identity_support',False))
            self.assertTrue(cfg.get('qualified_history_reconciliation',False))
            self.assertEqual(cfg['config_id'],'rsview-replay-raw-identity-beta-v24')
        for variant in ('v21','v22','v23','0','1'):
            with patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':variant}):
                self.assertFalse(clearance_native.recorded_measurement_config().get('raw_history_identity_support',False))
        self.assertFalse(clearance_native.live_measurement_config().get('raw_history_identity_support',False))

    def test_live_rejects_raw_identity_even_without_other_replay_flags(self):
        from rsview_centerline.clearance.online import OnlineEngine
        with self.assertRaisesRegex(ValueError,'replay-only'):
            OnlineEngine(RawConfig(qualified_history_reconciliation=False),source_mode='live')


if __name__ == '__main__':
    unittest.main()
