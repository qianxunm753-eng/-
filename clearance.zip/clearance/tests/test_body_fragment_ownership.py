"""A small observed face may belong to a body, not an equal-size peer."""
from dataclasses import dataclass, replace
import os
import unittest
from unittest.mock import patch
import numpy as np
from rsview_centerline import clearance_native
from rsview_centerline.clearance.protocol import ClearanceConfig, TrackUpdate
from rsview_centerline.clearance.tests.fixtures import cloud, line_track
from rsview_centerline.clearance.scene import extract_scene
from rsview_centerline.clearance.scene import SurfaceTracker
from rsview_centerline.clearance.objects import refine_objects
from rsview_centerline.clearance.measure import measure_candidates
from rsview_centerline.clearance.rsview_cache import build_packet
from rsview_centerline.clearance.tests.test_instance_ownership import parts
from rsview_centerline.clearance.tests.test_surface_tracking import pose


@dataclass(frozen=True)
class BodyConfig(ClearanceConfig):
    body_fragment_proposals: bool = True


def configuration(enabled=True):
    return BodyConfig(body_fragment_proposals=enabled,above_rail_measurement_only=True,
        qualified_object_cores=True,qualified_instance_ownership=True,spatial_object_ownership=True,
        current_instance_reconciliation=True,surface_object_proposals=True,temporal_object_proposals=True,
        scanline_object_proposals=True,geometry_label_priority=True,display_balance_sides=True)


def face_scene(near=1.998, upper=True):
    body = [[2.,y,z] for y in np.linspace(.8,1.2,21) for z in np.linspace(.2,1.,41)
            if not (.899 < y < 1.101 and .479 < z < .721)]
    if not upper:
        body = [p for p in body if p[2] < .48]
    fragment = [[near,y,z] for y in (.97,.99,1.01,1.03) for z in (.56,.58,.60,.62,.64)]
    return body,fragment


class BodyFragmentTests(unittest.TestCase):
    def evaluate(self, near=1.998, upper=True, cfg=None, unknown=False):
        body,fragment = face_scene(near,upper)
        frame = cloud(body+fragment)
        track = TrackUpdate('observed_dual',line_track())
        config = cfg or configuration()
        layers = extract_scene(frame,track,[],config)
        if unknown:
            small = min(layers.candidates,key=lambda c:len(c.point_indices))
            layers = replace(layers,candidates=tuple(replace(c,diagnostics=dict(c.diagnostics,
                point_role='unknown_ground')) if c is small else c for c in layers.candidates))
        layers = refine_objects(frame,track,layers,config)
        return frame,layers,measure_candidates(frame,track,layers,config),len(body)

    def test_bracketed_middle_fragment_shares_current_body_without_fake_points(self):
        frame,layers,results,first_fragment_index = self.evaluate()
        self.assertEqual(len(layers.candidates),1,'middle face is still incorrectly treated as a peer object')
        self.assertEqual(sorted(layers.candidates[0].point_indices.tolist()),list(range(len(frame.xyz_L))))
        self.assertEqual(results[0].observed_min_distance_m,1.998)
        self.assertEqual(results[0].observed_evidence.point_ref.index,first_fragment_index)
        self.assertFalse(layers.candidates[0].diagnostics['semantic_identity_confirmed'])

    def test_v21_geometry_remains_separate_when_new_rule_is_disabled(self):
        unused,layers,unused,unused = self.evaluate(cfg=configuration(False))
        self.assertEqual(len(layers.candidates),2)

    def test_foreground_object_inside_box_but_off_body_surface_is_not_absorbed(self):
        unused,layers,unused,unused = self.evaluate(near=1.95)
        self.assertEqual(len(layers.candidates),2)

    def test_one_sided_vertical_support_does_not_prove_body_membership(self):
        unused,layers,unused,unused = self.evaluate(upper=False)
        self.assertEqual(len(layers.candidates),2)

    def test_unknown_ground_fragment_cannot_become_a_body_part(self):
        unused,layers,unused,unused = self.evaluate(unknown=True)
        self.assertEqual(len(layers.candidates),2)

    def test_repeated_returns_cannot_invent_independent_fragment_support(self):
        body,unused = face_scene()
        fragment = [[1.998,.99,.60]]*120
        frame = cloud(body+fragment)
        track = TrackUpdate('observed_dual',line_track())
        layers = parts(frame,[np.arange(len(body)),np.arange(len(body),len(body)+len(fragment))])
        result = refine_objects(frame,track,layers,configuration())
        self.assertEqual(len(result.candidates),2)
        self.assertEqual(result.diagnostics['body_fragment_proposal_pairs'],0)

    def test_one_off_surface_core_return_prevents_a_body_claim(self):
        body,fragment = face_scene()
        fragment.append([1.90,.99,.60])
        frame = cloud(body+fragment)
        track = TrackUpdate('observed_dual',line_track())
        layers = parts(frame,[np.arange(len(body)),np.arange(len(body),len(body)+len(fragment))])
        result = refine_objects(frame,track,layers,configuration())
        self.assertEqual(result.diagnostics['body_fragment_proposal_pairs'],0,
                         'a minority competing return was erased by a footprint average')
        self.assertEqual(len(result.candidates),2)

    def test_independent_nested_frames_and_middle_face_are_not_one_body(self):
        a = [[2.,y,z] for y in np.arange(.8,1.201,.02) for z in np.arange(.2,1.001,.02)
             if y<.821 or y>1.179 or z<.241 or z>.959]
        b = [[2.02,y,z] for y in np.arange(.95,1.111,.02) for z in np.arange(.4,.801,.02)
             if y>1.10 or z<.441 or z>.759]
        fragment = [[2.005,y,z] for y in (.97,.99,1.01,1.03) for z in (.56,.58,.60,.62)]
        frame = cloud(a+b+fragment)
        track = TrackUpdate('observed_dual',line_track())
        layers = extract_scene(frame,track,[],configuration())
        self.assertEqual(len(layers.candidates),3,'counterexample must reach the real scene extractor')
        result = refine_objects(frame,track,layers,configuration())
        self.assertEqual(len(result.candidates),3,'projected distant bars falsely absorbed separate components')

    def test_distant_upper_and_lower_returns_are_not_a_local_surface_witness(self):
        body,fragment = face_scene()
        body = [p for p in body if p[2]<.25 or p[2]>.95]
        frame = cloud(body+fragment)
        track = TrackUpdate('observed_dual',line_track())
        layers = parts(frame,[np.arange(len(body)),np.arange(len(body),len(body)+len(fragment))])
        result = refine_objects(frame,track,layers,configuration())
        self.assertEqual(result.diagnostics['body_fragment_proposal_pairs'],0,
                         'far-away projected XY support is not a local connection')
        self.assertEqual(len(result.candidates),2)

    def test_two_current_bodies_cannot_greedily_claim_one_fragment(self):
        body,fragment = face_scene()
        second = [[x+.02,y,z] for x,y,z in body]
        frame = cloud(body+second+fragment)
        groups = [np.arange(len(body)),np.arange(len(body),2*len(body)),
                  np.arange(2*len(body),len(frame.xyz_L))]
        layers = parts(frame,groups)
        track = TrackUpdate('observed_dual',line_track())
        # These descriptions are explicit separate current components; do not
        # resolve their competing claims by list order or the majority density.
        for candidates in (layers.candidates,tuple(reversed(layers.candidates))):
            result = refine_objects(frame,track,replace(layers,candidates=candidates),configuration())
            self.assertEqual(result.diagnostics['body_fragment_proposal_pairs'],0,
                             'an unresolved competing body was chosen by greedy order')

    def test_actual_body_support_does_not_depend_on_first_return_in_voxel(self):
        body,fragment = face_scene(near=1.987)
        track = TrackUpdate('observed_dual',line_track())
        outcomes = []
        for columns in ((2.001,2.019),(2.019,2.001)):
            repeated = [[x,y,z] for unused,y,z in body for x in columns]
            frame = cloud(repeated+fragment)
            layers = extract_scene(frame,track,[],configuration())
            self.assertEqual(len(layers.candidates),2)
            result = refine_objects(frame,track,layers,configuration())
            outcomes.append(result.diagnostics['body_fragment_proposal_pairs'])
        self.assertEqual(outcomes,[1,1],'first-return voxel geometry changed the same real support')

    def historical_fixture(self, sequence=1, time=1.1, cfg=None):
        body,fragment = face_scene()
        frame = cloud(body+fragment,sequence=sequence,time=time)
        groups = [np.arange(len(body)),np.arange(len(body),len(body)+len(fragment))]
        old = cloud(body+fragment,sequence=sequence-1,time=time-.1)
        old = replace(old,ref_time_s=time,motion_status='compensated_history',diagnostics={
            'aligned_to_ref_time_s':time,
            'object_proposal_labels':np.r_[np.zeros(len(body),dtype=int),np.ones(len(fragment),dtype=int)]})
        track = TrackUpdate('observed_dual',line_track(time=time))
        return frame,track,refine_objects(frame,track,parts(frame,groups),cfg or configuration(),[old])

    def test_old_id_conflict_retains_independent_body_proof_but_not_a_one_scan_merge(self):
        unused,unused_track,layers = self.historical_fixture()
        self.assertEqual(len(layers.candidates),2)
        self.assertEqual(layers.diagnostics['body_fragment_proposal_pairs'],1)
        self.assertEqual(layers.diagnostics.get('body_fragment_history_veto_pairs'),1,
                         'a proposal count without its historical veto is misleading')
        links = layers.diagnostics['current_ownership_links']
        self.assertEqual(len(links),1)
        self.assertEqual(set(links[0]['candidate_ids']),{'part0','part1'})

    def test_two_exclusive_current_body_relations_reconcile_ids_with_real_minimum(self):
        cfg = configuration()
        tracker = SurfaceTracker(cfg)
        body,fragment = face_scene()
        first = cloud(body+fragment)
        groups = [np.arange(len(body)),np.arange(len(body),len(body)+len(fragment))]
        tracker.update(first,parts(first,groups),pose(first),line_track())
        frame,track,layers = self.historical_fixture()
        once = tracker.update(frame,layers,pose(frame),track.model)
        self.assertEqual(len({c.diagnostics['object_id'] for c in once.candidates}),2)
        frame,track,layers = self.historical_fixture(sequence=2,time=1.2)
        twice = tracker.update(frame,layers,pose(frame),track.model)
        self.assertEqual(len({c.diagnostics['object_id'] for c in twice.candidates}),1)
        results = measure_candidates(frame,track,twice,cfg)
        packet = build_packet(frame,track,twice,results,cfg)
        self.assertEqual(len(packet['measurements']),1)
        row = packet['measurements'][0]
        self.assertEqual(row['distance_m'],1.998)
        self.assertEqual(row['source_frame'],2)
        self.assertEqual(row['source_index'],len(body))
        self.assertFalse(twice.diagnostics.get('semantic_identity_confirmed',False))

    def test_unproven_middle_scan_breaks_body_confirmation(self):
        cfg = configuration()
        tracker = SurfaceTracker(cfg)
        body,fragment = face_scene()
        first = cloud(body+fragment)
        groups = [np.arange(len(body)),np.arange(len(body),len(body)+len(fragment))]
        tracker.update(first,parts(first,groups),pose(first),line_track())
        for sequence in (1,2,3):
            current_cfg = configuration(False) if sequence == 2 else cfg
            frame,track,layers = self.historical_fixture(sequence=sequence,time=1.+sequence*.1,cfg=current_cfg)
            result = tracker.update(frame,layers,pose(frame),track.model)
        self.assertEqual(len({c.diagnostics['object_id'] for c in result.candidates}),2)

    def test_explicit_v22_enables_body_rule_without_replacing_existing_default(self):
        with patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':'v22'}):
            self.assertTrue(clearance_native.recorded_measurement_config().get('body_fragment_proposals'))
        for variant in ('1','v21','mistyped-version'):
            with self.subTest(variant=variant), patch.dict(os.environ,{'RSVIEW_CLEARANCE_REPLAY_EXPERIMENT':variant}):
                config = clearance_native.recorded_measurement_config()
                self.assertFalse(config.get('body_fragment_proposals',False))
                self.assertTrue(config['above_rail_measurement_only'])
                self.assertTrue(config['config_id'].endswith('v21'))

    def test_body_rule_is_rejected_by_live_engine(self):
        from rsview_centerline.clearance.online import OnlineEngine
        with self.assertRaisesRegex(ValueError,'replay-only'):
            OnlineEngine({'body_fragment_proposals':True},source_mode='live')


if __name__ == '__main__':
    unittest.main()
