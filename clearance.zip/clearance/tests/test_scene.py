"""Catches shape/height gates and silent loss of original sparse boundaries."""
import unittest
from dataclasses import replace
import numpy as np
from rsview_centerline.clearance.protocol import ClearanceConfig, TrackUpdate
from rsview_centerline.clearance.tests.fixtures import cloud, line_track


class SceneTests(unittest.TestCase):
    def test_compact_temporal_support_materializes_only_requested_boundary_ref(self):
        from rsview_centerline.clearance.scene import TemporalSupport
        from rsview_centerline.clearance.protocol import PointRef
        class References:
            def __init__(self): self.reads=[]
            def __getitem__(self,index):
                self.reads.append(index)
                return PointRef(3,index,.9)
        references=References()
        support=TemporalSupport(np.array([1,4,7]),np.array([20,21,22]),references)
        self.assertEqual(references.reads,[])
        self.assertEqual(len(support),3)
        self.assertEqual(list(support),[1,4,7])
        self.assertEqual(support.get(4),(PointRef(3,21,.9),))
        self.assertEqual(support.get(2,()),())
        self.assertEqual(references.reads,[21])

    def test_repeated_returns_do_not_repeat_identical_ground_patch_fits(self):
        from unittest.mock import patch
        from scipy.spatial import cKDTree as RealTree
        x,y = np.meshgrid(np.linspace(-.4,.4,20),np.linspace(-.4,.4,20))
        unique = np.column_stack([x.ravel(),y.ravel(),np.full(x.size,-.1)])
        frame = cloud(np.repeat(unique,5,axis=0))
        model = replace(line_track(),diagnostics={'ground_plane':{'normal_L':[0,0,1],'offset_m':-.1}})
        patch_rows=[]
        class RecordingTree:
            def __init__(self,points): self.tree=RealTree(points)
            def query(self,points,**kwargs):
                if kwargs.get('k') == 20: patch_rows.append(len(points))
                return self.tree.query(points,**kwargs)
            def sparse_distance_matrix(self,other,*args,**kwargs):
                return self.tree.sparse_distance_matrix(other.tree,*args,**kwargs)
            def __getattr__(self,name): return getattr(self.tree,name)
        with patch('rsview_centerline.clearance.scene.cKDTree',RecordingTree):
            layers=self.extract(frame,TrackUpdate('observed_dual',model),[],self.cfg)
        self.assertEqual(layers.counts['ground'],2000)
        self.assertTrue(patch_rows)
        self.assertLessEqual(sum(patch_rows),400,'duplicate returns repeated the same planar work')

    def setUp(self):
        try:
            from rsview_centerline.clearance.scene import extract_scene
        except ImportError as exc:
            self.fail('scene feature missing: '+str(exc))
        self.extract = extract_scene
        self.cfg = ClearanceConfig()

    def test_sparse_low_base_survives_dense_ground(self):
        x, y = np.meshgrid(np.linspace(-4, 4, 100), np.linspace(-4, 4, 100))
        points = np.column_stack([x.ravel(), y.ravel(), np.full(x.size, -.1)])
        points = np.vstack([points, [2, 1, -.07], [2.01, 1.01, -.07]])
        model = replace(line_track(), diagnostics={'ground_plane': {'normal_L': [0,0,1], 'offset_m': -.1}})
        layers = self.extract(cloud(points), TrackUpdate('observed_dual', model), [], self.cfg)
        candidate_indices = np.concatenate([c.point_indices for c in layers.candidates])
        self.assertIn(10000, candidate_indices)
        self.assertIn(10001, candidate_indices)
        self.assertGreater(layers.counts['ground'], 9000)

    def test_unknown_shapes_and_singleton_retained(self):
        f = cloud([[2, 1, 1], [2.01, 1, 1.01], [3, 1, .03], [4, 1, 1.]])
        layers = self.extract(f, TrackUpdate('observed_dual', line_track()), [], self.cfg)
        indices = np.concatenate([c.point_indices for c in layers.candidates])
        np.testing.assert_array_equal(np.sort(indices), [0,1,2,3])
        self.assertTrue(any(len(c.point_indices)==1 for c in layers.candidates))

    def test_large_static_background_retained(self):
        points = [[3., y, z] for y in np.linspace(0,2,20) for z in np.linspace(.5,2,20)]
        layers = self.extract(cloud(points), TrackUpdate('observed_dual', line_track()), [], self.cfg)
        self.assertEqual(sum(len(c.point_indices) for c in layers.candidates), 400)

    def test_initialization_retains_preview_without_fake_track(self):
        layers = self.extract(cloud([[2,1,1]]), TrackUpdate('initializing'), [], self.cfg)
        self.assertEqual(sum(len(c.point_indices) for c in layers.candidates), 1)
        self.assertEqual(layers.diagnostics['roi_source'], 'sensor_preview')

    def test_split_components_do_not_claim_semantic_instance(self):
        layers = self.extract(cloud([[2,1,1], [2.01,1,1], [3,1,1]]),
                              TrackUpdate('observed_dual', line_track()), [], self.cfg)
        self.assertEqual(len(layers.candidates), 2)
        self.assertTrue(all(c.diagnostics['type']=='trackside_object' for c in layers.candidates))

    def test_display_sampling_is_not_measurement_exclusion(self):
        f = cloud([[2,1,1], [2.01,1,1]])
        track = TrackUpdate('observed_dual', line_track())
        a = self.extract(f, track, [], self.cfg)
        b = self.extract(f, track, [], replace(self.cfg, display_voxel_m=.5))
        np.testing.assert_array_equal(a.candidates[0].point_indices, b.candidates[0].point_indices)

    def test_biased_global_plane_does_not_turn_ground_into_object(self):
        x, y = np.meshgrid(np.linspace(-4,4,100), np.linspace(-4,4,100))
        actual_z = -.1+.012*y
        points = np.column_stack([x.ravel(), y.ravel(), actual_z.ravel()])
        points = np.vstack([points, [2,1,-.058], [2.01,1.01,-.05788]])
        # The seed plane is a little tilted relative to the actual ground.
        model = replace(line_track(), diagnostics={'ground_plane': {'normal_L': [0,0,1], 'offset_m': -.1}})
        layers = self.extract(cloud(points), TrackUpdate('observed_dual', model), [], self.cfg)
        candidate_indices = np.concatenate([c.point_indices for c in layers.candidates])
        self.assertIn(10000, candidate_indices)
        self.assertGreater(layers.counts['ground'], 9000)

    def test_curved_ground_is_connected_but_low_base_still_survives(self):
        x,y = np.meshgrid(np.linspace(-4,4,100),np.linspace(-4,4,100))
        z = -.1+.003*y*y
        points = np.column_stack([x.ravel(),y.ravel(),z.ravel()])
        points = np.vstack([points,[2,1,-.067],[2.01,1.01,-.06694]])
        model = replace(line_track(), diagnostics={'ground_plane': {'normal_L': [0,0,1], 'offset_m': -.1}})
        layers = self.extract(cloud(points),TrackUpdate('observed_dual',model),[],self.cfg)
        retained = np.concatenate([c.point_indices for c in layers.candidates])
        self.assertIn(10000,retained)
        self.assertGreater(layers.counts['ground'],9000)

    def test_temporal_support_requires_current_reference_and_old_actual_return(self):
        past = cloud([[2,1,1]],time=.9,sequence=0)
        current = cloud([[2,1,1]],time=1.,sequence=1)
        track = TrackUpdate('observed_dual',line_track())
        aligned = replace(past,ref_time_s=1.,sequence=1,scan_span_s=(.85,1.05),
                          motion_status='compensated_history',
                          diagnostics={'aligned_to_ref_time_s':1.,'history_sequences':[0]})
        layers = self.extract(current,track,[aligned],self.cfg)
        c = layers.candidates[0]
        np.testing.assert_array_equal(c.supported_indices,[0])
        self.assertEqual(c.diagnostics['temporal_support_refs'][0][0],past.refs[0])
        self.assertTrue(layers.diagnostics['temporal_support_used'])
        rejected = self.extract(current,track,[past],self.cfg)
        self.assertEqual(len(rejected.candidates[0].supported_indices),0)

    def test_near_ground_candidate_has_explicit_ambiguity_not_silent_deletion(self):
        model = replace(line_track(),diagnostics={'ground_plane':{'normal_L':[0,0,1],'offset_m':-.1}})
        f = cloud([[2,1,-.07]])
        layers = self.extract(f,TrackUpdate('observed_dual',model),[],self.cfg)
        self.assertIn('ambiguous_surface',layers.candidates[0].diagnostics['flags'])

    def test_ambiguity_lookup_has_no_per_component_global_set_intersection(self):
        from unittest.mock import patch
        f = cloud([[2,1,1],[3,1,1],[4,1,1]])
        with patch('rsview_centerline.clearance.scene.np.intersect1d',side_effect=AssertionError(
                'global layer set intersection per component exceeds the scene work budget')):
            layers = self.extract(f,TrackUpdate('observed_dual',line_track()),[],self.cfg)
        self.assertEqual(len(layers.candidates),3)

    def test_compact_neighbor_support_keeps_original_indices(self):
        from rsview_centerline.clearance.measure import measure_candidates
        f = cloud([[2,1,1],[2.01,1,1],[2.02,1,1]])
        update = TrackUpdate('observed_dual',line_track())
        layers = self.extract(f,update,[],self.cfg)
        candidate = layers.candidates[0]
        self.assertIn('support_neighbor_indices',candidate.diagnostics)
        results = measure_candidates(f,update,layers,self.cfg)
        self.assertTrue(results[0].supported_evidence.support_refs)
        self.assertTrue(all(r.index in (1,2) for r in results[0].supported_evidence.support_refs))

    def test_same_voxel_sparse_surface_is_retained_without_ground_crash(self):
        model=replace(line_track(),diagnostics={'ground_plane':{'normal_L':[0,0,1],'offset_m':-.1}})
        frame=cloud([[2.001,1.001,-.09],[2.002,1.002,-.09],[2.003,1.003,-.09]])
        try:
            layers=self.extract(frame,TrackUpdate('observed_dual',model),[],self.cfg)
        except ValueError as error:
            self.fail('sparse geometry must remain ambiguous, not crash: '+str(error))
        np.testing.assert_array_equal(layers.indices['object'],[0,1,2])
        np.testing.assert_array_equal(layers.indices['ambiguous'],[0,1,2])
        self.assertEqual(layers.counts['ground'],0)

    def test_shallow_returns_do_not_inherit_dense_noiseless_ground_membership(self):
        x,y=np.meshgrid(np.linspace(-4,4,100),np.linspace(-4,4,100))
        ground=np.column_stack([x.ravel(),y.ravel(),np.full(x.size,-.1)])
        model=replace(line_track(),diagnostics={'ground_plane':{'normal_L':[0,0,1],'offset_m':-.1}})
        for height in (.003,.01):
            with self.subTest(height_m=height):
                points=np.vstack([ground,[2,1,-.1+height],[2.01,1.01,-.1+height]])
                layers=self.extract(cloud(points),TrackUpdate('observed_dual',model),[],self.cfg)
                self.assertIn(10000,layers.indices['object'])
                self.assertIn(10001,layers.indices['ambiguous'])
                self.assertGreater(layers.counts['ground'],9000)

    def lower_terrain_scene(self):
        x,y=np.meshgrid(np.linspace(-.5,.5,24),np.linspace(0.,2.,42))
        rail_floor=np.column_stack([x.ravel(),y.ravel(),np.full(x.size,-.1)])
        x,y=np.meshgrid(np.linspace(2.,4.,42),np.linspace(0.,2.,42))
        outer_floor=np.column_stack([x.ravel(),y.ravel(),-.28+.01*y.ravel()])
        return rail_floor,outer_floor

    def test_lower_outer_ground_is_visible_but_not_a_measured_object(self):
        # A single rail-floor proposal must not miss a separate, broad terrain
        # surface 16-18 cm lower. Restoring seed-band-only discovery breaks this.
        main,outer=self.lower_terrain_scene()
        model=replace(line_track(),diagnostics={'ground_plane':{'normal_L':[0,0,1],'offset_m':-.1}})
        layers=self.extract(cloud(np.vstack([main,outer])),TrackUpdate('observed_dual',model),[],self.cfg)
        outer_ground=layers.indices['ground'][layers.indices['ground']>=len(main)]
        self.assertGreater(len(outer_ground),.85*len(outer))
        # Scene context keeps the native returns; excluding candidates is not
        # deleting the ground from the native display channel.
        self.assertEqual(layers.counts['roi'],len(main)+len(outer))

    def test_lower_local_ground_does_not_swallow_low_targets_or_box_lid(self):
        main,outer=self.lower_terrain_scene()
        low=np.array([[2.5,1.,-.24],[2.51,1.01,-.2399]]) # 3 cm above local floor
        x,y=np.meshgrid(np.linspace(2.7,3.5,18),np.linspace(.6,1.4,18))
        # Even the lid is below the rail reference, but NOT the local terrain.
        lid=np.column_stack([x.ravel(),y.ravel(),np.full(x.size,-.21)])
        frame=cloud(np.vstack([main,outer,low,lid]))
        model=replace(line_track(),diagnostics={'ground_plane':{'normal_L':[0,0,1],'offset_m':-.1}})
        layers=self.extract(frame,TrackUpdate('observed_dual',model),[],self.cfg)
        protected=np.arange(len(main)+len(outer),len(frame.xyz_L))
        self.assertTrue(np.isin(protected,layers.indices['object']).all())
        self.assertGreater(np.isin(np.arange(len(main),len(main)+len(outer)),layers.indices['ground']).sum(),.8*len(outer))

    def test_additional_terrain_is_rotation_invariant_and_preserves_original_indices(self):
        from rsview_centerline.clearance.scene import _ground_mask
        main,outer=self.lower_terrain_scene()
        # Airy is mounted sideways; ground is not a native-Z height filter.
        rotation=np.array([[0.,0.,-1.],[0.,1.,0.],[1.,0.,0.]])
        translation=np.array([.3,-.2,.4])
        points=np.vstack([main,outer])@rotation.T+translation
        normal=rotation@np.array([0.,0.,1.])
        plane={'normal_L':normal.tolist(),'offset_m':-.1+float(normal@translation)}
        mask=_ground_mask(points,plane,self.cfg,{})
        self.assertGreater(mask[len(main):].sum(),.85*len(outer))

    def test_isolated_lower_horizontal_patch_is_not_automatically_ground(self):
        main,_=self.lower_terrain_scene()
        x,y=np.meshgrid(np.linspace(2.,2.3,10),np.linspace(.5,.8,10))
        patch=np.column_stack([x.ravel(),y.ravel(),np.full(x.size,-.28)])
        model=replace(line_track(),diagnostics={'ground_plane':{'normal_L':[0,0,1],'offset_m':-.1}})
        layers=self.extract(cloud(np.vstack([main,patch])),TrackUpdate('observed_dual',model),[],self.cfg)
        self.assertTrue(np.isin(np.arange(len(main),len(main)+len(patch)),layers.indices['object']).all())

    def test_dense_shallow_target_on_lower_terrain_is_not_terrain(self):
        main,outer=self.lower_terrain_scene()
        x,y=np.meshgrid(np.linspace(2.7,3.,10),np.linspace(.6,.9,10))
        model=replace(line_track(),diagnostics={'ground_plane':{'normal_L':[0,0,1],'offset_m':-.1}})
        for height in (.003,.01,.03,.05):
            with self.subTest(local_height_m=height):
                target=np.column_stack([x.ravel(),y.ravel(),-.28+.01*y.ravel()+height])
                frame=cloud(np.vstack([main,outer,target]))
                layers=self.extract(frame,TrackUpdate('observed_dual',model),[],self.cfg)
                protected=np.arange(len(main)+len(outer),len(frame.xyz_L))
                self.assertTrue(np.isin(protected,layers.indices['object']).all(),
                                'dense raised surface became ground')

    def test_lower_lid_stays_object_when_surrounding_ground_is_sparse_or_rough(self):
        main,_=self.lower_terrain_scene()
        lx,ly=np.meshgrid(np.linspace(2.5,3.5,22),np.linspace(.5,1.5,22))
        lid=np.column_stack([lx.ravel(),ly.ravel(),np.full(lx.size,-.25)])
        model=replace(line_track(),diagnostics={'ground_plane':{'normal_L':[0,0,1],'offset_m':-.1}})
        for mode in ('sparse','rough'):
            with self.subTest(terrain=mode):
                count=10 if mode=='sparse' else 42
                x,y=np.meshgrid(np.linspace(2.,4.,count),np.linspace(0.,2.,count))
                x,y=x.ravel(),y.ravel()
                if mode=='rough':
                    visible=(x<2.5)|(x>3.5)|(y<.5)|(y>1.5)
                    x,y=x[visible],y[visible]
                z=np.full(len(x),-.28)
                if mode=='rough':
                    z+=np.random.default_rng(1337).uniform(-.04,.04,len(z))
                terrain=np.column_stack([x,y,z])
                frame=cloud(np.vstack([main,terrain,lid]))
                layers=self.extract(frame,TrackUpdate('observed_dual',model),[],self.cfg)
                protected=np.arange(len(main)+len(terrain),len(frame.xyz_L))
                self.assertTrue(np.isin(protected,layers.indices['object']).all(),
                                'visible lower ground evidence was ignored when deleting a lid')

    def test_three_collinear_low_outliers_do_not_veto_a_whole_terrain_surface(self):
        main,outer=self.lower_terrain_scene()
        noise=np.array([[4.05,y,-.30] for y in (.7,.85,1.)])
        model=replace(line_track(),diagnostics={'ground_plane':{'normal_L':[0,0,1],'offset_m':-.1}})
        layers=self.extract(cloud(np.vstack([main,outer,noise])),TrackUpdate('observed_dual',model),[],self.cfg)
        self.assertGreater(np.isin(np.arange(len(main),len(main)+len(outer)),layers.indices['ground']).sum(),.85*len(outer))

    def test_small_lower_corner_does_not_reclassify_whole_outer_terrain_as_a_lid(self):
        main,outer=self.lower_terrain_scene()
        lower=np.array([[1.9,.2,-.34],[2.2,.1,-.34],[2.2,.4,-.34]])
        model=replace(line_track(),diagnostics={'ground_plane':{'normal_L':[0,0,1],'offset_m':-.1}})
        layers=self.extract(cloud(np.vstack([main,outer,lower])),TrackUpdate('observed_dual',model),[],self.cfg)
        self.assertGreater(np.isin(np.arange(len(main),len(main)+len(outer)),layers.indices['ground']).sum(),.85*len(outer))
        self.assertTrue(np.isin(np.arange(len(main)+len(outer),len(main)+len(outer)+3),layers.indices['object']).all())




if __name__ == '__main__':
    unittest.main()
