"""Repeated independent current geometry can reconcile provisional region IDs."""
from dataclasses import dataclass, replace
import unittest
import numpy as np

from rsview_centerline.clearance.protocol import ClearanceConfig, TrackUpdate
from rsview_centerline.clearance.objects import refine_objects
from rsview_centerline.clearance.scene import SurfaceTracker
from rsview_centerline.clearance.measure import measure_candidates
from rsview_centerline.clearance.rsview_cache import build_packet
from rsview_centerline.clearance.tests.fixtures import cloud, line_track
from rsview_centerline.clearance.tests.test_instance_ownership import parts
from rsview_centerline.clearance.tests.test_surface_tracking import pose


@dataclass(frozen=True)
class ReconciliationConfig(ClearanceConfig):
    current_instance_reconciliation: bool = True


def configuration():
    return ReconciliationConfig(qualified_instance_ownership=True, qualified_object_cores=True,
        spatial_object_ownership=True, temporal_object_proposals=True, surface_object_proposals=True,
        geometry_label_priority=True, display_balance_sides=True)


def faces(kind='corner', near=2.):
    a=[[near,y,z] for y in (.3,.4,.5,.6) for z in np.arange(.2,.81,.04)]
    if kind=='corner':
        b=[[x,.7,z] for x in (2.04,2.08,2.12,2.16) for z in np.arange(.2,.81,.04)]
    else:
        b=[[near,y,z] for y in (.72,.82,.92,1.02) for z in np.arange(.2,.81,.04)]
    return a,b


def fixture(kind='corner', sequence=1, time=1.1, near=2., cfg=None):
    a,b=faces(kind,near)
    frame=cloud(a+b,sequence=sequence,time=time)
    layers=parts(frame,[np.arange(len(a)),np.arange(len(a),len(a)+len(b))])
    old=cloud(a+b,sequence=sequence-1,time=time-.1)
    old=replace(old,ref_time_s=time,motion_status='compensated_history',diagnostics={
        'aligned_to_ref_time_s':time,
        'object_proposal_labels':np.r_[np.zeros(len(a),dtype=int),np.ones(len(b),dtype=int)]})
    track=TrackUpdate('observed_dual',line_track(time=time))
    return frame,track,refine_objects(frame,track,layers,cfg or configuration(),[old])


class CurrentReconciliationTests(unittest.TestCase):
    def tracker(self):
        tracker=SurfaceTracker(configuration())
        a,b=faces()
        first=cloud(a+b)
        raw=parts(first,[np.arange(len(a)),np.arange(len(a),len(a)+len(b))])
        tracker.update(first,raw,pose(first),line_track())
        return tracker

    def test_conflicting_old_labels_do_not_erase_independent_current_corner_evidence(self):
        unused,unused_track,layers=fixture()
        # Proposal candidates remain independent until repeated evidence is
        # confirmed; existing historical ownership/measurement rules stay intact.
        self.assertEqual(len(layers.candidates),2)
        links=layers.diagnostics.get('current_ownership_links',[])
        self.assertEqual(len(links),1,'current common edge was discarded by old proposal labels')
        self.assertEqual(set(links[0]['candidate_ids']),{'part0','part1'})

    def test_two_current_corner_observations_reconcile_ids_and_one_current_minimum(self):
        tracker=self.tracker()
        first,track,layers=fixture()
        result=tracker.update(first,layers,pose(first),track.model)
        self.assertEqual(len({c.diagnostics['object_id'] for c in result.candidates}),2,
                         'one current relation prematurely merged historical regions')
        current,track,layers=fixture(sequence=2,time=1.2,near=1.98)
        result=tracker.update(current,layers,pose(current),track.model)
        self.assertEqual(len({c.diagnostics['object_id'] for c in result.candidates}),1,
                         'independently repeated current common edge failed to reconcile IDs')
        packet=build_packet(current,track,result,measure_candidates(current,track,result,configuration()),configuration())
        self.assertEqual(len(packet['measurements']),1)
        self.assertAlmostEqual(packet['measurements'][0]['distance_m'],1.98)
        self.assertEqual(packet['measurements'][0]['source_frame'],2)
        self.assertEqual(packet['measurements'][0]['source_index'],0)
        self.assertEqual(sum(len(c.point_indices) for c in result.candidates),len(current.xyz_L))

    def test_adjacent_coplanar_boxes_have_no_current_link_or_alias_merge(self):
        tracker=SurfaceTracker(configuration())
        for sequence,time in ((0,1.),(1,1.1),(2,1.2)):
            frame,track,layers=fixture('adjacent',sequence,time)
            self.assertEqual(layers.diagnostics.get('current_ownership_links',[]),[])
            result=tracker.update(frame,layers,pose(frame),track.model)
            self.assertEqual(len({c.diagnostics['object_id'] for c in result.candidates}),2)

    def test_missing_current_connection_breaks_confirmation_chain(self):
        tracker=self.tracker()
        frame,track,layers=fixture()
        tracker.update(frame,layers,pose(frame),track.model)
        frame,track,layers=fixture(sequence=2,time=1.2)
        layers=replace(layers,diagnostics=dict(layers.diagnostics,current_ownership_links=[]))
        tracker.update(frame,layers,pose(frame),track.model)
        frame,track,layers=fixture(sequence=3,time=1.3)
        result=tracker.update(frame,layers,pose(frame),track.model)
        self.assertEqual(len({c.diagnostics['object_id'] for c in result.candidates}),2)

    def test_unknown_core_cannot_participate_in_link_confirmation(self):
        tracker=self.tracker()
        for sequence,time in ((1,1.1),(2,1.2)):
            frame,track,layers=fixture(sequence=sequence,time=time)
            candidates=(layers.candidates[0],replace(layers.candidates[1],diagnostics={'point_role':'unknown_ground'}))
            result=tracker.update(frame,replace(layers,candidates=candidates),pose(frame),track.model)
            self.assertIsNone(result.candidates[1].diagnostics['object_id'])
            self.assertEqual(len(tracker.display_regions),2)

    def test_default_off_retains_the_old_conflict_veto(self):
        cfg=replace(configuration(),current_instance_reconciliation=False)
        frame,track,layers=fixture(cfg=cfg)
        self.assertEqual(layers.diagnostics.get('current_ownership_links',[]),[])
        tracker=SurfaceTracker(cfg)
        for sequence,time in ((0,1.),(1,1.1),(2,1.2)):
            frame,track,layers=fixture(sequence=sequence,time=time,cfg=cfg)
            result=tracker.update(frame,layers,pose(frame),track.model)
        self.assertEqual(len({c.diagnostics['object_id'] for c in result.candidates}),2)

    def descriptions(self):
        output=[]
        for shift in (0.,.5,1.):
            points=np.array([[2.,shift+y,.5] for y in (0.,.03,.06)])
            output.append(dict(points=points,lower=points.min(0),upper=points.max(0),
                radius=.05,last_seen=1.,can_seed=True))
        return output

    def test_pairwise_links_do_not_transitively_join_three_regions(self):
        tracker=SurfaceTracker(configuration())
        descriptions=self.descriptions()
        tracker._associate_display(descriptions,1.)
        tracker._associate_display(descriptions,1.1,[(0,1),(1,2)])
        assigned=tracker._associate_display(descriptions,1.2,[(0,1),(1,2)])
        self.assertEqual(len({item['display_id'] for item in assigned}),2)

    def test_constituent_connections_remain_complete_link_across_later_frames(self):
        tracker=SurfaceTracker(configuration())
        descriptions=self.descriptions()
        tracker._associate_display(descriptions,1.)
        for now in (1.1,1.2,1.3,1.4,1.5):
            assigned=tracker._associate_display(descriptions,now,[(0,1),(1,2)])
            self.assertGreaterEqual(len({item['display_id'] for item in assigned}),2,
                'merged A-B lineage erased missing A-C connection on a later scan')

    def test_minority_competing_parent_cannot_be_ignored_for_exclusive_connection(self):
        tracker=SurfaceTracker(configuration())
        def description(ys):
            points=np.array([[2.,y,.5] for y in ys])
            return dict(points=points,lower=points.min(0),upper=points.max(0),radius=.04,
                last_seen=1.,can_seed=True)
        a=description(np.arange(8)*.01)
        b=description([.30,.31])
        c=description([.60,.61,.62])
        tracker._associate_display([a,b,c],1.)
        mixed=description(list(np.arange(8)*.01)+[.30,.31])
        for now in (1.1,1.2):
            tracker._reconcile_current_regions([mixed,c],[(0,1)],now)
        self.assertEqual(len(tracker.display_regions),3,
            'minority old owner was ignored and a mixed current face confirmed a false identity')

    def test_new_constituents_need_their_own_two_complete_observations(self):
        tracker=SurfaceTracker(configuration())
        descriptions=self.descriptions()
        tracker._associate_display(descriptions,1.)
        tracker._associate_display(descriptions,1.1,[(0,1),(0,2)])
        tracker._associate_display(descriptions,1.2,[(0,1),(0,2)])
        self.assertEqual(len(tracker.display_regions),2)
        first_complete=tracker._associate_display(descriptions,1.3,[(0,2),(1,2)])
        self.assertEqual(len({item['display_id'] for item in first_complete}),2,
            'old A-C evidence counted as B-C evidence after adding B to the lineage')
        second_complete=tracker._associate_display(descriptions,1.4,[(0,2),(1,2)])
        self.assertEqual(len({item['display_id'] for item in second_complete}),1)

    def test_fine_region_history_has_a_fixed_representative_budget(self):
        frame=cloud([[2.,y,z] for y in np.arange(.1,2.1,.02) for z in np.arange(.1,2.1,.02)])
        tracker=SurfaceTracker(configuration())
        tracker.update(frame,parts(frame,[np.arange(len(frame.xyz_L))]),pose(frame),line_track())
        self.assertLessEqual(len(next(iter(tracker.display_regions.values()))['points']),1024)

    def test_duplicate_calls_at_same_time_do_not_count_as_second_observation(self):
        tracker=SurfaceTracker(configuration())
        descriptions=self.descriptions()[:2]
        tracker._associate_display(descriptions,1.)
        tracker._associate_display(descriptions,1.1,[(0,1)])
        assigned=tracker._associate_display(descriptions,1.1,[(0,1)])
        self.assertEqual(len({item['display_id'] for item in assigned}),2)

    def test_temporal_only_points_cannot_confirm_a_new_link(self):
        tracker=SurfaceTracker(configuration())
        descriptions=self.descriptions()[:2]
        tracker._associate_display(descriptions,1.)
        descriptions=[dict(d,can_seed=False) for d in descriptions]
        tracker._associate_display(descriptions,1.1,[(0,1)])
        assigned=tracker._associate_display(descriptions,1.2,[(0,1)])
        self.assertEqual(len({item['display_id'] for item in assigned}),2)

    def test_pose_loss_breaks_link_confirmation(self):
        tracker=self.tracker()
        frame,track,layers=fixture()
        tracker.update(frame,layers,pose(frame),track.model)
        bad=replace(pose(frame),usable=False)
        current,track,layers=fixture(sequence=2,time=1.2)
        tracker.update(current,layers,bad,track.model)
        self.assertEqual(tracker.current_link_witnesses,{})

    def test_confirmation_is_auditable_in_current_output(self):
        tracker=self.tracker()
        for sequence,time in ((1,1.1),(2,1.2)):
            frame,track,layers=fixture(sequence=sequence,time=time)
            result=tracker.update(frame,layers,pose(frame),track.model)
        self.assertEqual(result.diagnostics.get('current_reconciled_region_groups'),1)
        packet=build_packet(frame,track,result,measure_candidates(frame,track,result,configuration()),configuration())
        self.assertTrue(packet['measurements'][0].get('object_identity_reconciled'))
        self.assertFalse(result.diagnostics.get('semantic_identity_confirmed',False))

    def test_shared_native_preset_enables_repeated_current_reconciliation(self):
        from rsview_centerline.clearance_native import live_measurement_config
        self.assertTrue(live_measurement_config().get('current_instance_reconciliation',False))

    def test_previously_observed_interior_patches_do_not_spawn_duplicate_ids(self):
        first=cloud([[2.,y,z] for y in np.arange(.3,.901,.02) for z in np.arange(.2,.801,.02)])
        cfg=configuration()
        # A compact fully observed face fits the bounded fine occupancy map.
        # Every specified current patch is an actual subset, not a bbox guess.
        for y,z in ((.42,.34),(.46,.66),(.72,.48),(.84,.74)):
            with self.subTest(y=y,z=z):
                tracker=SurfaceTracker(cfg)
                seed=tracker.update(first,parts(first,[np.arange(len(first.xyz_L))]),pose(first),line_track())
                ids=np.flatnonzero((np.abs(first.xyz_L[:,1]-y)<.025)&(np.abs(first.xyz_L[:,2]-z)<.025))
                current=cloud(first.xyz_L[ids],sequence=1,time=1.1)
                result=tracker.update(current,parts(current,[np.arange(len(ids))]),pose(current),line_track(time=1.1))
                self.assertEqual(result.candidates[0].diagnostics['object_id'],seed.candidates[0].diagnostics['object_id'],
                    'small actually observed interior patch was lost by sparse region representatives')


if __name__=='__main__':
    unittest.main()
