"""The actual native recorded entry must select the new worker and window semantics."""
import importlib
import sys
import time
import unittest
from unittest.mock import patch
from types import SimpleNamespace
from rsview_centerline import clearance_native
from rsview_centerline.clearance.tests.test_online import request
from rsview_centerline.clearance.tests import test_recorded_playback as fixtures


class StopNativeTests(unittest.TestCase):
    def test_actual_worker_selects_parking_engine_for_replay_flag(self):
        from rsview_centerline.clearance_process import ClearanceProcess
        host=ClearanceProcess(python=sys.executable,config={'stop_window_fusion':True},source_mode='recorded_pcap')
        try:
            host.submit(request())
            packet=None;until=time.monotonic()+15.
            while time.monotonic()<until:
                packet=host.poll()
                if packet is not None:break
                time.sleep(.01)
            self.assertIsNotNone(packet)
            self.assertEqual(packet['status'],'completed',packet.get('error'))
            self.assertEqual(packet.get('measurement_basis'),'stop_window','real worker still used current-scan engine')
            self.assertEqual(packet['scope']['sensor_max_range_m'],10.)
        finally:host.close()

    def test_recorded_stop_entry_connects_player_and_never_changes_live_preset(self):
        self.assertTrue(hasattr(clearance_native,'enable_recorded_stop'),'parking native creation entry absent')
        native=fixtures.RecordedNativeTests().overlay()
        app=SimpleNamespace(playing=False,curLidarType='RSAIRY',railOverlay=None,mainView=None,statusLabel=native.status_label)
        logic=SimpleNamespace(app=app,smp=native.smp,vtk=native.vtk,getReader=lambda:native.reader,getReaderFileName=lambda:'200rpm_2.pcap')
        with patch.object(clearance_native,'VtkOnlineClearanceOverlay',return_value=native) as constructor:
            overlay=clearance_native.enable_recorded_stop(logic)
        self.assertIs(overlay.logic,logic)
        kwargs=constructor.call_args.kwargs
        self.assertTrue(kwargs['worker_config']['stop_window_fusion'])
        self.assertEqual(kwargs['worker_config']['sensor_max_range_m'],10.)
        self.assertFalse(clearance_native.live_measurement_config().get('stop_window_fusion',False))

    def test_fused_packet_status_is_window_not_current_scan(self):
        overlay=fixtures.RecordedNativeTests().overlay()
        packet=dict(sequence=40,measurements=[],motion_status='stop_window_aligned',mode='observed_dual',
            current_source=True,measurement_basis='stop_window',timing_ms={},
            stop_window={'state':'stage_preview','scan_count':40,'stage_scans':20,'reference_sequence':1,'elapsed_s':4.})
        status=overlay.packet_status(packet)
        self.assertIn('STOP WINDOW',status)
        self.assertNotIn('CURRENT SCAN',status)

    def test_parking_controller_is_not_available_on_a_live_sensor(self):
        try:module=importlib.import_module('rsview_centerline.clearance_stop')
        except ImportError:self.fail('parking menu controller absent')
        from rsview_centerline.clearance.tests.test_live_clearance import Action,Label
        logic=SimpleNamespace(app=SimpleNamespace(curLidarType='RSAIRY',railOverlay=None,statusLabel=Label()),
            getSensor=lambda:object(),getReader=lambda:None,getReaderFileName=lambda:'')
        action=Action();module.StopClearanceController(logic,action)
        self.assertFalse(action.enabled)

    def test_pending_packet_matches_actual_embedded_display_buffer_contract(self):
        import numpy as np
        from rsview_centerline.clearance.stop_fusion import StopFusionEngine
        from rsview_centerline.clearance_overlay import MemoryPacketCache
        points=np.tile([2.,1.,.3],(43001,1))
        packet=StopFusionEngine({'stop_window_fusion':True}).process(request(0,1.,
            xyz=points,point_times=np.ones(len(points)),rings=None))
        for entry in packet['_display'].values():
            values=MemoryPacketCache().cloud(entry)
            self.assertLessEqual(len(values),60000)
        self.assertEqual(packet['format'],'rsview-clearance-playback-v1')

    def test_paused_status_expires_without_submitting_or_counting_another_scan(self):
        overlay=fixtures.RecordedNativeTests().overlay()
        overlay.last_result=dict(sequence=20,device_time_s=12.,session_id=overlay.session,
            clock_id=overlay.clock,epoch=0,status='completed',measurement_basis='stop_window',
            measurements=[],clouds={},timing_ms={},stop_window=dict(operation_token='first',
                state='awaiting_stationary',scan_count=0,stage_scans=0,elapsed_s=0.,confirmed=False))
        overlay.current=overlay.last_result
        with patch.object(clearance_native,'_clock',return_value=0.):overlay.poll()
        with patch.object(clearance_native,'_clock',return_value=60.1):packet=overlay.poll()
        self.assertEqual(packet['stop_window']['state'],'time_budget_exceeded')
        self.assertGreaterEqual(packet['stop_window']['elapsed_s'],60.)
        self.assertEqual(packet['stop_window']['scan_count'],0)
        self.assertEqual(overlay.host.requests,[],'status timeout invented a scan request')
        self.assertIn('time_budget_exceeded',overlay.status_label.text)

    def test_native_dimension_formatter_honors_window_uncertainty_not_cached_label(self):
        from rsview_centerline.clearance_overlay import measurement_label
        item=dict(display_id='W1',uncertain=True,distance_m=2.,measurement_basis='stop_window',
            label='Window W1 2.000 m')
        self.assertIn('Window pending',measurement_label(item))
        item['uncertain']=False
        self.assertEqual(measurement_label(item),'Window W1 2.000 m')

    def test_status_ticks_do_not_accumulate_transport_age_or_leak_across_operations(self):
        overlay=fixtures.RecordedNativeTests().overlay()
        packet=dict(session_id='s',clock_id='c',epoch=0,measurement_basis='stop_window',
            worker_finished_at=1000.,measurements=[],stop_window=dict(operation_token='one',
                elapsed_s=0.,state='collecting',scan_count=5))
        for elapsed in (0.,10.,20.,30.):
            with patch.object(clearance_native,'_clock',return_value=elapsed), \
                    patch.object(clearance_native.time,'time',return_value=1000.+elapsed):
                overlay._advance_stop_status(packet)
            self.assertAlmostEqual(packet['stop_window']['elapsed_s'],elapsed)
        packet['stop_window']=dict(operation_token='two',elapsed_s=.5,state='collecting',scan_count=5)
        packet['worker_finished_at']=1030.
        with patch.object(clearance_native,'_clock',return_value=30.), \
                patch.object(clearance_native.time,'time',return_value=1030.):
            overlay._advance_stop_status(packet)
        self.assertAlmostEqual(packet['stop_window']['elapsed_s'],.5)

    def test_switching_normal_and_stop_modes_restores_trailing_and_closes_only_owned_overlay(self):
        from rsview_centerline import clearance_live,clearance_stop
        from rsview_centerline.clearance.tests.test_live_clearance import Action,Overlay
        logic=fixtures.RecordedMenuTests().logic()
        normal=clearance_live.LiveClearanceController(logic,Action())
        stop=clearance_stop.StopClearanceController(logic,Action())
        logic.app.clearanceController=normal;logic.app.stopClearanceController=stop
        def enable(native_logic):
            if native_logic.app.railOverlay is not None:native_logic.app.railOverlay.close()
            native_logic.app.railOverlay=Overlay(native_logic.getReader())
            return native_logic.app.railOverlay
        with patch.object(clearance_live,'enable_recorded',enable), \
                patch.object(clearance_stop,'enable_recorded_stop',enable):
            normal.toggle(True);first=normal.overlay
            stop.toggle(True);second=stop.overlay
            self.assertTrue(first.closed)
            self.assertIsNone(normal.overlay)
            self.assertFalse(normal.action.checked)
            self.assertIs(logic.app.railOverlay,second)
            normal.toggle(True)
            self.assertTrue(second.closed)
            self.assertIsNone(stop.overlay)
            self.assertFalse(stop.action.checked)
            normal.toggle(False)
        self.assertEqual(logic.getReader().trailing,17)
        self.assertTrue(logic.app.trailingFramesSpinBox.enabled)

    def test_normal_source_close_disposes_active_stop_window_and_restores_trailing(self):
        from rsview_centerline import clearance_live,clearance_stop
        from rsview_centerline.clearance.tests.test_live_clearance import Action,Overlay
        logic=fixtures.RecordedMenuTests().logic()
        normal=clearance_live.LiveClearanceController(logic,Action())
        stop=clearance_stop.StopClearanceController(logic,Action())
        logic.app.clearanceController=normal;logic.app.stopClearanceController=stop
        def enable(native_logic):
            native_logic.app.railOverlay=Overlay(native_logic.getReader())
            return native_logic.app.railOverlay
        with patch.object(clearance_stop,'enable_recorded_stop',enable):stop.toggle(True)
        owned=stop.overlay
        normal.source_closed()
        self.assertTrue(owned.closed)
        self.assertIsNone(stop.overlay)
        self.assertIsNone(logic.app.railOverlay)
        self.assertEqual(logic.getReader().trailing,17)
        self.assertTrue(logic.app.trailingFramesSpinBox.enabled)


if __name__=='__main__':unittest.main()
