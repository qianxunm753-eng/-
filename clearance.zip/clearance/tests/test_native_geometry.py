"""Catches slant-distance, unsupported extension, ROI and provenance bugs."""
import json
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
import numpy as np
from rsview_centerline.clearance.tests.fixtures import cloud, line_track


class NativeGeometryTests(unittest.TestCase):
    def test_stream_projection_prioritizes_supported_segment_over_clamped_endpoint(self):
        first=line_track(end=(0.,1.,0.))
        second=line_track(start=(10.,2.,0.),end=(10.,3.,0.))
        model=replace(first,segments=first.segments+second.segments)
        projected=self.geo.project_supported(np.array([[1.,2.5,0.],[1.,.5,0.],[1.,4.,0.]]),model)
        np.testing.assert_array_equal(projected.supported,[True,True,False])
        np.testing.assert_array_equal(projected.segment_index,[1,0,0])
        np.testing.assert_allclose(projected.distance_m,[9.,1.,np.sqrt(10.)])

    def test_many_segments_project_with_bounded_working_memory(self):
        import tracemalloc
        points=np.tile([[3.,1.,4.]],(10000,1))
        model=line_track()
        model=replace(model,segments=model.segments*12)
        tracemalloc.start()
        try:
            projected=self.geo.project_supported(points,model)
            _,peak=tracemalloc.get_traced_memory()
        finally:
            tracemalloc.stop()
        np.testing.assert_allclose(projected.distance_m,3.)
        np.testing.assert_array_equal(projected.segment_index,0)
        self.assertLess(peak,8*1024*1024,'projection buffers grow with all segments instead of streaming')

    def setUp(self):
        try:
            from rsview_centerline.clearance import geometry, native, protocol
        except ImportError as exc:
            self.fail("clearance interfaces not implemented: %s" % exc)
        self.geo, self.native, self.proto = geometry, native, protocol

    def test_plane_projection_uses_lateral_not_slant_distance(self):
        p = self.geo.project_supported(np.array([[3., 1., 4.]]), line_track())
        self.assertAlmostEqual(p.distance_m[0], 3., places=9)
        np.testing.assert_allclose(p.foot_L[0], [0, 1, 0], atol=1e-9)
        np.testing.assert_allclose(p.projected_L[0], [3, 1, 0], atol=1e-9)
        self.assertAlmostEqual(p.height_m[0], 4.)
        self.assertTrue(p.supported[0])

    def test_outside_support_is_not_clamped_into_valid_lateral_distance(self):
        p = self.geo.project_supported(np.array([[3., 3., 4.]]), line_track())
        self.assertFalse(p.supported[0])
        self.assertAlmostEqual(p.distance_m[0], np.sqrt(10))

    def test_support_endpoints_are_included(self):
        p = self.geo.project_supported(np.array([[2, 0, 1], [2, 2, 1.]]), line_track())
        np.testing.assert_array_equal(p.supported, [True, True])

    def test_rigid_reference_change_preserves_distance(self):
        r = np.array([[0., 0., 1.], [1., 0., 0.], [0., 1., 0.]])
        t = np.array([2., -4., 7.])
        model = line_track()
        s = model.segments[0]
        moved = replace(s, start_L=r@s.start_L+t, end_L=r@s.end_L+t,
                        left_endpoints_L=s.left_endpoints_L@r.T+t,
                        right_endpoints_L=s.right_endpoints_L@r.T+t,
                        normal_L=r@s.normal_L, across_L=r@s.across_L)
        p = self.geo.project_supported(np.array([[3., 1., 4.]])@r.T+t,
                                       replace(model, segments=(moved,)))
        self.assertAlmostEqual(p.distance_m[0], 3., places=9)

    def test_corridor_is_not_sensor_sphere(self):
        model = line_track(end=(0, 5, 0))
        f = cloud([[4.9, 4.9, 0], [5.01, 1., 0], [5., 1, 9.]])
        keep = self.geo.corridor_indices(f, model, self.proto.ClearanceConfig())
        self.assertIn(0, keep)
        self.assertGreater(np.linalg.norm(f.xyz_L[0]), 5.)
        self.assertNotIn(1, keep)
        self.assertIn(2, keep)  # no fixed object-height exclusion

    def test_corridor_keeps_candidate_beyond_track_support_for_diagnostics(self):
        keep = self.geo.corridor_indices(cloud([[2., 3., 0.]]), line_track(),
                                         self.proto.ClearanceConfig())
        self.assertIn(0, keep)

    def test_frame_clock_and_time_mismatch_rejected(self):
        for bad in (replace(line_track(), ref_time_s=1.01),
                    replace(line_track(), clock_id="computer:receive"),
                    replace(line_track(), session_id="different")):
            with self.assertRaises(ValueError):
                self.geo.corridor_indices(cloud([[2, 1, 0]]), bad,
                                          self.proto.ClearanceConfig())

    def test_invalid_returns_excluded_without_renumbering(self):
        f = cloud([[0, 0, 0], [float('nan'), 0, 0], [2, 1, 0.]])
        self.proto.validate_frame(f)
        keep = self.geo.corridor_indices(f, line_track(), self.proto.ClearanceConfig())
        np.testing.assert_array_equal(keep, [2])
        self.assertEqual(f.refs[keep[0]].index, 2)

    def test_empty_cloud_has_empty_geometry(self):
        p = self.geo.project_supported(np.empty((0, 3)), line_track())
        self.assertEqual(len(p.distance_m), 0)

    def test_invalid_track_models_rejected(self):
        model = line_track()
        for s in (replace(model.segments[0], end_L=np.zeros(3)),
                  replace(model.segments[0], normal_L=np.array([float('nan'), 0, 1])),
                  replace(model.segments[0], normal_L=np.array([0., 1., 0.]))):
            with self.assertRaises(ValueError):
                self.geo.project_supported(np.array([[2., 1., 0.]]),
                                           replace(model, segments=(s,)))

    def test_invalid_rail_endpoints_are_not_valid_track_support(self):
        model=line_track()
        for endpoints in (np.zeros((1,3)),np.full((2,3),np.nan)):
            bad=replace(model,segments=(replace(model.segments[0],left_endpoints_L=endpoints),))
            with self.assertRaises(ValueError):
                self.proto.validate_track(bad)

    def test_metadata_uses_actual_time_buffer_not_stale_range(self):
        with TemporaryDirectory() as temporary:
            folder=Path(temporary);self.write_fixture(folder)
            path=folder/'manifest.json';doc=json.loads(path.read_text())
            doc['frames'][0]['timestamp_range']=[1.,1.1];path.write_text(json.dumps(doc))
            actual=next(self.native.read_native_frames(folder))
            meta=next(self.native.read_native_metadata(folder))
            self.assertEqual(meta.ref_time_s,actual.ref_time_s)
            self.assertEqual(meta.scan_span_s,actual.scan_span_s)

    def write_fixture(self, folder, timestamps=True, short=False):
        xyz = np.array([[0, 0, 0], [2, 1, 0], [float('nan'), 0, 0]], dtype='<f4')
        xyz.tofile(folder/'xyz.bin')
        attrs = {}
        if timestamps:
            np.array([.96, 1., 1.04], dtype='<f8').tofile(folder/'stamp.bin')
            attrs['timestamp'] = dict(file='stamp.bin', dtype='double', components=1, tuples=3)
        np.array([2, 4, 6], dtype='<i4').tofile(folder/'ring.bin')
        attrs['Ring'] = dict(file='ring.bin', dtype='int', components=1, tuples=3)
        manifest = dict(input="test.pcap", error=None, byte_order="little", frames=[
            dict(frame=7, step=1., timestamp_range=[.95, 1.05],
                 xyz=dict(file='xyz.bin', dtype='float', components=3, tuples=4 if short else 3),
                 attributes=attrs)])
        (folder/'manifest.json').write_text(json.dumps(manifest), encoding='utf-8')

    def test_native_preserves_all_raw_returns_and_ring_and_time(self):
        with TemporaryDirectory() as temp:
            folder = Path(temp)
            self.write_fixture(folder)
            f = next(self.native.read_native_frames(folder))
            self.assertEqual(len(f.xyz_L), 3)
            self.assertTrue(np.isnan(f.xyz_L[2, 0]))
            self.assertEqual(f.refs[1].frame, 7)
            self.assertEqual(f.refs[1].index, 1)
            self.assertAlmostEqual(f.refs[1].time_s, 1.)
            np.testing.assert_array_equal(f.rings, [2, 4, 6])
            self.assertEqual(f.motion_status, 'raw')

    def test_native_bad_byte_count_rejected(self):
        with TemporaryDirectory() as temp:
            folder = Path(temp)
            self.write_fixture(folder, short=True)
            with self.assertRaises(ValueError):
                list(self.native.read_native_frames(folder))

    def test_missing_point_time_is_raw_not_deskewed(self):
        with TemporaryDirectory() as temp:
            folder = Path(temp)
            self.write_fixture(folder, timestamps=False)
            f = next(self.native.read_native_frames(folder))
            self.assertIsNone(f.refs[0].time_s)
            self.assertEqual(f.motion_status, 'raw')
            self.assertIn('missing_point_time', f.diagnostics['flags'])


if __name__ == '__main__':
    unittest.main()
