"""Online scheduling and actual isolated Python worker contracts."""
import importlib.util
import os
from pathlib import Path
import sys
import time
import unittest
from unittest.mock import patch
import subprocess

import numpy as np

from rsview_centerline.clearance.tests.test_track import rail_scene


def request(sequence=0, timestamp=1., **changes):
    frame = rail_scene()
    result = dict(sequence=sequence, device_time_s=timestamp,
                  session_id='online:test', clock_id='device:test',
                  xyz=frame.xyz_L, rings=frame.rings,
                  point_times=np.full(len(frame.xyz_L), timestamp),
                  scan_span_s=(timestamp, timestamp))
    result.update(changes)
    return result


class OnlineTests(unittest.TestCase):
    def test_supplied_pose_provider_change_never_interpolates_across_maps(self):
        from rsview_centerline.clearance.online import SuppliedPoses
        from dataclasses import replace
        poses=SuppliedPoses(6)
        base=replace(rail_scene(),clock_id='device:test')
        for timestamp,source in [(1.,'provider-a'),(1.2,'provider-b')]:
            scan=replace(base,ref_time_s=timestamp,scan_span_s=(timestamp,timestamp))
            poses.add(dict(matrix=np.eye(4),time_s=timestamp,usable=True,source=source),scan)
        self.assertIsNone(poses.sample(1.1,1.2))
        self.assertIsNone(poses.sample(1.,1.2))

    def test_empty_supplied_trajectory_clears_old_coverage(self):
        from rsview_centerline.clearance.online import SuppliedPoses
        poses=SuppliedPoses(6)
        scan=rail_scene()
        timestamp=scan.ref_time_s
        poses.add(dict(samples=[dict(time_s=timestamp,matrix=np.eye(4))],usable=True),scan)
        self.assertIsNotNone(poses.sample(timestamp,scan.scan_span_s[1]))
        poses.add(dict(samples=[]),scan)
        self.assertIsNone(poses.sample(timestamp,scan.scan_span_s[1]))

    def test_live_uncompensated_candidate_is_visible_but_not_confirmed(self):
        from rsview_centerline.clearance.online import OnlineEngine
        frame=rail_scene()
        objects=np.array([[x,1.8+y,z] for x in np.linspace(-.2,.2,8)
                         for y in (0.,.01) for z in np.linspace(1.,1.2,8)])
        xyz=np.vstack((frame.xyz_L,objects))
        packet=OnlineEngine(dict(sensor_max_range_m=5.,live_motion_estimation=True)).process(
            request(xyz=xyz,point_times=np.ones(len(xyz)),rings=None))
        self.assertTrue(packet['measurements'])
        self.assertTrue(all(m['uncertain'] for m in packet['measurements']))
        self.assertTrue(all('relative_motion_unavailable' in m['flags'] for m in packet['measurements']))
        self.assertAlmostEqual(packet['measurements'][0]['distance_m'],1.8,delta=.01)

    def test_live_crop_keeps_native_minimum_provenance_not_renumbered_returns(self):
        from rsview_centerline.clearance.online import OnlineEngine
        from dataclasses import replace
        frame = rail_scene()
        # A far prefix must not renumber the surviving native rail references.
        xyz = np.vstack(([[100.,100.,100.]], frame.xyz_L))
        engine = OnlineEngine(dict(sensor_max_range_m=5.))
        packet = engine.process(request(xyz=xyz, point_times=np.ones(len(xyz)), rings=None))
        cropped = engine.engine.measurement_frame
        self.assertLess(len(cropped.xyz_L), len(xyz))
        for i, reference in enumerate(cropped.refs):
            np.testing.assert_array_equal(cropped.xyz_L[i], xyz[reference.index])
        self.assertEqual(packet['input_points'], len(xyz))
        self.assertEqual(packet['retained_points'], len(cropped.xyz_L))

    def test_subperiod_lazy_submit_does_not_copy_native_cloud(self):
        host = self.host()
        self.assertTrue(host.submit(request(0,1.)))
        # The callback raises if a sub-period scan tries to pack its buffers.
        def forbidden_copy():
            self.fail('subperiod native cloud was serialized')
        identity = dict(sequence=1,device_time_s=1.1,session_id='online:test',clock_id='device:test')
        self.assertFalse(host.submit(identity, payload_factory=forbidden_copy))
        packet = self.await_packet(host)
        self.assertFalse(packet['current_source'])
        self.assertEqual(host.current['sequence'],1)

    def test_explicit_trajectory_deskews_scan_and_preserves_causal_identity(self):
        from rsview_centerline.clearance.online import SuppliedPoses
        from rsview_centerline.clearance.motion import deskew_frame
        from dataclasses import replace
        frame = rail_scene()
        frame = replace(frame, ref_time_s=1.,scan_span_s=(.9,1.1),clock_id='device:test',
            refs=tuple(replace(r,time_s=.9 if i%2==0 else 1.1) for i,r in enumerate(frame.refs)))
        first,last = np.eye(4),np.eye(4)
        last[2,3]=.2
        poses=SuppliedPoses(6)
        poses.add(dict(samples=[dict(time_s=.9,matrix=first.tolist()),
                                dict(time_s=1.1,matrix=last.tolist())],
            usable=True, clock_id=frame.clock_id,available_until_s=1.1,
            source='test_continuous'),frame)
        corrected=deskew_frame(frame,poses)
        self.assertEqual(corrected.motion_status,'deskewed_experimental')
        np.testing.assert_allclose(corrected.xyz_L[0]-frame.xyz_L[0],[0.,0.,-.1],atol=1e-9)
        np.testing.assert_allclose(corrected.xyz_L[1]-frame.xyz_L[1],[0.,0.,.1],atol=1e-9)
        self.assertIsNone(poses.sample(1.2,1.1))
        self.assertIsNone(poses.sample(1.,1.))

    def test_live_defaults_do_not_load_experimental_recording_measurement_roi(self):
        from rsview_centerline.clearance.online import OnlineEngine
        cfg=OnlineEngine(source_mode='live').config
        self.assertIsNone(cfg.confirmed_background_path)
        self.assertIsNone(cfg.confirmed_measurement_scope_path)

    def setUp(self):
        self.assertIsNotNone(importlib.util.find_spec('rsview_centerline.clearance.online'),
                             'online current-cloud engine is required')
        self.assertIsNotNone(importlib.util.find_spec('rsview_centerline.clearance_process'),
                             'nonblocking Python2 host is required')
        from rsview_centerline.clearance.online import OnlineEngine
        from rsview_centerline.clearance_process import ClearanceProcess
        self.engine_type, self.host_type = OnlineEngine, ClearanceProcess
        self.hosts = []

    def tearDown(self):
        for host in getattr(self, 'hosts', []):
            host.close()

    def host(self, **kwargs):
        host = self.host_type(python=sys.executable, **kwargs)
        self.hosts.append(host)
        return host

    def await_packet(self, host, timeout=15.):
        until = time.monotonic()+timeout
        while time.monotonic() < until:
            packet = host.poll()
            if packet is not None:
                return packet
            time.sleep(.005)
        self.fail('owned online worker returned no packet: '+str(host.diagnostics()))

    def test_current_cloud_computation_is_raw_without_pose(self):
        packet = self.engine_type().process(request(), epoch=0)
        self.assertEqual(packet['calculation'], 'online_current_cloud')
        self.assertEqual(packet['motion_status'], 'raw')
        self.assertEqual(packet['pose_scope'], 'unavailable_uncompensated')
        self.assertEqual(packet['mode'], 'observed_dual')
        self.assertFalse(packet['live_0_2s_verified'])
        self.assertEqual(packet['session_id'], 'online:test')
        self.assertNotIn('observation_refs', packet)
        for layer in packet['_display'].values():
            self.assertLessEqual(layer['count'], 20000)
            self.assertEqual(len(layer['data']), layer['count']*12)

    def test_recorded_pose_lookup_requires_explicit_simulation(self):
        with self.assertRaises(ValueError):
            self.engine_type(source_mode='live', experimental_pose_path='recorded.json')

    def test_explicit_causal_pose_is_accepted_without_recorded_lookup(self):
        pose = dict(matrix=np.eye(4).tolist(), time_s=1., clock_id='device:test',
                    coverage_s=(1.,1.), available_until_s=1., source='supplied_test', usable=True)
        packet = self.engine_type().process(request(pose=pose), epoch=0)
        self.assertEqual(packet['pose_scope'], 'explicit_supplied_pose')
        self.assertEqual(packet['motion_status'], 'deskewed_experimental')
        self.assertFalse(packet['absolute_accuracy_verified'])

    def test_bounded_input_rejects_oversize_without_subsampling_minima(self):
        host = self.host(max_points=10)
        with self.assertRaises(ValueError):
            host.submit(request())
        self.assertIsNone(host.diagnostics()['running'])

    def test_trigger_uses_device_period_and_one_latest_pending(self):
        host = self.host()
        self.assertTrue(host.submit(request(0,1.)))
        self.assertFalse(host.submit(request(1,1.1)))
        self.assertTrue(host.submit(request(2,1.2)))
        self.assertTrue(host.submit(request(4,1.4)))
        state = host.diagnostics()
        self.assertEqual(state['running']['sequence'], 0)
        self.assertEqual(state['pending']['sequence'], 4)
        self.assertEqual(state['pending_replacements'], 1)
        first = self.await_packet(host)
        self.assertEqual(first['sequence'], 0)
        self.assertFalse(first['current_source'])
        self.assertFalse(first['fresh_distance'])
        second = self.await_packet(host)
        self.assertEqual(second['sequence'], 4)
        self.assertTrue(second['current_source'])
        self.assertLessEqual(len(list(Path(host.directory).iterdir())), 5)

    def test_paused_refresh_computes_final_subperiod_scan_once_without_fabricating_time(self):
        host = self.host()
        self.assertTrue(host.submit(request(0,1.)))
        self.assertFalse(host.submit(request(1,1.1)))
        self.assertTrue(host.submit(request(1,1.1),force=True))
        self.assertFalse(host.submit(request(1,1.1),force=True))
        self.assertEqual(host.diagnostics()['pending']['sequence'],1)
        first = self.await_packet(host)
        self.assertEqual(first['sequence'],0)
        final = self.await_packet(host)
        self.assertEqual(final['sequence'],1)
        self.assertEqual(final['device_time_s'],1.1)
        self.assertTrue(final['current_source'])
        self.assertEqual(host.next_time,1.2)
        self.assertFalse(host.submit(request(1,1.1),force=True))

    def test_actual_process_result_has_exact_identity_and_closes_owned_resources(self):
        host = self.host()
        directory, child = Path(host.directory), host.child
        host.submit(request(91,10.))
        packet = self.await_packet(host)
        self.assertEqual((packet['sequence'], packet['device_time_s'], packet['session_id']),
                         (91,10.,'online:test'))
        self.assertTrue(packet['current_source'])
        self.assertGreaterEqual(packet['result_age_s'], 0.)
        self.assertGreater(packet['timing_ms']['compute'], 0.)
        host.close()
        self.assertIsNotNone(child.poll())
        self.assertFalse(directory.exists())
        host.close()

    def test_reset_cannot_publish_old_epoch_or_track_history(self):
        host = self.host()
        host.submit(request(10,5.))
        host.submit(request(1,1., xyz=np.empty((0,3)), point_times=np.empty(0),
                            rings=None, clock_id='reset:device'))
        packet = self.await_packet(host)
        self.assertEqual(packet['sequence'],1)
        self.assertEqual(packet['clock_id'],'reset:device')
        self.assertEqual(packet['epoch'],1)
        self.assertEqual(packet['mode'],'initializing')
        self.assertTrue(packet['current_source'])

    def test_worker_death_reports_failure_with_source_identity(self):
        host = self.host()
        host.submit(request(7,2.))
        host.child.terminate()
        host.child.wait(timeout=5)
        packet = self.await_packet(host)
        self.assertEqual(packet['sequence'], 7)
        self.assertEqual(packet['status'], 'failed')
        self.assertFalse(packet['fresh_distance'])
        self.assertIn('exited',packet['error'])

    def test_same_native_sequence_with_new_time_resets_source_epoch(self):
        host = self.host()
        host.submit(request(10,5.))
        host.submit(request(10,5.2,xyz=np.empty((0,3)), point_times=np.empty(0),rings=None))
        packet = self.await_packet(host)
        self.assertEqual(packet['epoch'],1)
        self.assertEqual(packet['mode'],'initializing')

    def test_same_frame_poll_keeps_progress_and_subperiod_frame_marks_old_result_stale(self):
        host = self.host()
        self.assertTrue(host.submit(request(0,1.)))
        self.assertFalse(host.submit(request(0,1.)))
        self.assertFalse(host.submit(request(1,1.1)))
        packet = self.await_packet(host)
        self.assertEqual(packet['sequence'],0)
        self.assertFalse(packet['current_source'])
        self.assertFalse(packet['fresh_distance'])

    def test_slow_real_worker_does_not_block_submit_or_poll(self):
        real_popen = subprocess.Popen
        library = str(Path(sys.prefix)/'Lib'/'site-packages')
        def start_slow(args, **kwargs):
            code = ("import site,sys,time; site.addsitedir(%r); "
                    "from rsview_centerline.clearance.online import OnlineEngine; "
                    "from rsview_centerline.clearance_process import run; "
                    "original=OnlineEngine.process; "
                    "OnlineEngine.process=lambda self,*a,**k: (time.sleep(.5),original(self,*a,**k))[1]; "
                    "run(sys.argv[1],int(sys.argv[2]))") % library
            return real_popen([args[0],'-c',code,args[-2],args[-1]], **kwargs)
        with patch('rsview_centerline.clearance_process.subprocess.Popen', side_effect=start_slow):
            host = self.host()
        frame = request()
        durations = []
        for seq in range(8):
            frame.update(sequence=seq,device_time_s=1.+seq*.2,
                         scan_span_s=(1.+seq*.2,1.+seq*.2),
                         point_times=np.full(len(frame['xyz']),1.+seq*.2))
            started = time.perf_counter()
            host.submit(frame)
            host.poll()
            durations.append(time.perf_counter()-started)
        self.assertLess(max(durations), .1)
        self.assertEqual(host.diagnostics()['pending']['sequence'],7)
        first = self.await_packet(host)
        self.assertEqual(first['sequence'],0)
        self.assertFalse(first['current_source'])
        second = self.await_packet(host)
        self.assertEqual(second['sequence'],7)
        self.assertTrue(second['current_source'])
        self.assertEqual(host.diagnostics()['pending_replacements'],6)

    def test_timeout_stops_only_owned_worker_and_reports_failure(self):
        host = self.host(worker_timeout_s=.05)
        host.submit(request())
        until = time.monotonic()+2.
        packet = None
        while packet is None and time.monotonic()<until:
            packet = host.tick()
            time.sleep(.005)
        self.assertIsNotNone(packet)
        self.assertEqual(packet['status'],'failed')
        self.assertIn('timeout',packet['error'])
        self.assertFalse(packet['fresh_distance'])

    def test_future_explicit_pose_is_rejected(self):
        pose = dict(matrix=np.eye(4).tolist(),time_s=1.,clock_id='device:test',
                    coverage_s=(1.,1.),available_until_s=2.,source='supplied_test',usable=True)
        with self.assertRaises(ValueError):
            self.engine_type().process(request(pose=pose),epoch=0)

    def test_failed_scan_reports_no_fresh_distance_and_next_scan_can_recover(self):
        host = self.host()
        host.submit(request(pose=dict(matrix=np.zeros((4,4)).tolist())))
        failed = self.await_packet(host)
        self.assertEqual(failed['status'],'failed')
        self.assertFalse(failed['fresh_distance'])
        host.submit(request(1,1.2))
        recovered = self.await_packet(host)
        self.assertEqual(recovered['status'],'completed')
        self.assertEqual(recovered['sequence'],1)


if __name__ == '__main__':
    unittest.main()
