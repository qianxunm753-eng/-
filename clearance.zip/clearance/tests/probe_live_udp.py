# -*- coding: utf-8 -*-
"""Owned native UI + UDP receiver probe. Recorded payloads, NOT a physical test."""
import json
import os
import subprocess
import time
import traceback
from PythonQt import QtCore, QtGui
import rsview.applogic as logic

report_path = os.environ['RSVIEW_LIVE_REPORT'].decode('mbcs')
state = dict(error=None, physical_lidar_test=False, live_0_2s_verified=False,
    absolute_accuracy_verified=False, transport='original PCAP UDP payloads -> loopback live source',
    results=[], stage='starting', checks={})
timer = None
sender = None
overlay = None
started = time.time()


def finish():
    global timer
    if timer is not None:
        timer.stop()
    try:
        if sender is not None and sender.poll() is None:
            sender.terminate()
            sender.wait()
        logic.close()
    except Exception:
        state['cleanup_error'] = traceback.format_exc()
    with open(report_path, 'wb') as stream:
        stream.write(json.dumps(state, indent=2).encode('utf-8'))
    QtGui.QApplication.instance().quit()


def check(name, condition):
    state['checks'][name] = bool(condition)
    if not condition:
        raise AssertionError(name)


def geometry_check(packet, current):
    import math
    check('source_mode_live', packet['source_mode'] == 'live')
    check('no_recorded_pose', packet['pose_scope'] == 'live_lidar_relative_experimental')
    check('compensation_state_explicit', packet['motion_status'] in ('raw','deskewed_experimental'))
    check('relative_not_absolute_accuracy', not packet['absolute_accuracy_verified'])
    check('calculation_not_cache', packet['calculation'] == 'online_current_cloud')
    check('live_rail_roles_configured', overlay.worker_config.get('rail_profile_roles') is True)
    check('spatial_ownership_configured', overlay.worker_config.get('spatial_object_ownership') is True)
    check('geometry_label_priority_configured', overlay.worker_config.get('geometry_label_priority') is True)
    check('structure_context_configured',overlay.worker_config.get('track_structure_context') is True)
    check('historical_proposals_configured',overlay.worker_config.get('temporal_object_proposals') is True)
    check('surface_proposals_configured',overlay.worker_config.get('surface_object_proposals') is True)
    check('local_terrain_footprint_configured',overlay.worker_config.get('local_terrain_validation') is True)
    check('qualified_object_cores_configured',overlay.worker_config.get('qualified_object_cores') is True)
    check('terrain_footprint_reaches_worker',packet.get('local_terrain_support',{}).get('footprint_required') is True)
    check('current_rail_roles_reported', packet['scene_diagnostics'].get('rail_roles', {}).get('method') ==
          'current_repeated_rail_cross_sections')
    if packet['mode'] in ('observed_dual','compensated_dual','predicted_track','estimated_single'):
        check('structure_context_reaches_worker',packet['scene_diagnostics'].get('rail_roles',{}).get('structure_context_enabled') is True)
    check('native_matches_delivered_annotation_count',len(current['measurements']) == len(packet['measurements']))
    check('native_boundary_marker_count',overlay.boundary_actors[0][0].data.GetNumberOfPoints() == len(current['measurements']))
    if current['measurements']:
        check('both_observed_sides_get_slots',len(set(m['side'] for m in current['measurements'])) == 2)
    for i, item in enumerate(current['measurements']):
        check('current_annotation_quality_reported',item.get('selection_quality') is not None)
        a, b = overlay.measure_lines[i][0].GetPoint1(), overlay.measure_lines[i][0].GetPoint2()
        distance = math.sqrt(sum((v-u)**2 for u, v in zip(a, b)))
        check('native_dimensions_match_distance', abs(distance-item['distance_m']) < 1e-8)
        check('selected_point_within_5m', math.sqrt(sum(v*v for v in item['point_L'])) <= 5.+1e-8)
        check('selected_point_current_result', item['source_frame'] == packet['sequence'])


def camera_for(packet):
    """Readable top-down audit camera in this owned window only."""
    import math
    def unit(values):
        size = math.sqrt(sum(v*v for v in values))
        return [v/size for v in values]
    a, b = packet['centerline'][0]
    t = unit([v-u for u, v in zip(a, b)])
    item = packet['measurements'][0]
    s = unit([v-u for u, v in zip(item['foot_L'], item['projected_L'])])
    n = unit([t[1]*s[2]-t[2]*s[1], t[2]*s[0]-t[0]*s[2], t[0]*s[1]-t[1]*s[0]])
    # This owned Airy audit uses the known sideways mount: up is toward -X.
    # A nearest base below railtop must not flip the camera beneath the floor.
    # This is camera layout only; do not infer measurement gravity from it.
    if n[0]>0:
        n=[-v for v in n]
    points = [p for pair in packet['centerline'] for p in pair]
    for selected in packet['measurements']:
        points.extend((selected['point_L'], selected['foot_L']))
    focal = [(min(p[i] for p in points)+max(p[i] for p in points))*.5 for i in range(3)]
    camera = logic.app.mainView.GetRenderer().GetActiveCamera()
    camera.SetFocalPoint(*focal)
    camera.SetPosition(*[c+v*9. for c, v in zip(focal, n)])
    camera.SetViewUp(*t)
    camera.ParallelProjectionOn()
    camera.SetParallelScale(4.5)


def tick():
    global overlay
    try:
        if time.time()-started > float(os.environ.get('RSVIEW_LIVE_DEADLINE', '80')):
            raise AssertionError('native loopback probe timed out: '+state['stage'])
        controller = logic.app.clearanceController
        if time.time()-state.get('last_progress', 0.) > 2.:
            state['last_progress'] = time.time()
            raw = logic.getSensor().GetClientSideObject().GetOutput()
            state.setdefault('progress', []).append(dict(elapsed_s=time.time()-started,
                raw_points=raw.GetNumberOfPoints(), last_input=overlay.last_input,
                timesteps=list(logic.getSensor().TimestepValues),
                error=overlay.input_error, stale=overlay.live_stale,
                status=unicode(logic.app.statusLabel.text),
                host=overlay.host.diagnostics() if overlay.host is not None else None))
        if state['stage'] == 'paused':
            check('pause_old_packet_cleared', overlay.current is None and overlay.last_result is None)
            if time.time()-state['paused_at'] > .4:
                logic.setPlayMode(True)
                state['resumed_session'] = overlay.session
                check('resume_new_session', overlay.session != state['old_session'])
                state['stage'] = 'resumed'
            return
        if state['stage'] == 'waiting_dropout':
            if overlay.live_stale:
                check('dropout_packet_cleared', overlay.current is None and overlay.last_result is None)
                check('dropout_worker_closed', overlay.host is None)
                check('dropout_raw_restored', bool(overlay.raw_rep.Visibility))
                action = logic.app.actions['actionLiveTracksideClearance']
                action.trigger()
                check('toggle_off_unchecked', not action.checked)
                check('toggle_off_restores_rail', isinstance(logic.app.railOverlay, logic.rail_live.LiveRailOverlay))
                # Re-enable then exercise actual close hook while still a live source.
                action.trigger()
                last = controller.overlay
                logic.close()
                check('close_owned_overlay_closed', last.closed)
                check('close_action_disabled', not action.enabled and not action.checked)
                check('close_no_sensor', logic.getSensor() is None)
                state['stage'] = 'completed'
                finish()
            return
        packet = overlay.last_result
        if packet is None or packet.get('status') != 'completed':
            return
        identity = (packet['session_id'], packet['sequence'])
        if identity == state.get('last_identity'):
            return
        state['last_identity'] = identity
        current = overlay.current
        geometry_check(packet, current)
        state['results'].append(dict(sequence=packet['sequence'], session=packet['session_id'],
            device_time_s=packet['device_time_s'], count=len(current['measurements']),
            compute_ms=packet['timing_ms']['packet_total'], age_s=packet.get('result_age_s'),
            motion_status=packet['motion_status'],
            timings=packet['timing_ms'],native_pack_routes=packet.get('native_pack_routes'),
            relative_pose_diagnostics=packet.get('relative_pose_diagnostics'),
            current_source=packet.get('current_source'), mode=packet['mode'],
            display_ids=[m.get('display_id') for m in current['measurements']],
            uncertain=[m['uncertain'] for m in current['measurements']],
            distances=[m['distance_m'] for m in current['measurements']]))
        state['results'][-1]['rail_roles'] = packet['scene_diagnostics'].get('rail_roles')
        state['results'][-1]['motion_translation_model']=packet.get('motion_translation_model')
        state['results'][-1]['motion_curve_check_error_m']=packet.get('motion_curve_check_error_m')
        state['results'][-1]['object_grouping'] = packet['scene_diagnostics'].get('object_grouping')
        state['results'][-1]['temporal_proposal_groups'] = packet['scene_diagnostics'].get('temporal_proposal_groups',0)
        state['results'][-1]['current_surface_proposal_groups'] = packet['scene_diagnostics'].get('current_surface_proposal_groups',0)
        state['results'][-1]['local_terrain_support']=packet.get('local_terrain_support')
        state['results'][-1]['qualified_object_cores_used']=packet['scene_diagnostics'].get('qualified_object_cores_used')
        state['results'][-1]['unknown_track_annotations'] = packet.get('unknown_track_annotations')
        state['results'][-1]['unknown_ground_annotations'] = packet.get('unknown_ground_annotations')
        state['results'][-1]['lower_reference_deferred'] = packet.get('lower_reference_annotations_deferred')
        state['results'][-1]['annotation_region_count'] = packet.get('annotation_region_count')
        state['results'][-1]['measurements'] = [dict(distance=m['distance_m'],point=m['point_L'],
            source_index=m['source_index'],flags=m['flags'],uncertain=m['uncertain'],
            selection_quality=m.get('selection_quality'),annotation_regions=m.get('annotation_region_ids'))
            for m in current['measurements']]
        if not current['measurements']:
            return
        if state['stage'] == 'running':
            # Capture real native actors before pause, without saving raw clouds.
            camera_for(current)
            logic.smp.Render(logic.app.mainView)
            logic.smp.SaveScreenshot((report_path[:-5]+'.png').encode('mbcs'), logic.app.mainView)
            state['old_session'] = overlay.session
            logic.setPlayMode(False)
            check('pause_worker_closed', overlay.host is None)
            check('pause_annotations_hidden', not any(a.GetVisibility() for a in overlay.actors+overlay.labels))
            state['paused_at'] = time.time()
            state['stage'] = 'paused'
        elif state['stage'] == 'resumed':
            check('resume_result_new_session', packet['session_id'] == state['resumed_session'])
            state['resumed_results'] = state.get('resumed_results', 0)+1
            if state['resumed_results'] >= 8:
                check('resume_relative_motion_computed', any(
                    r['session'] == state['resumed_session'] and
                    r['motion_status'] == 'deskewed_experimental' for r in state['results']))
                camera_for(current)
                logic.smp.Render(logic.app.mainView)
                logic.smp.SaveScreenshot((report_path[:-5]+'-compensated.png').encode('mbcs'),logic.app.mainView)
                sender.terminate()
                sender.wait()
                state['stage'] = 'waiting_dropout'
    except Exception:
        state['error'] = traceback.format_exc()
        finish()


try:
    logic.close()
    controller = logic.app.clearanceController
    action = logic.app.actions['actionLiveTracksideClearance']
    check('menu_installed_without_sensor', action is not None and not action.enabled)
    # Private loopback ports; neither device settings nor user's live port are changed.
    sensor = logic.smp.RSlidar16Source(guiName='Live validation (loopback)', LidarType=13,
        CalibrationPath='', SensorPosition='', MsopPort=16699, DifopPort=17788,
        GroupAddress='0.0.0.0', HostAddress='127.0.0.1', UserLayerBytes=0, TailLayerBytes=0, JumboFrame=0)
    sensor.Init()
    native = sensor.GetClientSideObject()
    state['native_state'] = str(native)
    state['proxy_properties'] = list(sensor.ListProperties())
    state['native_methods'] = [name for name in dir(native) if any(
        word in name for word in ('Port', 'Address', 'Start', 'Frame', 'Time'))]
    state['native_trailing_getter'] = hasattr(native, 'GetNumberOfTrailingFrames')
    native.SetLaserSelection('1'*480)
    native.SetColumnSelection('1')
    native.SetPointsRange('')
    native.SetCropReturns('0 0 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000')
    native.SetCropDistReturns('0 0 0.000000 5.000000')
    logic.app.sensor = sensor
    logic.app.curLidarType = 'RSAIRY'
    logic.app.colorByInitialized = False
    logic.app.rep = logic.smp.Show(sensor)
    controller.source_ready()
    check('live_action_enabled', action.enabled)
    logic.enablePlaybackActions()
    logic.setPlayMode(True)
    state['proxy_state'] = dict((name, str(getattr(sensor, name))) for name in
        ('InputType', 'MsopPort', 'DifopPort', 'HostAddress', 'GroupAddress', 'LidarType'))
    state['native_start_doc'] = native.Start.__doc__
    with open(report_path, 'wb') as stream:
        stream.write(json.dumps(state, indent=2).encode('utf-8'))
    action.trigger()
    overlay = controller.overlay
    state['worker_config']=dict(overlay.worker_config)
    check('native_live_overlay_enabled', action.checked and overlay is logic.app.railOverlay)
    check('background_prior_disabled', overlay.worker_config['confirmed_background_path'] is None)
    check('world_scope_prior_disabled', overlay.worker_config['confirmed_measurement_scope_path'] is None)
    workspace = os.path.dirname(os.path.dirname(logic.clearance_live.__file__))
    python = os.path.join(os.environ['LOCALAPPDATA'], 'uv', 'cache', 'archive-v0',
        'YrB8poOFTUorDkrQ', 'Scripts', 'python.exe')
    args = [python, '-B', '-m', 'rsview_centerline.clearance.tests.replay_loopback_udp',
        '--source', os.environ.get('RSVIEW_LIVE_SOURCE',os.path.join(os.environ['USERPROFILE'], 'Desktop', '1212121.pcap')),
        '--report', report_path[:-5]+'-sender.json', '--duration', '65']
    args = [v.encode('mbcs') if isinstance(v, unicode) else v for v in args]
    sender_env = os.environ.copy()
    for name in ('PYTHONHOME', 'PYTHONPATH', 'PYTHONSTARTUP'):
        sender_env.pop(name, None)
    sender = subprocess.Popen(args, cwd=workspace.encode('mbcs') if isinstance(workspace, unicode) else workspace,
        env=sender_env, close_fds=True, creationflags=0x08000000)
    state['stage'] = 'running'
    timer = QtCore.QTimer()
    timer.connect('timeout()', tick)
    timer.start(100)
except Exception:
    state['error'] = traceback.format_exc()
    finish()
