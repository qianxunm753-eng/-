import json
import tempfile
from pathlib import Path
import unittest
from dataclasses import replace
import numpy as np
from scipy.spatial.transform import Rotation
from rsview_centerline.clearance.protocol import PointRef, PoseSample, ClearanceConfig
from rsview_centerline.clearance.tests.fixtures import cloud


def pose(t, x=0., angle=0.):
    m = np.eye(4)
    m[:3,:3] = Rotation.from_euler('z',angle,degrees=True).as_matrix()
    m[0,3] = x
    return PoseSample(t,m,'device:test',(0.,3.),3.,'analytic_test',True)


class Analytic:
    def sample(self,t,available_until_s):
        return replace(pose(t,.1*t,10*t),available_until_s=available_until_s)


class MotionTests(unittest.TestCase):
    def setUp(self):
        from rsview_centerline.clearance.motion import deskew_frame, transform_history, load_experimental_poses
        self.deskew,self.merge,self.load = deskew_frame,transform_history,load_experimental_poses

    def test_transform_preserves_source_refs(self):
        f = cloud([[1,0,0]],time=1.)
        f = replace(f,refs=(PointRef(0,0,1.05),))
        out = self.deskew(f,Analytic())
        expected = np.linalg.inv(pose(1.,.1,10).T_WL)@pose(1.05,.105,10.5).T_WL@np.array([1,0,0,1])
        np.testing.assert_allclose(out.xyz_L[0],expected[:3],atol=1e-10)
        self.assertEqual(out.refs,f.refs)
        self.assertEqual(out.motion_status,'deskewed_experimental')

    def test_missing_point_time_remains_raw(self):
        f = cloud([[1,0,0]],times=False)
        out = self.deskew(f,Analytic())
        self.assertEqual(out.motion_status,'raw')
        self.assertIn('missing_point_time',out.diagnostics['flags'])

    def test_future_pose_cannot_change_current_output(self):
        frames = [cloud([[1,0,0]],time=t,sequence=i) for i,t in enumerate((1.,1.1,1.2))]
        document = {'poses':[{'frame':i,'matrix':pose(t,.1*i).T_WL.tolist()} for i,t in enumerate((1.,1.1,1.2))],
                    'diagnostics':[{'frame':i,'timestamp':f.ref_time_s,'rank':6,'jacobian_condition':10.} for i,f in enumerate(frames)]}
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary)/'poses.json'
            path.write_text(json.dumps(document))
            a = self.deskew(frames[1],self.load(path,frames))
            document['poses'][2]['matrix'][0][3]=1000.
            path.write_text(json.dumps(document))
            b = self.deskew(frames[1],self.load(path,frames))
            np.testing.assert_array_equal(a.xyz_L,b.xyz_L)

    def test_rank_deficiency_is_not_valid_motion(self):
        frames = [cloud([[1,0,0]],time=t,sequence=i) for i,t in enumerate((1.,1.1))]
        document = {'poses':[{'frame':i,'matrix':pose(f.ref_time_s).T_WL.tolist()} for i,f in enumerate(frames)],
                    'diagnostics':[{'frame':i,'timestamp':f.ref_time_s,'rank':3} for i,f in enumerate(frames)]}
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary)/'poses.json';path.write_text(json.dumps(document))
            out = self.deskew(frames[1],self.load(path,frames))
            self.assertEqual(out.motion_status,'raw')

    def test_clock_reversal_resets_history(self):
        past = replace(cloud([[1,0,0]],time=1.2,sequence=2),motion_status='deskewed_experimental')
        current = replace(cloud([[2,0,0]],time=1.1,sequence=1),motion_status='deskewed_experimental')
        out = self.merge([past],current,Analytic(),ClearanceConfig())
        self.assertEqual(len(out.refs),1)
        self.assertIn('history_reset_clock_reversal',out.diagnostics['flags'])

    def test_history_uses_real_elapsed_time_and_original_indices(self):
        past = replace(cloud([[1,0,0]],time=1.,sequence=3),motion_status='deskewed_experimental')
        current = replace(cloud([[2,0,0]],time=1.5,sequence=12),motion_status='deskewed_experimental')
        out = self.merge([past],current,Analytic(),ClearanceConfig())
        self.assertEqual([r.frame for r in out.refs],[12,3])
        expected = np.linalg.inv(pose(1.5,.15,15).T_WL)@pose(1.,.1,10).T_WL@np.array([1,0,0,1])
        np.testing.assert_allclose(out.xyz_L[1],expected[:3],atol=1e-10)

    def test_object_history_does_not_copy_current_scan_or_support_itself(self):
        past = replace(cloud([[1,0,0]],time=1.,sequence=3),motion_status='deskewed_experimental')
        current = replace(cloud([[2,0,0],[3,0,0]],time=1.5,sequence=12),motion_status='deskewed_experimental')
        out = self.merge([past],current,Analytic(),ClearanceConfig(),include_current=False)
        self.assertEqual([r.frame for r in out.refs],[3])
        self.assertEqual(out.diagnostics['current_point_count'],0)
        self.assertEqual(out.diagnostics['aligned_to_ref_time_s'],1.5)
        expected = np.linalg.inv(pose(1.5,.15,15).T_WL)@pose(1.,.1,10).T_WL@np.array([1,0,0,1])
        np.testing.assert_allclose(out.xyz_L[0],expected[:3],atol=1e-10)

    def test_history_only_still_rejects_changed_pose_map(self):
        past = replace(cloud([[1,0,0]],time=1.,sequence=3),motion_status='deskewed_experimental',
                       diagnostics={'pose_map_key':('other-map',0,'other-file')})
        current = replace(cloud([[2,0,0]],time=1.5,sequence=12),motion_status='deskewed_experimental')
        out = self.merge([past],current,Analytic(),ClearanceConfig(),include_current=False)
        self.assertNotEqual(out.motion_status,'compensated_history')

    def test_zero_returns_do_not_become_phantom_objects_during_motion(self):
        f = cloud([[0,0,0],[1,0,0]])
        f = replace(f,refs=(PointRef(0,0,1.05),PointRef(0,1,1.05)))
        out = self.deskew(f,Analytic())
        np.testing.assert_array_equal(out.xyz_L[0],[0,0,0])
        future = replace(cloud([[2,0,0]],time=1.2,sequence=1),motion_status='deskewed_experimental')
        merged = self.merge([out],future,Analytic(),ClearanceConfig())
        np.testing.assert_array_equal(merged.xyz_L[1],[0,0,0])

    def test_provider_that_requires_future_data_is_not_causal(self):
        class Future:
            def sample(self,t,available_until_s):
                return replace(pose(t),available_until_s=available_until_s+1.)
        out = self.deskew(cloud([[1,0,0]]),Future())
        self.assertEqual(out.motion_status,'raw')

    def test_invalid_or_uncovered_point_pose_remains_raw(self):
        class Invalid:
            def sample(self,t,available_until_s):
                s = replace(pose(t),available_until_s=available_until_s)
                if t > 1.01:
                    m = s.T_WL.copy();m[0,0]=2.
                    return replace(s,T_WL=m)
                return s
        f = replace(cloud([[1,0,0]]),refs=(PointRef(0,0,1.05),))
        self.assertEqual(self.deskew(f,Invalid()).motion_status,'raw')
        class Uncovered:
            def sample(self,t,available_until_s):
                return replace(pose(t),coverage_s=(0.,.9),available_until_s=available_until_s)
        self.assertEqual(self.deskew(f,Uncovered()).motion_status,'raw')

    def test_history_wrong_clock_or_future_pose_is_not_fused(self):
        current = replace(cloud([[2,0,0]],time=1.2,sequence=1),motion_status='deskewed_experimental')
        past = replace(cloud([[1,0,0]]),motion_status='deskewed_experimental')
        class WrongClock:
            def sample(self,t,available_until_s):
                s = replace(pose(t),available_until_s=available_until_s)
                return replace(s,clock_id='other-clock') if t < 1.1 else s
        out = self.merge([past],current,WrongClock(),ClearanceConfig())
        self.assertEqual(len(out.refs),1)

    def test_one_scan_budget_does_not_accidentally_include_all_history(self):
        past=replace(cloud([[1,0,0]]),motion_status='deskewed_experimental')
        current=replace(cloud([[2,0,0]],time=1.2,sequence=1),motion_status='deskewed_experimental')
        self.assertEqual(len(self.merge([past],current,Analytic(),replace(ClearanceConfig(),history_max_scans=1)).refs),1)

    def test_future_clock_epoch_cannot_change_earlier_deskew(self):
        frames=[cloud([[1,0,0]],time=t,sequence=i) for i,t in enumerate((1.,1.1,1.,1.1))]
        translations=(0.,.1,100.,100.1)
        document={'poses':[{'frame':i,'matrix':pose(f.ref_time_s,x).T_WL.tolist()}
                           for i,(f,x) in enumerate(zip(frames,translations))],
                  'diagnostics':[{'frame':i,'timestamp':f.ref_time_s,'rank':6}
                                 for i,f in enumerate(frames)]}
        with tempfile.TemporaryDirectory() as temporary:
            path=Path(temporary)/'poses.json';path.write_text(json.dumps(document))
            prefix=self.deskew(frames[0],self.load(path,frames[:2]))
            complete=self.deskew(frames[0],self.load(path,frames))
        np.testing.assert_array_equal(complete.xyz_L,[[1.,0.,0.]])
        np.testing.assert_array_equal(complete.xyz_L,prefix.xyz_L)
        self.assertEqual(complete.motion_status,'deskewed_experimental')

    def test_first_scan_after_clock_reset_cannot_borrow_old_epoch_velocity(self):
        frames=[cloud([[1,0,0]],time=t,sequence=i) for i,t in enumerate((1.,1.1,1.2,1.1))]
        frames[3]=replace(frames[3],refs=(PointRef(3,0,1.125),))
        document={'poses':[{'frame':i,'matrix':pose(f.ref_time_s,x).T_WL.tolist()}
                           for i,(f,x) in enumerate(zip(frames,(0.,.1,.2,100.)))],
                  'diagnostics':[{'frame':i,'timestamp':f.ref_time_s,'rank':6}
                                 for i,f in enumerate(frames)]}
        with tempfile.TemporaryDirectory() as temporary:
            path=Path(temporary)/'poses.json';path.write_text(json.dumps(document))
            out=self.deskew(frames[3],self.load(path,frames))
        self.assertEqual(out.motion_status,'raw')
        np.testing.assert_array_equal(out.xyz_L,[[1.,0.,0.]])



if __name__ == '__main__':
    unittest.main()
