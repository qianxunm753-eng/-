"""Full old/new delivery invariants for a layout-only correction."""
import argparse
import json
from pathlib import Path

import numpy as np


def inspect(old, new, output):
    if output.exists():
        raise FileExistsError('new report path required')
    manifests=[json.loads((p/'manifest.json').read_text(encoding='utf-8')) for p in (old,new)]
    assert manifests[0]['frames']==manifests[1]['frames']
    assert manifests[0]['source_sha256']==manifests[1]['source_sha256']
    assert manifests[1]['source_sha256_after']==manifests[1]['source_sha256']
    count=manifests[1]['frames']
    boundaries=0
    extras=[]
    fields=('mode','centerline','candidate_count','layer_counts','scene_diagnostics','scope')
    for sequence in range(count):
        a,b=[json.loads((p/('frame-%04d.json'%sequence)).read_text(encoding='utf-8'))
             for p in (old,new)]
        for field in fields:
            assert a[field]==b[field], (sequence,'changed non-layout field',field)
        immutable=lambda m:{k:v for k,v in m.items() if not k.startswith('dimension_')
                            and not k.startswith('display_layout_')}
        assert list(map(immutable,a['measurements']))==list(map(immutable,b['measurements'])), \
            (sequence,'distance, source, membership or identity changed')
        for name, entry in a['clouds'].items():
            assert entry==b['clouds'][name],(sequence,'cloud metadata changed',name)
            assert (old/entry['file']).read_bytes()==(new/entry['file']).read_bytes(), \
                (sequence,'current display cloud changed',name)
            assert (new/entry['file']).stat().st_size==entry['count']*12
        for item in b['measurements']:
            assert item['source_frame']==sequence
            for distance,point,foot in (
                (item['distance_m'],item['projected_L'],item['foot_L']),
                (item['observed_min_distance_m'],item['observed_projected_L'],item['observed_foot_L']),
                (item['distance_m'],item.get('dimension_projected_L',item['projected_L']),
                 item.get('dimension_foot_L',item['foot_L']))):
                assert abs(np.linalg.norm(np.array(point)-foot)-distance)<1e-8, \
                    (sequence,'geometric length mismatch')
            boundaries+=1
        if any(m.get('display_layout_support_count',0) for m in b['measurements']):
            extras.append(sequence)
        if sequence in (40,45):
            assert not any(m['source_index']==67710 for m in b['measurements'])
            assert b['clouds']['ground']['count']>0
    assert extras,'exclusive current support was never exercised'
    report=dict(frames=count,measurement_checks=boundaries,centerlines_unchanged=True,
        all_distances_and_sources_and_memberships_unchanged=True,current_clouds_byte_identical=True,
        geometric_lengths_passed=True,ground_regression_40_45_passed=True,
        exclusive_current_layout_support_frames=extras,source_unchanged=True,
        source_sha256=manifests[1]['source_sha256'],absolute_accuracy_verified=False,
        live_0_2s_verified=False)
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='exclusive_current_layout_support_frames'}))


if __name__=='__main__':
    p=argparse.ArgumentParser(__doc__)
    p.add_argument('--old',type=Path,required=True)
    p.add_argument('--new',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    inspect(args.old,args.new,args.output)
