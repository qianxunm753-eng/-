# -*- coding: utf-8 -*-
"""Owned hidden native PCAP probe; no radar settings or original PCAP writes."""
import json
import os
import tempfile
import traceback
from PythonQt import QtCore, QtGui
import rsview.applogic as logic


def run():
    report = dict(error=None, stage='characterize', checks={})
    folder = tempfile.mkdtemp(prefix='rsview-recorded-probe-')
    factories = {}
    try:
        from clearance_native import patch_recording_decoder, prepare_pcap_reader
        factories = patch_recording_decoder(logic)
        logic.chooseCalibrationFile = lambda unused: True
        logic.networkConfigPcap = lambda unused: True
        pointer = os.path.join(folder, 'input_path.log')
        with open(pointer, 'wb') as stream:
            stream.write(os.path.join(os.path.expanduser('~'), 'Desktop', '333.pcap'))
        logic.openPCAP(pointer)
        logic.stop()
        reader = logic.getReader()
        steps = prepare_pcap_reader(reader)
        report['steps'] = dict(count=len(steps), first=steps[:4], last=steps[-4:])
        native = reader.GetClientSideObject()
        report['native_methods'] = [s for s in dir(native) if any(word in s.lower()
            for word in ('time', 'frame', 'output', 'information'))]
        report['reader_properties'] = list(reader.ListProperties())
        report['frames'] = []
        for frame in (20, 28, 21):
            reader.UpdatePipeline(float(frame))
            data = native.GetOutput()
            item = dict(frame=frame, points=data.GetNumberOfPoints(),
                span=list(data.GetPointData().GetArray('timestamp').GetRange()))
            info = data.GetInformation()
            item['information'] = str(info)
            for name in ('vtkDataObject', 'vtkStreamingDemandDrivenPipeline'):
                cls = getattr(logic.vtk, name, None)
                if cls is not None and hasattr(cls, 'DATA_TIME_STEP'):
                    key = cls.DATA_TIME_STEP()
                    item['data_time_step'] = info.Get(key) if info.Has(key) else None
            report['frames'].append(item)
        report['menu_enabled'] = bool(logic.app.clearanceController.action.enabled)
        report['checks']['pcap_menu_available'] = report['menu_enabled']
        report['stage'] = 'characterized'
    except Exception:
        report['error'] = traceback.format_exc()
    finally:
        for name, factory in factories.items():
            setattr(logic, name, factory)
        logic.close()
        # Only the probe-owned pointer and the native loader's small logs.
        for name in ('input_path.log', 'tmp.log', 'input.log'):
            path = os.path.join(folder, name)
            if os.path.isfile(path):
                os.remove(path)
        os.rmdir(folder)
        with open(os.environ['RSVIEW_RECORDED_REPORT'].decode('mbcs'), 'wb') as stream:
            stream.write(json.dumps(report, indent=2).encode('utf-8'))
        QtGui.QApplication.instance().quit()


timer = QtCore.QTimer()
timer.setSingleShot(True)
timer.connect('timeout()', run)
timer.start(1000)
