# -*- coding: utf-8 -*-
"""Read native decoder enums/defaults in an owned hidden RSView process."""
import json
import os
import traceback
from PythonQt import QtCore, QtGui
import rsview.applogic as logic


def run():
    result = {}
    reader = None
    try:
        reader = logic.smp.RSlidar16Reader()
        calibration = logic.vvCalibrationDialog(logic.getMainWindow())
        result['calibration'] = dict((name,str(getattr(calibration,name)())) for name in
            ('GetSensorType','GetSensorTypeName','GetJumboFrameNum','GetCalibrationPath','GetPosition'))
        result['combos'] = []
        todo = [calibration]
        while todo:
            widget = todo.pop()
            todo.extend(widget.children())
            if isinstance(widget,QtGui.QComboBox):
                result['combos'].append(dict(name=str(widget.objectName),items=[
                    [str(widget.itemText(i)),str(widget.itemData(i))] for i in range(widget.count)]))
        network = logic.vvNetworkConfigPcapDialog(logic.getMainWindow())
        result['network'] = dict((name,str(getattr(network,name)())) for name in
            ('GetUseVlan','GetUserLayerBytes','GetTailLayerBytes','GetMsopPort','GetDifopPort','GetInputTypeStr'))
        for factory,getter in ((logic.vvLaserSelectionDialog,'getLaserSelection'),
                               (logic.vvLaserSelectionDialog,'getLaserDefault480'),
                               (logic.vvColumnSelectionDialog,'getColumnSelection'),
                               (logic.vvPointsSelectionDialog,'getPointsSelection'),
                               (logic.vvCropReturnsDialog,'GetCropReturns'),
                               (logic.vvCropDistReturnsDialog,'GetCropDistReturns')):
            result[getter] = str(getattr(factory(logic.getMainWindow()),getter)())
    except Exception:
        result['error'] = traceback.format_exc()
    finally:
        if reader is not None:
            logic.smp.Delete(reader)
        with open(os.environ['RSVIEW_SETTINGS_REPORT'].decode('mbcs'),'wb') as stream:
            stream.write(json.dumps(result,indent=2).encode('utf-8'))
        QtGui.QApplication.instance().quit()


timer = QtCore.QTimer()
timer.setSingleShot(True)
timer.connect('timeout()',run)
timer.start(1000)
