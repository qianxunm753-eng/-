import importlib.util
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import Mock,patch


class ExportLauncherTests(unittest.TestCase):
    def test_timeout_only_terminates_owned_handle(self):
        path = Path(__file__).parents[2]/'analysis/20261002_clearance/run_experiment.py'
        spec = importlib.util.spec_from_file_location('clearance_launcher_test',path)
        module = importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary);exe=root/'RSView.exe';source=root/'input.pcap'
            exe.write_bytes(b'test');source.write_bytes(b'preserve')
            child = Mock(pid=12345)
            child.wait.side_effect = [subprocess.TimeoutExpired('owned',.01),0]
            unrelated = Mock(pid=77777)
            with patch.object(module.subprocess,'Popen',return_value=child) as launch:
                with self.assertRaises(TimeoutError):
                    module.export_capture(exe,source,root/'new',timeout=.01)
            child.terminate.assert_called_once_with()
            child.kill.assert_not_called()
            unrelated.terminate.assert_not_called()
            self.assertEqual(launch.call_count,1)
            self.assertEqual(source.read_bytes(),b'preserve')


if __name__ == '__main__':
    unittest.main()
