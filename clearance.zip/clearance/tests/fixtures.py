"""Hand-checkable point scenes; never imported by production code."""
import numpy as np


def cloud(points, time=1.0, sequence=0, times=True, session="test"):
    from rsview_centerline.clearance.protocol import CloudFrame, PointRef
    xyz = np.asarray(points, dtype=np.float64).reshape(-1, 3)
    return CloudFrame(session, sequence, time, "device:test", xyz,
                      tuple(PointRef(sequence, i, time if times else None)
                            for i in range(len(xyz))), None, (time-.05, time+.05))


def line_track(start=(0., 0., 0.), end=(0., 2., 0.), time=1., gauge=1.5):
    from rsview_centerline.clearance.protocol import TrackModel, TrackSegment
    a, b = np.asarray(start, dtype=float), np.asarray(end, dtype=float)
    normal = np.array([0., 0., 1.])
    tangent = (b-a)/np.linalg.norm(b-a)
    across = np.cross(tangent, normal)
    sides = np.stack([a, b])
    segment = TrackSegment(a, b, sides-across*gauge/2, sides+across*gauge/2,
                           normal, across, 0., ())
    return TrackModel("test", time, "device:test", "observed_dual", (segment,),
                      time, time, gauge)
