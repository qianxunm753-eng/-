# -*- coding: utf-8 -*-
"""Owned native 22222.pcap regression; never use the live clearance menu."""
import hashlib
import json
import os
import tempfile
import traceback
from PythonQt import QtCore, QtGui
import rsview.applogic as logic


def run():
    report_path = os.environ['RSVIEW_LEGACY_REPORT'].decode('mbcs')
    state = dict(error=None, frame=10)
    originals = {}
    choose, network = logic.chooseCalibrationFile, logic.networkConfigPcap
    pointer_folder = None
    try:
        filename = os.path.join(os.environ['USERPROFILE'], 'Desktop', '22222.pcap')
        digest = hashlib.sha256()
        with open(filename, 'rb') as stream:
            for block in iter(lambda: stream.read(1024*1024), b''):
                digest.update(block)
        state['source_sha256'] = digest.hexdigest()
        if state['source_sha256'] != '715a8bab1c5efb75f2886188901feac6b555aa0a893734265219f921a8eff718':
            raise AssertionError('legacy recording identity changed')
        # This recording, too, is the verified Airy source used in the old UI.
        from clearance_native import patch_recording_decoder, prepare_pcap_reader
        originals = patch_recording_decoder(logic)
        logic.chooseCalibrationFile = lambda unused: True
        logic.networkConfigPcap = lambda unused: True
        pointer_folder = tempfile.mkdtemp(prefix='rsview-legacy-probe-')
        pointer = os.path.join(pointer_folder, 'input_path.log')
        with open(pointer, 'wb') as stream:
            stream.write(filename.encode('mbcs') if isinstance(filename, unicode) else filename)
        logic.openPCAP(pointer)
        logic.stop()
        logic.app.tempTimer.stop()
        reader = logic.getReader()
        steps = prepare_pcap_reader(reader)
        logic.app.scene.AnimationTime = float(steps[10])
        reader.UpdatePipeline(float(steps[10]))
        QtGui.QApplication.processEvents()
        logic.onTimeChanged()
        overlay = logic.app.railOverlay
        state.update(overlay_type=type(overlay).__name__, reader_frames=len(steps),
            menu_enabled=bool(logic.app.actions['actionLiveTracksideClearance'].enabled),
            menu_checked=bool(logic.app.actions['actionLiveTracksideClearance'].checked),
            center_visible=bool(overlay.representation.Visibility),
            gauge_visible=bool(overlay.measurement_representation.Visibility),
            labels=[label.GetInput() for label in overlay.labels if label.GetVisibility()])
        if (state['overlay_type'] != 'VtkRailOverlay' or state['menu_enabled'] or
                state['menu_checked'] or not state['center_visible'] or not state['gauge_visible']):
            raise AssertionError('legacy gauge or PCAP menu isolation regressed')
    except Exception:
        state['error'] = traceback.format_exc()
    finally:
        logic.chooseCalibrationFile, logic.networkConfigPcap = choose, network
        for name, factory in originals.items():
            setattr(logic, name, factory)
        try:
            logic.close()
        except Exception:
            state['cleanup_error'] = traceback.format_exc()
        if pointer_folder is not None:
            try:
                os.remove(os.path.join(pointer_folder, 'input_path.log'))
                os.rmdir(pointer_folder)
            except OSError:
                # Native openPCAP also creates input.log/tmp.log. Keep these
                # small diagnostic files rather than recursively removing them.
                state['pointer_directory_retained'] = pointer_folder
        with open(report_path, 'wb') as stream:
            stream.write(json.dumps(state, indent=2).encode('utf-8'))
        QtGui.QApplication.instance().quit()


timer = QtCore.QTimer()
timer.setSingleShot(True)
timer.connect('timeout()', run)
timer.start(1000)
