"""Relative LiDAR estimation: known synthetic motion, not a field accuracy test."""
import unittest
from unittest.mock import patch
from dataclasses import replace

import numpy as np
from scipy.spatial.transform import Rotation

from rsview_centerline.clearance.protocol import CloudFrame, PointRef


def frame(points,sequence,time_s):
    return CloudFrame('motion-test',sequence,time_s,'lidar-test',points,
        tuple(PointRef(sequence,i,time_s) for i in range(len(points))),None,(time_s-.05,time_s+.05))


def corner():
    rng=np.random.default_rng(42)
    xy=rng.uniform(-1.7,1.7,(1200,2))
    return np.vstack((np.c_[xy,np.full(len(xy),-1.)],
                      np.c_[np.full(len(xy),2.),xy],
                      np.c_[xy[:,0],np.full(len(xy),-2.),xy[:,1]]))


class LiveMotionTests(unittest.TestCase):
    def test_final_inlier_geometry_is_checked_independently_of_solver_rank(self):
        from rsview_centerline.clearance.motion import LiveLidarPoses
        tracker=LiveLidarPoses()
        rng=np.random.default_rng(2)
        points=np.c_[rng.uniform(-2.,2.,(2500,2)),np.zeros(2500)]
        tracker.update(frame(points,0,1.))
        # A coarse solver's rank cannot justify a degenerate final inlier set.
        with patch('numpy.linalg.lstsq',return_value=(np.zeros(6),[],6,np.ones(6))):
            poses=tracker.update(frame(points,1,1.2))
        self.assertIsNone(poses.sample(1.2,1.25))
        self.assertFalse(tracker.diagnostics['usable'])

    def test_three_planes_recover_forward_motion_without_recorded_pose(self):
        from rsview_centerline.clearance.motion import LiveLidarPoses
        tracker=LiveLidarPoses(max_scans=6)
        world=corner()
        tracker.update(frame(world,0,1.))
        rotation=Rotation.from_rotvec([.008,-.012,.004]).as_matrix()
        translation=np.array([.02,-.01,.22])
        local=(world-translation)@rotation
        poses=tracker.update(frame(local,1,1.2))
        pose=poses.sample(1.2,1.25)
        self.assertIsNotNone(pose)
        self.assertTrue(pose.usable)
        np.testing.assert_allclose(pose.T_WL[:3,3],translation,atol=.012)
        np.testing.assert_allclose(pose.T_WL[:3,:3],rotation,atol=.006)
        self.assertFalse(pose.diagnostics['independent_truth'])

    def test_plane_only_is_degenerate_not_a_claimed_stationary_pose(self):
        from rsview_centerline.clearance.motion import LiveLidarPoses
        tracker=LiveLidarPoses(max_scans=6)
        rng=np.random.default_rng(2)
        points=np.c_[rng.uniform(-2.,2.,(2500,2)),np.zeros(2500)]
        tracker.update(frame(points,0,1.))
        poses=tracker.update(frame(points+[.2,0.,0.],1,1.2))
        self.assertIsNone(poses.sample(1.2,1.25))
        self.assertFalse(tracker.diagnostics['usable'])

    def test_clock_reversal_starts_a_new_local_map(self):
        from rsview_centerline.clearance.motion import LiveLidarPoses,pose_map_key
        tracker=LiveLidarPoses(max_scans=6)
        points=corner()
        tracker.update(frame(points,0,1.))
        poses=tracker.update(frame(points-[0.,0.,.1],1,1.2))
        key=pose_map_key(poses.sample(1.2,1.25))
        tracker.update(frame(points,0,.5))
        poses=tracker.update(frame(points-[0.,0.,.1],1,.7))
        self.assertNotEqual(pose_map_key(poses.sample(.7,.75)),key)
        self.assertIsNone(poses.sample(1.2,1.25))

    def test_velocity_guess_scales_with_skipped_frame_time_not_sequence(self):
        from rsview_centerline.clearance.motion import LiveLidarPoses
        tracker=LiveLidarPoses(max_scans=6)
        points=corner()
        for sequence,time_s,z in [(0,1.,0.),(1,1.2,.22),(5,1.6,.66)]:
            poses=tracker.update(frame(points-[0.,0.,z],sequence,time_s))
        np.testing.assert_allclose(poses.sample(1.6,1.65).T_WL[:3,3],[0.,0.,.66],atol=.015)


if __name__=='__main__':
    unittest.main()
