"""A dense preview cannot discard the actual raw closest return or invent scans."""
import importlib
import unittest
from dataclasses import replace
import numpy as np
from rsview_centerline.clearance.tests.fixtures import cloud
from rsview_centerline.clearance.protocol import PointRef

try:module=importlib.import_module('rsview_centerline.clearance.stop_window')
except ModuleNotFoundError:module=None


class StopWindowTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(module,'bounded parking window not implemented')
        self.now=0.

    def window(self,**changes):
        return module.StopWindow(clock=lambda:self.now,**changes)

    def test_display_voxel_does_not_remove_later_real_closer_point(self):
        window=self.window(voxel_m=.05)
        window.add(cloud([[2.024,1.,.3]],sequence=10,time=1.),np.eye(4))
        window.add(cloud([[2.004,1.,.3]],sequence=11,time=1.1),np.eye(4))
        self.assertEqual(len(window.geometry().xyz_L),1)
        frames=list(window.iter_aligned())
        self.assertEqual(len(frames),2)
        self.assertEqual(min(f.xyz_L[:,0].min() for f in frames),2.004)
        self.assertEqual(frames[1].refs[0],PointRef(11,0,1.1))

    def test_identical_scan_never_counts_twice(self):
        window=self.window()
        frame=cloud([[2.,1.,.3]],sequence=10,time=1.)
        self.assertTrue(window.add(frame,np.eye(4)))
        self.assertFalse(window.add(frame,np.eye(4)))
        self.assertEqual(window.scan_count,1)

    def test_clock_or_source_jump_clears_old_raw_window(self):
        window=self.window()
        window.add(cloud([[2.,1.,.3]],sequence=10,time=1.),np.eye(4))
        window.add(cloud([[3.,1.,.3]],sequence=9,time=.9),np.eye(4))
        self.assertEqual(window.scan_count,1)
        self.assertEqual(list(window.iter_aligned())[0].refs[0].frame,9)
        window.add(cloud([[4.,1.,.3]],sequence=20,time=2.,session='new'),np.eye(4))
        self.assertEqual(window.scan_count,1)

    def test_common_reference_alignment_preserves_native_indices(self):
        window=self.window()
        initial=np.eye(4);initial[0,3]=1.
        second=np.eye(4);second[0,3]=1.01
        frame=replace(cloud([[2.,1.,.3]],sequence=11,time=1.1),refs=(PointRef(11,71,1.1),))
        window.add(cloud([[2.,1.,.3]],sequence=10,time=1.),initial)
        window.add(frame,second)
        aligned=list(window.iter_aligned())[1]
        self.assertAlmostEqual(aligned.xyz_L[0,0],2.01,places=14)
        self.assertEqual(aligned.refs[0].index,71)
        self.assertEqual(window.reference_sequence,10)

    def test_ten_meters_crop_retains_original_point_number(self):
        window=self.window(radius_m=10.)
        window.add(cloud([[10.01,0.,0.],[9.99,0.,0.],[np.nan,0.,0.]],sequence=1),np.eye(4))
        frame=list(window.iter_aligned())[0]
        self.assertEqual(len(frame.xyz_L),1)
        self.assertEqual(frame.refs[0].index,1)
        self.assertEqual(frame.xyz_L[0,0],9.99)

    def test_byte_budget_rejects_without_silently_dropping_boundary_points(self):
        window=self.window(byte_budget=1)
        self.assertFalse(window.add(cloud([[2.,1.,.3]],sequence=1),np.eye(4)))
        self.assertEqual(window.scan_count,0)
        self.assertEqual(window.reason,'capacity_reached')

    def test_capacity_rejection_is_latched_until_explicit_window_reset(self):
        window=self.window(map_budget=1)
        self.assertTrue(window.add(cloud([[2.,1.,.3]],sequence=1,time=1.),np.eye(4)))
        self.assertFalse(window.add(cloud([[3.,1.,.3]],sequence=2,time=1.1),np.eye(4)))
        self.assertFalse(window.add(cloud([[2.,1.,.3]],sequence=3,time=1.2),np.eye(4)),
            'rejected geometry was bypassed by another scan that happened to fit')
        self.assertEqual(window.scan_count,1)
        self.assertEqual(window.reason,'capacity_reached')
        window.clear()
        self.assertTrue(window.add(cloud([[2.,1.,.3]],sequence=4,time=1.3),np.eye(4)))

    def test_sixty_second_wall_budget_never_adds_more_data(self):
        window=self.window(budget_s=60.)
        window.add(cloud([[2.,1.,.3]],sequence=1,time=1.),np.eye(4))
        self.now=60.01
        self.assertFalse(window.add(cloud([[2.,1.,.3]],sequence=2,time=1.1),np.eye(4)))
        self.assertEqual(window.scan_count,1)
        self.assertEqual(window.reason,'time_budget_exceeded')

    def test_compressed_xyz_times_and_ring_values_are_lossless(self):
        window=self.window()
        frame=replace(cloud([[2.00000000000003,1.,.300000000000001]],sequence=17),rings=np.array([9]))
        window.add(frame,np.eye(4))
        restored=list(window.iter_aligned())[0]
        np.testing.assert_array_equal(restored.xyz_L,frame.xyz_L)
        np.testing.assert_array_equal(restored.rings,frame.rings)
        self.assertEqual(restored.refs,frame.refs)


if __name__=='__main__':unittest.main()
