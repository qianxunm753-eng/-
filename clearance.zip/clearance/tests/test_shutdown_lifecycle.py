"""The application-owned Python quit slot must release itself before teardown."""
import unittest
from types import SimpleNamespace
from rsview_centerline import clearance_live
from . import test_recorded_playback as recorded_helpers
from .test_live_clearance import Action,Overlay


class ApplicationSignals:
    def __init__(self):self.slots=[]
    def connect(self,signal,slot):
        if signal!='aboutToQuit()':raise AssertionError(signal)
        self.slots.append(slot)
    def disconnect(self,signal,slot):
        if signal!='aboutToQuit()':raise AssertionError(signal)
        self.slots.remove(slot)
    def emit_quit(self):
        for slot in list(self.slots):slot()


class ShutdownTests(unittest.TestCase):
    def controller(self):
        application=ApplicationSignals();logic=recorded_helpers.RecordedMenuTests().logic()
        logic.QtGui=SimpleNamespace(QApplication=SimpleNamespace(instance=lambda:application))
        controller=clearance_live.LiveClearanceController(logic,Action())
        self.assertTrue(hasattr(controller,'application_quit'),
            'quit cleanup slot still retained by application after cleanup')
        application.connect('aboutToQuit()',controller.application_quit)
        return controller,application,logic

    def test_quit_closes_owned_source_and_releases_application_slot(self):
        controller,application,logic=self.controller()
        controller._save_trailing()
        owned=controller.overlay=logic.app.railOverlay=Overlay(logic.getReader())
        application.emit_quit()
        self.assertTrue(owned.closed)
        self.assertIsNone(controller.overlay);self.assertIsNone(logic.app.railOverlay)
        self.assertEqual(logic.getReader().trailing,17)
        self.assertEqual(application.slots,[],'Qt must not retain the bound Python slot into finalization')

    def test_ordinary_source_close_does_not_disconnect_future_quit_cleanup(self):
        controller,application,logic=self.controller()
        controller.source_closed()
        self.assertEqual(len(application.slots),1)
        owned=controller.overlay=logic.app.railOverlay=Overlay(logic.getReader())
        application.emit_quit()
        self.assertTrue(owned.closed)
        self.assertEqual(application.slots,[])

    def test_cleanup_error_does_not_leave_a_late_python_quit_callback(self):
        controller,application,logic=self.controller()
        def fail():raise RuntimeError('test cleanup failure')
        controller.source_closed=fail
        with self.assertRaisesRegex(RuntimeError,'test cleanup failure'):application.emit_quit()
        self.assertEqual(application.slots,[])


if __name__=='__main__':unittest.main()
