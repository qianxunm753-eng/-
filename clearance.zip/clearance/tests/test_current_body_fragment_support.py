"""A nearby old map is not current attachment proof for a weak fragment."""
import unittest
import numpy as np
from rsview_centerline.clearance.scene import SurfaceTracker
from rsview_centerline.clearance.tests.test_observable_instances import configuration


def description(points,seed=True):
    points=np.asarray(points,dtype=float)
    return dict(points=points,lower=points.min(0),upper=points.max(0),radius=.065,
        can_seed=seed,has_current_support=True,last_seen=1.)


class CurrentBodySupportTests(unittest.TestCase):
    def scene(self):
        body=np.array([[2.,y,z] for y in (.6,.7,.8) for z in (.4,.5,.6,.9,1.,1.1)])
        old_fragment=np.array([[1.96,.7,.5],[1.96,.72,.5]])
        tracker=SurfaceTracker(configuration())
        tracker._associate_display([description(np.concatenate([body,old_fragment]))],1.)
        return tracker,body,old_fragment

    def test_weak_fragment_without_current_attachment_cannot_pollute_visible_body(self):
        tracker,body,fragment=self.scene()
        current=body[body[:,2]>.8]
        result=tracker._associate_display([description(current),description(fragment,False)],1.1,
            ownership_points=[current,fragment])
        self.assertEqual(result[0]['display_id'],'T1')
        self.assertIsNone(result[1]['display_id'],
                          'old-map proximity silently confirmed a detached weak current fragment')
        self.assertEqual(result[1]['proposed_display_id'],'T1')
        stored=tracker.display_regions['T1']
        old_rows=np.flatnonzero(np.isclose(stored['points'][:,0],1.96))
        self.assertTrue(len(old_rows))
        self.assertTrue(np.all(stored['point_times'][old_rows]==1.),'unverified fragment refreshed old body geometry')

    def test_attached_current_fragment_keeps_current_body_identity(self):
        tracker,body,unused=self.scene()
        current=body[body[:,2]>.8]
        fragment=np.array([[1.97,.7,1.],[1.97,.72,1.]])
        result=tracker._associate_display([description(current),description(fragment,False)],1.1,
            ownership_points=[current,fragment])
        self.assertEqual([r['display_id'] for r in result],['T1','T1'])

    def test_partial_only_view_keeps_known_id_without_inventing_a_current_body(self):
        tracker,unused,fragment=self.scene()
        result=tracker._associate_display([description(fragment,False)],1.1,ownership_points=[fragment])
        self.assertEqual(result[0]['display_id'],'T1')


if __name__=='__main__':
    unittest.main()
