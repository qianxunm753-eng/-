"""Packed connectivity keys must preserve independently hand-checked cells."""
import unittest
from unittest.mock import patch
import numpy as np


class VoxelTests(unittest.TestCase):
    def helper(self):
        try:
            from rsview_centerline.clearance.voxel import representatives
        except ImportError as error:
            self.fail('packed voxel helper missing: '+str(error))
        return representatives

    def test_native_representatives_and_membership_preserve_cell_order(self):
        indices, inverse = self.helper()(np.array([[.11,0,0],[0,0,0],[.12,0,0],[-.06,0,0]]), .05)
        np.testing.assert_array_equal(indices, [3,1,0])
        np.testing.assert_array_equal(inverse, [2,1,2,0])

    def test_empty_and_invalid_geometry(self):
        a, b = self.helper()(np.empty((0,3)), .05)
        self.assertEqual(len(a)+len(b), 0)
        for voxel, xyz in [(0.,np.zeros((1,3))),(.05,np.array([[np.nan,0,0]]))]:
            with self.assertRaises(ValueError):
                self.helper()(xyz, voxel)

    def test_one_or_two_returns_keep_exact_cell_order_without_general_sorting(self):
        cases=(
            ([[.11,0.,0.]],[0],[0]),
            ([[.12,0.,0.],[.11,0.,0.]],[0],[0,0]),
            ([[.11,0.,0.],[-.06,0.,0.]],[1,0],[1,0]),
            ([[0.,-.06,0.],[0.,.11,0.]],[0,1],[0,1]),
            ([[0.,0.,.11],[0.,0.,-.06]],[1,0],[1,0]),
            ([[-1.e14,0.,0.],[1.e14,0.,0.]],[0,1],[0,1]),
        )
        for points,want_indices,want_inverse in cases:
            with self.subTest(points=points):
                with patch('numpy.unique',wraps=np.unique) as sorting:
                    indices,inverse=self.helper()(np.array(points),.05)
                np.testing.assert_array_equal(indices,want_indices)
                np.testing.assert_array_equal(inverse,want_inverse)
                self.assertEqual(indices.dtype,np.dtype('int64'))
                self.assertEqual(inverse.dtype,np.dtype('int64'))
                self.assertEqual(sorting.call_count,0,
                    'one/two returns still invoke general packed-key sorting')


if __name__ == '__main__':
    unittest.main()
