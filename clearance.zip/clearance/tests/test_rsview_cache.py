"""RSView delivery contracts: spatial scope, raw boundary evidence and small files."""
import importlib.util
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from rsview_centerline.clearance.geometry import corridor_indices
from rsview_centerline.clearance.protocol import ClearanceConfig, TrackUpdate
from rsview_centerline.clearance.scene import extract_scene
from rsview_centerline.clearance.measure import measure_candidates
from rsview_centerline.clearance.tests.fixtures import cloud, line_track


class RSViewScopeTests(unittest.TestCase):
    def test_overhead_is_outside_measurement_scope_not_projected_to_zero(self):
        frame = cloud([(0.01, 1., 8.), (2., 1., 1.), (2., 1., .05)])
        cfg = SimpleNamespace(**dict(ClearanceConfig().__dict__,
            measurement_height_range_m=(-.3, 3.5), sensor_max_range_m=5.))
        self.assertEqual(corridor_indices(frame, line_track(), cfg).tolist(), [1, 2])

    def test_far_corner_is_outside_explicit_sensor_near_field(self):
        frame = cloud([(4., 4., 1.), (2., 1., 1.)])
        cfg = SimpleNamespace(**dict(ClearanceConfig().__dict__,
            measurement_height_range_m=(-.3, 3.5), sensor_max_range_m=5.))
        self.assertEqual(corridor_indices(frame, line_track(end=(0., 5., 0.)), cfg).tolist(), [1])


class RSViewCacheTests(unittest.TestCase):
    def annotation_parts(self,shift=0.,upper_x=2.02):
        from rsview_centerline.clearance.protocol import Candidate, SceneLayers
        from types import SimpleNamespace
        cfg=SimpleNamespace(**vars(ClearanceConfig()))
        cfg.geometry_label_priority=True
        frame=cloud([[2.,y,.4] for y in (.7,.9,1.1,1.2)]+
                    [[upper_x,y+shift,1.] for y in (.7,.9,1.1,1.2)])
        candidates=tuple(Candidate('part%d'%i,np.arange(i*4,(i+1)*4),np.arange(i*4,(i+1)*4),1.,1.,
            {'display_id':'T%d'%(i+1),'display_observations':4-i,
             'display_slot_reserved':i==0,'display_anchor_L':[2.,.9,.4]}) for i in range(2))
        layers=SceneLayers({'object':np.arange(8)},candidates,{}, {})
        track=TrackUpdate('observed_dual',line_track())
        results=measure_candidates(frame,track,layers,cfg)
        return frame,track,layers,results,cfg

    def test_current_same_footprint_parts_share_one_annotation_not_two_device_claims(self):
        frame,track,layers,results,cfg=self.annotation_parts()
        packet=self.module().build_packet(frame,track,layers,results,cfg)
        self.assertEqual(len(packet['measurements']),1,'current overlapping footprint consumed two labels')
        self.assertEqual(len(results),2,'annotation grouping changed measurement-engine object membership')
        self.assertEqual(len(packet['_display']['object']),8)

    def test_annotation_group_keeps_stable_identity_and_actual_current_minimum(self):
        frame,track,layers,results,cfg=self.annotation_parts(upper_x=1.98)
        packet=self.module().build_packet(frame,track,layers,results,cfg)
        self.assertEqual(len(packet['measurements']),1)
        item=packet['measurements'][0]
        self.assertEqual(item['display_id'],'T1')
        self.assertAlmostEqual(item['distance_m'],1.98)
        self.assertEqual(item['source_index'],4)

    def test_grouping_keeps_an_isolated_raw_minimum_warning_and_native_source(self):
        frame,track,layers,unused,cfg=self.annotation_parts()
        frame=cloud(np.vstack((frame.xyz_L,[[1.97,1.,.4]])))
        first=replace(layers.candidates[0],point_indices=np.array([0,1,2,3,8]))
        layers=replace(layers,indices={'object':np.arange(9)},
                       candidates=(first,layers.candidates[1]))
        results=measure_candidates(frame,track,layers,cfg)
        packet=self.module().build_packet(frame,track,layers,results,cfg)
        self.assertEqual(len(packet['measurements']),1)
        item=packet['measurements'][0]
        self.assertTrue(item['uncertain'])
        self.assertTrue(item['raw_near_warning'])
        self.assertAlmostEqual(item['distance_m'],2.)
        self.assertAlmostEqual(item['observed_min_distance_m'],1.97)
        self.assertEqual(item['observed_source_index'],8)
        self.assertEqual(item.get('observed_source_frame'),0)
        self.assertEqual(item.get('observed_source_time_s'),1.)

    def test_annotation_bridge_does_not_transitively_join_separate_footprints(self):
        from rsview_centerline.clearance.protocol import Candidate,SceneLayers
        cfg=replace(ClearanceConfig(),geometry_label_priority=True)
        points=[[2.+i*.02,y,.4+i*.3] for i in range(3)
                for y in (.5+i*.15,1.+i*.15,1.5+i*.15)]
        frame=cloud(points)
        candidates=tuple(Candidate('part%d'%i,np.arange(i*3,(i+1)*3),np.arange(i*3,(i+1)*3),1.,1.,
            {'display_id':'T%d'%i}) for i in range(3))
        layers=SceneLayers({'object':np.arange(9)},candidates,{}, {})
        track=TrackUpdate('observed_dual',line_track())
        packet=self.module().build_packet(frame,track,layers,
            measure_candidates(frame,track,layers,cfg),cfg)
        self.assertGreaterEqual(len(packet['measurements']),2)

    def test_equal_distance_longitudinally_separate_objects_keep_two_annotations(self):
        frame,track,layers,results,cfg=self.annotation_parts(shift=.8,upper_x=2.)
        packet=self.module().build_packet(frame,track,layers,results,cfg)
        self.assertEqual(len(packet['measurements']),2)

    def lower_surface_fixture(self,ground_height):
        from types import SimpleNamespace
        from rsview_centerline.clearance.protocol import Candidate, SceneLayers
        x,y=np.meshgrid(np.linspace(1.7,2.3,7),np.linspace(.6,1.4,7))
        ground=np.column_stack((x.ravel(),y.ravel(),np.full(x.size,ground_height)))
        points=np.vstack((ground,[[2.,y,-.15] for y in (.9,.92,.94)]))
        frame=cloud(points)
        indices=np.arange(len(ground),len(points))
        candidate=Candidate('lower-surface',indices,indices,1.,1.,{})
        layers=SceneLayers({'ground':np.arange(len(ground)),'object':indices},(candidate,),{}, {})
        model=replace(line_track(),diagnostics={'ground_plane':{'normal_L':[0.,0.,1.],'offset_m':0.}})
        track=TrackUpdate('observed_dual',model)
        cfg=SimpleNamespace(**vars(ClearanceConfig()))
        cfg.geometry_label_priority=True
        return frame,track,layers,measure_candidates(frame,track,layers,cfg),cfg

    def test_below_reference_without_local_raised_surface_evidence_does_not_fill_labels(self):
        frame,track,layers,results,cfg=self.lower_surface_fixture(0.)
        packet=self.module().build_packet(frame,track,layers,results,cfg)
        self.assertEqual(packet['measurements'],[],'unresolved lower terrain promoted to primary equipment')
        self.assertEqual(len(results),1,'literal observation was deleted')
        self.assertEqual(len(packet.get('secondary_measurements',[])),1)
        self.assertAlmostEqual(packet['secondary_measurements'][0]['observed_min_distance_m'],2.)
        self.assertEqual(packet['secondary_measurements'][0]['source_index'],49)

    def test_5cm_target_above_confirmed_lower_terrain_is_not_hidden_by_global_plane(self):
        frame,track,layers,results,cfg=self.lower_surface_fixture(-.20)
        packet=self.module().build_packet(frame,track,layers,results,cfg)
        self.assertEqual(len(packet['measurements']),1)
        self.assertEqual(packet['measurements'][0]['source_index'],49)
        self.assertAlmostEqual(packet['measurements'][0]['distance_m'],2.)

    def test_single_scan_row_of_ground_cannot_certify_lower_target_height(self):
        frame,track,layers,unused,cfg=self.lower_surface_fixture(-.20)
        frame.xyz_L[:49,0]=2.
        packet=self.module().build_packet(frame,track,layers,
            measure_candidates(frame,track,layers,cfg),cfg)
        self.assertEqual(packet['measurements'],[])
        self.assertEqual(len(packet['secondary_measurements']),1)

    def test_secondary_quality_records_keep_uniform_distance_fields_and_raw_provenance(self):
        frame,track,layers,unused,cfg=self.lower_surface_fixture(-.20)
        layers=replace(layers,candidates=(replace(layers.candidates[0],
            diagnostics={'ambiguous_indices':layers.candidates[0].point_indices}),))
        results=measure_candidates(frame,track,layers,cfg)
        packet=self.module().build_packet(frame,track,layers,results,cfg)
        self.assertEqual(packet['measurements'],[])
        record=packet['secondary_measurements'][0]
        self.assertIn('supported_min_distance_m',record)
        self.assertEqual(record.get('observed_source_index'),49)

    def observed_rail_neighbor(self,above_head):
        from rsview_centerline.clearance.protocol import Candidate,SceneLayers
        cfg=replace(ClearanceConfig(),geometry_label_priority=True)
        frame=cloud([[.75,y,.17] for y in (.9,.92,.94)]+
                    [[.75,y,.17+above_head] for y in (.9,.92,.94)])
        candidate=Candidate('raised',np.arange(3,6),np.arange(3,6),1.,1.,{})
        layers=SceneLayers({'rails':np.arange(3),'object':np.arange(3,6)},(candidate,),{}, {})
        model=replace(line_track(start=(0.,0.,.17),end=(0.,2.,.17)),
                      diagnostics={'ground_plane':{'normal_L':[0.,0.,1.],'offset_m':0.}})
        track=TrackUpdate('observed_dual',model)
        return self.module().build_packet(frame,track,layers,measure_candidates(frame,track,layers,cfg),cfg)

    def test_boundary_directly_adjoining_current_rail_returns_stays_secondary(self):
        packet=self.observed_rail_neighbor(.03)
        self.assertEqual(packet['measurements'],[], 'known-rail neighbor was promoted as separate equipment')
        self.assertEqual(packet['secondary_measurements'][0]['reason'],'near_current_observed_rail')
        self.assertEqual(packet['secondary_measurements'][0]['source_index'],3)

    def test_5cm_above_observed_rail_is_not_a_centerline_distance_cutoff(self):
        packet=self.observed_rail_neighbor(.05)
        self.assertEqual(len(packet['measurements']),1)
        self.assertAlmostEqual(packet['measurements'][0]['distance_m'],.75)
        self.assertEqual(packet['measurements'][0]['source_index'],3)

    def test_one_lifted_return_cannot_certify_an_entire_mixed_lower_ground_region(self):
        from rsview_centerline.clearance.protocol import Candidate
        frame,track,layers,unused,cfg=self.lower_surface_fixture(-.20)
        floor_points=[[2.02+x,.8+y,-.20] for x in (0.,.04,.08,.12) for y in (0.,.04,.08)]
        frame=cloud(np.vstack((frame.xyz_L,floor_points)))
        indices=np.arange(49,len(frame.xyz_L))
        layers=replace(layers,indices={'ground':np.arange(49),'object':indices},
                       candidates=(Candidate('mixed',indices,indices,1.,1.,{}),))
        results=measure_candidates(frame,track,layers,cfg)
        packet=self.module().build_packet(frame,track,layers,results,cfg)
        self.assertEqual(packet['measurements'],[], 'one raised edge certified the surrounding floor')

    def test_annotation_layout_only_runs_for_delivered_regions(self):
        from unittest.mock import patch
        module=self.module()
        frame,update,layers,results,cfg=self.fixture()
        with patch.object(module,'_dimension_annotation',wraps=module._dimension_annotation) as layout:
            packet=module.build_packet(frame,update,layers,results,cfg,max_labels=1)
        self.assertEqual(len(packet['measurements']),1)
        self.assertEqual(layout.call_count,1,'unshown regions still consume geometric layout work')
        self.assertEqual(len(results),3)

    def test_packet_layout_uses_exclusive_current_bridge_support_without_changing_minimum(self):
        from rsview_centerline.clearance.scene import SurfaceTracker
        from rsview_centerline.clearance.protocol import Candidate, SceneLayers
        from rsview_centerline.clearance.tests.test_surface_tracking import pose
        cfg=ClearanceConfig()
        tracker=SurfaceTracker(cfg)
        def candidate(name,indices):
            indices=np.array(indices)
            return Candidate(name,indices,indices,1.,1.)
        first=cloud([[2.,y,.5] for y in np.linspace(0.,2.,41)]+[[2.5,1.,.5]])
        original=SceneLayers({'object':np.arange(42)},
            (candidate('wide',range(41)),candidate('other',[41])),{})
        old=tracker.update(first,original,pose(first),line_track())
        identity=old.candidates[0].diagnostics['display_id']
        # A single unique lower fragment plus an ambiguous bridge. No old
        # return is injected into either the measurement or display cloud.
        frame=cloud([[2.,1.,.5],[2.5,1.,.5],[2.,0.,.5]],sequence=1,time=1.1)
        update=TrackUpdate('observed_dual',replace(line_track(),ref_time_s=1.1))
        current=SceneLayers({'object':np.arange(3)},
            (candidate('bridge',[0,1]),candidate('partial',[2])),{})
        current=tracker.update(frame,current,pose(frame),update.model)
        results=measure_candidates(frame,update,current,cfg)
        packet=self.module().build_packet(frame,update,current,results,cfg)
        item=next(m for m in packet['measurements'] if m['display_id']==identity)
        np.testing.assert_allclose(item['dimension_foot_L'],[0.,1.,0.],atol=1e-10)
        self.assertEqual(item['source_frame'],1)
        self.assertEqual(item['source_index'],2)
        self.assertEqual(item['observed_source_index'],2)
        self.assertEqual(item['distance_m'],2.)
        self.assertEqual(item['point_count'],1)
        self.assertEqual(item['display_member_count'],1)
        self.assertEqual(item['member_fragment_ids'],['partial'])
        self.assertEqual(len(packet['measurements']),2)
        self.assertEqual(len(packet['_display']['object']),3)

    def zigzag_track(self, sign=1.):
        from rsview_centerline.clearance.protocol import TrackModel
        nodes=np.array([[0.,0.,0.],[sign*.02,.4,0.],[0.,.8,0.],
                        [sign*.02,1.2,0.],[0.,1.6,0.]])
        segments=tuple(line_track(a,b).segments[0] for a,b in zip(nodes[:-1],nodes[1:]))
        return replace(line_track(),segments=segments)

    def annotation(self, anchor, points=None):
        item=dict(_display_anchor_L=anchor,projected_L=[2.,.8,0.],foot_L=[0.,.8,0.],
                  distance_m=2.,point_L=[2.,.8,.5],source_index=3)
        if points is not None:
            item['_display_points_L']=points
        return item

    def test_short_segment_slope_changes_do_not_shift_dimension_station(self):
        items=[self.annotation([2.,.8,.5]) for unused in range(2)]
        for item,sign in zip(items,(1.,-1.)):
            self.module()._dimension_annotation(item,self.zigzag_track(sign))
            np.testing.assert_allclose(item['dimension_foot_L'],[0.,.8,0.],atol=1e-10)
            np.testing.assert_allclose(item['point_L'],[2.,.8,.5])
            self.assertEqual(item['source_index'],3)
            self.assertEqual(item['distance_m'],2.)
        np.testing.assert_allclose(items[0]['dimension_projected_L'],
                                   items[1]['dimension_projected_L'],atol=1e-10)

    def test_old_anchor_outside_current_visible_region_moves_to_current_region(self):
        item=self.annotation([2.,1.6,.5],[[2.,.7,.5],[2.,.8,.5]])
        self.module()._dimension_annotation(item,line_track())
        np.testing.assert_allclose(item['dimension_foot_L'],[0.,.8,0.],atol=1e-10)
        self.assertEqual(item['dimension_anchor_policy'],'current_visible_station')
        self.assertEqual(item['source_index'],3)
        self.assertEqual(item['distance_m'],2.)

    def test_annotation_follows_a_curved_centerline_not_an_infinite_straight_line(self):
        nodes=np.array([[0.,0.,0.],[.04,.4,0.],[.16,.8,0.],[.36,1.2,0.],[.64,1.6,0.]])
        model=replace(line_track(),segments=tuple(line_track(a,b).segments[0]
                      for a,b in zip(nodes[:-1],nodes[1:])))
        item=self.annotation([2.,.8,.5])
        self.module()._dimension_annotation(item,model)
        foot=np.asarray(item['dimension_foot_L'])
        # Annotation foot remains on the finite measured polyline, even when
        # its stable layout station differs from the actual nearest-return foot.
        residuals=[]
        for segment in model.segments:
            delta=segment.end_L-segment.start_L
            t=np.clip((foot-segment.start_L)@delta/(delta@delta),0.,1.)
            residuals.append(np.linalg.norm(foot-segment.start_L-t*delta))
        self.assertLess(min(residuals),1e-10)
        self.assertGreater(foot[0],.01)

    def test_dimension_layout_is_rigid_pose_equivariant(self):
        model=self.zigzag_track()
        original=self.annotation([2.,.8,.5],[[2.,.7,.5],[2.,.9,.5]])
        self.module()._dimension_annotation(original,model)
        rotation=np.array([[0.,0.,1.],[1.,0.,0.],[0.,1.,0.]])
        offset=np.array([2.,-4.,7.])
        moved=replace(model,segments=tuple(replace(s,start_L=rotation@s.start_L+offset,
            end_L=rotation@s.end_L+offset,left_endpoints_L=s.left_endpoints_L@rotation.T+offset,
            right_endpoints_L=s.right_endpoints_L@rotation.T+offset,
            normal_L=rotation@s.normal_L,across_L=rotation@s.across_L) for s in model.segments))
        item=self.annotation(rotation@np.array([2.,.8,.5])+offset,
            np.array([[2.,.7,.5],[2.,.9,.5]])@rotation.T+offset)
        for key in ('point_L','projected_L','foot_L'):
            item[key]=(rotation@np.asarray(item[key])+offset).tolist()
        self.module()._dimension_annotation(item,moved)
        for key in ('dimension_foot_L','dimension_projected_L'):
            np.testing.assert_allclose(item[key],rotation@np.asarray(original[key])+offset,atol=1e-10)

    def test_no_layout_support_uses_actual_current_evidence_not_old_endpoint(self):
        item=self.annotation([2.,4.,.5],[[2.,3.,.5],[2.,4.,.5]])
        self.module()._dimension_annotation(item,line_track())
        self.assertNotIn('dimension_foot_L',item)
        self.assertEqual(item['source_index'],3)
        from rsview_centerline import clearance_overlay
        self.assertEqual(clearance_overlay.dimension_endpoints(item),
                         (item['projected_L'],item['foot_L']))

    def test_reservation_remembers_only_delivered_annotations_with_small_packet_limit(self):
        from rsview_centerline.clearance.scene import SurfaceTracker
        from rsview_centerline.clearance.tests.test_surface_tracking import pose
        frame,update,layers,results,cfg=self.fixture()
        tracker=SurfaceTracker(cfg)
        layers=tracker.update(frame,layers,pose(frame))
        packet=self.module().build_packet(frame,update,layers,results,cfg,max_labels=1,selection=tracker)
        self.assertEqual(tracker.selected_display_ids,{item['display_id'] for item in packet['measurements']})

    def test_current_reserved_region_is_not_evicted_by_new_clear_fragment(self):
        from rsview_centerline import clearance_overlay
        items=[dict(display_id='T1',display_slot_reserved=True,uncertain=True,point_count=300,
                    distance_m=2.,flags=['nearest_ambiguous_surface']),
               dict(display_id='T2',display_slot_reserved=False,uncertain=False,point_count=30,
                    distance_m=1.,flags=[])]
        self.assertEqual(sorted(items,key=clearance_overlay.measurement_priority)[0]['display_id'],'T1')

    def test_reserved_tiny_region_does_not_monopolize_a_label_over_new_visible_object(self):
        from rsview_centerline import clearance_overlay
        items=[dict(display_id='T1',display_slot_reserved=True,uncertain=False,point_count=2,
                    distance_m=2.,flags=[]),
               dict(display_id='T2',display_slot_reserved=False,uncertain=False,point_count=300,
                    distance_m=1.,flags=[])]
        self.assertEqual(sorted(items,key=clearance_overlay.measurement_priority)[0]['display_id'],'T2')

    def test_split_fragments_share_one_annotation_with_exact_current_minimum(self):
        frame,update,layers,results,cfg = self.fixture()
        # The positive-side returns are two disconnected fragments of one
        # previously observed connected region. The other side stays distinct.
        layers = replace(layers,candidates=tuple(replace(c,diagnostics=dict(c.diagnostics,
            display_id='T1' if frame.xyz_L[c.point_indices[0],0]>0 else 'T2',
            display_anchor_L=[2.,1.6,.5],display_observations=5)) for c in layers.candidates))
        packet = self.module().build_packet(frame,update,layers,results,cfg)
        self.assertEqual(len(packet['measurements']),2)
        item = next(m for m in packet['measurements'] if m['display_id']=='T1')
        self.assertEqual(item['point_count'],3)
        self.assertAlmostEqual(item['distance_m'],2.)  # current supported pair
        self.assertAlmostEqual(item['observed_min_distance_m'],1.8)  # raw isolated return
        self.assertEqual(item['source_index'],0)
        self.assertEqual(item['observed_source_index'],2)
        self.assertTrue(item['raw_near_warning'])

    def test_dimension_annotation_keeps_length_and_anchor_separate_from_real_return(self):
        frame,update,layers,results,cfg = self.fixture()
        layers = replace(layers,candidates=tuple(replace(c,diagnostics=dict(c.diagnostics,
            display_id='T%d'%i,display_anchor_L=[2.,1.6,.5])) for i,c in enumerate(layers.candidates)))
        packet = self.module().build_packet(frame,update,layers,results,cfg)
        for item in packet['measurements']:
            self.assertEqual(item['dimension_model'],'stable_annotation')
            # The old 1.6 m anchor is outside this current visible fragment.
            # Layout is clipped to its present station range, not frozen there.
            points=frame.xyz_L[next(c for c in layers.candidates
                         if c.candidate_id==item['candidate_id']).point_indices]
            np.testing.assert_allclose(item['dimension_foot_L'],[0.,points[:,1].max(),0.])
            self.assertAlmostEqual(np.linalg.norm(np.asarray(item['dimension_projected_L'])-
                                  item['dimension_foot_L']),item['distance_m'],places=10)
            np.testing.assert_allclose(item['point_L'],frame.xyz_L[item['source_index']])
            self.assertEqual(item['dimension_anchor_policy'],'current_visible_station')

    def test_renderer_dimension_geometry_does_not_move_true_boundary_markers(self):
        from rsview_centerline import clearance_overlay
        item=dict(point_L=[2.,1.,.5],projected_L=[2.,1.,0.],foot_L=[0.,1.,0.],
                  dimension_projected_L=[2.,1.6,0.],dimension_foot_L=[0.,1.6,0.])
        self.assertEqual(clearance_overlay.dimension_endpoints(item),([2.,1.6,0.],[0.,1.6,0.]))
        self.assertEqual(list(clearance_overlay.boundary_markers([item])[0]),[2.,1.,.5])
        self.assertEqual(clearance_overlay.dimension_endpoints(dict(projected_L=[2,1,0],foot_L=[0,1,0])),
                         ([2,1,0],[0,1,0]))

    def test_current_display_region_not_displaced_by_a_tiny_established_fragment(self):
        from rsview_centerline import clearance_overlay
        items=[dict(display_id='T1',uncertain=True,point_count=300,display_observations=1,distance_m=2.),
               dict(display_id='T2',uncertain=False,point_count=2,display_observations=100,distance_m=1.)]
        self.assertEqual(sorted(items,key=clearance_overlay.measurement_priority)[0]['display_id'],'T1')

    def test_dense_nearest_ambiguous_ground_boundary_cannot_displace_clear_regions(self):
        from rsview_centerline import clearance_overlay
        items=[dict(display_id='T1',uncertain=True,point_count=9000,display_observations=100,
                    distance_m=.3,flags=['nearest_ambiguous_surface']),
               dict(display_id='T2',uncertain=False,point_count=300,display_observations=1,
                    distance_m=2.,flags=[])]
        self.assertEqual(sorted(items,key=clearance_overlay.measurement_priority)[0]['display_id'],'T2')

    def test_boundary_marker_uses_real_height_not_the_track_plane_projection(self):
        from rsview_centerline import clearance_overlay
        items = [dict(point_L=[2.,1.,.5],projected_L=[2.,1.,0.],foot_L=[0.,1.,0.]),
                 dict(point_L=[-3.,1.,.03],projected_L=[-3.,1.,0.],foot_L=[0.,1.,0.])]
        actual, feet = clearance_overlay.boundary_markers(items)
        np.testing.assert_allclose(actual,[2.,1.,.5,-3.,1.,.03],rtol=0.,atol=1e-8)
        self.assertEqual(list(feet),[0.,1.,0.,0.,1.,0.])
        self.assertEqual(list(clearance_overlay.boundary_markers([])[0]),[])

    def test_unconfirmed_raw_minimum_stays_separate_from_selected_boundary(self):
        from rsview_centerline import clearance_overlay
        items=[dict(raw_near_warning=True,source_index=1,observed_source_index=0,
                    point_L=[2.,1.,.5],observed_point_L=[1.2,1.,.5]),
               dict(raw_near_warning=False,source_index=3,observed_source_index=3,
                    point_L=[-2.,1.,.5],observed_point_L=[-2.,1.,.5])]
        raw=clearance_overlay.raw_boundary_markers(items)
        np.testing.assert_allclose(raw,[1.2,1.,.5],rtol=0.,atol=1e-7)

    def test_unsupported_raw_near_return_does_not_become_confident_green_estimate(self):
        from rsview_centerline.clearance.protocol import Candidate, SceneLayers
        frame = cloud([(1.2, 1., .5), (2., 1., .5), (2.01, 1.01, .5)])
        update, cfg = TrackUpdate('observed_dual', line_track()), ClearanceConfig()
        candidate = Candidate('object', np.array([0, 1, 2]), np.array([1, 2]), 1., 1.)
        layers = SceneLayers({'object': np.array([0, 1, 2])}, (candidate,), {})
        result = measure_candidates(frame, update, layers, cfg)
        item = self.module().build_packet(frame, update, layers, result, cfg)['measurements'][0]
        self.assertAlmostEqual(item['distance_m'], 2.)
        self.assertEqual(item['source_index'], 1)
        self.assertAlmostEqual(item['observed_min_distance_m'], 1.2)
        self.assertEqual(item['observed_source_index'], 0)
        self.assertTrue(item['raw_near_warning'])
        self.assertEqual(item['boundary_choice'], 'supported_current_return')

    def module(self):
        name = 'rsview_centerline.clearance.rsview_cache'
        self.assertIsNotNone(importlib.util.find_spec(name), 'RSView cache bridge is missing')
        return __import__(name, fromlist=['build_packet'])

    def fixture(self):
        frame = cloud([(2., 1., .5), (2.03, 1.02, .53), (1.8, 1., .5),
                       (-2.3, 1., .7), (-2.31, 1.02, .72)])
        update = TrackUpdate('observed_dual', line_track())
        cfg = ClearanceConfig()
        layers = extract_scene(frame, update, [], cfg)
        results = measure_candidates(frame, update, layers, cfg)
        return frame, update, layers, results, cfg

    def test_label_distance_and_line_use_same_actual_return(self):
        module = self.module()
        frame, update, layers, results, cfg = self.fixture()
        packet = module.build_packet(frame, update, layers, results, cfg)
        self.assertTrue(packet['measurements'])
        for item in packet['measurements']:
            a, b = np.asarray(item['projected_L']), np.asarray(item['foot_L'])
            self.assertAlmostEqual(np.linalg.norm(a-b), item['distance_m'], places=10)
            np.testing.assert_allclose(item['point_L'], frame.xyz_L[item['source_index']])
        self.assertEqual(packet['sequence'], 0)
        self.assertEqual(packet['calculation'], 'offline_precomputed')

    def test_packet_keeps_surface_identity_separate_from_raw_evidence(self):
        module = self.module()
        frame, update, layers, results, cfg = self.fixture()
        layers = replace(layers,candidates=tuple(replace(c,diagnostics=dict(c.diagnostics,
            surface_id='S%d' % i,surface_observations=5,surface_association='matched'))
            for i,c in enumerate(layers.candidates)))
        packet = module.build_packet(frame, update, layers, results, cfg)
        for item in packet['measurements']:
            self.assertIn('surface_id',item)
            self.assertEqual(item['surface_observations'],5)
            self.assertEqual(item['surface_association'],'matched')
            self.assertEqual(item['source_frame'],frame.sequence)
            self.assertTrue(item['candidate_id'].startswith('frame0-component'))

    def test_established_surface_is_not_displaced_just_by_new_surface_density(self):
        module = self.module()
        frame = cloud([(2.,1.,.5),(2.01,1.01,.51)] +
                      [(-2.3-i*.001,1.+i*.001,.7) for i in range(20)])
        update,cfg = TrackUpdate('observed_dual',line_track()),ClearanceConfig()
        layers = extract_scene(frame,update,[],cfg)
        layers = replace(layers,candidates=tuple(replace(c,diagnostics=dict(c.diagnostics,
            surface_id='S%d' % i,surface_observations=5 if i==0 else 1,
            surface_association='matched' if i==0 else 'new')) for i,c in enumerate(layers.candidates)))
        results = measure_candidates(frame,update,layers,cfg)
        packet = module.build_packet(frame,update,layers,results,cfg,max_labels=1)
        self.assertEqual(packet['measurements'][0]['candidate_id'],layers.candidates[0].candidate_id)
        # Embedded Python must not resort the producer's tracked priority by density.
        from rsview_centerline import clearance_overlay
        with tempfile.TemporaryDirectory() as directory:
            module.write_packet(directory,module.build_packet(frame,update,layers,results,cfg))
            loaded = clearance_overlay.PacketCache(directory).get(0)
            self.assertEqual(loaded['measurements'][0]['candidate_id'],layers.candidates[0].candidate_id)

    def test_label_priority_does_not_promote_tiny_fragment_just_because_it_is_closer(self):
        module = self.module()
        frame = cloud([(1.,1.,.5),(1.01,1.01,.51)] +
                      [(-2.3-i*.001,1.+i*.001,.7) for i in range(20)])
        update,cfg = TrackUpdate('observed_dual',line_track()),ClearanceConfig()
        layers = extract_scene(frame,update,[],cfg)
        layers = replace(layers,candidates=tuple(replace(c,diagnostics=dict(c.diagnostics,
            surface_id='S%d' % i,surface_observations=5,surface_association='matched'))
            for i,c in enumerate(layers.candidates)))
        packet = module.build_packet(frame,update,layers,measure_candidates(frame,update,layers,cfg),cfg,max_labels=1)
        self.assertEqual(packet['measurements'][0]['point_count'],20)
        # The tiny fragment is still measured; it is only outside this one text slot.
        self.assertEqual(len(measure_candidates(frame,update,layers,cfg)),2)

    def test_cache_selects_exact_frame_never_nearest_or_future(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            frame, update, layers, results, cfg = self.fixture()
            module.write_packet(folder, module.build_packet(frame, update, layers, results, cfg))
            from rsview_centerline import clearance_overlay
            cache = clearance_overlay.PacketCache(str(folder))
            self.assertEqual(cache.get(0)['sequence'], 0)
            self.assertIsNone(cache.get(1))
            self.assertIsNone(cache.get(-1))

    def test_target_dispatch_does_not_change_existing_22222(self):
        self.module()
        from rsview_centerline import clearance_overlay
        self.assertTrue(clearance_overlay.is_target_file('C:/data/1212121.pcap'))
        self.assertFalse(clearance_overlay.is_target_file('C:/data/22222.pcap'))
        self.assertFalse(clearance_overlay.is_target_file('C:/other/unknown.pcap'))

    def test_invalid_track_has_no_fresh_measurement_or_old_centerline(self):
        module = self.module()
        frame, _, _, _, cfg = self.fixture()
        update = TrackUpdate('ambiguous_track')
        layers = extract_scene(frame, update, [], cfg)
        results = measure_candidates(frame, update, layers, cfg)
        packet = module.build_packet(frame, update, layers, results, cfg)
        self.assertEqual(packet['centerline'], [])
        self.assertEqual(packet['measurements'], [])

    def test_packet_is_bounded_and_no_point_ref_or_neighbor_log_replication(self):
        module = self.module()
        frame, update, layers, results, cfg = self.fixture()
        packet = module.build_packet(frame, update, layers, results, cfg)
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            module.write_packet(folder, packet)
            self.assertLess((folder/'frame-0000.json').stat().st_size, 32768)
            self.assertNotIn('observation_refs', packet)
            self.assertNotIn('support_neighbor_indices', packet)

    def test_ambiguous_nearest_surface_does_not_take_priority_over_clear_object(self):
        module = self.module()
        frame, update, layers, results, cfg = self.fixture()
        # A component may have many supported points while its actual nearest
        # return is still an ambiguous ground/rail boundary.
        results = [replace(r, flags=r.flags+('nearest_ambiguous_surface',))
                   if r.side == 'right' else r for r in results]
        packet = module.build_packet(frame, update, layers, results, cfg, max_labels=1)
        self.assertAlmostEqual(packet['measurements'][0]['distance_m'], 2.3)
        self.assertFalse(packet['measurements'][0]['uncertain'])

    def test_close_screen_anchors_do_not_overlap_distance_labels(self):
        self.module()
        from rsview_centerline import clearance_overlay
        self.assertTrue(hasattr(clearance_overlay, 'label_positions'))
        positions = clearance_overlay.label_positions([(100, 100), (110, 110)], [150, 150], (800, 600))
        a, b = positions
        overlaps = a[0] < b[0]+150 and b[0] < a[0]+150 and a[1] < b[1]+24 and b[1] < a[1]+24
        self.assertFalse(overlaps)
        for x, y in positions:
            self.assertGreaterEqual(x, 0)
            self.assertLessEqual(x+150, 800)
            self.assertGreaterEqual(y, 0)
            self.assertLessEqual(y+24, 600)


if __name__ == '__main__':
    unittest.main()
