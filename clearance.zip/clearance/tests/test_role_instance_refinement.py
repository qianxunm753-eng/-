"""Literature-inspired role/proposal changes must preserve native boundaries."""
from dataclasses import dataclass, replace
import unittest
import numpy as np

from rsview_centerline.clearance.protocol import ClearanceConfig, Candidate, SceneLayers, TrackUpdate
from rsview_centerline.clearance.scene import extract_scene
from rsview_centerline.clearance.objects import refine_objects
from rsview_centerline.clearance.measure import measure_candidates
from rsview_centerline.clearance.rsview_cache import build_packet
from rsview_centerline.clearance.tests.fixtures import cloud, line_track
from rsview_centerline.clearance.tests.test_rail_roles import profile_scene


@dataclass(frozen=True)
class ProposedConfig(ClearanceConfig):
    track_structure_context: bool = True
    temporal_object_proposals: bool = True
    surface_object_proposals: bool = True


class StructureContextTests(unittest.TestCase):
    def test_unknown_rail_fragment_cannot_bridge_into_independent_surface(self):
        rails, ground, model = profile_scene()
        unknown = [[-.675, y, .09] for y in (1.21, 1.23, 1.25)]
        target = [[-.625, y, .09] for y in (1.21, 1.23, 1.25)]
        frame = cloud(np.vstack((rails, ground, unknown, target)))
        layers = extract_scene(frame, TrackUpdate('observed_dual', model), [],
                               ProposedConfig(rail_profile_roles=True))
        start = len(rails)+len(ground)
        a, b = set(range(start,start+3)), set(range(start+3,start+6))
        self.assertTrue(a <= set(layers.indices['unknown_track_structure']))
        self.assertTrue(all(not (a & set(c.point_indices) and b & set(c.point_indices))
                            for c in layers.candidates), 'unresolved rail points joined a real object')
        self.assertTrue(b <= set(layers.indices['object']), 'near-rail target was deleted')
        packet=build_packet(frame,TrackUpdate('observed_dual',model),layers,
            measure_candidates(frame,TrackUpdate('observed_dual',model),layers,
                               ProposedConfig(rail_profile_roles=True,geometry_label_priority=True)),
            ProposedConfig(rail_profile_roles=True,geometry_label_priority=True))
        self.assertFalse(b & {m['source_index'] for m in packet['measurements']},
                         'clean residue automatically became equipment after role splitting')

    def test_repeated_above_fit_returns_are_unknown_not_confirmed_equipment(self):
        rails, ground, model = profile_scene()
        extension = [[.72, y, .235] for y in (.3,.8,1.3,1.8,2.3)]
        frame = cloud(np.vstack((rails, ground, extension)))
        cfg = ProposedConfig(rail_profile_roles=True, geometry_label_priority=True)
        track = TrackUpdate('observed_dual',model)
        layers = extract_scene(frame,track,[],cfg)
        ids = np.arange(len(rails)+len(ground),len(frame.xyz_L))
        self.assertTrue(np.isin(ids,layers.indices['unknown_track_structure']).all(),
                        'repeated rail-adjacent extension was promoted without independent object evidence')
        self.assertFalse(np.isin(ids,layers.indices['rails']).any(), 'context invented confirmed rail identity')
        packet = build_packet(frame,track,layers,measure_candidates(frame,track,layers,cfg),cfg)
        self.assertFalse({m['source_index'] for m in packet['measurements']} & set(ids))
        self.assertTrue(np.isin(ids,layers.indices['object']).all(), 'unknown returns were erased')

    def test_isolated_five_cm_target_above_rail_keeps_original_measurement(self):
        rails, ground, model = profile_scene()
        target = [[.72+x,y,.22] for x in (-.01,.01) for y in (1.3,1.32,1.34)]
        frame = cloud(np.vstack((rails,ground,target)))
        cfg = ProposedConfig(rail_profile_roles=True,geometry_label_priority=True)
        track = TrackUpdate('observed_dual',model)
        layers = extract_scene(frame,track,[],cfg)
        ids = set(range(len(rails)+len(ground),len(frame.xyz_L)))
        self.assertFalse(ids & set(layers.indices['rails']))
        self.assertFalse(ids & set(layers.indices['unknown_track_structure']))
        packet = build_packet(frame,track,layers,measure_candidates(frame,track,layers,cfg),cfg)
        self.assertTrue(ids & {m['source_index'] for m in packet['measurements']})

    def test_expanded_unknown_observations_cannot_teach_confirmed_rail_profile(self):
        rails,ground,model=profile_scene()
        isolated=[[.72,1.3,.20]]
        expanded=[[.72,y,.206] for y in (.3,.8,1.8,2.3)]
        frame=cloud(np.vstack((rails,ground,isolated,expanded)))
        cfg=ProposedConfig(rail_profile_roles=True)
        layers=extract_scene(frame,TrackUpdate('observed_dual',model),[],cfg)
        target=len(rails)+len(ground)
        self.assertNotIn(target,layers.indices['rails'],'expanded unknown search confirmed an isolated target')
        self.assertIn(target,layers.indices['object'])


class TemporalProposalTests(unittest.TestCase):
    def scene(self, history_labels=None):
        # One continuously observed earlier face; two disconnected same-height
        # visible pieces now. No fabricated current points between the pieces.
        previous = cloud([[2.,y,.5] for y in np.arange(.3,1.01,.02)],sequence=0,time=1.)
        previous = replace(previous, ref_time_s=1.1,motion_status='compensated_history',
            diagnostics=dict(aligned_to_ref_time_s=1.1,
                object_proposal_labels=np.zeros(len(previous.xyz_L),dtype=np.int64)
                if history_labels is None else history_labels))
        groups = [[[2.,y,.5] for y in np.arange(.3,.61,.02)],
                  [[2.,y,.5] for y in np.arange(.72,1.01,.02)]]
        current = cloud(groups[0]+groups[1],sequence=1,time=1.1)
        split = len(groups[0])
        candidates = tuple(Candidate('piece%d'%i,np.asarray(g),np.asarray(g),1.1,1.1)
            for i,g in enumerate((range(split),range(split,len(current.xyz_L)))))
        layers = SceneLayers({'object':np.arange(len(current.xyz_L))},candidates,{}, {})
        track = TrackUpdate('observed_dual',line_track(time=1.1))
        return current,track,layers,previous

    def test_shared_exclusive_historical_proposal_merges_current_fragments(self):
        current,track,layers,previous = self.scene()
        refined = refine_objects(current,track,layers,ProposedConfig(),[previous])
        self.assertEqual(len(refined.candidates),1, 'same object still emitted two same-height candidates')
        np.testing.assert_array_equal(refined.candidates[0].point_indices,np.arange(len(current.xyz_L)))
        measured = measure_candidates(current,track,refined,ProposedConfig())
        self.assertEqual(len(measured),1)
        self.assertEqual(measured[0].observed_evidence.point_ref.frame,1)
        self.assertAlmostEqual(measured[0].observed_min_distance_m,2.)
        self.assertFalse(refined.candidates[0].diagnostics.get('semantic_identity_confirmed',False))

    def test_no_history_cannot_invent_object_membership(self):
        current,track,layers,unused = self.scene()
        refined = refine_objects(current,track,layers,ProposedConfig(),[])
        self.assertEqual(len(refined.candidates),2)

    def test_different_historical_owners_keep_adjacent_objects_separate(self):
        current,track,layers,previous = self.scene()
        labels = np.where(previous.xyz_L[:,1]<.67,0,1)
        previous = replace(previous,diagnostics=dict(previous.diagnostics,object_proposal_labels=labels))
        refined = refine_objects(current,track,layers,ProposedConfig(),[previous])
        self.assertEqual(len(refined.candidates),2)

    def test_unaligned_stale_foreign_and_future_history_cannot_merge(self):
        current,track,layers,previous = self.scene()
        for bad in (replace(previous,motion_status='raw'),
                    replace(previous,session_id='other'),
                    replace(previous,diagnostics=dict(previous.diagnostics,aligned_to_ref_time_s=1.)),
                    replace(previous,refs=tuple(replace(r,time_s=.1) for r in previous.refs)),
                    replace(previous,refs=tuple(replace(r,frame=2) for r in previous.refs))):
            with self.subTest(history=bad.motion_status,session=bad.session_id,ref=bad.refs[0]):
                self.assertEqual(len(refine_objects(current,track,layers,ProposedConfig(),[bad]).candidates),2)

    def test_unknown_role_cannot_acquire_independent_object_owner(self):
        current,track,layers,previous = self.scene()
        candidates = (replace(layers.candidates[0],diagnostics={'point_role':'unknown_track'}),
                      layers.candidates[1])
        layers = replace(layers,candidates=candidates)
        self.assertEqual(len(refine_objects(current,track,layers,ProposedConfig(),[previous]).candidates),2)

    def test_legacy_configuration_keeps_same_height_fragments_separate(self):
        current,track,layers,previous = self.scene()
        self.assertEqual(len(refine_objects(current,track,layers,ClearanceConfig(),[previous]).candidates),2)

    def test_replay_carries_current_proposal_ownership_through_motion_alignment(self):
        from rsview_centerline.clearance.replay import ReplayEngine
        from rsview_centerline.clearance.tests.test_motion import Analytic
        current,unused,layers,aligned = self.scene()
        previous = cloud(aligned.xyz_L,sequence=0,time=1.)
        engine = ReplayEngine(ProposedConfig(),'tracked',Analytic(),
            observer=lambda f: TrackUpdate('observed_dual',line_track(time=f.ref_time_s)))
        engine.step(previous)
        update,refined,results = engine.step(current)
        self.assertEqual(len(refined.candidates),1, 'online path lost historical proposal labels')
        self.assertEqual(len(results),1)
        self.assertEqual(results[0].observed_evidence.point_ref.frame,1)

    def test_history_owner_labels_stay_parallel_to_transformed_point_refs(self):
        from rsview_centerline.clearance.motion import transform_history
        from rsview_centerline.clearance.tests.test_motion import Analytic
        past = replace(cloud([[2.,.3,.5],[2.,.8,.5]],time=1.,sequence=0),
            motion_status='deskewed_experimental',diagnostics={'object_proposal_labels':np.array([4,9])})
        current = replace(cloud([[2.,.4,.5]],time=1.1,sequence=1),motion_status='deskewed_experimental')
        aligned = transform_history([past],current,Analytic(),ProposedConfig(),include_current=False)
        self.assertIn('object_proposal_labels',aligned.diagnostics,'proposal ownership was dropped during alignment')
        np.testing.assert_array_equal(aligned.diagnostics['object_proposal_labels'],[4,9])
        self.assertEqual(aligned.refs,past.refs)

    def test_shared_history_cannot_hide_competing_owner(self):
        current,track,layers,previous = self.scene()
        # Two separate proposals at exactly the same observed surface: geometry
        # does not resolve ownership. Duplicate density cannot break the tie.
        pts=np.concatenate((np.repeat(previous.xyz_L,20,axis=0),previous.xyz_L))
        refs=tuple(previous.refs[int(i)] for i in np.r_[np.repeat(np.arange(len(previous.xyz_L)),20),
                                                     np.arange(len(previous.xyz_L))])
        labels=np.r_[np.zeros(len(previous.xyz_L)*20,dtype=int),np.ones(len(previous.xyz_L),dtype=int)]
        previous=replace(previous,xyz_L=pts,refs=refs,
            diagnostics=dict(previous.diagnostics,object_proposal_labels=labels))
        self.assertEqual(len(refine_objects(current,track,layers,ProposedConfig(),[previous]).candidates),2)

    def test_native_competing_owner_at_voxel_edge_cannot_be_sampled_away(self):
        current,track,layers,previous=self.scene()
        for order in ((2.079,2.064),(2.064,2.079)):
            extra=np.array([[x,p[1],.5] for p in previous.xyz_L for x in order])
            refs=previous.refs+tuple(previous.refs[int(i//2)] for i in range(len(extra)))
            labels=np.r_[np.zeros(len(previous.xyz_L),dtype=int),np.ones(len(extra),dtype=int)]
            past=replace(previous,xyz_L=np.r_[previous.xyz_L,extra],refs=refs,
                diagnostics=dict(previous.diagnostics,object_proposal_labels=labels))
            with self.subTest(order=order):
                self.assertEqual(len(refine_objects(current,track,layers,ProposedConfig(),[past]).candidates),2,
                                 'voxel representative hid a real competing owner')

    def test_minority_competing_owner_blocks_whole_candidate_membership(self):
        current,track,layers,previous=self.scene()
        extra=np.array([[2.,.3,.5]])
        past=replace(previous,xyz_L=np.r_[previous.xyz_L,extra],refs=previous.refs+(previous.refs[0],),
            diagnostics=dict(previous.diagnostics,
                object_proposal_labels=np.r_[np.zeros(len(previous.xyz_L),dtype=int),1]))
        self.assertEqual(len(refine_objects(current,track,layers,ProposedConfig(),[past]).candidates),2,
                         'majority support swallowed an ambiguous current boundary')

    def test_inherited_merges_expire_when_original_proof_leaves_history_horizon(self):
        from rsview_centerline.clearance.replay import ReplayEngine
        from rsview_centerline.clearance.tests.test_motion import Analytic
        current,unused,layers,aligned=self.scene()
        cfg=ProposedConfig(history_seconds=.25,surface_object_proposals=False)
        engine=ReplayEngine(cfg,'tracked',Analytic(),
            observer=lambda f: TrackUpdate('observed_dual',line_track(time=f.ref_time_s)))
        engine.step(cloud(aligned.xyz_L,sequence=0,time=1.))
        first=engine.step(current)[1]
        self.assertEqual(len(first.candidates),1)
        for seq in range(2,6):
            last=engine.step(cloud(current.xyz_L,sequence=seq,time=1.+seq*.1))[1]
        self.assertEqual(len(last.candidates),2,'inferred labels renewed expired physical bridge proof')

    def test_one_current_corner_cannot_renew_temporal_only_attachment(self):
        from rsview_centerline.clearance.replay import ReplayEngine
        from rsview_centerline.clearance.tests.test_motion import Analytic
        a=[[2.,y,z] for y in np.arange(.3,.601,.02) for z in np.arange(.2,.801,.04)]
        b=[[x,.7,z] for x in np.arange(2.04,2.161,.02) for z in np.arange(.2,.801,.04)]
        c=[[2.08,.58,z] for z in np.arange(.2,.801,.04)]
        bridge=[[2.04,.58,.5],[2.08,.64,.5]]
        cfg=ProposedConfig(history_seconds=.25)
        engine=ReplayEngine(cfg,'tracked',Analytic(),
            observer=lambda f: TrackUpdate('observed_dual',line_track(time=f.ref_time_s)))
        engine.step(cloud(a+b+c+bridge,sequence=0,time=1.))
        for seq in range(1,7):
            last=engine.step(cloud(a+b+c,sequence=seq,time=1.+seq*.1))[1]
        # The two observed planes may still form a current corner. The line
        # that was joined only by expired bridges must remain its own fragment.
        self.assertGreater(len(last.candidates),1,'one fresh pair renewed every member of a mixed group')

    def test_temporal_group_preserves_a_rare_current_nearest_return(self):
        current,track,layers,previous=self.scene()
        current.xyz_L[-1,0]=1.98
        refined=refine_objects(current,track,layers,ProposedConfig(),[previous])
        self.assertEqual(len(refined.candidates),1)
        results=measure_candidates(current,track,refined,ProposedConfig())
        self.assertAlmostEqual(results[0].observed_min_distance_m,1.98)
        self.assertEqual(results[0].observed_evidence.point_ref.index,len(current.xyz_L)-1)


class CurrentSurfaceProposalTests(unittest.TestCase):
    def refine(self,parts,config=None,history=()):
        frame=cloud(np.concatenate([np.asarray(p) for p in parts]))
        ends=np.cumsum([0]+[len(p) for p in parts])
        candidates=tuple(Candidate('surface%d'%i,np.arange(ends[i],ends[i+1]),
            np.arange(ends[i],ends[i+1]),1.,1.) for i in range(len(parts)))
        layers=SceneLayers({'object':np.arange(len(frame.xyz_L))},candidates,{}, {})
        track=TrackUpdate('observed_dual',line_track())
        cfg=config or ProposedConfig()
        return frame,track,refine_objects(frame,track,layers,cfg,history)

    def test_interleaved_coplanar_scan_strips_form_one_current_proposal(self):
        parts=[[[2.,y,z] for y in rows for z in np.arange(.2,.81,.04)]
               for rows in ((.3,.5,.7,.9),(.4,.6,.8,1.))]
        frame,track,layers=self.refine(parts)
        self.assertEqual(len(layers.candidates),1,'interleaved same-surface strips produced duplicate objects')
        np.testing.assert_array_equal(layers.candidates[0].point_indices,np.arange(len(frame.xyz_L)))
        result=measure_candidates(frame,track,layers,ProposedConfig())[0]
        self.assertAlmostEqual(result.observed_min_distance_m,2.)

    def test_observed_corner_edges_support_adjacent_faces(self):
        # Surface x=2 and surface y=.7 both reach the same observed vertical
        # corner, with a scan-sized gap. They are not parallel stacked boxes.
        a=[[2.,y,z] for y in (.3,.4,.5,.6) for z in np.arange(.2,.81,.04)]
        b=[[x,.7,z] for x in (2.04,2.08,2.12,2.16) for z in np.arange(.2,.81,.04)]
        frame,track,layers=self.refine([a,b])
        self.assertEqual(len(layers.candidates),1,'faces meeting at an observed corner stayed fragmented')
        self.assertEqual(len(layers.candidates[0].point_indices),len(a)+len(b))

    def test_parallel_nearby_objects_are_not_merged(self):
        parts=[[[x,y,z] for y in (.3,.5,.7,.9) for z in (.2,.4,.6,.8)] for x in (2.,2.12)]
        self.assertEqual(len(self.refine(parts)[2].candidates),2)

    def test_coplanar_adjacent_boxes_with_disjoint_station_support_stay_separate(self):
        parts=[[[2.,y,z] for y in rows for z in (.2,.4,.6,.8)]
               for rows in ((.3,.4,.5,.6),(.72,.82,.92,1.02))]
        self.assertEqual(len(self.refine(parts)[2].candidates),2)

    def test_no_visible_common_edge_means_no_corner_proposal(self):
        a=[[2.,y,z] for y in (.3,.4,.5,.6) for z in (.2,.4,.6,.8)]
        b=[[x,.7,z] for x in (2.04,2.08,2.12,2.16) for z in (1.,1.2,1.4,1.6)]
        self.assertEqual(len(self.refine([a,b])[2].candidates),2)

    def test_default_route_does_not_use_new_current_surface_proposals(self):
        parts=[[[2.,y,z] for y in rows for z in (.2,.4,.6,.8)]
               for rows in ((.3,.5,.7,.9),(.4,.6,.8,1.))]
        self.assertEqual(len(self.refine(parts,ClearanceConfig())[2].candidates),2)

    def test_two_disjoint_diagonal_ribbons_do_not_become_one_planar_object(self):
        parts=[[[2.,y,y+offset+w] for y in np.arange(.3,.901,.02) for w in (0.,.02)]
               for offset in (0.,.15)]
        self.assertEqual(len(self.refine(parts)[2].candidates),2,
                         'bbox overlap replaced actual occupied planar overlap')

    def test_current_corner_cannot_override_different_exclusive_history_owners(self):
        a=[[2.,y,z] for y in (.3,.4,.5,.6) for z in np.arange(.2,.81,.04)]
        b=[[x,.7,z] for x in (2.04,2.08,2.12,2.16) for z in np.arange(.2,.81,.04)]
        previous=cloud(a+b,sequence=-1,time=.9)
        previous=replace(previous,ref_time_s=1.,motion_status='compensated_history',
            diagnostics=dict(aligned_to_ref_time_s=1.,
                object_proposal_labels=np.r_[np.zeros(len(a),dtype=int),np.ones(len(b),dtype=int)]))
        self.assertEqual(len(self.refine([a,b],history=[previous])[2].candidates),2,
                         'current geometry bypassed exclusive owner conflict')

    def test_new_route_conflict_veto_also_applies_to_vertical_footprint_rule(self):
        parts=[[[2.+x,1.+y,z] for x in (0.,.02,.04) for y in (0.,.02,.04)] for z in (.2,1.)]
        previous=cloud(parts[0]+parts[1],sequence=-1,time=.9)
        previous=replace(previous,ref_time_s=1.,motion_status='compensated_history',
            diagnostics=dict(aligned_to_ref_time_s=1.,object_proposal_labels=np.r_[np.zeros(9,dtype=int),
                np.ones(9,dtype=int)]))
        self.assertEqual(len(self.refine(parts,history=[previous])[2].candidates),2)
        self.assertEqual(len(self.refine(parts,ClearanceConfig(),[previous])[2].candidates),1,
                         'legacy default-off vertical grouping unexpectedly changed')


if __name__ == '__main__':
    unittest.main()
