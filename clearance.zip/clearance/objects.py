"""Conservative geometric ownership, never a device-type classifier.

Native 3-D connectivity is established by scene.py. Vertically separated
fragments may additionally share an actually observed track-plane footprint.
Overlapping side-by-side boxes and horizontally separated neighbors are not
merged. All distance evidence stays in the current native point index space.
"""
from dataclasses import replace
import numpy as np
from scipy.spatial import cKDTree, ConvexHull, QhullError
from .protocol import measurement_model, validate_frame, validate_track
from .voxel import representatives as voxel_representatives


def _spatial_sample(points, config, maximum=64):
    keep, unused = voxel_representatives(points,config.neighbor_base_m*.5)
    sample = points[keep]
    if len(sample)>maximum:
        ranks=np.linspace(0,len(sample)-1,max(2,maximum//3),dtype=int)
        keep=np.unique(np.concatenate([np.argsort(sample[:,axis],kind='stable')[ranks]
                                       for axis in range(3)]))
        sample=sample[keep]
    return sample


def qualified_core_indices(frame,candidate,config):
    """Evidence for proposing a group, never a replacement measurement set.

    Whole unknown roles remain unknown. A mostly uncertain surface cannot be
    approved by a small reliable island; fractions use occupied cells rather
    than raw density. Every native ambiguous return remains in its candidate.
    """
    empty=np.empty(0,dtype=np.int64)
    if (candidate.diagnostics.get('point_role') in ('unknown_ground','unknown_track','unknown_rail_scope') or
            candidate.diagnostics.get('structure_split_pending')):
        return empty
    indices=candidate.point_indices
    uncertain=np.asarray(candidate.diagnostics.get('ambiguous_indices',()))
    if not uncertain.size:
        return indices
    ambiguous=np.isin(indices,uncertain)
    if not ambiguous.any():
        return indices
    if not config.qualified_object_cores:
        return empty
    keep,inverse=voxel_representatives(frame.xyz_L[indices],config.neighbor_base_m*.5)
    uncertain_cells=np.zeros(len(keep),dtype=bool)
    np.maximum.at(uncertain_cells,inverse,ambiguous)
    if not len(keep) or np.mean(~uncertain_cells)<.7:
        return empty
    return indices[~ambiguous]


def _proposal_radius(points,config):
    # This radius only searches for geometric membership. In the qualified
    # route neither excluded unknown density nor repeated core returns may
    # change it. Literal measurements never use this derived centre.
    center=(points.min(axis=0)+points.max(axis=0))*.5 if config.qualified_object_cores else points.mean(axis=0)
    return config.neighbor_base_m+config.neighbor_angle_rad*np.linalg.norm(center)


def _historical_owners(frame, candidates, history, config, cores=None,diagnostics=None):
    """Exclusive geometric proposal support, NOT learned semantic identity.

    Use one latest eligible past scan; never combine labels from different
    frames or infer connectivity by stacking them. Unknown points carry -1.
    Replay v25 may use a validated qualified instance ID for that source's
    multiple fragment labels. Unqualified labels stay separate competitors.
    Historical XYZ only proposes membership; all measurement indices remain
    current. Compare every nearby owner independently to avoid density ties.
    """
    owners = [None]*len(candidates)
    conflicts = np.zeros(len(candidates),dtype=bool)
    qualified = set()
    qualified_ids = {}
    if config.qualified_history_reconciliation:
        from .history_evidence import qualified_history_instances
        instances = qualified_history_instances(frame,history,config)
        qualified = {(item['source_frame'],item['label']) for item in instances}
        if config.qualified_history_owner_keys:
            qualified_ids = {(item['source_frame'],item['label']):item['object_id'] for item in instances}
    if diagnostics is not None:
        diagnostics['historical_instance_owner_alias_groups'] = 0
    parts=[]
    for past in history:
        if (past.session_id != frame.session_id or past.clock_id != frame.clock_id or
                past.motion_status != 'compensated_history' or past.ref_time_s != frame.ref_time_s or
                past.diagnostics.get('aligned_to_ref_time_s') != frame.ref_time_s):
            continue
        labels=np.asarray(past.diagnostics.get('object_proposal_labels',()))
        if labels.shape != (len(past.xyz_L),) or labels.dtype.kind not in 'iu':
            continue
        try:
            origins=np.asarray(past.diagnostics.get('object_proposal_origin_time_s',
                [r.time_s for r in past.refs]),dtype=float)
        except (TypeError,ValueError):
            if config.qualified_history_reconciliation:
                continue
            raise
        if origins.shape != (len(past.xyz_L),):
            continue
        valid=np.array([r.frame<frame.sequence and r.time_s is not None and
            0.<=frame.scan_span_s[1]-r.time_s<=config.history_seconds+1e-9
            for r in past.refs],dtype=bool)
        valid &= (labels>=0)&np.isfinite(past.xyz_L).all(axis=1)
        valid &= np.isfinite(origins)&(origins<=frame.scan_span_s[1])
        valid &= frame.scan_span_s[1]-origins<=config.history_seconds+1e-9
        valid &= np.einsum('ij,ij->i',past.xyz_L,past.xyz_L)>1e-12
        if valid.any():
            source=np.array([r.frame for r in past.refs],dtype=np.int64)
            parts.append((past.xyz_L[valid],labels[valid],source[valid],origins[valid]))
    if not parts:
        return owners,conflicts
    points=np.concatenate([p[0] for p in parts])
    labels=np.concatenate([p[1] for p in parts])
    sources=np.concatenate([p[2] for p in parts])
    origins=np.concatenate([p[3] for p in parts])
    latest=int(sources.max())
    keep=sources==latest
    points,labels,origins=points[keep],labels[keep],origins[keep]
    if config.qualified_history_owner_keys:
        # Labels namespace source fragments, not physical/instance owners.
        # Only independently qualified records from this SAME source may
        # establish alias keys. Every other raw label remains a competitor;
        # equal distance, overlap or a tentative ID does not merge its key.
        aliases = {}
        for label in np.unique(labels):
            identity = qualified_ids.get((latest,int(label)))
            owner_key = ('instance',identity) if identity is not None else ('label',int(label))
            aliases.setdefault(owner_key,[]).append(int(label))
        owner_labels = labels.copy()
        alias_count = 0
        for members in aliases.values():
            if len(members)>1:
                owner_labels[np.isin(labels,members)] = min(members)
                alias_count += 1
        labels = owner_labels
        if diagnostics is not None:
            diagnostics['historical_instance_owner_alias_groups'] = alias_count
    keys=np.unique(labels)
    groups=[points[labels==key] for key in keys]
    lower=np.array([p.min(axis=0) for p in groups])
    upper=np.array([p.max(axis=0) for p in groups])
    trees={}
    for i,candidate in enumerate(candidates):
        core=cores[i] if cores is not None else qualified_core_indices(frame,candidate,config)
        if not len(core):
            continue
        native=frame.xyz_L[candidate.point_indices]
        sample=_spatial_sample(frame.xyz_L[core],config)
        if not len(sample):
            continue
        radius=_proposal_radius(frame.xyz_L[core] if config.qualified_object_cores else native,config)
        # Competing ownership must still cover ALL actual returns, including
        # excluded unknown ones. Use the largest observed native search scale,
        # not a density-weighted mean that can shrink and hide a competitor.
        conflict_radius=(config.neighbor_base_m+config.neighbor_angle_rad*np.linalg.norm(native,axis=1).max()
                         if config.qualified_object_cores else radius)
        separation=np.maximum(0.,np.maximum(native.min(axis=0)-upper,lower-native.max(axis=0)))
        nearby=np.flatnonzero(np.linalg.norm(separation,axis=1)<=conflict_radius)
        matches={}
        ambiguity=np.zeros(len(sample),dtype=int)
        native_owners=[]
        for j in nearby:
            if j not in trees:
                # Absence of competing ownership cannot be inferred from a
                # voxel representative that may hide a real radius-edge return.
                trees[j]=cKDTree(groups[j])
            if np.any(trees[j].query(native,k=1)[0]<=conflict_radius):
                native_owners.append(int(j))
            matched=trees[j].query(sample,k=1)[0]<=radius
            ambiguity+=matched
            matches[int(j)]=matched
        exclusive=[j for j,mask in matches.items() if (mask&(ambiguity==1)).mean()>=.7]
        conflicts[i]=len(native_owners)>1
        if len(exclusive)==1 and native_owners==exclusive:
            label=int(keys[exclusive[0]])
            # All raw competing groups still participate above. Qualification
            # grants positive evidence only; it never deletes a minority owner.
            if not config.qualified_history_reconciliation or (latest,label) in qualified:
                owners[i]=(latest,label,float(origins[labels==label].min()))
    return owners,conflicts


def _current_surface_pairs(frame, candidates, descriptions, config, cores=None):
    """Observed surface/corner proposals; not physical equipment classification.

    Require a real scan-sized gap plus either mutually coplanar interleaved
    support or two near-orthogonal planes reaching a common observed edge.
    No size/height classifier, extrapolated edge or transitive joining.
    """
    pairs=np.zeros((len(candidates),len(candidates)),dtype=bool)
    surfaces=[]
    native_edges=[]
    native_edge_trees={}
    for i,candidate in enumerate(candidates):
        core=cores[i] if cores is not None else qualified_core_indices(frame,candidate,config)
        if not len(core):
            surfaces.append(None)
            native_edges.append(None)
            continue
        native=frame.xyz_L[core]
        sample=_spatial_sample(native,config)
        if len(sample)<3:
            surfaces.append(None)
            native_edges.append(None)
            continue
        center=sample.mean(axis=0)
        values,vectors=np.linalg.eigh(np.cov(sample,rowvar=False))
        if values[1]<1e-8 or values[0]>.15*values[1]:
            surfaces.append(None)
            native_edges.append(None)
            continue
        surfaces.append((sample,center,vectors[:,0],cKDTree(native)))
        if config.native_shared_edge_evidence:
            current=candidate.diagnostics.get('support_neighbor_valid')
            if current is None:
                native_edges.append(native)
            else:
                current=np.asarray(current,dtype=bool)
                rows=current.any(axis=1) if current.ndim==2 else current
                supported=(np.isin(core,candidate.point_indices[rows])
                           if rows.shape==(len(candidate.point_indices),) else np.zeros(len(core),dtype=bool))
                native_edges.append(native[supported])
        else:
            native_edges.append(None)
    for i,a in enumerate(surfaces):
        if a is None:
            continue
        lo,hi,unused,radius=descriptions[i]
        for j in range(i+1,len(surfaces)):
            b=surfaces[j]
            if b is None:
                continue
            other_lo,other_hi,unused,other_radius=descriptions[j]
            if lo[0]*other_lo[0]<0 or hi[0]*other_hi[0]<0:
                continue
            gap=np.maximum(0.,np.maximum(lo-other_hi,other_lo-hi))
            limit=2.*min(radius,other_radius)
            if np.linalg.norm(gap)>limit:
                continue
            cosine=abs(float(a[2]@b[2]))
            complete_edge=config.native_shared_edge_evidence and cosine<=.35
            proximity=native_edges[j] if complete_edge else b[0]
            if complete_edge:
                if not len(native_edges[i]) or not len(proximity):
                    continue
                if i not in native_edge_trees:
                    native_edge_trees[i]=cKDTree(native_edges[i])
                proximity_tree=native_edge_trees[i]
            else:
                proximity_tree=a[3]
            if not len(proximity) or proximity_tree.query(proximity,k=1)[0].min()>limit:
                continue
            tolerance=.4*min(radius,other_radius)
            if cosine>=np.cos(np.deg2rad(15.)):
                # Neighboring coplanar boxes with disjoint stations are NOT an
                # interleaved face, even if a single beam-sized gap separates them.
                overlap=np.minimum(hi,other_hi)-np.maximum(lo,other_lo)
                if (overlap[1]<=config.neighbor_base_m or overlap[2]<=config.neighbor_base_m or
                        np.quantile(np.abs((b[0]-a[1])@a[2]),.7)>tolerance or
                        np.quantile(np.abs((a[0]-b[1])@b[2]),.7)>tolerance):
                    continue
                # Bounding ranges overlap for separate diagonal ribbons too.
                # Test the actual occupied convex support in the fitted plane
                # in BOTH directions; a wide bounding box is not membership.
                unused_values,basis=np.linalg.eigh(np.cov(a[0],rowvar=False))
                projected_a=(a[0]-a[1])@basis[:,1:]
                projected_b=(b[0]-a[1])@basis[:,1:]
                try:
                    hull_a=ConvexHull(projected_a).equations
                    hull_b=ConvexHull(projected_b).equations
                except QhullError:
                    continue
                margin=config.neighbor_base_m*.25
                inside_a=(projected_b@hull_a[:,:2].T+hull_a[:,2]<=margin).all(axis=1)
                inside_b=(projected_a@hull_b[:,:2].T+hull_b[:,2]<=margin).all(axis=1)
                if inside_a.mean()<.7 or inside_b.mean()<.7:
                    continue
            elif cosine<=.35:
                direction=np.cross(a[2],b[2]); direction/=np.linalg.norm(direction)
                normals=np.stack((a[2],b[2]))
                origin=np.linalg.lstsq(normals,np.array([a[1]@a[2],b[1]@b[2]]),rcond=None)[0]
                spans=[]
                for surface,index in ((a,i),(b,j)):
                    observed_points=native_edges[index] if complete_edge else surface[0]
                    delta=observed_points-origin
                    along=delta@direction
                    distance=np.linalg.norm(delta-along[:,None]*direction,axis=1)
                    observed=distance<=limit
                    if observed.sum()<2:
                        break
                    spans.append((float(along[observed].min()),float(along[observed].max())))
                if (len(spans)!=2 or min(s[1] for s in spans)-max(s[0] for s in spans)<=config.neighbor_base_m):
                    continue
            else:
                continue
            pairs[i,j]=pairs[j,i]=True
    return pairs


def _current_scanline_pairs(frame, candidates, descriptions, axes, origin, config, cores=None):
    """Bounded cross-row proposals from mutually occupied current footprints.

    Ring identifiers distinguish observed rows; their numeric order is NOT
    assumed to be elevation order. This is not a cylinder/device classifier.
    Sparse, unknown-role and large-gap parts cannot prove this relation.
    """
    pairs = np.zeros((len(candidates), len(candidates)), dtype=bool)
    if frame.rings is None:
        return pairs
    rings = np.asarray(frame.rings)
    if rings.shape != (len(frame.xyz_L),) or rings.dtype.kind not in 'iu':
        return pairs
    footprints = []
    ring_sets = []
    for i, candidate in enumerate(candidates):
        indices = cores[i] if cores is not None else qualified_core_indices(frame, candidate, config)
        coordinates = (frame.xyz_L[indices]-origin)@axes
        # Occupied cells, not repeated return counts, supply independent support.
        keep, unused = voxel_representatives(
            np.column_stack((coordinates[:,:2], np.zeros(len(coordinates)))), config.neighbor_base_m*.25)
        sample = coordinates[keep,:2]
        if len(sample) > 64:
            selection = np.unique(np.concatenate([
                np.argsort(sample[:,axis], kind='stable')[np.linspace(0,len(sample)-1,32,dtype=int)]
                for axis in (0,1)]))
            sample = sample[selection]
        footprints.append(sample if len(sample) >= 3 else None)
        ring_sets.append(set(rings[indices].tolist()))
    for i, sample in enumerate(footprints):
        if sample is None:
            continue
        lo, hi, unused, radius = descriptions[i]
        for j in range(i+1, len(footprints)):
            other = footprints[j]
            if other is None or len(ring_sets[i] | ring_sets[j]) < 2:
                continue
            other_lo, other_hi, unused, other_radius = descriptions[j]
            scale = min(radius, other_radius)
            vertical_gap = max(lo[2], other_lo[2])-min(hi[2], other_hi[2])
            if vertical_gap <= 1e-9 or vertical_gap > min(.25, 3.*scale):
                continue
            if lo[0]*other_lo[0] < 0 or hi[0]*other_hi[0] < 0:
                continue
            horizontal_gap = np.maximum(0., np.maximum(lo[:2]-other_hi[:2], other_lo[:2]-hi[:2]))
            limit = .5*scale
            if np.linalg.norm(horizontal_gap) > limit:
                continue
            a = cKDTree(other).query(sample,k=1)[0] <= limit
            b = cKDTree(sample).query(other,k=1)[0] <= limit
            if a.sum() >= 3 and b.sum() >= 3 and a.mean() >= .8 and b.mean() >= .8:
                pairs[i,j] = pairs[j,i] = True
    return pairs


def _current_body_fragment_pairs(frame, candidates, descriptions, axes, origin, config, cores=None):
    """Asymmetric cross-height surface support, never box-containment identity.

    A fragment needs nearby real support above/below its height interval
    AND on both station sides of its local patch. Every qualified return
    is checked using actual body points; voxels only count independent
    support. Competing current body claims abstain, never pick by order.
    No historical return, new XYZ or device-type template is used here.
    """
    pairs = np.zeros((len(candidates),len(candidates)),dtype=bool)
    geometry = []
    for i,candidate in enumerate(candidates):
        indices = cores[i] if cores is not None else qualified_core_indices(frame,candidate,config)
        coordinates = (frame.xyz_L[indices]-origin)@axes
        keep,unused = voxel_representatives(coordinates,config.neighbor_base_m*.5)
        footprint,unused = voxel_representatives(
            np.column_stack((coordinates[:,:2],np.zeros(len(coordinates)))),config.neighbor_base_m*.25)
        geometry.append((coordinates,len(keep),len(footprint)))

    def supported(observed,fragment,tolerance,limit,footprint):
        if len(observed)<3:
            return False
        independent = (np.column_stack((observed[:,:2],np.zeros(len(observed))))
                       if footprint else observed)
        keep,inverse = voxel_representatives(independent,
            config.neighbor_base_m*(.25 if footprint else .5))
        if len(keep)<3:
            return False
        # Full returns decide support. A first voxel representative can be
        # further from a threshold than another actual return in that cell.
        tree = cKDTree(observed[:,:2] if footprint else observed)
        neighborhoods = tree.query_ball_point(fragment[:,:2] if footprint else fragment,
                                               tolerance if footprint else limit)
        matched = []
        for point,neighbors in zip(fragment,neighborhoods):
            neighbors = np.asarray(neighbors,dtype=np.int64)
            if footprint and len(neighbors):
                neighbors = neighbors[np.linalg.norm(observed[neighbors]-point,axis=1)<=limit]
            if not len(neighbors):
                return False
            matched.append(inverse[neighbors])
        return len(np.unique(np.concatenate(matched)))>=3

    directed = np.zeros_like(pairs)
    for i,(body,cell_count,unused_foot_cells) in enumerate(geometry):
        if cell_count<9:
            continue
        lo,hi,unused,radius = descriptions[i]
        for j,(fragment,small_cell_count,small_foot_cells) in enumerate(geometry):
            if i==j or small_cell_count<3 or small_foot_cells<3 or cell_count<3*small_cell_count:
                continue
            other_lo,other_hi,unused,other_radius = descriptions[j]
            scale = min(radius,other_radius)
            if lo[0]*other_lo[0]<0 or hi[0]*other_hi[0]<0:
                continue
            if other_lo[2]-lo[2]<=scale or hi[2]-other_hi[2]<=scale:
                continue
            tolerance = .4*scale
            horizontal_gap = np.maximum(0.,np.maximum(lo[:2]-other_hi[:2],other_lo[:2]-hi[:2]))
            if np.linalg.norm(horizontal_gap)>tolerance:
                continue
            # Existing cross-row gap ceiling: distant projected bars do not
            # establish a local surface hole, even with identical XY.
            limit = min(.25,3.*scale)
            lower = body[body[:,2]<other_lo[2]-scale]
            upper = body[body[:,2]>other_hi[2]+scale]
            if len(lower)<3 or len(upper)<3:
                continue
            if not all(supported(observed,fragment,tolerance,limit,True) for observed in (lower,upper)):
                continue
            # A hollow frame with an unrelated face inside it also brackets
            # heights. Require a bounded local patch surround at CURRENT
            # fragment heights, not an extrapolated closed hull or template.
            same_height = body[(body[:,2]>=other_lo[2]-tolerance)&(body[:,2]<=other_hi[2]+tolerance)]
            left = same_height[same_height[:,1]<other_lo[1]-tolerance]
            right = same_height[same_height[:,1]>other_hi[1]+tolerance]
            if all(supported(observed,fragment,tolerance,limit,False) for observed in (left,right)):
                directed[i,j]=True
    # Complete-link prevents transitive bridges but cannot choose among two
    # alternative current bodies. Keep all such fragments unclaimed.
    directed[:,np.count_nonzero(directed,axis=0)>1]=False
    return directed | directed.T


def _combine(candidates):
    if len(candidates) == 1:
        candidate = candidates[0]
        return replace(candidate, diagnostics=dict(candidate.diagnostics,
            member_fragment_ids=[candidate.candidate_id], object_ownership='single_observed_component'))
    indices = np.concatenate([c.point_indices for c in candidates])
    order = np.argsort(indices, kind='stable')
    diagnostics = {}
    flags, temporal = [], {}
    for candidate in candidates:
        flags.extend(candidate.diagnostics.get('flags', ()))
        temporal.update(candidate.diagnostics.get('temporal_support_refs', {}))
    for key in ('support_neighbor_indices', 'support_neighbor_valid'):
        if all(key in c.diagnostics for c in candidates):
            diagnostics[key] = np.concatenate([c.diagnostics[key] for c in candidates])[order]
    diagnostics.update(flags=tuple(dict.fromkeys(flags)), temporal_support_refs=temporal,
        ambiguous_indices=np.unique(np.concatenate([np.asarray(c.diagnostics.get('ambiguous_indices', ()),
            dtype=np.int64) for c in candidates])), member_fragment_ids=[c.candidate_id for c in candidates],
        object_ownership='vertical_observed_footprint', semantic_identity_confirmed=False)
    return replace(candidates[0], point_indices=indices[order], supported_indices=np.unique(
        np.concatenate([c.supported_indices for c in candidates])),
        first_seen_s=min(c.first_seen_s for c in candidates), last_seen_s=max(c.last_seen_s for c in candidates),
        diagnostics=diagnostics)


def refine_objects(frame, track, layers, config, history=()):
    validate_frame(frame)
    model = measurement_model(track)
    if model is None or len(layers.candidates) < 2:
        return layers
    validate_track(model, frame)
    segment = model.segments[0]
    tangent = segment.end_L-segment.start_L
    tangent /= np.linalg.norm(tangent)
    axes = np.column_stack((segment.across_L, tangent, segment.normal_L))
    descriptions = []
    # Per-call reuse only: no stale role or ambiguity decision crosses frames.
    # These cores propose ownership, never replace the current measurement set.
    cores=[qualified_core_indices(frame,c,config) for c in layers.candidates] if config.qualified_object_cores else None
    for i,candidate in enumerate(layers.candidates):
        proposal_indices=cores[i] if cores is not None and len(cores[i]) else candidate.point_indices
        coordinates = (frame.xyz_L[proposal_indices]-segment.start_L)@axes
        sample = coordinates[np.linspace(0, len(coordinates)-1, min(64, len(coordinates)), dtype=int), :2]
        if config.spatial_object_ownership:
            # Ownership uses occupied footprint cells, not the native return
            # order/density. Every raw point still belongs to the candidate.
            footprint = np.column_stack((coordinates[:,:2],np.zeros(len(coordinates))))
            keep, unused = voxel_representatives(footprint,config.neighbor_base_m*.5)
            sample = coordinates[keep,:2]
            if len(sample)>64:
                ranks=np.linspace(0,len(sample)-1,32,dtype=int)
                keep=np.unique(np.concatenate([np.argsort(sample[:,axis],kind='stable')[ranks]
                                               for axis in range(2)]))
                sample=sample[keep]
        radius = _proposal_radius(frame.xyz_L[proposal_indices],config)
        descriptions.append((coordinates.min(axis=0), coordinates.max(axis=0), sample, radius))
    groups = [[i] for i in range(len(descriptions))]
    lower = np.array([d[0] for d in descriptions])
    upper = np.array([d[1] for d in descriptions])
    radii = np.array([d[3] for d in descriptions])
    possible = ((np.maximum(lower[:,None,:2],lower[None,:,:2]) <=
                 np.minimum(upper[:,None,:2],upper[None,:,:2])+1e-9).all(axis=2))
    possible &= (np.maximum(lower[:,None,2],lower[None,:,2])-
                 np.minimum(upper[:,None,2],upper[None,:,2]) > np.minimum(radii[:,None],radii[None,:]))
    possible &= (upper[:,None,0]*upper[None,:,0] >= 0)&(lower[:,None,0]*lower[None,:,0] >= 0)
    unknown_ground = np.array([c.diagnostics.get('point_role') in ('unknown_ground','unknown_track') or
                               c.diagnostics.get('structure_split_pending',False)
                               for c in layers.candidates], dtype=bool)
    if cores is not None:
        unknown_ground |= np.array([not len(core) for core in cores],dtype=bool)
    # An overlapping footprint does not turn unresolved track/terrain into an
    # object's base. Keep this role separate even when vertically aligned.
    possible &= ~unknown_ground[:, None] & ~unknown_ground[None, :]
    footprint_possible=possible.copy()
    owner_diagnostics = {}
    owner_kwargs = {'diagnostics':owner_diagnostics} if config.qualified_history_owner_keys else {}
    parents,conflicts = (_historical_owners(frame,layers.candidates,history,config,cores,**owner_kwargs)
               if config.temporal_object_proposals else ([None]*len(descriptions),np.zeros(len(descriptions),dtype=bool)))
    temporal = np.zeros_like(possible)
    for i,parent in enumerate(parents):
        if parent is None:
            continue
        for j in range(i+1,len(parents)):
            if parents[j] != parent or unknown_ground[i] or unknown_ground[j]:
                continue
            gap=np.maximum(0.,np.maximum(lower[i]-upper[j],lower[j]-upper[i]))
            if (np.linalg.norm(gap)<=2.*min(radii[i],radii[j]) and
                    upper[i,0]*upper[j,0]>=0 and lower[i,0]*lower[j,0]>=0):
                temporal[i,j]=temporal[j,i]=True
    possible |= temporal
    surfaces = (_current_surface_pairs(frame,layers.candidates,descriptions,config,cores)
                if config.surface_object_proposals else np.zeros_like(possible))
    scanline = np.zeros_like(possible)
    if config.scanline_object_proposals:
        scanline = _current_scanline_pairs(frame,layers.candidates,descriptions,axes,
                                           segment.start_L,config,cores)
        scanline &= ~unknown_ground[:,None] & ~unknown_ground[None,:]
        surfaces |= scanline
    body_pairs = np.zeros_like(possible)
    if config.body_fragment_proposals:
        body_pairs = _current_body_fragment_pairs(frame,layers.candidates,descriptions,axes,
                                                  segment.start_L,config,cores)
        body_pairs &= ~unknown_ground[:,None] & ~unknown_ground[None,:]
        surfaces |= body_pairs
    reconcile=(config.current_instance_reconciliation and config.qualified_instance_ownership
               and config.qualified_object_cores)
    if reconcile:
        independent_surfaces=surfaces.copy()
        independent_footprints=footprint_possible.copy()
    possible |= surfaces
    for i in range(len(parents)):
        for j in np.flatnonzero(possible[i,i+1:])+i+1:
            if (conflicts[i] or conflicts[j] or
                    (parents[i] is not None and parents[j] is not None and parents[i]!=parents[j])):
                surfaces[i,j]=surfaces[j,i]=False
                possible[i,j]=possible[j,i]=False
                footprint_possible[i,j]=footprint_possible[j,i]=False

    def footprint_belongs(a, b):
        lo, hi, sample, radius = descriptions[a]
        other_lo, other_hi, other_sample, other_radius = descriptions[b]
        # Same side is necessary, never sufficient. Require real footprint
        # overlap in BOTH horizontal dimensions, not proximity along one side.
        if hi[0]*other_hi[0] < 0 or lo[0]*other_lo[0] < 0:
            return False
        if np.any(np.maximum(lo[:2], other_lo[:2]) > np.minimum(hi[:2], other_hi[:2])+1e-9):
            return False
        if max(lo[2], other_lo[2])-min(hi[2], other_hi[2]) <= min(radius, other_radius):
            return False  # Existing 3-D connectivity owns overlapping heights.
        distance_a = cKDTree(other_sample).query(sample, k=1)[0]
        distance_b = cKDTree(sample).query(other_sample, k=1)[0]
        return bool((distance_a <= min(radius, other_radius)).mean() >= .7 and
                    (distance_b <= min(radius, other_radius)).mean() >= .7)

    # Keep independent CURRENT geometry as evidence, not as permission to
    # override history on one scan. The tracker requires repeated exclusive
    # observations before reconciling provisional IDs. Temporal-only edges
    # and historical owner labels never populate this matrix.
    current_proofs=np.zeros_like(possible)
    if reconcile:
        for i in range(len(descriptions)):
            for j in np.flatnonzero(independent_surfaces[i,i+1:] | independent_footprints[i,i+1:])+i+1:
                if not unknown_ground[i] and not unknown_ground[j] and (independent_surfaces[i,j] or
                        (independent_footprints[i,j] and footprint_belongs(i,j))):
                    current_proofs[i,j]=current_proofs[j,i]=True

    current_edges={}
    def current_edge(a,b):
        key=tuple(sorted((a,b)))
        if key not in current_edges:
            current_edges[key]=bool(surfaces[a,b] or (footprint_possible[a,b] and footprint_belongs(a,b)))
        return current_edges[key]

    def belongs(a,b):
        return bool(temporal[a,b] or current_edge(a,b))

    for i in range(len(groups)):
        if not groups[i]:
            continue
        for j in np.flatnonzero(possible[i,i+1:])+i+1:
            # Complete-link membership prevents a broad bridging fragment
            # from transitively joining unrelated adjacent physical objects.
            if groups[j] and possible[np.ix_(groups[i],groups[j])].all() and all(
                    belongs(a, b) for a in groups[i] for b in groups[j]):
                groups[i].extend(groups[j])
                groups[j] = []
    candidates=[]
    temporal_groups=0
    surface_groups=0
    for group in groups:
        if not group:
            continue
        candidate=_combine([layers.candidates[i] for i in group])
        edges=[(a,b) for p,a in enumerate(group) for b in group[p+1:]]
        needed_history=[parents[a] for a,b in edges if not current_edge(a,b)]
        if edges and not needed_history and any(surfaces[a,b] for a,b in edges):
            candidate=replace(candidate,diagnostics=dict(candidate.diagnostics,
                object_ownership='verified_current_surface_proposal',semantic_identity_confirmed=False))
            surface_groups+=1
        elif needed_history:
            # Fresh geometry for one pair cannot renew an attached fragment
            # whose membership still depends on an older temporal-only edge.
            parent=min(needed_history,key=lambda p:p[2])
            candidate=replace(candidate,diagnostics=dict(candidate.diagnostics,
                object_ownership='shared_exclusive_historical_proposal',semantic_identity_confirmed=False,
                object_proposal_parent=dict(source_frame=parent[0],proposal_label=parent[1],proof_time_s=parent[2])))
            temporal_groups+=1
        candidates.append(candidate)
    candidates=tuple(candidates)
    extra=dict(owner_diagnostics)
    if config.scanline_object_proposals:
        extra['scanline_proposal_pairs'] = int(np.count_nonzero(np.triu(scanline,1)))
    if config.body_fragment_proposals:
        extra['body_fragment_proposal_pairs'] = int(np.count_nonzero(np.triu(body_pairs,1)))
        extra['body_fragment_history_veto_pairs'] = int(np.count_nonzero(np.triu(body_pairs & ~surfaces,1)))
    if reconcile:
        retained=[g for g in groups if g]
        links=[]
        first=np.array([group[0] for group in retained],dtype=int)
        # A complete cross-group relation necessarily contains its first-member
        # pair. Reject impossible pairs in bulk, but still check every member
        # for the surviving pairs. No threshold, membership or ordering change.
        first_pairs=current_proofs[np.ix_(first,first)]
        for i,a in enumerate(retained):
            for j in np.flatnonzero(first_pairs[i,i+1:])+i+1:
                # A proven edge to one member must not drag an attached,
                # unresolved fragment into another object's identity.
                if current_proofs[np.ix_(a,retained[j])].all():
                    links.append(dict(candidate_ids=[candidates[i].candidate_id,candidates[j].candidate_id],
                        evidence='qualified_current_shared_geometry'))
        extra['current_ownership_links']=links
    return replace(layers, candidates=candidates, counts=dict(layers.counts,
        fragments=len(layers.candidates), components=len(candidates)), diagnostics=dict(layers.diagnostics,
        object_grouping=('current_body_fragment_and_bounded_geometric_proposals' if config.body_fragment_proposals else
            'current_scanline_and_bounded_geometric_proposals' if config.scanline_object_proposals else
            'current_surface_and_bounded_historical_proposals' if
            config.surface_object_proposals or config.temporal_object_proposals else
            'native_connectivity_and_vertical_observed_footprints'),
        temporal_proposal_groups=temporal_groups,
        current_surface_proposal_groups=surface_groups,
        qualified_object_cores_used=config.qualified_object_cores,
        grouped_fragments=len(layers.candidates)-len(candidates), semantic_identity_confirmed=False,**extra))
