import unittest
from unittest.mock import patch
import numpy as np
from .fixtures_p3 import moving_requests,engine_fingerprint,locked_engine
from .test_engine import request
from ..engine import ImageFusionEngine
from ..state import RefinementBudget


class P3SnapshotTests(unittest.TestCase):
    def engine(self,count=20):
        engine=ImageFusionEngine({'image_snapshot_support':True})
        for item in moving_requests(count):engine.process(item)
        return engine

    def freeze(self,engine,budget=None):
        self.assertTrue(hasattr(engine,'freeze_window'),'completed compensated snapshot interface missing')
        return engine.freeze_window(budget or RefinementBudget())

    def test_off_keeps_locked_baseline(self):
        old=locked_engine();new=ImageFusionEngine({'image_snapshot_support':True})
        for item in moving_requests(21)+[request(22,np.tile([1.,0.,1.],(100,1))),request(40)]:
            old.process(item);new.process(item)
            self.assertEqual(engine_fingerprint(new),engine_fingerprint(old))

    def test_freeze_uses_accepted_reference_not_last_input(self):
        engine=self.engine();engine.process(request(20,np.tile([1.,0.,1.],(100,1))))
        before=engine_fingerprint(engine);snapshot=self.freeze(engine)
        self.assertEqual(snapshot.key.source_frames,tuple(range(20)))
        self.assertEqual(snapshot.key.reference_sequence,19)
        self.assertEqual(engine_fingerprint(engine),before)

    def test_snapshot_views_are_readonly_without_copying_xyz(self):
        engine=self.engine(3);snapshot=self.freeze(engine)
        scan=snapshot.scans[0]
        self.assertTrue(np.shares_memory(scan.corrected_xyz,engine.window[0]['xyz']))
        self.assertFalse(scan.corrected_xyz.flags.writeable)
        self.assertTrue(engine.window[0]['xyz'].flags.writeable)
        self.assertFalse(hasattr(scan,'raw_xyz'))
        with self.assertRaises(ValueError):scan.corrected_xyz[0,0]=100.
        self.assertIs(snapshot.baseline_pair,engine.last_pair)

    def test_ring_metadata_pressure_never_rejects_baseline(self):
        old=locked_engine();new=ImageFusionEngine({'image_snapshot_support':True,'image_snapshot_metadata_limit':1})
        for item in moving_requests(3):
            item['rings']=np.arange(len(item['xyz']),dtype=np.int32)%96
            old.process(item);new.process(item)
        self.assertEqual(engine_fingerprint(new),engine_fingerprint(old))
        self.assertTrue(hasattr(new,'freeze_window'),'snapshot interface missing')
        with self.assertRaisesRegex(ValueError,'metadata'):new.freeze_window(RefinementBudget())

    def test_duplicate_does_not_advance_revision_and_source_reset_changes_generation(self):
        engine=self.engine(3);a=self.freeze(engine).key
        engine.process(moving_requests(3)[-1]);b=self.freeze(engine).key
        self.assertEqual(a,b)
        engine.process(request(2,session='another'));c=self.freeze(engine).key
        self.assertNotEqual(a,c);self.assertGreater(c.generation,a.generation)
        self.assertEqual(c.source_frames,(2,))

    def test_expired_or_capacity_freeze_does_not_change_baseline(self):
        engine=self.engine(3);before=engine_fingerprint(engine)
        for budget in (RefinementBudget(deadline_s=0.),RefinementBudget(window_limit_bytes=1)):
            self.assertTrue(hasattr(engine,'freeze_window'),'snapshot interface missing')
            with self.assertRaises(ValueError):engine.freeze_window(budget)
            self.assertEqual(engine_fingerprint(engine),before)

    def test_real_display_origins_reproduce_baseline_bytes(self):
        engine=self.engine(3);snapshot=self.freeze(engine)
        inverse=np.linalg.inv(snapshot.scans[-1].pose)
        lookup={r.sequence:r for r in snapshot.scans}
        from ..registration import transform
        for name in ('fused','single'):
            origins=snapshot.display_origins[name]
            self.assertEqual(len(origins),snapshot.baseline_pair[name]['count'])
            if name=='single':continue  # Baseline single is genuinely un-deskewed current points.
            reconstructed=[]
            for seq,index in origins:
                r=lookup[int(seq)];row=np.flatnonzero(r.original_indices==index)[0]
                reconstructed.append(transform(r.corrected_xyz[row:row+1],inverse@r.pose)[0])
            np.testing.assert_allclose(np.asarray(reconstructed,dtype='<f4'),
                np.frombuffer(snapshot.baseline_pair[name]['data'],dtype='<f4').reshape(-1,3),atol=1e-6)

    def test_optional_metadata_exception_keeps_committed_baseline(self):
        engine=self.engine(3);old=locked_engine()
        for item in moving_requests(4):old.process(item)
        with patch('rsview_centerline.fusion.p3_snapshot.attach_metadata',side_effect=MemoryError('allocation')):
            packet=engine.process(moving_requests(4)[-1])
        self.assertEqual(packet['fusion']['scan_count'],4)
        self.assertEqual(engine_fingerprint(engine),engine_fingerprint(old))

    def test_provenance_does_not_repeat_baseline_voxel_sampling(self):
        engine=ImageFusionEngine({'image_snapshot_support':True,'image_display_filter_preview':True})
        with patch('rsview_centerline.fusion.p3_snapshot.selection',side_effect=AssertionError('duplicate voxel sampling')):
            for item in moving_requests(3):engine.process(item)
        snapshot=self.freeze(engine)
        self.assertEqual(snapshot.key.source_frames,(0,1,2))
        self.assertIn('clean_fused',snapshot.display_origins)
