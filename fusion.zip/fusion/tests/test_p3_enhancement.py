import importlib
import unittest
from unittest.mock import patch
from dataclasses import replace
import numpy as np
from .fixtures_p3 import structure_snapshot
from ..p3_geometry import GeometryPolicy
from ..state import RefinementBudget


class P3EnhancementTests(unittest.TestCase):
    def module(self):
        try:return importlib.import_module('rsview_centerline.fusion.p3_enhancement')
        except ImportError:self.fail('P3 independent acceptance/packing absent')

    def enhance(self,snapshot,budget=None):
        return self.module().enhance(snapshot,budget or RefinementBudget(),GeometryPolicy())

    def test_supported_candidate_keeps_twenty_sources_and_identical_origins(self):
        snapshot=structure_snapshot(pose_error_m=.0015)
        before=tuple(r.corrected_xyz.tobytes() for r in snapshot.scans)
        result=self.enhance(snapshot)
        self.assertTrue(result.accepted,(result.reason,result.report))
        self.assertEqual(result.key,snapshot.key)
        self.assertEqual(result.report['source_frames'],tuple(range(20)))
        self.assertTrue(result.report['reference_excludes_checked_scan'])
        self.assertTrue(result.report['supported_local_improvement'])
        for k,v in snapshot.display_origins.items():np.testing.assert_array_equal(result.display_origins[k],v)
        self.assertEqual(result.pair['single']['data'],snapshot.baseline_pair['single']['data'])
        self.assertEqual(tuple(r.corrected_xyz.tobytes() for r in snapshot.scans),before)

    def test_incomplete_or_unknown_keeps_exact_baseline(self):
        for snapshot in (structure_snapshot(count=4),structure_snapshot('stripe')):
            result=self.enhance(snapshot)
            self.assertFalse(result.accepted);self.assertIs(result.pair,snapshot.baseline_pair)

    def test_budget_rejection_precedes_solver_or_packing(self):
        snapshot=structure_snapshot()
        for budget in (RefinementBudget(deadline_s=0.),RefinementBudget(window_limit_bytes=1),
                RefinementBudget(temporary_limit_bytes=1),RefinementBudget(cancelled=lambda:True)):
            result=self.enhance(snapshot,budget)
            self.assertFalse(result.accepted);self.assertEqual(result.reason,'budget')
            self.assertIs(result.pair,snapshot.baseline_pair)

    def test_optional_packing_failure_keeps_base(self):
        snapshot=structure_snapshot(pose_error_m=.0015);module=self.module()
        with patch.object(module,'pack_shadow_pair',side_effect=MemoryError('packing')):
            result=self.enhance(snapshot)
        self.assertFalse(result.accepted);self.assertEqual(result.reason,'packing_failed')
        self.assertIs(result.pair,snapshot.baseline_pair)

    def test_forged_key_or_removed_source_cannot_claim_improvement(self):
        snapshot=structure_snapshot(pose_error_m=.0015);module=self.module()
        from ..p3_refinement import ShadowProposal
        bad=ShadowProposal(replace(snapshot.key,revision=999),tuple(r.pose for r in snapshot.scans[:-1]),True,'forged',{})
        with patch.object(module,'refine_shadow',return_value=bad):result=self.enhance(snapshot)
        self.assertFalse(result.accepted);self.assertEqual(result.reason,'invalid_proposal')

    def test_source_gap_or_missing_origin_does_not_drop_points_to_pass(self):
        snapshot=structure_snapshot(pose_error_m=.0015);module=self.module()
        wrong={k:v.copy() for k,v in snapshot.display_origins.items()};wrong['fused'][0,0]=999
        snapshot=replace(snapshot,display_origins=wrong)
        result=self.enhance(snapshot)
        self.assertFalse(result.accepted);self.assertIs(result.pair,snapshot.baseline_pair)

    def test_large_unknown_geometry_motion_refuses_even_if_planes_improve(self):
        snapshot=structure_snapshot(pose_error_m=.01)
        result=self.enhance(snapshot)
        self.assertFalse(result.accepted);self.assertIs(result.pair,snapshot.baseline_pair)

    def test_nonconcurrent_scan_transforms_do_not_exhaust_temporary_budget(self):
        module=self.module()
        self.assertTrue(hasattr(module,'temporary_peak_estimate'),'phase-aware allocation estimate absent')
        estimate=module.temporary_peak_estimate((70000,)*20,4000000)
        self.assertEqual(estimate,61280000)
        self.assertLess(estimate,64*1024**2)
