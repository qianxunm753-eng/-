import unittest
from types import SimpleNamespace
from unittest.mock import patch
from ... import fusion_native,clearance_native
from ...parking_replay import ParkingReplayDriver
from ...clearance.tests.test_live_clearance import Action
from ...clearance.tests import test_recorded_playback as replay_support
from .test_contour_native import StyledOverlay
from .test_parking_replay import FakeClock


class ParkingStyledOverlay(StyledOverlay):
    def __init__(self,reader):
        super().__init__(reader);self.session='s';self.clock='c';self.host=SimpleNamespace(epoch=0)
        self.receiver=None
    def set_parking_receiver(self,*args,**kwargs):self.receiver=(args,kwargs)


class ParkingNativeTests(unittest.TestCase):
    def controller(self):
        logic=replay_support.RecordedMenuTests().logic();logic.app.scene=SimpleNamespace(AnimationTime=4.)
        selected=[];logic.getCurrentTimesteps=lambda:[4,7,9]
        logic.getTimeKeeper=lambda:SimpleNamespace(getTime=lambda:logic.app.scene.AnimationTime)
        logic.stop=lambda:setattr(logic.app,'playing',False)
        def observed():
            c=getattr(logic.app,'imageFusionController',None)
            if c is not None and c.parking_driver is not None and c.parking_driver.active:
                selected.append(logic.app.scene.AnimationTime)
        logic.onTimeChanged=observed
        try:c=fusion_native.ImageFusionController(logic,Action(),Action(),Action(),None,Action(),Action(),Action())
        except TypeError:self.fail('parking native actions missing')
        logic.app.imageFusionController=c
        return c,logic,selected

    def enabled(self):
        def enable(logic,contour_mode='baseline'):
            logic.app.railOverlay=ParkingStyledOverlay(logic.getReader());return logic.app.railOverlay
        return patch.object(fusion_native,'enable_image',enable)

    def test_parking_actions_default_off_and_live_unavailable(self):
        c,logic,selected=self.controller()
        self.assertFalse(c.parking_action.checked);self.assertTrue(c.parking_action.enabled)
        self.assertFalse(c.capture_action.enabled)
        logic.getSensor=lambda:object();c.source_ready()
        self.assertFalse(c.parking_action.enabled)

    def test_manual_start_rebuilds_own_worker_and_preserves_settings_tf(self):
        c,logic,selected=self.controller()
        with self.enabled():
            c.set_parking_capture(True);old=c.overlay
            c.single_view(True);c.overlay.set_image_display_settings(True,1.25,(-1.,1.,-2.,2.,-3.,3.))
            c.begin_parking_capture();first=c.parking_driver.request_id
            self.assertTrue(old.closed);self.assertIsNot(c.overlay,old)
            self.assertEqual(c.overlay.settings['point_size'],1.25);self.assertTrue(c.overlay.image_single_view)
            self.assertEqual(logic.getReader().trailing,0);self.assertFalse(logic.app.playing)
            self.assertEqual(selected,[4.,4.]);c.begin_parking_capture()
            self.assertNotEqual(c.parking_driver.request_id,first);self.assertEqual(selected,[4.,4.,4.])
        c.source_closed();self.assertEqual(logic.getReader().trailing,17)

    def test_parking_and_quality_switches_are_exclusive(self):
        c,logic,selected=self.controller()
        with self.enabled():
            c.set_parking_capture(True);self.assertEqual(c.contour_mode,'parking')
            self.assertFalse(c.contour_action.checked)
            c.set_contour_refinement(True)
            self.assertEqual(c.contour_mode,'quality');self.assertFalse(c.parking_action.checked)
            c.set_parking_capture(True);self.assertEqual(c.contour_mode,'parking')
            self.assertFalse(c.contour_action.checked)

    def receiver(self,overlay,accept,on_result=lambda p:None,metadata=lambda:{} ,driver=None):
        self.assertTrue(hasattr(overlay,'set_parking_receiver'),'pre-render parking receiver missing')
        overlay.worker_config={'image_fusion_only':True,'image_contour_mode':'parking','recorded_playback_continuity':True}
        overlay.set_parking_receiver(accept,on_result,metadata,driver=driver)

    def test_stale_packet_rejected_before_display_buffer_pop_or_render(self):
        overlay=replay_support.RecordedNativeTests().overlay()
        packet=dict(sequence=4,status='completed',_display={'object':'old'},_single_display={'object':'old_single'})
        overlay.host.packet=packet;self.receiver(overlay,lambda p:False)
        with patch.object(overlay,'display_packet') as display:overlay.poll()
        self.assertIn('_display',packet);self.assertFalse(display.called)

    def test_real_sparse_ids_force_new_scans_without_changing_source(self):
        overlay=replay_support.RecordedNativeTests().overlay();clock=FakeClock();selected=[]
        d=ParkingReplayDriver([4,7],selected.append,clock);d.start('p',4,(overlay.session,overlay.clock,0))
        self.receiver(overlay,d.accepts,d.ack,d.request_metadata,d)
        overlay._update_recorded(4,poll=False)
        identity=dict(overlay.host.current,status='completed',parking=dict(request_id='p',capture_generation=0,
            pair_generation=0,state='collecting',remaining_s=60.))
        d.ack(identity);overlay._update_recorded(7,poll=False)
        self.assertEqual([r[0]['sequence'] for r in overlay.host.requests],[4,7])
        self.assertTrue(all(r[1] for r in overlay.host.requests))
        self.assertEqual(overlay.host.epoch,0)
        self.assertEqual(overlay.session,'pcap:one')

    def test_old_decoded_frame_cannot_be_submitted_or_acked(self):
        overlay=replay_support.RecordedNativeTests().overlay();d=ParkingReplayDriver([4,7],lambda f:None,FakeClock())
        d.start('p',4,(overlay.session,overlay.clock,0));self.receiver(overlay,d.accepts,d.ack,d.request_metadata,d)
        overlay.reader.decoded_step=3;overlay._update_recorded(4,poll=False)
        self.assertEqual(overlay.host.requests,[]);self.assertEqual(d.pending_frame,4)
        overlay.reader.decoded_step=None;overlay._update_recorded(4,poll=False)
        self.assertEqual(len(overlay.host.requests),1)

    def test_manual_seek_cancels_without_touching_new_decode(self):
        overlay=replay_support.RecordedNativeTests().overlay();d=ParkingReplayDriver([4,7],lambda f:None,FakeClock())
        d.start('p',4,(overlay.session,overlay.clock,0));self.receiver(overlay,d.accepts,d.ack,d.request_metadata,d)
        with patch.object(overlay.reader,'UpdatePipeline') as decode:overlay._update_recorded(7,poll=False)
        self.assertFalse(decode.called);self.assertFalse(d.active);self.assertEqual(overlay.host.requests,[])

    def test_cancelled_queued_tick_never_touches_destroyed_view(self):
        c,logic,selected=self.controller()
        with self.enabled():c.set_parking_capture(True);c.begin_parking_capture()
        d=c.parking_driver;c.cancel_parking_capture('closed');c.source_closed()
        logic.onTimeChanged=lambda:self.fail('destroyed native view touched')
        d.tick();d.ack({});self.assertEqual(selected,[4.,4.])
        self.assertIsNone(c.parking_driver)

    def test_generation_change_keeps_held_pair_explicit_and_status_short(self):
        overlay=replay_support.RecordedNativeTests().overlay()
        packet=dict(sequence=9,measurement_basis='image_only',current_source=True,
            parking=dict(state='awaiting_stability',capture_generation=1,pair_generation=0,
                retained_count=0,actual_count=0,trusted_count=0,reason='x'*1000,request_id='p'*128),
            fusion=dict(reference_sequence=4,reference_time_s=10.4,age_s=.5))
        status=overlay.packet_status(packet)
        self.assertIn('g1/p0',status);self.assertIn('w/a/t 0/0/0',status)
        self.assertIn('ref 4',status);self.assertLess(len(status),180)

    def test_status_does_not_resize_comparison_viewport(self):
        overlay=replay_support.RecordedNativeTests().overlay();overlay.view=SimpleNamespace(size=(800,600))
        p=dict(sequence=7,measurement_basis='image_only',parking=dict(state='collecting',capture_generation=0,
            pair_generation=0,retained_count=3,actual_count=3,trusted_count=3),
            fusion=dict(reference_sequence=7,reference_time_s=10.7,age_s=0.))
        for unused in range(3):overlay.packet_status(p)
        self.assertEqual(overlay.view.size,(800,600))

    def test_expired_tick_freezes_pair_and_never_submits_idle_refresh(self):
        overlay=replay_support.RecordedNativeTests().overlay();clock=FakeClock();d=ParkingReplayDriver([4,7],lambda f:None,clock)
        d.start('p',4,(overlay.session,overlay.clock,0));self.receiver(overlay,d.accepts,d.ack,d.request_metadata,d)
        overlay.last_input=4;overlay.last_input_at=0.;clock.advance(61.)
        before=overlay.last_result
        with patch.object(overlay.reader,'UpdatePipeline') as decode:overlay.poll()
        self.assertFalse(decode.called);self.assertIs(overlay.last_result,before)
        self.assertEqual(overlay.host.requests,[]);self.assertEqual(d.state,'incomplete')
