import sys
import time
import unittest
from unittest.mock import patch
from rsview_centerline.clearance_process import ClearanceProcess
from .fixtures_parking import parking_request


class ParkingIpcTests(unittest.TestCase):
    def host(self,config=None):
        host=ClearanceProcess(python=sys.executable,config=config or dict(image_fusion_only=True,image_contour_mode='parking'),
            source_mode='recorded_pcap')
        self.addCleanup(host.close);return host

    def packet(self,host):
        deadline=time.monotonic()+15.
        while time.monotonic()<deadline:
            packet=host.poll()
            if packet is not None:return packet
            time.sleep(.01)
        self.fail('actual worker result timeout')

    def test_actual_worker_preserves_parking_command_and_remaining(self):
        host=self.host();host.submit(parking_request(0,request_id='p',remaining_s=47.),force=True)
        p=self.packet(host)
        self.assertEqual(p['parking']['request_id'],'p')
        self.assertGreater(p['parking']['remaining_s'],0.)
        self.assertLessEqual(p['parking']['remaining_s'],47.)

    def test_none_command_is_idle(self):
        host=self.host();host.submit(parking_request(0,request_id=None,remaining_s=0.),force=True)
        p=self.packet(host);self.assertEqual(p['parking']['state'],'idle')

    def test_invalid_token_or_remaining_rejected_before_current_changes(self):
        host=self.host()
        for token,remaining in [('',1.),('中文',1.),('a'*129,1.),(object(),1.),('p',float('nan')),
            ('p',float('inf')),('p',-1.),('p',60.1)]:
            with self.assertRaises(ValueError):host.submit(parking_request(0,request_id=token,remaining_s=remaining),force=True)
            self.assertIsNone(host.current)

    def test_lazy_factory_cannot_replace_token_or_increase_deadline(self):
        host=self.host();frame=parking_request(0,remaining_s=10.)
        with self.assertRaises(ValueError):host.submit(frame,force=True,payload_factory=lambda:dict(frame,capture_request_id='other'))
        with self.assertRaises(ValueError):host.submit(frame,force=True,payload_factory=lambda:dict(frame,capture_remaining_s=11.))

    def test_lazy_factory_can_only_reduce_remaining(self):
        host=self.host();frame=parking_request(0,remaining_s=10.)
        host.submit(frame,force=True,payload_factory=lambda:dict(frame,capture_remaining_s=5.))
        p=self.packet(host);self.assertEqual(p['parking']['request_id'],'p')
        self.assertGreater(p['parking']['remaining_s'],0.)
        self.assertLessEqual(p['parking']['remaining_s'],5.)

    def test_metadata_is_whitelisted_not_arbitrary_objects(self):
        host=self.host()
        with patch.object(host,'_dispatch'):
            host.submit(dict(parking_request(0),untrusted_extra=object()),force=True)
        self.assertIn('capture_request_id',list(host.pending))
        self.assertNotIn('untrusted_extra',list(host.pending))

    def test_legacy_replay_has_no_parking_metadata(self):
        host=self.host(dict(image_fusion_only=True))
        with patch.object(host,'_dispatch'):
            host.submit(parking_request(0),force=True)
        self.assertNotIn('capture_request_id',host.pending)
        self.assertNotIn('capture_remaining_s',host.pending)

    def test_actual_failed_packet_preserves_validated_command(self):
        host=self.host();frame=dict(parking_request(0),point_times=None)
        host.submit(frame,force=True);p=self.packet(host)
        self.assertEqual(p['status'],'failed')
        self.assertEqual(p['parking']['request_id'],'p')
        self.assertEqual(p['parking']['state'],'incomplete')
