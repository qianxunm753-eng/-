import importlib
import unittest
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
from ... import fusion_native,clearance_native
from ...clearance.tests.test_live_clearance import Action
from ...clearance.tests import test_recorded_playback as replay_support
from . import test_parking_native as parking_support


class ControlHost:
    def __init__(self,session='s',clock='c'):
        self.epoch=0;self.current=dict(session_id=session,clock_id=clock,epoch=0,sequence=19,device_time_s=2.9)
        self.commands=[];self.control_packet=None;self.requests=[];self.closed=self.failed=False
        self.image_control=SimpleNamespace(suspended=False)
    def request_image_control(self,command,token,source,key=None,budget_s=60.):
        self.commands.append((command,token,source,key,budget_s));self.image_control.suspended=True;return True
    def poll_image_control(self):
        packet,self.control_packet=self.control_packet,None;return packet
    def cancel_image_control(self,token):self.cancelled=token;return True
    def resume_image_submissions(self):self.image_control.suspended=False;return True
    def poll(self):return None


def receipt(driver,state='frozen',count=20):
    session,clock,epoch=driver.source_key
    key=dict(session_id=session,clock_id=clock,epoch=epoch,generation=1,revision=count,
        reference_sequence=count-1,reference_time_s=1.+(count-1)*.1,source_frames=tuple(range(count)))
    cloud=dict(data=np.array([[1.,0.,1.]],dtype='<f4').tobytes(),count=1,dtype='little-float32-xyz')
    return dict(format='rsview-image-control-v1',command='freeze' if state=='frozen' else 'enhance',
        request_id=driver.request_id,source_key=driver.source_key,snapshot_key=key,state=state,reason='fixture',
        report={'scan_count':count},pair=dict(fused=cloud,single=cloud,source_frames=list(range(count)),
        sequence=count-1,time=key['reference_time_s'],raw_points=20,bytes=800))


class P3NativeTests(unittest.TestCase):
    def driver(self,host=None):
        try:module=importlib.import_module('rsview_centerline.p3_replay')
        except ImportError:self.fail('P3 replay enhancement driver absent')
        return module.P3ReplayEnhancement(host or ControlHost(),lambda:100.)

    def overlay(self):
        overlay=replay_support.RecordedNativeTests().overlay()
        overlay.worker_config={'image_fusion_only':True,'image_contour_mode':'baseline'}
        overlay.host=ControlHost(overlay.session,overlay.clock);overlay.requested_frame=overlay.last_input=19
        overlay.image_single_view=False;overlay.image_clean_view=False
        overlay.last_input_at=None;overlay.last_result=None
        return overlay

    def test_driver_freezes_then_enhances_same_complete_key(self):
        host=ControlHost();driver=self.driver(host)
        self.assertTrue(driver.begin(('s','c',0)));token=driver.request_id
        host.control_packet=receipt(driver);packet=driver.poll()
        self.assertEqual(host.commands[-1][0],'enhance')
        self.assertEqual(host.commands[-1][1],token)
        self.assertEqual(host.commands[-1][3],packet['snapshot_key'])
        driver.cancel('user');self.assertFalse(driver.accepts(receipt(driver,'accepted')))

    def test_underfilled_window_does_not_submit_extra_scans_or_enhance(self):
        host=ControlHost();driver=self.driver(host);driver.begin(('s','c',0))
        host.control_packet=receipt(driver,count=4);driver.poll()
        self.assertEqual([r[0] for r in host.commands],['freeze'])
        self.assertEqual(host.requests,[])

    def test_controller_child_does_not_rebuild_rolling_baseline(self):
        controller,logic,unused=parking_support.ParkingNativeTests().controller()
        controller.p3_action=Action();controller.p3_baseline_action=Action()
        self.assertTrue(hasattr(controller,'set_p3_detail'),'P3 child menu handler missing')
        def enable(logic,contour_mode='baseline',parking_detail=False):
            overlay=parking_support.ParkingStyledOverlay(logic.getReader());overlay.host=ControlHost()
            overlay.requested_frame=overlay.last_input=19
            overlay.set_p3_receiver=lambda *args:None
            overlay.set_image_detail_view=lambda checked:True
            logic.app.railOverlay=overlay;return overlay
        with patch.object(fusion_native,'enable_image',enable):
            controller.set_image_fusion(True);old=controller.overlay;host=old.host;reader=old.reader
            logic.app.playing=True;controller.set_p3_detail(True)
            self.assertFalse(logic.app.playing);self.assertFalse(old.closed)
            self.assertIs(controller.overlay,old);self.assertIs(old.host,host);self.assertIs(old.reader,reader)
            self.assertTrue(controller.action.checked);self.assertTrue(controller.p3_action.checked,logic.app.statusLabel.text)
            self.assertFalse(controller.parking_action.checked)
            controller.set_p3_detail(False);self.assertFalse(logic.app.playing)
            self.assertFalse(controller.p3_action.checked);self.assertFalse(old.closed)

    def test_stale_control_rejected_before_pair_or_actor_consumption(self):
        overlay=self.overlay();driver=self.driver(overlay.host);driver.begin((overlay.session,overlay.clock,0))
        self.assertTrue(hasattr(overlay,'set_p3_receiver'),'native P3 pre-render guard missing')
        overlay.set_p3_receiver(driver.accepts,lambda p:None,True);overlay.p3_driver=driver
        packet=receipt(driver);packet['request_id']='stale';overlay.host.control_packet=packet
        with patch.object(overlay,'display_packet',side_effect=lambda p:setattr(overlay,'last_result',p)):
            overlay.poll()
        self.assertIsNone(overlay.last_result);self.assertIn('pair',packet)

    def test_native_ab_uses_one_frozen_pair_and_no_scan_submission(self):
        overlay=self.overlay();driver=self.driver(overlay.host);driver.begin((overlay.session,overlay.clock,0))
        self.assertTrue(hasattr(overlay,'set_p3_receiver'),'native P3 receiver missing')
        overlay.set_p3_receiver(driver.accepts,lambda p:None,True);overlay.p3_driver=driver
        frozen=receipt(driver);overlay.host.control_packet=frozen
        with patch.object(overlay,'display_packet',side_effect=lambda p:setattr(overlay,'last_result',p)):
            overlay.poll();baseline=overlay.last_result['_image_pairs']['fused']
            candidate=receipt(driver,'accepted');candidate['pair']['fused']=dict(candidate['pair']['fused'],data=np.array([[1.001,0.,1.]],dtype='<f4').tobytes())
            overlay.host.control_packet=candidate;overlay.poll()
            overlay.set_image_detail_view(False)
            self.assertEqual(overlay.last_result['clouds'],baseline)
            overlay.set_image_detail_view(True)
            self.assertNotEqual(overlay.last_result['clouds'],baseline)
            overlay.set_image_single_view(True)
            self.assertEqual(overlay.last_result['clouds'],{'object':frozen['pair']['single']})
        self.assertEqual(overlay.host.requests,[])

    def test_frozen_same_frame_does_not_decode_or_submit_again(self):
        overlay=self.overlay();driver=self.driver(overlay.host);driver.begin((overlay.session,overlay.clock,0))
        self.assertTrue(hasattr(overlay,'set_p3_receiver'),'native P3 suspension missing')
        overlay.set_p3_receiver(driver.accepts,lambda p:None,True);overlay.p3_driver=driver
        overlay._update_recorded(19,poll=False)
        self.assertFalse(hasattr(overlay.reader,'step'))
        self.assertEqual(overlay.host.requests,[])

    def test_cancel_after_host_close_has_no_io_or_render_work(self):
        host=ControlHost();driver=self.driver(host);driver.begin(('s','c',0));host.closed=True
        with patch.object(host,'cancel_image_control',side_effect=AssertionError('closed host IO')):
            driver.cancel('source_closed')
        self.assertFalse(driver.valid);self.assertFalse(driver.awaiting_release)

    def test_nonfinite_clock_cannot_begin_a_valid_capture(self):
        host=ControlHost();driver=self.driver(host);driver.clock=lambda:float('nan')
        with self.assertRaises(ValueError):driver.begin(('s','c',0))
        self.assertEqual(host.commands,[]);self.assertFalse(driver.valid)

    def test_replay_advance_invalidates_detail_before_next_decode(self):
        overlay=self.overlay();driver=self.driver(overlay.host);driver.begin((overlay.session,overlay.clock,0))
        overlay.set_p3_receiver(driver.accepts,lambda p:None,True);overlay.p3_driver=driver
        # A direct user seek invalidates the old candidate even if decoder later fails.
        overlay._update_recorded(20,poll=False)
        self.assertFalse(driver.valid)
        self.assertFalse(driver.accepts(receipt(driver,'accepted')))

    def test_p3_child_disabled_without_parent_and_in_other_modes(self):
        c,logic,unused=parking_support.ParkingNativeTests().controller()
        c.p3_action=Action();c.p3_baseline_action=Action();c.source_ready()
        self.assertFalse(c.p3_action.enabled)
        c.set_p3_detail(True);self.assertFalse(c.p3_action.checked)
        c.contour_mode='parking';c.source_ready();self.assertFalse(c.p3_action.enabled)

    def test_decode_error_cannot_freeze_old_window_as_selected_frame(self):
        c,logic,unused=parking_support.ParkingNativeTests().controller()
        c.p3_action=Action();c.p3_baseline_action=Action()
        overlay=parking_support.ParkingStyledOverlay(logic.getReader());overlay.host=ControlHost()
        overlay.input_error='still decoding selected frame';c.overlay=overlay
        c.set_p3_detail(True)
        self.assertEqual(overlay.host.commands,[])
        self.assertFalse(c.p3_action.checked)

    def test_each_stale_snapshot_identity_field_is_rejected(self):
        host=ControlHost();driver=self.driver(host);driver.begin(('s','c',0))
        host.control_packet=receipt(driver);driver.poll()
        for field,value in [('session_id','other'),('clock_id','other'),('epoch',1),('generation',2),
                ('revision',21),('reference_sequence',18),('reference_time_s',99.),('source_frames',tuple(range(1,21)))]:
            packet=receipt(driver,'accepted');packet['snapshot_key']=dict(packet['snapshot_key'],**{field:value})
            self.assertFalse(driver.accepts(packet),field)

    def test_deadline_unchecks_child_without_resuming_or_losing_baseline(self):
        overlay=self.overlay();driver=self.driver(overlay.host);driver.begin((overlay.session,overlay.clock,0))
        controller,logic,unused=parking_support.ParkingNativeTests().controller()
        controller.overlay=overlay;controller.p3_action=Action();controller.p3_baseline_action=Action()
        controller.p3_action.setChecked(True);controller.p3_driver=driver
        overlay.logic=logic;overlay.p3_driver=driver
        overlay.set_p3_receiver(driver.accepts,controller._p3_result,True)
        overlay.host.control_packet=receipt(driver)
        with patch.object(overlay,'display_packet',side_effect=lambda p:setattr(overlay,'last_result',p)):
            overlay.poll();before=overlay.last_result['_image_pairs']['fused']
            driver.clock=lambda:161.;overlay.poll()
        self.assertFalse(controller.p3_action.checked)
        self.assertEqual(overlay.last_result['clouds'],before)
        self.assertFalse(getattr(logic.app,'playing',False))
