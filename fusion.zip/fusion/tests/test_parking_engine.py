import unittest
import json
import pickle
from unittest.mock import patch
import numpy as np
from ..engine import ImageFusionEngine
from .fixtures_parking import parking_request,static_independent_sample
from .fixtures_contour import snapshot_bytes


class ParkingEngineTests(unittest.TestCase):
    def engine(self,**config):
        try:return ImageFusionEngine(dict(image_contour_mode='parking',**config))
        except ValueError:self.fail('parking engine route missing')

    def advance(self,e,count=9):
        for i in range(count):p=e.process(parking_request(i))
        return p

    def test_twenty_trusted_scans_are_new_after_stability(self):
        e=self.engine();p=self.advance(e,26)
        self.assertEqual(p['parking']['state'],'capture_complete',p['parking'])
        self.assertEqual(p['parking']['actual_count'],20)
        self.assertEqual(p['parking']['trusted_count'],20)
        self.assertEqual(p['fusion']['source_frames'],list(range(6,26)))
        self.assertEqual(p['parking']['trusted_source_frames'],list(range(6,26)))
        self.assertEqual(p['parking']['unknown_count'],0)
        self.assertEqual(p['measurements'],[]);self.assertEqual(p['centerline'],[])
        before=p['_display'];p=e.process(parking_request(26))
        self.assertEqual(p['_display'],before);self.assertTrue(p['fusion']['held'])

    def test_bad_speed_does_not_contaminate_next_good_predictor(self):
        e=self.engine();self.advance(e);runtime=e.parking_runtime
        before=snapshot_bytes(runtime.mapper)
        p=e.process(parking_request(9,static_independent_sample(9)-[.03,0.,0.]))
        self.assertEqual(snapshot_bytes(runtime.mapper),before)
        self.assertNotIn(9,p['parking']['source_frames'])
        p=e.process(parking_request(10))
        self.assertIn(10,p['parking']['source_frames']);self.assertNotIn(9,p['parking']['source_frames'])

    def test_motion_and_unobservable_plane_cannot_fake_stability(self):
        e=self.engine()
        for i in range(10):p=e.process(parking_request(i,static_independent_sample(i)-[i*.01,0.,0.]))
        self.assertEqual(p['parking']['actual_count'],0)
        e=self.engine()
        for i in range(9):p=e.process(parking_request(i,static_independent_sample(i)[:1600]))
        self.assertNotEqual(p['parking']['state'],'capture_complete')
        self.assertEqual(p['parking']['trusted_count'],0)

    def test_initial_stability_recovers_after_expired_warm_reference(self):
        e=self.engine();e.process(parking_request(0));deadline=e.parking_runtime.capture.deadline_s
        for i in range(1,8):
            p=e.process(parking_request(i,static_independent_sample(i)[:20]))
            self.assertEqual(p['parking']['actual_count'],0)
        p=e.process(parking_request(8))
        self.assertEqual(p['relative_pose_diagnostics']['reason'],'reference_anchor')
        self.assertEqual(p['parking']['stable_count'],0)
        self.assertEqual(p['parking']['actual_count'],0)
        self.assertNotEqual(e.parking_runtime.mapper.last_good_time,1.)
        for i in range(9,14):
            p=e.process(parking_request(i));self.assertEqual(p['parking']['actual_count'],0)
        self.assertEqual(p['parking']['state'],'collecting')
        p=e.process(parking_request(14))
        self.assertEqual(p['parking']['source_frames'],[14])
        self.assertEqual(p['parking']['trusted_count'],0)
        self.assertEqual(e.parking_runtime.capture.deadline_s,deadline)
        self.assertEqual(p['session_id'],'image:test');self.assertEqual(p['epoch'],0)

    def test_expired_warm_reanchor_rolls_back_if_preview_pack_fails(self):
        e=self.engine();e.process(parking_request(0))
        for i in range(1,8):e.process(parking_request(i,static_independent_sample(i)[:20]))
        r=e.parking_runtime;before=snapshot_bytes(r.mapper)
        with patch.object(e,'paired_views',side_effect=ValueError('expired_warm_pack_failure')):
            p=e.process(parking_request(8))
        self.assertEqual(snapshot_bytes(r.mapper),before)
        self.assertEqual(p['parking']['actual_count'],0)
        self.assertIn('expired_warm_pack_failure',p['parking']['reason'])
        p=e.process(parking_request(9))
        self.assertEqual(p['relative_pose_diagnostics']['reason'],'reference_anchor')
        self.assertEqual(p['parking']['stable_count'],0)

    def test_duplicate_reverse_and_new_command(self):
        e=self.engine();p=self.advance(e);before=p['parking']['retained_count']
        p=e.process(parking_request(8));self.assertEqual(p['parking']['retained_count'],before)
        p=e.process(parking_request(4));self.assertEqual(p['parking']['state'],'idle')
        p=e.process(parking_request(4,request_id='new'))
        self.assertEqual(p['parking']['request_id'],'new');self.assertEqual(p['parking']['retained_count'],0)

    def test_source_change_cancels_and_does_not_restart_same_token(self):
        e=self.engine();self.advance(e)
        p=e.process(dict(parking_request(9),session_id='other'))
        self.assertEqual(p['parking']['state'],'idle')
        p=e.process(dict(parking_request(10),session_id='other'))
        self.assertEqual(p['parking']['state'],'idle')

    def test_pack_failure_has_no_partial_map_window_pair_commit(self):
        e=self.engine();self.advance(e);r=e.parking_runtime
        before=snapshot_bytes(r.mapper);records=r.records;pair=r.last_pair
        with patch.object(e,'paired_views',side_effect=ValueError('controlled_pack_failure')):
            p=e.process(parking_request(9))
        self.assertEqual(snapshot_bytes(r.mapper),before)
        self.assertIs(r.records,records);self.assertIs(r.last_pair,pair)
        self.assertTrue(p['fusion']['held']);self.assertIn('controlled_pack_failure',p['parking']['reason'])

    @staticmethod
    def all_rejected(scans,budget):
        # Isolate the orchestration contract for a legitimate checker outcome;
        # the real checker can produce this (documented independent repro).
        from ..parking_quality import ParkingScanCheck
        return {s.record.sequence:ParkingScanCheck('rejected','controlled_all_rejected',(),{}, {}) for s in scans}

    def test_empty_contributors_clear_next_fitting_map_but_hold_preview(self):
        e=self.engine();self.advance(e);r=e.parking_runtime;pair=r.last_pair
        deadline=r.capture.deadline_s
        with patch('rsview_centerline.fusion.parking_engine.check_parking_window',side_effect=self.all_rejected):
            p=e.process(parking_request(9))
        self.assertEqual(p['parking']['source_frames'],[])
        self.assertEqual(p['parking']['trusted_source_frames'],[])
        self.assertEqual(p['parking']['rejected_count'],4)
        self.assertIs(r.last_pair,pair);self.assertTrue(p['fusion']['held'])
        self.assertTrue(r.mapper.geometry is None,'rejected geometry remains in fitting map')
        self.assertFalse(r.mapper.key_sources);self.assertFalse(r.mapper.keys)
        self.assertIsNone(r.mapper.last_good_time)
        np.testing.assert_array_equal(r.mapper.relative,np.eye(4))
        self.assertEqual(r.capture.deadline_s,deadline)
        p=e.process(parking_request(10))
        self.assertEqual(p['relative_pose_diagnostics']['reason'],'reference_anchor')
        self.assertEqual(p['parking']['trusted_count'],0)
        self.assertNotIn(10,p['parking']['source_frames'])

    def test_empty_map_allocation_failure_rolls_back_all_staged_checks(self):
        e=self.engine();self.advance(e);r=e.parking_runtime
        before=snapshot_bytes(r.mapper);records=r.records;pair=r.last_pair;checks=r.checks
        with patch('rsview_centerline.fusion.parking_engine.check_parking_window',side_effect=self.all_rejected),\
            patch('rsview_centerline.fusion.parking_engine.LocalMap',side_effect=MemoryError('empty_map_allocation')):
            p=e.process(parking_request(9))
        self.assertEqual(snapshot_bytes(r.mapper),before)
        self.assertTrue(r.records is records,'failed empty-map staging committed raw window')
        self.assertTrue(r.last_pair is pair,'failed empty-map staging changed frozen pair')
        self.assertTrue(r.checks is checks,'failed empty-map staging committed rejected checks')
        self.assertEqual(p['parking']['source_frames'],[6,7,8])
        self.assertIn('empty_map_allocation',p['parking']['reason'])

    def test_full_models_and_window_sources_are_reconstructable(self):
        e=self.engine();self.advance(e)
        r=e.parking_runtime
        for scan in r.records:
            record=scan.record
            np.testing.assert_allclose(record.model.corrected_points(record.raw_xyz,record.point_times,e.imu),
                record.corrected_xyz,atol=1e-10)
            self.assertFalse(record.raw_xyz.flags.writeable)
        sources=[key[1] for key in r.mapper.key_sources]
        self.assertTrue(sources)
        self.assertTrue(set(sources)<=set(s.record.sequence for s in r.records))
        self.assertTrue(all(i>=6 for i in sources))
        self.assertEqual(r.mapper.last_good_time,r.records[-1].record.reference_s)

    def test_last_packing_crosses_deadline_without_committing_completion(self):
        e=self.engine();self.advance(e);r=e.parking_runtime
        before=snapshot_bytes(r.mapper);records=r.records;pair=r.last_pair
        pack=e.paired_views
        # The runtime uses a forked deadline. Advance its injected clock
        # during packing, rather than editing the unrelated original fork.
        now=[r.clock()];r.clock=lambda:now[0];r.capture.clock=r.clock
        def advance(*args):
            result=pack(*args);now[0]+=61.;return result
        with patch.object(e,'paired_views',side_effect=advance):p=e.process(parking_request(9))
        self.assertEqual(snapshot_bytes(r.mapper),before);self.assertIs(r.records,records)
        self.assertIs(r.last_pair,pair);self.assertEqual(p['parking']['state'],'incomplete')

    def test_warm_pack_failure_does_not_commit_warm_mapper(self):
        e=self.engine();e.process(parking_request(0));r=e.parking_runtime
        before=snapshot_bytes(r.mapper)
        with patch.object(e,'paired_views',side_effect=ValueError('warm_pack_failure')):
            p=e.process(parking_request(1))
        self.assertEqual(snapshot_bytes(r.mapper),before)
        self.assertIn('warm_pack_failure',p['parking']['reason'])

    def test_packet_is_primitive_and_has_no_measurement_paths(self):
        e=self.engine();p=self.advance(e)
        json.dumps({k:v for k,v in p.items() if not k.startswith('_')},allow_nan=False)
        pickle.loads(pickle.dumps(p,protocol=2))
        self.assertEqual(p['secondary_measurements'],[])
        self.assertEqual(p['measurement_region_count'],0)
        self.assertEqual(p['mode'],'image_only')

    def test_injected_deadline_and_cancellation_never_freshen_budget(self):
        e=self.engine();e.process(parking_request(0));r=e.parking_runtime
        now=[1.e9];r.clock=lambda:now[0];r.capture.clock=r.clock
        # New request anchors the worker's own clock, not the native origin.
        p=e.process(parking_request(1,request_id='clock',remaining_s=.3))
        deadline=r.capture.deadline_s;now[0]+=.4
        p=e.process(parking_request(2,request_id='clock',remaining_s=60.))
        self.assertEqual(p['parking']['state'],'incomplete');self.assertEqual(r.capture.deadline_s,deadline)
        e=self.engine();e.process(parking_request(0));r=e.parking_runtime;r.cancelled=lambda:True
        p=e.process(parking_request(1));self.assertEqual(p['parking']['state'],'incomplete')

    def test_capacity_and_model_failure_do_not_commit_scan(self):
        e=self.engine(image_byte_budget=1000);p=e.process(parking_request(0))
        self.assertEqual(p['parking']['retained_count'],0)
        self.assertEqual(e.parking_runtime.mapper.last_good_time,None)
        e=self.engine();self.advance(e);r=e.parking_runtime;pair=r.last_pair
        with patch('rsview_centerline.fusion.parking_alignment.saved_scan_model',side_effect=ValueError('bad_model')):
            p=e.process(parking_request(9))
        self.assertIs(r.last_pair,pair);self.assertNotIn(9,p['parking']['source_frames'])
