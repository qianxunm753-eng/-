"""Cross-scan support is reversible evidence, never noise truth or geometry."""
import unittest
import numpy as np
from ..surface_diagnostics import diagnose_window
from ..p3_snapshot import SnapshotKey,CompensatedScan,CompensatedWindowSnapshot
from ..engine import ImageFusionEngine
from ..state import RefinementBudget


def supported_window():
    scans=[]
    for i in range(20):
        # Two separately observed surfaces must stay separate. A thin observed
        # feature is supported by three scans; duplicate weak returns by one.
        xyz=[[1.,0.,1.],[1.,.10,1.]]
        if i<3:xyz.append([1.,.035,1.])
        if i==0:xyz.extend([[1.,.07,1.]]*100)
        xyz=np.asarray(xyz)
        scans.append(CompensatedScan(i,float(i),(float(i),float(i)),xyz,np.full(len(xyz),float(i)),
            np.arange(len(xyz),dtype=np.int64),np.eye(4)))
    scans=tuple(scans);engine=ImageFusionEngine()
    pair=engine.paired_views(np.concatenate([s.corrected_xyz for s in scans]),scans[-1].corrected_xyz)
    pair.update(source_frames=list(range(20)),sequence=19,time=19.,raw_points=143,bytes=4096)
    pair['_surface_raw_single']={'xyz':scans[-1].corrected_xyz,'indices':scans[-1].original_indices}
    key=SnapshotKey('s','c',0,1,20,19,19.,tuple(range(20)))
    return CompensatedWindowSnapshot(key,scans,pair,{})


class SurfaceSupportTests(unittest.TestCase):
    def result(self):return diagnose_window(supported_window(),(.9,1.1,-.01,.12,.9,1.1),RefinementBudget())

    def test_support_counts_distinct_scans_not_repeated_points_from_one_scan(self):
        result=self.result();views=result['pair']['surface_views']
        self.assertIn('support',views,'no cross-scan evidence view')
        xyz=np.frombuffer(views['support']['data'],dtype='<f4').reshape(-1,3)
        score=np.frombuffer(views['support']['support_data'],dtype='<f4')
        expected={0.:20,.035:3,.07:1,.10:20}
        self.assertEqual(len(xyz),4);self.assertEqual(len(score),4)
        for point,count in zip(xyz,score):self.assertEqual(count,expected[round(float(point[1]),3)])

    def test_stable_subset_retains_thin_supported_feature_and_separate_rear_surface(self):
        result=self.result();views=result['pair']['surface_views']
        self.assertIn('stable',views,'no reversible stable subset')
        stable=np.frombuffer(views['stable']['data'],dtype='<f4').reshape(-1,3)
        self.assertEqual(sorted(round(float(v),3) for v in stable[:,1]),[0.,.035,.10])
        self.assertEqual(views['local']['count'],4,'weak real feature was deleted from all-points baseline')
        self.assertEqual(views['support']['data'],views['local']['data'])
        self.assertEqual(result['report']['coordinate_edits'],0)
        self.assertFalse(result['report']['measurement_allowed'])

    def test_no_consensus_does_not_fabricate_or_substitute_a_stable_surface(self):
        snap=supported_window()
        scans=tuple(CompensatedScan(i,float(i),(float(i),float(i)),np.array([[1.,float(i),1.]]),
            np.array([float(i)]),np.array([0]),np.eye(4)) for i in range(20))
        snap=CompensatedWindowSnapshot(snap.key,scans,snap.baseline_pair,{})
        result=diagnose_window(snap,(.9,1.1,-.01,.12,.9,1.1),RefinementBudget())
        self.assertIn('stable',result['pair']['surface_views'],'stable evidence absent')
        self.assertEqual(result['pair']['surface_views']['stable']['count'],0)
        self.assertEqual(result['pair']['surface_views']['local']['count'],1)

    def test_cancelled_support_work_never_mutates_frozen_baseline(self):
        snap=supported_window();base=snap.baseline_pair['fused']['data']
        with self.assertRaises(ValueError):
            diagnose_window(snap,(.9,1.1,-.01,.12,.9,1.1),RefinementBudget(cancelled=lambda:True))
        self.assertEqual(snap.baseline_pair['fused']['data'],base)

    def test_observation_roi_edge_does_not_erase_nearby_scan_evidence(self):
        snap=supported_window();scans=[]
        for i in range(20):
            # All returns are within 2mm, but 19 lie just outside the display
            # box. The displayed point still has 20 distinct nearby scans.
            xyz=np.array([[1.,-.009 if i==0 else -.011,1.]])
            scans.append(CompensatedScan(i,float(i),(float(i),float(i)),xyz,np.array([float(i)]),np.array([0]),np.eye(4)))
        snap=CompensatedWindowSnapshot(snap.key,tuple(scans),snap.baseline_pair,{})
        result=diagnose_window(snap,(.9,1.1,-.01,.12,.9,1.1),RefinementBudget())
        views=result['pair']['surface_views']
        self.assertEqual(views['local']['count'],1)
        self.assertEqual(np.frombuffer(views['support']['support_data'],dtype='<f4').tolist(),[20.])
        self.assertEqual(views['stable']['count'],1)

    def test_optional_support_capacity_failure_preserves_original_surface_views(self):
        snap=supported_window();base=snap.baseline_pair['fused']['data']
        try:result=diagnose_window(snap,(.9,1.1,-.01,.12,.9,1.1),RefinementBudget(temporary_limit_bytes=22900))
        except ValueError:self.fail('optional evidence allocation discarded the existing local surface views')
        self.assertEqual(result['pair']['surface_views']['local']['count'],4)
        self.assertEqual(result['pair']['fused']['data'],base)
        self.assertNotIn('support',result['pair']['surface_views'])
        self.assertEqual(result['report']['support_state'],'temporary_budget')

    def test_ten_metre_display_boundary_does_not_clip_nearby_scan_evidence(self):
        snap=supported_window();scans=[]
        for i in range(20):
            xyz=np.array([[9.999 if i==0 else 10.001,0.,0.]])
            scans.append(CompensatedScan(i,float(i),(float(i),float(i)),xyz,np.array([float(i)]),np.array([0]),np.eye(4)))
        snap=CompensatedWindowSnapshot(snap.key,tuple(scans),snap.baseline_pair,{})
        result=diagnose_window(snap,(9.9,10.,-.1,.1,-.1,.1),RefinementBudget())
        view=result['pair']['surface_views']['support']
        self.assertEqual(view['count'],1)
        self.assertEqual(np.frombuffer(view['support_data'],dtype='<f4').tolist(),[20.])

    def test_twenty_mm_sphere_includes_boundary_with_only_roundoff_tolerance(self):
        snap=supported_window();scans=[]
        for i in range(20):
            xyz=np.array([[1. if i==0 else 1.02 if i<10 else 1.020001,0.,1.]])
            scans.append(CompensatedScan(i,float(i),(float(i),float(i)),xyz,np.array([float(i)]),np.array([0]),np.eye(4)))
        snap=CompensatedWindowSnapshot(snap.key,tuple(scans),snap.baseline_pair,{})
        view=diagnose_window(snap,(.999,1.001,-.1,.1,.9,1.1),RefinementBudget())['pair']['surface_views']['support']
        self.assertEqual(np.frombuffer(view['support_data'],dtype='<f4').tolist(),[10.])


if __name__=='__main__':unittest.main()
