"""Display depth/ROI must not become a new geometry or acquisition transform."""
import importlib
import math
import unittest
from types import SimpleNamespace
from unittest.mock import patch


class DisplayMathTests(unittest.TestCase):
    def setUp(self):
        try:self.module=importlib.import_module('rsview_centerline.image_display')
        except ImportError:self.fail('display-only camera depth / settings absent')

    def test_depth_uses_virtual_camera_axis_not_distance_to_lidar(self):
        axis,offset=self.module.camera_projection((0,0,-2),(0,0,0))
        self.assertEqual(axis,(0.,0.,1.));self.assertEqual(offset,2.)
        p=(100.,0.,-1.)
        self.assertEqual(sum(a*v for a,v in zip(axis,p))+offset,1.)

    def test_rotation_changes_projection_but_not_point_coordinates(self):
        axis,offset=self.module.camera_projection((-2,0,0),(0,0,0))
        self.assertEqual(axis,(1.,0.,0.));self.assertEqual(offset,2.)
        bounds=(1.,2.,-1.,1.,0.,3.)
        self.assertEqual(self.module.projected_range(bounds,axis,offset),(3.,4.))
        self.assertEqual(bounds,(1.,2.,-1.,1.,0.,3.))

    def test_display_layer_zero_is_the_view_focus_not_the_lidar_or_camera_position(self):
        self.assertTrue(hasattr(self.module,'layer_projection'),'focal-relative view layer projection absent')
        axis,offset=self.module.layer_projection((0,0,-40),(0,0,2))
        self.assertEqual(axis,(0.,0.,1.));self.assertEqual(offset,-2.)
        self.assertEqual(sum(a*p for a,p in zip(axis,(1.,1.,2.)))+offset,0.)
        self.assertEqual(sum(a*p for a,p in zip(axis,(1.,1.,3.)))+offset,1.)

    def test_pair_range_is_shared_and_does_not_follow_single_view_subset(self):
        bounds=self.module.union_bounds([(1.,2.,-1.,1.,0.,3.),(1.,1.,0.,0.,1.,1.)])
        axis,offset=self.module.camera_projection((0,0,-2),(0,0,0))
        self.assertEqual(self.module.projected_range(bounds,axis,offset),(2.,5.))

    def test_constant_depth_has_finite_nonzero_color_range(self):
        values=self.module.projected_range((0.,0.,0.,0.,1.,1.),(0.,0.,1.),0.)
        self.assertLess(values[0],1.);self.assertGreater(values[1],1.)

    def test_display_settings_validate_before_applying(self):
        settings=self.module.display_settings(True,1.,(-1,1,-2,2,-3,3))
        self.assertEqual(settings,dict(depth=True,point_size=1.,roi=(-1.,1.,-2.,2.,-3.,3.)))
        for size in (0.,float('nan'),6.):
            with self.assertRaises(ValueError):self.module.display_settings(True,size,None)
        for roi in ((1,-1,-1,1,-1,1),(0,0,-1,1,-1,1),(math.nan,1,-1,1,-1,1)):
            with self.assertRaises(ValueError):self.module.display_settings(True,1.,roi)
        with self.assertRaises(ValueError):self.module.camera_projection((0,0,0),(0,0,0))


class DisplayNativeTests(unittest.TestCase):
    def test_hidden_image_actor_does_not_leave_its_depth_legend_over_raw_view(self):
        from rsview_centerline import image_display
        appearance=image_display.ImageAppearance.__new__(image_display.ImageAppearance)
        legend=SimpleNamespace(visible=True)
        legend.SetVisibility=lambda value:setattr(legend,'visible',bool(value))
        appearance.closed=False;appearance.settings={'depth':True,'roi':None}
        appearance.actor=SimpleNamespace(GetVisibility=lambda:False);appearance.legend=legend
        appearance.bounds=(0,1,0,1,0,1);appearance.last_projection=None
        camera=SimpleNamespace(GetPosition=lambda:(0,0,-2),GetFocalPoint=lambda:(0,0,0))
        appearance.renderer=SimpleNamespace(GetActiveCamera=lambda:camera)
        appearance.calculator=SimpleNamespace(SetFunction=lambda value:None)
        appearance.table=SimpleNamespace(SetRange=lambda *v:None)
        appearance.mapper=SimpleNamespace(SetScalarRange=lambda *v:None)
        appearance._start()
        self.assertFalse(legend.visible,'old depth legend leaked over restored raw source')

    def test_late_native_setup_failure_releases_created_appearance_and_base_observer(self):
        from rsview_centerline import clearance_native,image_display
        appearances=[]
        class Appearance:
            def __init__(self,overlay):self.closed=False;appearances.append(self)
            def close(self):self.closed=True
        host=SimpleNamespace(closed=False)
        host.close=lambda:setattr(host,'closed',True)
        renderer=SimpleNamespace(observers=[42])
        renderer.RemoveObserver=lambda token:renderer.observers.remove(token)
        class Reader:
            def GetClientSideObject(self):return self
            def SetNumberOfTrailingFrames(self,value):raise RuntimeError('injected reader setup failure')
        raw=SimpleNamespace(Visibility=0)
        actor=SimpleNamespace(GetProperty=lambda:SimpleNamespace(SetPointSize=lambda v:None,SetColor=lambda *v:None))
        def base_init(self,*args,**kwargs):
            self.render_observer=42;self.renderer=renderer;self.actors=[];self.labels=[]
            self.raw_rep=raw;self.raw_visibility=1;self.cloud_actors={'object':(None,actor)}
        with patch.object(clearance_native,'ClearanceProcess',return_value=host),\
                patch.object(clearance_native.VtkClearanceOverlay,'__init__',base_init),\
                patch.object(image_display,'ImageAppearance',Appearance):
            with self.assertRaisesRegex(RuntimeError,'injected reader setup failure'):
                clearance_native.VtkOnlineClearanceOverlay(None,None,None,None,'test.pcap',Reader(),
                    source_mode='recorded_pcap',worker_config={'image_fusion_only':True})
        self.assertTrue(host.closed)
        self.assertTrue(appearances[0].closed,'created image display retained after later native failure')
        self.assertEqual(renderer.observers,[])
        self.assertEqual(raw.Visibility,1)

    def test_failed_appearance_setup_does_not_leave_a_renderer_callback_or_legend(self):
        from rsview_centerline import image_display
        class Node:
            def __getattr__(self,name):return lambda *args:Node()
        class Mapper(Node):
            def SelectColorArray(self,*args):raise RuntimeError('injected native setup failure')
        class Renderer:
            def __init__(self):self.legends=[];self.callbacks={}
            def AddActor2D(self,value):self.legends.append(value)
            def RemoveActor2D(self,value):
                if value in self.legends:self.legends.remove(value)
            def AddObserver(self,event,callback):self.callbacks[1]=callback;return 1
            def RemoveObserver(self,token):self.callbacks.pop(token,None)
        mapper=Mapper();actor=Node();actor.GetMapper=lambda:mapper;renderer=Renderer()
        overlay=SimpleNamespace(vtk=None,renderer=renderer,cloud_actors={'object':(Node(),actor)})
        with patch.object(image_display,'_kind',side_effect=lambda vtk,name:Node):
            with self.assertRaisesRegex(RuntimeError,'injected native setup failure'):
                image_display.ImageAppearance(overlay)
        self.assertEqual(renderer.legends,[],'failed display setup left a scalar bar attached')
        self.assertEqual(renderer.callbacks,{},'failed display setup left a bound callback retained')

    def test_settings_use_existing_pair_and_do_not_submit_or_modify_points(self):
        from rsview_centerline import clearance_native
        from rsview_centerline.clearance.tests import test_recorded_playback as helpers
        overlay=helpers.RecordedNativeTests().overlay()
        self.assertTrue(hasattr(overlay,'set_image_display_settings'),'native display settings seam absent')
        calls=[]
        class Appearance:
            def configure(self,depth,point_size,roi):calls.append((depth,point_size,roi))
        overlay.image_appearance=Appearance()
        packet=dict(sequence=20,measurement_basis='image_only',measurements=[],
            fusion={'reference_sequence':20},clouds={'object':{'data':b'unchanged'}})
        overlay.last_result=packet
        with patch.object(overlay,'display_packet',side_effect=lambda p:p):
            self.assertTrue(overlay.set_image_display_settings(True,1.,(-1,1,-2,2,-3,3)))
        self.assertEqual(calls,[(True,1.,(-1,1,-2,2,-3,3))])
        self.assertEqual(packet['clouds']['object']['data'],b'unchanged')
        self.assertEqual(packet['fusion']['reference_sequence'],20)
        self.assertEqual(overlay.host.requests,[])

    def test_display_menu_is_disabled_on_source_close(self):
        from rsview_centerline import fusion_native
        from rsview_centerline.clearance.tests import test_recorded_playback as helpers
        from rsview_centerline.clearance.tests.test_live_clearance import Action,Overlay
        logic=helpers.RecordedMenuTests().logic();display=Action()
        try:controller=fusion_native.ImageFusionController(logic,Action(),Action(),None,display)
        except TypeError:self.fail('native display action absent')
        def enable(logic):logic.app.railOverlay=Overlay(logic.getReader());return logic.app.railOverlay
        with patch.object(fusion_native,'enable_image',enable):controller.toggle(True)
        self.assertTrue(display.enabled)
        controller.source_closed();self.assertFalse(display.enabled)


if __name__=='__main__':unittest.main()
