import importlib
import unittest
from dataclasses import replace
import numpy as np
from scipy.spatial.transform import Rotation
from .fixtures_p3 import structure_snapshot
from ..state import RefinementBudget
from ..p3_geometry import build_geometry,GeometryPolicy


class P3RefinementTests(unittest.TestCase):
    def module(self):
        try:return importlib.import_module('rsview_centerline.fusion.p3_refinement')
        except ImportError:self.fail('anchored P3 shadow solver absent')

    def solve(self,snapshot,budget=None):
        policy=GeometryPolicy();budget=budget or RefinementBudget()
        context=build_geometry(snapshot,RefinementBudget(),policy)
        return self.module().refine_shadow(snapshot,context,budget,policy)

    def test_mixed_structure_pose_error_shrinks(self):
        snapshot=structure_snapshot(pose_error_m=.0015)
        before=tuple(r.corrected_xyz.tobytes() for r in snapshot.scans)
        proposal=self.solve(snapshot)
        self.assertTrue(proposal.solved,proposal.reason)
        self.assertEqual(proposal.key,snapshot.key)
        np.testing.assert_array_equal(proposal.poses[-1],snapshot.scans[-1].pose)
        old=np.sqrt(np.mean([np.sum(r.pose[:3,3]**2) for r in snapshot.scans]))
        new=np.sqrt(np.mean([np.sum(p[:3,3]**2) for p in proposal.poses]))
        self.assertLessEqual(new,.5*old)
        self.assertLessEqual(proposal.diagnostics['max_visible_displacement_m'],.02)
        self.assertEqual(tuple(r.corrected_xyz.tobytes() for r in snapshot.scans),before)

    def test_arc_is_not_flattened(self):
        snapshot=structure_snapshot(pose_error_m=.001)
        proposal=self.solve(snapshot)
        self.assertTrue(proposal.solved,proposal.reason)
        for scan,pose in zip(snapshot.scans,proposal.poses):
            points=scan.corrected_xyz[-100:]
            moved=points@pose[:3,:3].T+pose[:3,3]
            np.testing.assert_allclose(np.linalg.norm(np.diff(points,axis=0),axis=1),
                np.linalg.norm(np.diff(moved,axis=0),axis=1),atol=1e-12)

    def test_degenerate_plane_rejects(self):
        proposal=self.solve(structure_snapshot('single_plane',pose_error_m=.001,count=4))
        self.assertFalse(proposal.solved)
        self.assertEqual(proposal.reason,'unobservable_window')

    def test_far_return_displacement_guard(self):
        snapshot=structure_snapshot(count=4)
        first=snapshot.scans[0]
        points=np.vstack([first.corrected_xyz,[[9.9,0.,1.],[0.,19.,0.]]])
        scan=replace(first,corrected_xyz=points,original_indices=np.arange(len(points)),
            point_times=np.full(len(points),first.reference_s),rings=np.zeros(len(points),dtype=np.int32))
        snapshot=replace(snapshot,scans=(scan,)+snapshot.scans[1:])
        poses=[r.pose.copy() for r in snapshot.scans]
        poses[0][:3,:3]=Rotation.from_euler('z',.1,degrees=True).as_matrix()
        poses[0][1,3]=.02  # Each individual cap passes, combined 10m point motion does not.
        ok,diagnostics=self.module().displacement_guard(snapshot,poses,RefinementBudget(),GeometryPolicy())
        self.assertFalse(ok)
        self.assertGreater(diagnostics['max_visible_displacement_m'],.02)

    def test_cancel_and_expiry_keep_base_poses(self):
        snapshot=structure_snapshot(count=4)
        for budget in (RefinementBudget(deadline_s=0.),RefinementBudget(cancelled=lambda:True)):
            proposal=self.solve(snapshot,budget)
            self.assertFalse(proposal.solved)
            self.assertEqual(proposal.reason,'budget')
            for a,b in zip(proposal.poses,snapshot.scans):np.testing.assert_array_equal(a,b.pose)
