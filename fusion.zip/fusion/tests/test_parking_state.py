import importlib
import unittest
from dataclasses import replace
import numpy as np
from .fixtures_parking import stable_evidence
from .fixtures_contour import make_record


class ParkingStateTests(unittest.TestCase):
    def module(self):
        try:return importlib.import_module('rsview_centerline.fusion.parking_state')
        except ImportError:self.fail('parking capture state / local clock budget missing')

    def gate(self):
        c=self.module().ParkingCapture(clock=lambda:0.)
        c.start('p',('controlled','device',0),0.);return c

    def collecting(self):
        c=self.gate()
        for i in range(5):c.observe(stable_evidence(i),i*.1)
        return c

    def test_confirmation_scan_is_not_capture_and_unknown_cannot_finish(self):
        c=self.collecting();self.assertEqual(c.state,'collecting')
        self.assertEqual(c.snapshot(.4)['actual_count'],0)
        self.assertTrue(c.observe(stable_evidence(5),.5)['accept_capture_scan'])
        c.update_counts(20,19,.5);self.assertEqual(c.state,'collecting')
        c.finish('deadline',60.);self.assertEqual(c.state,'incomplete')

    def test_manual_start_is_required_and_duplicate_does_not_warm(self):
        c=self.module().ParkingCapture(clock=lambda:0.)
        self.assertFalse(c.observe(stable_evidence(0),0.)['accept_capture_scan'])
        c.start('p',('controlled','device',0),0.)
        for i in range(20):c.observe(stable_evidence(0),i*.01)
        self.assertEqual(c.state,'awaiting_stability')
        self.assertEqual(c.snapshot(.2)['stable_count'],1)

    def test_five_scans_also_require_actual_point_time_span(self):
        c=self.gate()
        for i in range(5):c.observe(replace(stable_evidence(i),reference_s=1.+i*.05,reference_dt_s=.05),i*.1)
        self.assertEqual(c.state,'awaiting_stability')
        c.observe(replace(stable_evidence(5),reference_s=1.5),.5)
        self.assertEqual(c.state,'collecting')

    def test_unknown_rates_and_unobservable_registration_are_not_zero_motion(self):
        for change in ({'translation_rate_m_s':None},{'rotation_rate_rad_s':None},
            {'observable':False},{'reference_dt_s':None},{'coverage':.499},
            {'correspondence_count':149},{'translation_rate_m_s':np.nan}):
            c=self.gate()
            for i in range(6):c.observe(replace(stable_evidence(i),**change),i*.1)
            self.assertEqual(c.state,'awaiting_stability',change)
            self.assertEqual(c.snapshot(.6)['stable_count'],0)

    def test_motion_cannot_warm_and_single_outlier_does_not_clear_capture(self):
        c=self.gate()
        for i in range(5):c.observe(replace(stable_evidence(i),translation_rate_m_s=.031),i*.1)
        self.assertEqual(c.state,'awaiting_stability')
        c=self.collecting();c.update_counts(3,2,.4)
        d=c.observe(replace(stable_evidence(5),translation_rate_m_s=.061),.5)
        self.assertFalse(d['accept_capture_scan']);self.assertEqual(c.snapshot(.5)['actual_count'],3)
        self.assertTrue(c.observe(stable_evidence(6),.6)['accept_capture_scan'])
        self.assertEqual(c.capture_generation,0)

    def test_three_motion_steps_change_generation_without_extending_deadline(self):
        c=self.collecting();deadline=c.deadline_s
        for i in range(5,8):d=c.observe(replace(stable_evidence(i),rotation_rate_rad_s=np.deg2rad(2.1)),i*.1)
        self.assertEqual(c.state,'awaiting_stability');self.assertEqual(c.capture_generation,1)
        self.assertTrue(d['reset_capture_window']);self.assertEqual(c.deadline_s,deadline)
        self.assertEqual(d['reason'],'motion_evidence')

    def test_three_failures_are_evidence_loss_not_detected_motion(self):
        c=self.collecting()
        for i in range(5,8):d=c.observe(replace(stable_evidence(i),observable=False),i*.1)
        self.assertEqual(c.state,'awaiting_stability');self.assertEqual(d['reason'],'evidence_lost')
        self.assertFalse(d['motion_detected'])

    def test_enter_and_exit_limits_use_real_rates_and_hysteresis(self):
        c=self.gate()
        for i in range(5):c.observe(replace(stable_evidence(i),translation_rate_m_s=.03,
            rotation_rate_rad_s=np.deg2rad(1.)),i*.1)
        self.assertEqual(c.state,'collecting')
        self.assertTrue(c.observe(replace(stable_evidence(5),translation_rate_m_s=.06,
            rotation_rate_rad_s=np.deg2rad(2.)),.5)['accept_capture_scan'])

    def test_reverse_changed_source_and_clock_gap_cancel_without_counting(self):
        self.module()
        cases=[replace(stable_evidence(6),sequence=2),replace(stable_evidence(6),reference_s=1.2),
            replace(stable_evidence(6),source_key=('other','device',0)),
            replace(stable_evidence(6),reference_s=2.1,reference_dt_s=.7)]
        for evidence in cases:
            c=self.collecting();d=c.observe(evidence,.6)
            self.assertFalse(d['accept_capture_scan']);self.assertEqual(c.state,'idle')

    def test_deadline_expires_without_new_scan_and_remaining_only_shrinks(self):
        c=self.gate();c.limit_remaining(30.,10.)
        self.assertEqual(c.deadline_s,40.)
        c.limit_remaining(60.,11.);self.assertEqual(c.deadline_s,40.)
        self.assertEqual(c.snapshot(40.)['state'],'incomplete')
        self.assertFalse(c.observe(stable_evidence(1),41.)['accept_capture_scan'])
        c.start('next',('controlled','device',0),50.);self.assertEqual(c.deadline_s,110.)

    def test_frozen_capture_and_cancel_do_not_accept_more_scans(self):
        c=self.collecting();c.update_counts(20,20,.5)
        self.assertEqual(c.state,'capture_complete')
        self.assertFalse(c.observe(stable_evidence(5),.6)['accept_capture_scan'])
        self.assertEqual(c.snapshot(100.)['actual_count'],20)
        c.cancel('user');self.assertEqual(c.state,'idle')
        self.assertFalse(c.observe(stable_evidence(6),101.)['accept_capture_scan'])

    def test_invalid_counts_and_tokens_are_not_published(self):
        c=self.collecting()
        for actual,trusted in ((21,20),(5,6),(-1,0),(1.5,1)):
            with self.assertRaises(ValueError):c.update_counts(actual,trusted,.5)
        for token in ('','x'*129,'中文'):
            with self.assertRaises(ValueError):c.start(token,('controlled','device',0),0.)
        for remaining in (-1.,61.,np.nan):
            with self.assertRaises(ValueError):c.limit_remaining(remaining,.5)

    def test_fork_does_not_modify_original_stability_or_count_state(self):
        c=self.gate();c.observe(stable_evidence(0),0.);other=c.fork()
        for i in range(1,5):other.observe(stable_evidence(i),i*.1)
        self.assertEqual(other.state,'collecting');self.assertEqual(c.state,'awaiting_stability')
        self.assertEqual(c.snapshot(.4)['stable_count'],1)

    def test_captured_scan_owns_diagnostics_and_does_not_relabel_device_epoch(self):
        m=self.module();r=make_record();diag={'usable':True,'counts':np.array([3,4])}
        s=m.CapturedScan(r,'p',7,diag);diag['usable']=False;diag['counts'][0]=100
        self.assertTrue(s.geometry_diag['usable']);self.assertEqual(s.geometry_diag['counts'][0],3)
        self.assertEqual(s.record.source_key,('controlled','device',0))
        self.assertEqual(s.capture_key,(('controlled','device',0),'p',7))
        with self.assertRaises(ValueError):s.geometry_diag['counts'][0]=9

    def test_budget_uses_its_local_clock_and_no_infinite_deadline_bypass(self):
        m=self.module();now=[-1000000.]
        b=m.ParkingBudget(-999990.,lambda:now[0],lambda:False)
        self.assertTrue(b.check(64*1024**2));self.assertFalse(b.check(64*1024**2+1))
        now[0]=-999990.;self.assertFalse(b.check())
        b=m.ParkingBudget(1e9,lambda:0.,lambda:True);self.assertFalse(b.check())
