"""Opt-in real-return detail fitting; labels here are evaluation-only."""
import unittest
from unittest.mock import patch
from dataclasses import replace
import numpy as np
from ..registration import LocalMap,representatives
from ..state import RefinementBudget
from ..engine import ImageFusionEngine
from .fixtures_parking import parking_scans,parking_request


def unequal_scene():
    a=np.linspace(-2.,2.,200)
    plane=np.array([[x,y,0.] for x in a for y in a])
    rod=np.array([[.5+.01*np.cos(t),-.55+.01*np.sin(t),z]
        for z in np.linspace(.4,1.2,60) for t in np.linspace(0.,2*np.pi,16,endpoint=False)])
    return np.vstack((plane,rod)),len(plane)


class ParkingDetailTests(unittest.TestCase):
    def sampler(self):
        from ..registration import detail_representatives
        return detail_representatives

    def test_detail_retains_more_thin_feature_without_losing_background_budget(self):
        points,split=unequal_scene();before=points.tobytes()
        coarse=representatives(points,.09,800)
        chosen=self.sampler()(points,.09,800)
        self.assertGreaterEqual(np.count_nonzero(chosen>=split),2*np.count_nonzero(coarse>=split))
        self.assertGreaterEqual(np.count_nonzero(chosen<split),400)
        self.assertLessEqual(len(chosen),800);self.assertEqual(len(chosen),len(np.unique(chosen)))
        self.assertEqual(before,points.tobytes())
        self.assertTrue(np.isin(coarse[np.linspace(0,len(coarse)-1,400,dtype=int)],chosen).all())

    def test_sparse_and_tiny_inputs_are_safe_real_subsets(self):
        sample=self.sampler()
        for n in (0,1,5,20):
            points=np.column_stack((np.arange(n),np.zeros(n),np.ones(n)))
            rows=sample(points,.09,10)
            self.assertLessEqual(len(rows),10)
            self.assertTrue(((rows>=0)&(rows<n)).all())
        with self.assertRaises(ValueError):sample(np.zeros((2,3)),.09,0)

    def test_map_policy_is_opt_in_and_survives_rebuild_fork(self):
        scans=parking_scans(3);records=tuple(s.record for s in scans)
        legacy=LocalMap();detail=LocalMap(detail_sampling=True)
        a=legacy.rebuilt(records,RefinementBudget(),training_only=True)
        b=detail.rebuilt(records,RefinementBudget(),training_only=True)
        self.assertFalse(a.detail_sampling);self.assertTrue(b.detail_sampling)
        self.assertTrue(b.fork().detail_sampling);self.assertEqual(len(b.geometry),4)
        changed=[]
        for r in records:
            xyz=r.corrected_xyz.copy();xyz[r.original_indices%5==0]+=[4.,0.,0.]
            changed.append(replace(r,raw_xyz=xyz,corrected_xyz=xyz))
        c=detail.rebuilt(tuple(changed),RefinementBudget(),training_only=True)
        np.testing.assert_array_equal(b.geometry[0],c.geometry[0])

    def test_detail_context_is_fixed_independent_and_has_smaller_local_groups(self):
        from ..parking_quality import build_parking_context,check_micro_candidate
        scans=parking_scans(4);r=scans[0].record
        context=build_parking_context(scans,0,RefinementBudget(),detail_sampling=True)
        self.assertNotIn(0,context.reference_ids)
        self.assertTrue(any(name[0]=='detail' for name,rows in context.groups))
        for name,rows in context.groups:
            if name[0]=='detail':
                self.assertLessEqual(np.ptp(context.target[rows],axis=0).max(),.12+1e-9)
        noise=context.noise_budget_m.tobytes();rows=context.check_rows.tobytes()
        xyz=r.corrected_xyz.copy();xyz[:,0]+=.015
        self.assertFalse(check_micro_candidate(r,replace(r,corrected_xyz=xyz),context).accepted)
        self.assertEqual(noise,context.noise_budget_m.tobytes());self.assertEqual(rows,context.check_rows.tobytes())

    def test_detail_flag_cannot_enter_other_modes_or_live(self):
        with self.assertRaises(ValueError):ImageFusionEngine({'image_parking_detail':True})
        with self.assertRaises(ValueError):ImageFusionEngine({'image_contour_mode':'parking','image_parking_detail':True},source_mode='live')

    def test_flag_off_keeps_default_baseline_numerically_identical(self):
        default=ImageFusionEngine({'image_contour_mode':'parking'})
        explicit=ImageFusionEngine({'image_contour_mode':'parking','image_parking_detail':False})
        for i in range(9):
            a=default.process(parking_request(i));b=explicit.process(parking_request(i))
            self.assertEqual(a['_display'],b['_display'])
            self.assertEqual(a['_single_display'],b['_single_display'])
            self.assertEqual(a['relative_pose_diagnostics'],b['relative_pose_diagnostics'])
            self.assertEqual(a['parking']['checks'],b['parking']['checks'])
            self.assertNotIn('detail_enabled',a['parking'])

    def test_detail_retains_old_baseline_when_independent_check_is_unavailable(self):
        e=ImageFusionEngine({'image_contour_mode':'parking','image_parking_detail':True})
        for i in range(8):packet=e.process(parking_request(i))
        self.assertTrue(packet['parking']['detail_enabled'])
        self.assertIn(packet['relative_pose_diagnostics']['detail_state'],('baseline_retained','accepted'))
        self.assertEqual(packet['measurements'],[])
        self.assertEqual(packet['parking']['source_frames'],[6,7])
        self.assertFalse(e.parking_runtime.mapper.detail_sampling)

    def test_optional_detail_failure_does_not_discard_valid_baseline_scan(self):
        e=ImageFusionEngine({'image_contour_mode':'parking','image_parking_detail':True})
        for i in range(8):e.process(parking_request(i))
        with patch('rsview_centerline.fusion.parking_engine.parking_detail_candidate',
                   side_effect=ValueError('optional_detail_capacity')):
            packet=e.process(parking_request(8))
        self.assertEqual(packet['parking']['source_frames'],[6,7,8])
        self.assertEqual(packet['relative_pose_diagnostics']['detail_state'],'baseline_retained')
        self.assertEqual(packet['relative_pose_diagnostics']['detail_reason'],'optional_detail_capacity')

    def observable_window(self):
        from ..parking_alignment import RigidScanModel
        scans=parking_scans(4);result=[]
        for s in scans:
            r=s.record;p=r.pose.copy()
            if r.sequence==3:p[0,3]=.001
            r=replace(r,raw_xyz=r.raw_xyz[:4800],corrected_xyz=r.corrected_xyz[:4800],
                point_times=r.point_times[:4800],original_indices=r.original_indices[:4800],
                pose=p,model=RigidScanModel(p))
            result.append(replace(s,record=r))
        return tuple(result)

    def test_observable_real_return_candidate_can_pass_without_point_projection(self):
        from ..parking_engine import _detail_pass
        from ..parking_quality import check_parking_window
        from ..registration import transform
        scans=self.observable_window();checks=check_parking_window(scans,RefinementBudget())
        previous=check_parking_window(scans[:-1],RefinementBudget())
        result,new_checks,diag=_detail_pass(scans,checks,scans[:-1],previous,RefinementBudget())
        self.assertEqual(diag['detail_state'],'accepted',diag)
        before=scans[-1].record;after=result[-1].record
        self.assertLess(np.linalg.norm(after.pose[:3,3]),.0003)
        np.testing.assert_array_equal(before.raw_xyz,after.raw_xyz)
        np.testing.assert_array_equal(before.corrected_xyz,after.corrected_xyz)
        np.testing.assert_allclose(after.model.world_points(after.raw_xyz,after.point_times),
                                   transform(after.corrected_xyz,after.pose),atol=1e-12)
        self.assertEqual([c.status for c in new_checks.values()],['passed']*4)

    def test_accepted_candidate_cannot_degrade_another_trusted_scan(self):
        from ..parking_engine import _detail_pass
        from ..parking_quality import check_parking_window
        scans=self.observable_window();checks=check_parking_window(scans,RefinementBudget())
        previous=check_parking_window(scans[:-1],RefinementBudget())
        staged=dict(checks);staged[0]=replace(staged[0],status='rejected')
        with patch('rsview_centerline.fusion.parking_engine.check_parking_window',return_value=staged):
            result,new_checks,diag=_detail_pass(scans,checks,scans[:-1],previous,RefinementBudget())
        self.assertIs(result,scans);self.assertIs(new_checks,checks)
        self.assertEqual(diag['detail_reason'],'other_scan_support_regression')

    def test_optional_deadline_exhaustion_retains_already_staged_baseline(self):
        e=ImageFusionEngine({'image_contour_mode':'parking','image_parking_detail':True})
        for i in range(9):e.process(parking_request(i))
        runtime=e.parking_runtime;now=[runtime.clock()]
        runtime.clock=lambda:now[0];runtime.capture.clock=runtime.clock
        pack=e.paired_views;packed=[]
        def observed_pack(*args):
            self.assertLess(now[0],runtime.capture.deadline_s,'new packing after deadline')
            packed.append(1);return pack(*args)
        def expired(*args):
            now[0]+=61.;return None,'refinement_budget'
        with patch.object(e,'paired_views',side_effect=observed_pack),\
             patch('rsview_centerline.fusion.parking_engine.parking_detail_candidate',side_effect=expired):
            packet=e.process(parking_request(9))
        self.assertEqual(packet['parking']['source_frames'],[6,7,8,9])
        self.assertEqual(packet['fusion']['reference_sequence'],9)
        self.assertEqual(len(packed),1)
        self.assertEqual(packet['parking']['state'],'incomplete')
        self.assertEqual(packet['relative_pose_diagnostics']['detail_state'],'baseline_retained')

    def test_optional_map_capacity_is_reserved_before_allocation(self):
        e=ImageFusionEngine(dict(image_contour_mode='parking',image_parking_detail=True,
            image_display_limit=1,image_display_filter_preview=True,image_byte_budget=1592320))
        for i in range(9):e.process(parking_request(i))
        def proposal(records,checks,*unused):
            last=records[-1];r=last.record
            candidate=records[:-1]+(replace(last,record=replace(r,pose=r.pose.copy())),)
            return candidate,checks,dict(detail_state='accepted',detail_reason='independent_detail_improvement')
        with patch('rsview_centerline.fusion.parking_engine._detail_pass',side_effect=proposal):
            packet=e.process(parking_request(9))
        self.assertEqual(packet['parking']['source_frames'],[6,7,8,9])
        self.assertEqual(packet['relative_pose_diagnostics']['detail_state'],'baseline_retained')
        self.assertEqual(packet['relative_pose_diagnostics']['detail_reason'],'detail_capacity_reached')


if __name__=='__main__':unittest.main()
