"""Phase branch measures full real compensated windows, never display samples."""
import importlib
import unittest
from dataclasses import replace
import numpy as np
from ..p3_snapshot import SnapshotKey,CompensatedScan,CompensatedWindowSnapshot
from ..engine import ImageFusionEngine
from ..state import RefinementBudget
from .fixtures_p3 import moving_requests,engine_fingerprint
from ...clearance.protocol import ClearanceConfig,Candidate,SceneLayers,TrackUpdate
from ...clearance.tests.fixtures import line_track


def snapshot(points_per_scan,translation=.01):
    scans=[]
    for seq,world in enumerate(points_per_scan):
        pose=np.eye(4);pose[1,3]=seq*translation;stamp=1.+seq*.1
        xyz=np.asarray(world,dtype=float)-pose[:3,3];indices=np.arange(len(xyz),dtype=np.int64)
        scans.append(CompensatedScan(seq,stamp,(stamp-.05,stamp+.05),xyz,
            np.full(len(xyz),stamp),indices,pose,None))
    # Deliberately unrelated tiny display buffer. It cannot yield the minimum.
    pair=dict(fused=ImageFusionEngine.packed([[9.,9.,9.]]),single=ImageFusionEngine.packed([[9.,9.,9.]]))
    key=SnapshotKey('test','device:test',0,1,len(scans),len(scans)-1,scans[-1].reference_s,tuple(range(len(scans))))
    return CompensatedWindowSnapshot(key,tuple(scans),pair,{})


class WindowMeasurementTests(unittest.TestCase):
    def setUp(self):
        try:self.module=importlib.import_module('rsview_centerline.fusion.window_measurement')
        except ImportError:self.fail('20-frame measurement adapter missing')

    def test_full_real_minimum_and_origin_survive_display_sampling(self):
        from ...clearance.stop_fusion import measure_window
        frames=[[[2.024,1.,.3]]] * 20;frames=list(frames);frames[5]=[[2.004,1.,.3]]
        source=snapshot(frames);window=self.module.build_measurement_window(source,ClearanceConfig(),RefinementBudget())
        geometry=window.geometry();layers=SceneLayers({'object':np.array([0])},
            (Candidate('body',np.array([0]),np.array([0]),1.,2.9,{}),),{'object':1})
        model=line_track(time=2.9);model=replace(model,session_id='test')
        result=measure_window(window,TrackUpdate('observed_dual',model),layers,ClearanceConfig())[0]
        self.assertAlmostEqual(result.observed_min_distance_m,2.004,places=12)
        self.assertEqual(result.observed_evidence.point_ref.frame,5)
        self.assertEqual(result.observed_evidence.point_ref.index,0)
        np.testing.assert_allclose(result.observed_evidence.point_L,[2.004,.81,.3],atol=1e-12)
        self.assertEqual(window.reference_sequence,19);self.assertEqual(window.scan_count,20)

    def test_pending_preview_is_separate_and_keeps_literal_raw_origin(self):
        from ...clearance.stop_fusion import measure_window
        frames=[[[2.024,1.,.3]]]*20;frames=list(frames);frames[5]=[[2.004,1.,.3]]
        window=self.module.build_measurement_window(snapshot(frames),ClearanceConfig(),RefinementBudget())
        layers=SceneLayers({},(Candidate('body',np.array([0]),np.array([0]),1.,2.9,{}),),{'object':1})
        model=replace(line_track(time=2.9),session_id='test')
        results=measure_window(window,TrackUpdate('observed_dual',model),layers,ClearanceConfig())
        packet=dict(measurements=[],secondary_measurements=[dict(candidate_id='body',reason='unresolved_annotation_quality')])
        if not hasattr(self.module,'pending_previews'):self.fail('separate pending-window preview missing')
        previews=self.module.pending_previews(results,layers,packet)
        self.assertEqual(packet['measurements'],[])
        self.assertEqual(len(previews),1);item=previews[0]
        self.assertAlmostEqual(item['distance_m'],2.004,places=12)
        self.assertEqual(item['source_frame'],5);self.assertEqual(item['source_index'],0)
        self.assertTrue(item['uncertain']);self.assertTrue(item['window_raw_preview'])
        self.assertIsNone(item['supported_distance_m']);self.assertIsNone(item['object_id'])
        from ...clearance_overlay import raw_boundary_markers
        self.assertEqual(list(raw_boundary_markers(previews)),[],'same raw point must not create a second marker')
        packet['secondary_measurements'][0]['reason']='unknown_track_role'
        self.assertEqual(self.module.pending_previews(results,layers,packet),[])

    def test_phase_map_retains_more_than_old_parking_preset_within_bounded_memory(self):
        rows=np.arange(128000)
        points=np.c_[-2.+(rows%100)*.03,-2.+((rows//100)%100)*.03,.3+(rows//10000)*.03]
        s=snapshot(np.split(points,20),translation=0.)
        try:window=self.module.build_measurement_window(s,{},RefinementBudget(temporary_limit_bytes=128*1024**2))
        except (AttributeError,ValueError):self.fail('phase adapter still inherits the insufficient parking map capacity')
        self.assertEqual(window.point_count,128000);self.assertEqual(window.scan_count,20)
        self.assertEqual(len(window.representatives),128000)

    def test_real_rail_and_box_have_window_distance_in_latest_reference(self):
        from ...clearance.tests.test_track import rail_scene
        rail=rail_scene().xyz_L
        box=np.array([[x,y,z] for x in np.linspace(-.25,.2,12)
            for y in (2.004,2.3) for z in np.linspace(.8,1.3,12)])
        # Translation is along Z, so the independently known lateral distance
        # remains 2.004m; all geometry must instead shift .19m along Z.
        s=snapshot([np.vstack([rail,box])]*20,translation=0.)
        scans=[]
        for scan in s.scans:
            pose=np.eye(4);pose[2,3]=scan.sequence*.01
            scans.append(replace(scan,pose=pose,corrected_xyz=scan.corrected_xyz-pose[:3,3]))
        s=replace(s,scans=tuple(scans));before=[r.corrected_xyz.tobytes() for r in s.scans]
        cfg=ClearanceConfig(qualified_object_cores=True,surface_object_proposals=True,geometry_label_priority=True)
        packet=self.module.measure_snapshot(s,cfg,RefinementBudget())
        self.assertEqual(packet['measurement_basis'],'rolling_20_window')
        self.assertEqual(packet['sequence'],19);self.assertFalse(packet['current_scan_measurement'])
        self.assertFalse(packet['absolute_accuracy_verified']);self.assertFalse(packet['semantic_one_object_one_label_verified'])
        self.assertTrue(packet['centerline']);self.assertTrue(packet['measurements'])
        nearest=min(packet['measurements'],key=lambda item:abs(item['distance_m']-2.004))
        self.assertAlmostEqual(nearest['distance_m'],2.004,delta=.04)
        self.assertIn(nearest['source_frame'],range(20));self.assertTrue(nearest['uncertain'])
        self.assertEqual(packet['window_measurement']['source_frames'],list(range(20)))
        self.assertNotIn('_display',packet);self.assertEqual(before,[r.corrected_xyz.tobytes() for r in s.scans])
        stack=[packet]
        while stack:
            value=stack.pop()
            self.assertNotIsInstance(value,(np.ndarray,np.generic),'scientific types cannot enter embedded Python2 IPC')
            if isinstance(value,dict):stack.extend(value.values())
            elif isinstance(value,(list,tuple)):stack.extend(value)

    def test_incomplete_or_cancelled_window_cannot_publish(self):
        with self.assertRaises(ValueError):self.module.measure_snapshot(snapshot([[[2.,1.,.3]]]*19),ClearanceConfig(),RefinementBudget())
        budget=RefinementBudget(cancelled=lambda:True)
        with self.assertRaises(ValueError):self.module.measure_snapshot(snapshot([[[2.,1.,.3]]]*20),ClearanceConfig(),budget)

    def test_no_observed_track_cannot_generate_distance_or_nominal_gauge(self):
        s=snapshot([[[2.,1.,.3]]]*20)
        packet=self.module.measure_snapshot(s,ClearanceConfig(),RefinementBudget())
        self.assertEqual(packet['measurements'],[]);self.assertEqual(packet['centerline'],[])
        self.assertEqual(packet['window_measurement']['state'],'track_unavailable')


class WindowControlTests(unittest.TestCase):
    def completed(self,enabled=True):
        engine=ImageFusionEngine({'image_window_measurement':enabled,'image_snapshot_support':True})
        for event in moving_requests(20):engine.process(event)
        request=dict(command='freeze',request_id='measure-guard',source_key=engine.identity,snapshot_key=None,budget_s=60.)
        frozen=engine.process_image_control(request,RefinementBudget())
        request.update(command='measure',snapshot_key=frozen['snapshot_key'])
        return engine,request,frozen

    def test_disabled_or_advanced_snapshot_never_publishes_window_distances(self):
        engine,request,frozen=self.completed(False)
        reply=engine.process_image_control(request,RefinementBudget())
        self.assertEqual(reply['reason'],'window_measurement_disabled');self.assertIsNone(reply['pair'])
        engine,request,frozen=self.completed()
        engine.process(moving_requests(21)[-1])
        reply=engine.process_image_control(request,RefinementBudget())
        self.assertEqual(reply['reason'],'snapshot_changed');self.assertIsNone(reply['pair'])

    def test_cancel_or_temporary_capacity_failure_retains_original_image_only(self):
        for budget in (RefinementBudget(cancelled=lambda:True),RefinementBudget(temporary_limit_bytes=1)):
            engine,request,frozen=self.completed();before=engine_fingerprint(engine)
            reply=engine.process_image_control(request,budget)
            self.assertEqual(reply['state'],'baseline_retained');self.assertEqual(reply['reason'],'window_measurement_failed')
            self.assertEqual(reply['pair'],frozen['pair']);self.assertNotIn('measurement_packet',reply['report'])
            self.assertEqual(engine_fingerprint(engine),before)

    def test_feature_flag_is_strict_and_cannot_change_other_modes(self):
        for value in (1,None,'yes'):
            with self.assertRaises(ValueError):ImageFusionEngine({'image_window_measurement':value})
        for mode in ('parking','quality','window','trajectory'):
            with self.assertRaises(ValueError):ImageFusionEngine({'image_window_measurement':True,'image_contour_mode':mode})
        with self.assertRaises(ValueError):ImageFusionEngine({'image_window_measurement':True,'image_motion_detail':True})

    def test_capable_baseline_can_measure_existing_window_without_reprocessing(self):
        engine=ImageFusionEngine({'image_window_measurement_capable':True,'image_snapshot_support':True})
        for event in moving_requests(20):original=engine.process(event)
        before=engine_fingerprint(engine)
        request=dict(command='freeze',request_id='direct-measure',source_key=engine.identity,snapshot_key=None,budget_s=60.)
        frozen=engine.process_image_control(request,RefinementBudget())
        request.update(command='measure',snapshot_key=frozen['snapshot_key'])
        reply=engine.process_image_control(request,RefinementBudget())
        self.assertEqual(reply['state'],'accepted')
        self.assertEqual(reply['pair']['fused']['data'],original['_display']['object']['data'])
        self.assertEqual(engine_fingerprint(engine),before)
        self.assertNotIn('image_window_measurement',engine.config)

    def test_capability_cannot_enable_other_policies_or_nonboolean_config(self):
        for value in (1,None,'yes'):
            with self.assertRaises(ValueError):ImageFusionEngine({'image_window_measurement_capable':value})
        for mode in ('parking','quality','window','trajectory'):
            with self.assertRaises(ValueError):ImageFusionEngine({'image_window_measurement_capable':True,'image_contour_mode':mode})
        with self.assertRaises(ValueError):ImageFusionEngine({'image_window_measurement_capable':True,'image_motion_detail':True})

    def test_measure_control_preserves_original_twenty_scan_pair(self):
        engine=ImageFusionEngine({'image_window_measurement':True,'image_snapshot_support':True})
        baseline=ImageFusionEngine({'image_snapshot_support':True})
        for event in moving_requests(20):a=baseline.process(event);b=engine.process(event)
        self.assertEqual(a['_display'],b['_display']);before=engine_fingerprint(engine)
        request=dict(command='freeze',request_id='measure',source_key=engine.identity,snapshot_key=None,budget_s=60.)
        frozen=engine.process_image_control(request,RefinementBudget())
        request.update(command='measure',snapshot_key=frozen['snapshot_key'])
        try:reply=engine.process_image_control(request,RefinementBudget())
        except ValueError:self.fail('measure command is not connected to the frozen image window')
        self.assertEqual(reply['state'],'accepted')
        self.assertEqual(reply['pair']['fused']['data'],b['_display']['object']['data'])
        self.assertEqual(reply['report']['measurement_packet']['measurement_basis'],'rolling_20_window')
        self.assertEqual(engine_fingerprint(engine),before)


if __name__=='__main__':unittest.main()
