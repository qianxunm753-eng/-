import importlib
import time
import unittest
import numpy as np
from scipy.spatial.transform import Rotation
from ..state import ScanRecord,RefinementBudget
from ..registration import LocalMap
from ..imu import ImuSeries
from .test_core import scene
from .fixtures_contour import snapshot_bytes
from .fixtures_contour import make_record


def moving_scan(translation_m,rotation_rad,gyro_available=True,seed=19):
    truth=scene();rng=np.random.default_rng(seed);times=rng.uniform(1.,1.1,len(truth));beta=(times-1.05)/.1
    displacement=np.asarray(translation_m);angle=np.asarray(rotation_rad)
    rotations=Rotation.from_rotvec(beta[:,None]*angle)
    raw=rotations.inv().apply(truth-beta[:,None]*displacement)
    imu=ImuSeries(np.linspace(.8,1.2,81),np.tile(angle/.1,(81,1)),max_gap_s=.025) if gyro_available else None
    corrected=imu.deskew(raw,times,1.05) if imu is not None else raw
    record=ScanRecord(('controlled','device',0),1,1.05,(1.,1.1),raw,times,
        np.arange(len(raw)),None,corrected,np.eye(4),None)
    return record,imu,truth


class ContourTrajectoryTests(unittest.TestCase):
    def test_minority_parallel_surface_has_its_own_protection_gate(self):
        from scipy.spatial import cKDTree
        unused,v=self.modules();rng=np.random.default_rng(2026)
        dominant=np.column_stack([np.full(1000,.1),rng.uniform(.1,.4,(1000,2))])
        narrow=np.column_stack([np.full(30,.3),rng.uniform(.2,.24,(30,2))])
        target=np.vstack([dominant,narrow]);normals=np.tile([1.,0.,0.],(len(target),1))
        before=target.copy();before[:1000,0]+=.020
        after=target.copy();after[:1000,0]+=.001;after[1000:,0]+=.030
        report=v.compare_geometry(before,after,(target,cKDTree(target),normals,np.ones(len(target))))
        self.assertFalse(report.accepted,'dominant plane concealed degradation of narrow surface')
        self.assertEqual(report.reason,'local_patch_regression')
        self.assertTrue(any(patch[0]>=.029 for patch in report.after.patch_metrics.values()))

    def test_disconnected_coplanar_feature_is_not_absorbed_by_large_face(self):
        from scipy.spatial import cKDTree
        unused,v=self.modules();rng=np.random.default_rng(56)
        dominant=np.column_stack([np.full(1000,.1),rng.uniform(.001,.008,(1000,2))])
        narrow=np.column_stack([np.full(30,.1),rng.uniform(.052,.060,(30,2))])
        target=np.vstack([dominant,narrow]);normals=np.tile([1.,0.,0.],(len(target),1))
        before=target.copy();before[:1000,0]+=.020
        after=target.copy();after[:1000,0]+=.001;after[1000:,0]+=.030
        report=v.compare_geometry(before,after,(target,cKDTree(target),normals,np.ones(len(target))))
        self.assertFalse(report.accepted)
        self.assertEqual(report.reason,'local_patch_regression')

    def modules(self):
        try:return (importlib.import_module('rsview_centerline.fusion.trajectory'),
                    importlib.import_module('rsview_centerline.fusion.validation'))
        except ImportError:self.fail('joint frame trajectory / independent validation missing')

    def test_independent_guard_does_not_accept_p90_or_coverage_regression(self):
        unused,v=self.modules();before=v.ValidationMetrics(.010,.007,1.,{},True)
        for after in (v.ValidationMetrics(.012001,.006,.95,{},True),
                      v.ValidationMetrics(.009,.006,.9499,{},True),
                      v.ValidationMetrics(.009,.008,1.,{},True),
                      v.ValidationMetrics(.009,.006,1.,{},False)):
            self.assertFalse(v.accept_refinement(before,after).accepted)
        self.assertTrue(v.accept_refinement(before,v.ValidationMetrics(.009,.006,.95,{},True)).accepted)

    def test_global_improvement_cannot_cover_a_bad_local_patch(self):
        unused,v=self.modules()
        before=v.ValidationMetrics(.01,.008,1.,{'edge':(.01,.008,1.)},True)
        after=v.ValidationMetrics(.002,.001,1.,{'edge':(.04,.03,1.)},True)
        self.assertFalse(v.accept_refinement(before,after).accepted)

    def test_nonimprovement_reason_cannot_hide_local_regression_from_window(self):
        unused,v=self.modules()
        before=v.ValidationMetrics(.01,.008,1.,{'edge':(.001,.0005,1.)},True)
        after=v.ValidationMetrics(.01,.009,1.,{'edge':(.04,.03,1.)},True)
        self.assertEqual(v.accept_refinement(before,after).reason,'local_patch_regression')

    def test_original_index_holdout_is_disjoint_even_after_input_filtering(self):
        unused,v=self.modules();indices=np.array([1,3,5,10,11,21,25])
        fit,check=v.split_original_indices(indices)
        np.testing.assert_array_equal(indices[check],[5,10,25])
        self.assertFalse(set(fit)&set(check));self.assertEqual(len(fit)+len(check),len(indices))

    def test_joint_current_scan_translation_and_rotation_align_real_times(self):
        t,unused=self.modules()
        cases=[([.06,-.03,.02],[0.,0.,0.],True),([.05,.02,-.03],[.01,-.02,.03],True),
               ([.04,-.02,.01],[.01,.02,-.02],False)]
        for displacement,angle,gyro in cases:
            with self.subTest(gyro=gyro,angle=angle):
                record,imu,truth=moving_scan(displacement,angle,gyro)
                mapper=LocalMap();mapper.update(truth,np.full(len(truth),.95),None,.95,None,
                    scan_key=(record.source_key,0));before=snapshot_bytes(mapper)
                result=t.JointTrajectorySolver().solve(record,mapper,imu,RefinementBudget())
                self.assertTrue(result.usable,result.diagnostics)
                error=np.linalg.norm(result.points-truth,axis=1)
                self.assertLess(np.percentile(error,90),.002)
                self.assertEqual(snapshot_bytes(mapper),before)
                self.assertEqual(len(result.points),len(record.raw_xyz))
                self.assertEqual(bool(result.diagnostics['imu_active']),gyro)

    def test_gyro_rotation_is_not_applied_twice(self):
        t,unused=self.modules();record,imu,truth=moving_scan([0.,0.,0.],[0.,0.,.1])
        model=t.TrajectoryModel('gyro',record.span_s,record.reference_s,np.eye(4),np.eye(4))
        np.testing.assert_allclose(model.corrected_points(record.raw_xyz,record.point_times,imu),truth,atol=1e-8)

    def test_single_plane_cannot_be_made_observable_by_regularization(self):
        t,unused=self.modules();record,imu,truth=moving_scan([.04,0.,0.],[0.,0.,0.])
        rows=np.arange(400);plane=ScanRecord(record.source_key,1,record.reference_s,record.span_s,
            record.raw_xyz[rows],record.point_times[rows],record.original_indices[rows],None,
            record.corrected_xyz[rows],record.pose,None)
        mapper=LocalMap();mapper.update(truth[rows],np.full(400,.95),None,.95,None)
        before=snapshot_bytes(mapper);result=t.JointTrajectorySolver().solve(plane,mapper,imu,RefinementBudget())
        self.assertFalse(result.usable);self.assertIn('unobservable',result.diagnostics['reason'])
        self.assertEqual(snapshot_bytes(mapper),before)

    def test_zero_span_deadline_and_current_source_map_are_not_new_solutions(self):
        t,unused=self.modules();record,imu,truth=moving_scan([.05,0.,0.],[0.,0.,0.])
        mapper=LocalMap();mapper.update(truth,np.full(len(truth),.95),None,.95,None,
            scan_key=(record.source_key,record.sequence))
        result=t.JointTrajectorySolver().solve(record,mapper,imu,RefinementBudget())
        self.assertFalse(result.usable);self.assertEqual(result.diagnostics['reason'],'self_support_refused')
        mapper.key_sources.clear()
        result=t.JointTrajectorySolver().solve(record,mapper,imu,RefinementBudget(deadline_s=0.))
        self.assertFalse(result.usable)

    def test_missing_gyro_coverage_is_explicit_lidar_only(self):
        t,unused=self.modules();record,unused,truth=moving_scan([.04,0.,0.],[0.,0.,.01],False)
        imu=ImuSeries([2.,2.1],np.zeros((2,3)))
        mapper=LocalMap();mapper.update(truth,np.full(len(truth),.95),None,.95,None)
        result=t.JointTrajectorySolver().solve(record,mapper,imu,RefinementBudget())
        self.assertFalse(result.diagnostics['imu_active'])
        self.assertIn('coverage',result.diagnostics['imu_status'])

    def test_zero_real_span_has_no_invented_endpoint_time(self):
        t,unused=self.modules();record=make_record(1);mapper=LocalMap()
        mapper.update(scene(),np.full(1200,.95),None,.95,None)
        result=t.JointTrajectorySolver().solve(record,mapper,None,RefinementBudget())
        self.assertFalse(result.usable);self.assertEqual(result.diagnostics['reason'],'zero_scan_span')
        np.testing.assert_array_equal(result.points,record.raw_xyz)

    def test_nonrigid_or_nonfinite_endpoint_is_refused(self):
        t,unused=self.modules();bad=np.eye(4);bad[0,0]=2.
        with self.assertRaises(ValueError):t.TrajectoryModel('lidar',(1.,1.1),1.05,bad,np.eye(4))

    def test_nonlinear_motion_residual_is_not_reported_as_exact_geometry(self):
        t,unused=self.modules();record,imu,truth=moving_scan([.06,0.,0.],[0.,0.,0.])
        beta=(record.point_times-1.05)/.1;raw=record.raw_xyz.copy();raw[:,0]-=.12*beta**2
        nonlinear=ScanRecord(record.source_key,1,record.reference_s,record.span_s,raw,
            record.point_times,record.original_indices,None,raw,record.pose,None)
        mapper=LocalMap();mapper.update(truth,np.full(1200,.95),None,.95,None)
        result=t.JointTrajectorySolver().solve(nonlinear,mapper,imu,RefinementBudget())
        self.assertGreater(np.percentile(np.linalg.norm(result.points-truth,axis=1),90),.002)
        self.assertFalse(imu.diagnostics['gyro_bias_calibrated'])
