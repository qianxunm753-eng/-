"""Surface inspection uses one frozen replay window, never reacquires or measures."""
import unittest
import types
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
from .test_p3_native import ControlHost,receipt,P3NativeTests
from rsview_centerline.p3_replay import P3ReplayEnhancement
from rsview_centerline import image_display


class SurfaceHost(ControlHost):
    def request_image_control(self,command,token,source,key=None,budget_s=60.,options=None):
        self.options=options
        return super().request_image_control(command,token,source,key,budget_s)


class SurfaceNativeTests(unittest.TestCase):
    def driver(self):
        host=SurfaceHost()
        try:driver=P3ReplayEnhancement(host,lambda:100.,command='surface',options={'roi':(-1,1,-1,1,-1,1)})
        except TypeError:self.fail('surface lifecycle not connected to frozen replay control')
        driver.begin(('s','c',0));return driver,host

    def test_surface_driver_freezes_then_diagnoses_without_calling_old_refinement(self):
        driver,host=self.driver();host.control_packet=receipt(driver);driver.poll()
        self.assertEqual([c[0] for c in host.commands],['freeze','surface'])
        self.assertEqual(host.options,{'roi':(-1,1,-1,1,-1,1)})
        self.assertEqual(host.requests,[])
        wrong=receipt(driver,'accepted');self.assertFalse(driver.accepts(wrong))
        wrong['command']='surface';self.assertTrue(driver.accepts(wrong))

    def test_surface_views_switch_same_reference_and_restore_exact_baseline(self):
        overlay=P3NativeTests().overlay();driver,host=self.driver();overlay.host=host
        frozen=receipt(driver)
        xyz=np.array([[1.,.003,1.],[1.,.006,1.]],dtype='<f4')
        cloud=dict(data=xyz.tobytes(),count=2,dtype='little-float32-xyz')
        packet=receipt(driver,'accepted');packet.update(command='surface',report={'scope':'surface_diagnostic_only','roi':(-2,2,-2,2,-2,2)})
        packet['pair']['surface_views']={'local':cloud,'baseline':frozen['pair']['fused'],'frames':dict(cloud,frame_data=np.array([0,19],dtype='<f4').tobytes()),'raw_single':cloud}
        with patch.object(overlay,'display_packet',side_effect=lambda p:setattr(overlay,'last_result',p)):
            overlay._display_p3_packet(frozen)
            baseline=overlay.last_result['_image_pairs']['fused']
            overlay._display_p3_packet(packet)
            self.assertTrue(hasattr(overlay,'set_image_surface_view'),'native surface view selection absent')
            self.assertTrue(overlay.set_image_surface_view('local'))
            self.assertEqual(overlay.last_result['clouds']['object']['data'],xyz.tobytes())
            overlay.set_image_surface_view('baseline')
            self.assertEqual(overlay.last_result['clouds']['object']['data'],frozen['pair']['fused']['data'])
            overlay.set_image_surface_view(None)
            self.assertEqual(overlay.last_result['clouds'],baseline)
        self.assertEqual(overlay.last_result['fusion']['reference_sequence'],19)
        self.assertEqual(host.requests,[])

    def test_camera_depth_slab_moves_with_view_not_with_lidar_measurement(self):
        self.assertTrue(hasattr(image_display,'surface_slice_planes'),'camera-relative surface slab absent')
        planes=image_display.surface_slice_planes((0,0,-2),(0,0,0),1.,.2)
        self.assertEqual(planes[0][0],(0.,0.,1.));self.assertEqual(planes[1][0],(0.,0.,-1.))
        np.testing.assert_allclose(planes[0][1],(0,0,.9));np.testing.assert_allclose(planes[1][1],(0,0,1.1))
        turned=image_display.surface_slice_planes((-2,0,0),(0,0,0),1.,.2)
        np.testing.assert_allclose(turned[0][1],(.9,0,0))
        with self.assertRaises(ValueError):image_display.surface_slice_planes((0,0,-2),(0,0,0),0.,float('nan'))

    def test_changing_surface_roi_invalidates_old_crop_and_restores_global_baseline(self):
        original=(-1.,1.,-1.,1.,-1.,1.)
        for changed in ((-2.,2.,-2.,2.,-2.,2.),(2.,3.,2.,3.,2.,3.),None):
            with self.subTest(roi=changed):
                overlay=P3NativeTests().overlay();driver,host=self.driver();overlay.host=host
                overlay.p3_driver=driver;overlay.set_p3_receiver(driver.accepts,lambda p:None,True)
                appearance=SimpleNamespace(settings=image_display.display_settings(True,1.,original),surface_mode='frames')
                appearance.configure=lambda depth,size,roi:setattr(appearance,'settings',image_display.display_settings(depth,size,roi))
                appearance.surface_style=lambda mode,*args:setattr(appearance,'surface_mode',mode)
                overlay.image_appearance=appearance
                frozen=receipt(driver);packet=receipt(driver,'accepted')
                packet.update(command='surface',report={'roi':original})
                packet['pair']['surface_views']={'local':dict(frozen['pair']['fused'],data=b'old crop')}
                with patch.object(overlay,'display_packet',side_effect=lambda p:setattr(overlay,'last_result',p)):
                    overlay._display_p3_packet(frozen);overlay._display_p3_packet(packet)
                    baseline=overlay.last_result['_image_pairs']['fused']
                    overlay.set_image_display_settings(False,2.,changed)
                self.assertFalse(driver.valid,'new ROI still tied to the old frozen crop')
                self.assertIsNone(overlay.surface_view)
                self.assertNotIn('_surface_views',overlay.last_result)
                self.assertEqual(overlay.last_result['clouds'],baseline)
                self.assertEqual(overlay.last_result['surface']['reason'],'roi_changed')
                self.assertNotIn('roi',overlay.last_result['surface'])
                self.assertIsNone(overlay.p3_accept_packet)
                self.assertIsNone(appearance.surface_mode)
                self.assertEqual(appearance.settings['roi'],changed)
                self.assertEqual(host.requests,[])

    def test_same_surface_roi_allows_color_and_point_size_changes_without_cancelling(self):
        overlay=P3NativeTests().overlay();driver,host=self.driver();overlay.host=host;overlay.p3_driver=driver
        roi=(-1.,1.,-1.,1.,-1.,1.)
        appearance=SimpleNamespace(settings=image_display.display_settings(True,1.,roi))
        appearance.configure=lambda depth,size,box:setattr(appearance,'settings',image_display.display_settings(depth,size,box))
        overlay.image_appearance=appearance
        overlay.last_result={'surface':{'roi':roi},'_surface_views':{'local':{}},'measurement_basis':'image_only'}
        overlay.surface_view='local'
        with patch.object(overlay,'display_packet'):
            overlay.set_image_display_settings(False,2.,list(roi))
        self.assertTrue(driver.valid);self.assertEqual(overlay.surface_view,'local')
        self.assertIn('_surface_views',overlay.last_result);self.assertEqual(host.requests,[])

    def test_surface_menu_preserves_existing_reader_and_worker_and_is_mutually_exclusive(self):
        from . import test_parking_native as parking_support
        from rsview_centerline import fusion_native
        from rsview_centerline.clearance.tests.test_live_clearance import Action
        controller,logic,unused=parking_support.ParkingNativeTests().controller()
        controller.surface_action=Action();controller.p3_action=Action();controller.surface_actions={}
        def enable(logic,contour_mode='baseline',parking_detail=False):
            overlay=parking_support.ParkingStyledOverlay(logic.getReader());overlay.host=SurfaceHost()
            overlay.requested_frame=overlay.last_input=19;overlay.set_p3_receiver=lambda *args:None
            overlay.get_image_display_settings=lambda:{'roi':(-1,1,-1,1,-1,1)}
            overlay.set_image_surface_view=lambda *args:True;overlay.set_image_detail_view=lambda checked:True
            logic.app.railOverlay=overlay;return overlay
        with patch.object(fusion_native,'enable_image',enable):
            controller.set_image_fusion(True);overlay=controller.overlay;host=overlay.host
            self.assertTrue(hasattr(controller,'set_surface_diagnostics'),'surface menu handler absent')
            controller.set_surface_diagnostics(True)
            self.assertIs(controller.overlay,overlay);self.assertIs(overlay.host,host)
            self.assertTrue(controller.action.checked);self.assertTrue(controller.surface_action.checked)
            self.assertFalse(controller.p3_action.checked);self.assertFalse(logic.app.playing)
            controller.surface_actions={name:Action() for name in ('local','layer','support','stable')}
            overlay.last_result={'_surface_views':{'local':{}}};controller.source_ready()
            self.assertTrue(controller.surface_actions['local'].enabled)
            self.assertTrue(controller.surface_actions['layer'].enabled)
            self.assertFalse(controller.surface_actions['support'].enabled,'unavailable support view menu still enabled')
            self.assertFalse(controller.surface_actions['stable'].enabled)
            controller.source_closed();self.assertFalse(controller.surface_action.enabled)
            self.assertFalse(controller.surface_action.checked)

    def test_frame_colors_are_installed_before_the_final_visible_render(self):
        from rsview_centerline.clearance_native import VtkOnlineClearanceOverlay
        from rsview_centerline.clearance_overlay import VtkClearanceOverlay
        overlay=VtkOnlineClearanceOverlay.__new__(VtkOnlineClearanceOverlay)
        state=SimpleNamespace(ready=False,rendered=False)
        overlay.view=object();overlay.smp=SimpleNamespace(Render=lambda view:setattr(state,'rendered',state.ready))
        overlay.image_appearance=SimpleNamespace(surface_mode='frames',prepare=lambda packet:None,
            finish=lambda packet:setattr(state,'ready',True))
        def base_display(owner,packet,frame=None):state.rendered=state.ready;return packet
        with patch.object(VtkClearanceOverlay,'display_packet',base_display):
            overlay.display_packet({'measurement_basis':'image_only'})
        self.assertTrue(state.rendered,'frame field updated only after render; click leaves old coloring visible')

    def test_cross_scan_support_view_uses_same_real_coordinates_and_renders_after_scalar_upload(self):
        from rsview_centerline.clearance_native import VtkOnlineClearanceOverlay
        from rsview_centerline.clearance_overlay import VtkClearanceOverlay
        overlay=P3NativeTests().overlay();xyz=np.array([[1.,0.,1.],[1.,.05,1.]],dtype='<f4').tobytes()
        cloud=dict(data=xyz,count=2,dtype='little-float32-xyz',support_data=np.array([1,20],dtype='<f4').tobytes())
        overlay.last_result=dict(measurement_basis='image_only',_image_pairs={'fused':{'object':cloud}},
            _surface_views={'support':cloud,'stable':dict(cloud,count=1,data=xyz[12:],support_data=b'')})
        state=SimpleNamespace(ready=False,rendered=False)
        appearance=SimpleNamespace(surface_mode=None,prepare=lambda p:setattr(state,'ready',False),finish=lambda p:setattr(state,'ready',True))
        appearance.surface_style=lambda mode,*args:setattr(appearance,'surface_mode',mode)
        overlay.image_appearance=appearance;overlay.view=object()
        overlay.smp=SimpleNamespace(Render=lambda view:setattr(state,'rendered',state.ready))
        def base_display(owner,packet,frame=None):state.rendered=state.ready;return packet
        with patch.object(VtkClearanceOverlay,'display_packet',base_display):
            self.assertTrue(overlay.set_image_surface_view('support'))
            self.assertEqual(appearance.surface_mode,'support','cross-scan counts displayed as depth instead')
            self.assertEqual(overlay.last_result['clouds']['object']['data'],xyz)
            self.assertTrue(state.rendered,'support scalars not visible until another interaction')
            self.assertTrue(overlay.set_image_surface_view('stable'))
            self.assertIsNone(appearance.surface_mode)
            overlay.set_image_surface_view(None)
            self.assertEqual(overlay.last_result['clouds']['object']['data'],xyz)

    def test_support_scalar_values_are_owned_and_old_scan_field_is_removed_before_point_upload(self):
        import array
        appearance=image_display.ImageAppearance.__new__(image_display.ImageAppearance)
        class Field:
            def __init__(self):self.name='image_scan_ordinal'
            def GetName(self):return self.name
            def SetName(self,name):self.name=name
            def Initialize(self):pass
            def SetNumberOfComponents(self,count):pass
            def SetVoidArray(self,*args):pass
            def Modified(self):pass
        class PointData:
            def __init__(self):self.fields={'image_scan_ordinal':object()}
            def RemoveArray(self,name):self.fields.pop(name,None)
            def AddArray(self,value):self.fields[value.GetName()]=value
        fields=PointData();appearance.frame_array=Field();appearance.frame_values=array.array('f',[99])
        appearance.surface_mode='support';appearance.pair={};appearance.frame_entry=None
        appearance.data=SimpleNamespace(GetPointData=lambda:fields,GetNumberOfPoints=lambda:3,Modified=lambda:None)
        score=np.array([1,3,20],dtype='<f4').tobytes()
        packet={'_image_pairs':appearance.pair,'_surface_views':{'support':{'count':3,'support_data':score}}}
        appearance.prepare(packet)
        self.assertEqual(fields.fields,{},'old scalar can mismatch the next cloud count during base rendering')
        appearance.finish(packet)
        self.assertEqual(appearance.frame_values.tolist(),[1.,3.,20.])
        self.assertEqual(list(fields.fields),['image_scan_support'])
        packet['_surface_views']['support']['support_data']=np.array([1,3,21],dtype='<f4').tobytes()
        appearance.prepare(packet)
        with self.assertRaises(ValueError):appearance.finish(packet)

    def test_embedded_nonpackage_control_module_validates_surface_roi(self):
        # RSView imports image_control at top level, unlike the scientific worker.
        module=types.ModuleType('embedded_image_control')
        source=Path(image_display.__file__).with_name('image_control.py').read_bytes()
        exec(compile(source,'embedded-image-control.py','exec'),module.__dict__)
        key=receipt(SimpleNamespace(source_key=('s','c',0),request_id='s'))['snapshot_key']
        try:
            with patch.dict('sys.modules',{'image_display':image_display}):
                result=module.validate_control('surface','s',('s','c',0),key,60.,{'roi':(-1,1,-1,1,-1,1)})
        except (ImportError,ValueError):self.fail('embedded top-level control cannot import display validation')
        self.assertEqual(result['options']['roi'],(-1.,1.,-1.,1.,-1.,1.))


if __name__=='__main__':unittest.main()
