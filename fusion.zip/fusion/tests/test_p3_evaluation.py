import importlib
import unittest
import tempfile
import json
from pathlib import Path
import numpy as np
from .fixtures_p3 import structure_snapshot
from .test_core import scene
from ..p3_geometry import GeometryPolicy


class P3EvaluationTests(unittest.TestCase):
    def module(self):
        try:return importlib.import_module('rsview_centerline.analysis.20261013_p3.run_comparison')
        except ImportError:self.fail('one-pass same-snapshot evaluation absent')

    def test_rejected_quality_is_not_reported_as_success(self):
        result,report=self.module().evaluate_snapshot(structure_snapshot('stripe'),GeometryPolicy())
        self.assertFalse(report['quality_passed']);self.assertFalse(report['supported_local_improvement'])
        self.assertFalse(report['physical_accuracy_verified'])
        self.assertTrue(report['same_snapshot_key']);self.assertTrue(report['same_display_origins'])

    def test_supported_relative_improvement_keeps_source_ids_and_origin_sets(self):
        result,report=self.module().evaluate_snapshot(structure_snapshot(pose_error_m=.0015),GeometryPolicy())
        self.assertTrue(report['quality_passed'],report)
        self.assertTrue(report['all_local_guards_passed'])
        self.assertEqual(report['accepted_source_frames'],tuple(range(20)))
        self.assertEqual(report['accepted_source_frames'],report['baseline_source_frames'])
        self.assertFalse(report['field_equipment_quality_verified'])

    def test_incomplete_window_is_not_filled_with_duplicate_scans(self):
        result,report=self.module().evaluate_snapshot(structure_snapshot(count=4),GeometryPolicy())
        self.assertFalse(report['quality_passed'])
        self.assertEqual(report['baseline_source_frames'],(0,1,2,3))
        self.assertEqual(report['reason'],'base_window_incomplete')

    def test_development_and_holdout_are_different_recordings(self):
        module=self.module();self.assertTrue(set(module.DEVELOPMENT_RECORDINGS).isdisjoint(module.HOLDOUT_RECORDINGS))
        self.assertNotIn('80rpm_1.pcap',module.DEVELOPMENT_RECORDINGS)

    def test_real_array_file_pipeline_does_not_modify_source_or_reuse_output(self):
        module=self.module()
        with tempfile.TemporaryDirectory(prefix='p3-eval-test-') as temporary:
            folder=Path(temporary);source=folder/'record.pcap';source.write_bytes(b'independent unit fixture, not native PCAP')
            frames=[]
            for i in range(4):
                xyz=scene().astype('<f8');times=np.full(len(xyz),1.+i*.1,dtype='<f8')
                xyz.tofile(folder/('xyz%d.bin'%i));times.tofile(folder/('t%d.bin'%i))
                frames.append(dict(frame=i,timestamp_range=[float(times[0]),float(times[0])],
                    xyz=dict(file='xyz%d.bin'%i,dtype='double',tuples=len(xyz),components=3),
                    attributes={'timestamp':dict(file='t%d.bin'%i,dtype='double',tuples=len(times),components=1)}))
            manifest=folder/'manifest.json';manifest.write_text(json.dumps(dict(input=str(source),frames=frames)),encoding='utf8')
            report=module.compare_capture(manifest,folder/'output',GeometryPolicy())
            self.assertTrue(report['source_unchanged']);self.assertEqual(source.read_bytes(),b'independent unit fixture, not native PCAP')
            self.assertFalse(report['quality_passed']);self.assertEqual(report['baseline_source_frames'],[0,1,2,3])
            with self.assertRaises(FileExistsError):module.compare_capture(manifest,folder/'output',GeometryPolicy())
