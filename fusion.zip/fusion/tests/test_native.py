import sys
import time
import unittest
from types import SimpleNamespace
from unittest.mock import patch
from rsview_centerline.fusion.tests.test_engine import request
from rsview_centerline.clearance_process import ClearanceProcess
from rsview_centerline.clearance_overlay import MemoryPacketCache


class NativeTests(unittest.TestCase):
    def test_actual_worker_selects_image_only_engine(self):
        host=ClearanceProcess(python=sys.executable,config={'image_fusion_only':True},source_mode='recorded_pcap')
        try:
            host.submit(request());packet=None;deadline=time.monotonic()+15.
            while time.monotonic()<deadline:
                packet=host.poll()
                if packet is not None:break
                time.sleep(.01)
            self.assertIsNotNone(packet)
            self.assertEqual(packet['status'],'completed',packet.get('error'))
            self.assertEqual(packet['calculation'],'image_fusion_only')
            self.assertEqual(packet['measurements'],[])
            self.assertIn('_single_display',packet)
        finally:host.close()

    def test_live_cannot_start_image_only_worker(self):
        with self.assertRaises(ValueError):
            host=ClearanceProcess(python=sys.executable,config={'image_fusion_only':True},source_mode='live')
            host.close()

    def test_larger_image_buffer_does_not_change_legacy_default_limit(self):
        from rsview_centerline.fusion.engine import ImageFusionEngine
        import numpy as np
        entry=ImageFusionEngine.packed(np.ones((60001,3)))
        with self.assertRaises(ValueError):MemoryPacketCache().cloud(entry)
        self.assertEqual(len(MemoryPacketCache(max_points=150000).cloud(entry)),60001*3)

    def test_native_single_fused_switch_uses_same_pair_without_submitting_a_scan(self):
        from rsview_centerline import clearance_native
        from rsview_centerline.clearance.tests.test_recorded_playback import RecordedNativeTests
        overlay=RecordedNativeTests().overlay()
        self.assertTrue(hasattr(overlay,'set_image_single_view'),'native A/B switch absent')
        packet=dict(sequence=20,measurement_basis='image_only',measurements=[],
            fusion={'reference_sequence':20},_image_pairs={'single':{'object':'single'},'fused':{'object':'fused'}})
        overlay.last_result=packet
        def render(value):overlay.last_result=value
        with patch.object(overlay,'display_packet',render):
            overlay.set_image_single_view(True)
            self.assertEqual(overlay.last_result['clouds'],{'object':'single'})
            overlay.set_image_single_view(False)
            self.assertEqual(overlay.last_result['clouds'],{'object':'fused'})
        self.assertEqual(overlay.host.requests,[])
        self.assertEqual(packet['fusion']['reference_sequence'],20)

    def test_image_menu_enables_replay_only_and_restores_tf_on_source_close(self):
        from rsview_centerline.clearance.tests.test_recorded_playback import RecordedMenuTests
        from rsview_centerline.clearance.tests.test_live_clearance import Action,Overlay
        try:from rsview_centerline import fusion_native
        except ImportError:self.fail('image menu absent')
        logic=RecordedMenuTests().logic();action=Action();single=Action()
        controller=fusion_native.ImageFusionController(logic,action,single)
        def enable(native_logic):
            native_logic.app.railOverlay=Overlay(native_logic.getReader())
            return native_logic.app.railOverlay
        with patch.object(fusion_native,'enable_image',enable):controller.toggle(True)
        self.assertTrue(action.checked)
        self.assertEqual(logic.getReader().trailing,0)
        self.assertTrue(single.enabled)
        owned=controller.overlay;controller.source_closed()
        self.assertTrue(owned.closed)
        self.assertEqual(logic.getReader().trailing,17)
        self.assertFalse(single.enabled)

    def test_selected_native_filename_is_text_not_python2_ansi_bytes_in_worker_config(self):
        from rsview_centerline import fusion_native
        logic=SimpleNamespace(getReaderFileName=lambda:b'C:/recording.pcap')
        with patch.object(fusion_native,'enable_recorded',side_effect=lambda logic,config:config):
            config=fusion_native.enable_image(logic)
        self.assertIsInstance(config['image_source_path'],str)
        self.assertEqual(config['image_source_path'],'C:/recording.pcap')

    def test_three_modes_are_exclusive_and_root_close_disposes_image(self):
        from rsview_centerline import clearance_live,clearance_stop,fusion_native
        from rsview_centerline.clearance.tests.test_recorded_playback import RecordedMenuTests
        from rsview_centerline.clearance.tests.test_live_clearance import Action,Overlay
        logic=RecordedMenuTests().logic()
        normal=clearance_live.LiveClearanceController(logic,Action())
        stop=clearance_stop.StopClearanceController(logic,Action())
        image=fusion_native.ImageFusionController(logic,Action(),Action())
        logic.app.clearanceController=normal;logic.app.stopClearanceController=stop;logic.app.imageFusionController=image
        def enable(logic):
            if logic.app.railOverlay is not None:logic.app.railOverlay.close()
            logic.app.railOverlay=Overlay(logic.getReader());return logic.app.railOverlay
        with patch.object(clearance_live,'enable_recorded',enable),patch.object(clearance_stop,'enable_recorded_stop',enable), \
                patch.object(fusion_native,'enable_image',enable):
            normal.toggle(True);a=normal.overlay
            stop.toggle(True);b=stop.overlay
            image.toggle(True);c=image.overlay
            self.assertTrue(a.closed and b.closed)
            self.assertIsNone(normal.overlay);self.assertIsNone(stop.overlay)
            self.assertIs(logic.app.railOverlay,c)
            normal.toggle(True);self.assertTrue(c.closed);self.assertFalse(image.single_action.enabled)
            image.toggle(True);owned=image.overlay
            normal.source_closed()
        self.assertTrue(owned.closed);self.assertIsNone(logic.app.railOverlay)
        self.assertEqual(logic.getReader().trailing,17)

    def test_delayed_accepted_pair_discloses_input_reference_and_wall_age(self):
        from rsview_centerline.clearance.tests.test_recorded_playback import RecordedNativeTests
        overlay=RecordedNativeTests().overlay();overlay.last_input=60
        overlay.host.current={'sequence':60,'device_time_s':16.}
        packet=dict(sequence=20,measurement_basis='image_only',current_source=False,result_age_s=9.,
            relative_pose_diagnostics={},fusion=dict(state='window_ready',scan_count=20,
                reference_sequence=20,reference_time_s=12.,age_s=0.))
        status=overlay.packet_status(packet)
        self.assertIn('DELAYED',status)
        self.assertIn('input 60',status)
        self.assertIn('ref 20',status)
        self.assertIn('lag 4.00s',status)
        self.assertIn('result age 9.00s',status)

    def test_disabling_image_restores_legacy_filename_overlay(self):
        from rsview_centerline import clearance_live,fusion_native
        from rsview_centerline.clearance.tests.test_recorded_playback import RecordedMenuTests
        from rsview_centerline.clearance.tests.test_live_clearance import Action,Overlay
        logic=RecordedMenuTests().logic('22222.pcap')
        normal=clearance_live.LiveClearanceController(logic,Action())
        logic.app.clearanceController=normal
        image=fusion_native.ImageFusionController(logic,Action(),Action())
        image.overlay=logic.app.railOverlay=Overlay();legacy=Overlay()
        def restore(logic):logic.app.railOverlay=legacy;return legacy
        with patch.object(clearance_live,'restore_pcap_rail',restore):image.toggle(False)
        self.assertIs(logic.app.railOverlay,legacy)

    def test_clean_switch_is_reversible_and_keeps_single_fused_pair_and_input(self):
        from rsview_centerline.clearance.tests.test_recorded_playback import RecordedNativeTests
        overlay=RecordedNativeTests().overlay()
        self.assertTrue(hasattr(overlay,'set_image_clean_view'),'display-only clean switch missing')
        packet=dict(sequence=20,measurement_basis='image_only',measurements=[],fusion={'reference_sequence':20},
            _image_pairs=dict(single={'object':'single'},fused={'object':'fused'},
                clean_single={'object':'clean_single'},clean_fused={'object':'clean_fused'}))
        overlay.last_result=packet
        def render(value):overlay.last_result=value
        with patch.object(overlay,'display_packet',render):
            overlay.set_image_single_view(False)
            self.assertEqual(packet['clouds'],{'object':'fused'})
            self.assertTrue(overlay.set_image_clean_view(True))
            self.assertEqual(packet['clouds'],{'object':'clean_fused'})
            overlay.set_image_single_view(True)
            self.assertEqual(packet['clouds'],{'object':'clean_single'})
            overlay.set_image_clean_view(False)
            self.assertEqual(packet['clouds'],{'object':'single'})
        self.assertEqual(overlay.host.requests,[])
        self.assertEqual(packet['fusion']['reference_sequence'],20)

    def test_clean_menu_resets_after_source_close_without_changing_tf_restore(self):
        from rsview_centerline import fusion_native
        from rsview_centerline.clearance.tests.test_recorded_playback import RecordedMenuTests
        from rsview_centerline.clearance.tests.test_live_clearance import Action,Overlay
        logic=RecordedMenuTests().logic();clean=Action()
        try:controller=fusion_native.ImageFusionController(logic,Action(),Action(),clean)
        except TypeError:self.fail('native image controller has no optional clean action')
        def enable(native_logic):
            native_logic.app.railOverlay=Overlay(native_logic.getReader())
            return native_logic.app.railOverlay
        with patch.object(fusion_native,'enable_image',enable):controller.toggle(True)
        self.assertTrue(clean.enabled)
        clean.checked=True;controller.source_closed()
        self.assertFalse(clean.enabled);self.assertFalse(clean.checked)
        self.assertEqual(logic.getReader().trailing,17)


if __name__=='__main__':unittest.main()
