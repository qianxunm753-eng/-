"""Rolling 20-scan detail fitting preserves baseline and every real return."""
import unittest
import numpy as np
from ..engine import ImageFusionEngine
from .fixtures_p3 import moving_requests,engine_fingerprint
from .test_parking_detail import unequal_scene


class MotionDetailTests(unittest.TestCase):
    def test_motion_refinement_resolves_skewed_point_time_support(self):
        from ..registration import transform
        from .test_core import scene
        world=scene();reference=1.1;velocity=np.array([1.1,0.,0.])
        times=np.random.default_rng(307).uniform(1.,1.015,len(world))
        observed=world-(times-1.)[:,None]*velocity
        # Exercise exactly the policy constructed by the replay engine.
        mapper=ImageFusionEngine({'image_motion_detail':True}).mapper
        mapper.update(world,np.ones(len(world)),None,1.,None)
        result=mapper.update(observed,times,None,reference,None)
        self.assertTrue(result.usable,result.diagnostics)
        self.assertTrue(result.diagnostics['deskew_refinement_converged'],result.diagnostics)
        self.assertLess(result.diagnostics['deskew_remaining_change_m'],.0005)
        # Early-only returns weakly support extrapolation to the late reference;
        # verify observed surfaces tightly, not falsely promise perfect pose.
        self.assertAlmostEqual(result.pose[0,3],.11,delta=.01)
        self.assertLess(np.percentile(np.linalg.norm(transform(result.points,result.pose)-world,axis=1),95),.002)
        self.assertLessEqual(result.diagnostics['translation_refinements'],60)

    def test_enabling_detail_spends_more_map_samples_on_real_small_structure(self):
        points,split=unequal_scene();n=len(points)
        request=dict(sequence=0,device_time_s=.05,session_id='detail',clock_id='c',
            xyz=points,point_times=np.full(n,.05),scan_span_s=(0.,.1))
        baseline=ImageFusionEngine();detail=ImageFusionEngine({'image_motion_detail':True})
        before=request['xyz'].tobytes()
        a=baseline.process(request);b=detail.process(request)
        # The geometry differs by fitting selection, not fabricated points or
        # a smaller displayed object. Both first-frame anchors are identity.
        coarse=baseline.mapper.geometry[0];fine=detail.mapper.geometry[0]
        self.assertGreater(np.count_nonzero(fine[:,2]>.3),np.count_nonzero(coarse[:,2]>.3),
            'rolling map did not retain more observed small-feature samples')
        self.assertGreaterEqual(np.count_nonzero(fine[:,2]==0.),3000)
        self.assertLessEqual(len(fine),14000)
        self.assertEqual(a['_display'],b['_display'])
        self.assertEqual(b['fusion']['raw_window_points'],a['fusion']['raw_window_points'])
        self.assertEqual(b['retained_points'],a['retained_points'])
        self.assertEqual(request['xyz'].tobytes(),before)

    def test_disabled_flag_keeps_mature_baseline_bytes_and_state(self):
        baseline=ImageFusionEngine();off=ImageFusionEngine({'image_motion_detail':False})
        for request in moving_requests(20):
            a=baseline.process(request);b=off.process(request)
            self.assertEqual(a['_display'],b['_display'])
            self.assertEqual(a['_single_display'],b['_single_display'])
            self.assertEqual(a['relative_pose_diagnostics'],b['relative_pose_diagnostics'])
        self.assertEqual(engine_fingerprint(baseline),engine_fingerprint(off))
        self.assertEqual(a['fusion']['scan_count'],20)

    def test_detail_keeps_twenty_actual_scans_and_compatible_snapshot_controls(self):
        from ..state import RefinementBudget
        engine=ImageFusionEngine({'image_motion_detail':True,'image_snapshot_support':True})
        for request in moving_requests(20):packet=engine.process(request)
        self.assertTrue(packet['fusion'].get('motion_detail_enabled',False),'new fitting not identified in rolling image output')
        self.assertEqual(packet['fusion']['source_frames'],list(range(20)))
        self.assertEqual(packet['fusion']['display_radius_m'],10.)
        self.assertEqual(packet['measurements'],[])
        self.assertFalse(packet['absolute_accuracy_verified'])
        freeze=dict(command='freeze',request_id='detail',source_key=engine.identity,snapshot_key=None,budget_s=60.)
        result=engine.process_image_control(freeze,RefinementBudget())
        self.assertEqual(result['state'],'frozen')
        self.assertEqual(result['pair']['fused']['data'],packet['_display']['object']['data'])
        engine.reset()
        self.assertTrue(engine.mapper.detail_sampling,'reset silently returned to old fitting')

    def test_motion_detail_is_baseline_replay_only_and_requires_boolean(self):
        for mode in ('quality','parking','window','trajectory'):
            with self.assertRaises(ValueError):ImageFusionEngine({'image_contour_mode':mode,'image_motion_detail':True})
        for value in ('yes',1,None):
            with self.assertRaises(ValueError):ImageFusionEngine({'image_motion_detail':value})
        with self.assertRaises(ValueError):ImageFusionEngine({'image_motion_detail':True},source_mode='live')


if __name__=='__main__':unittest.main()
