"""Controlled independent scans: not physical parking or accuracy truth."""
import numpy as np
from .fixtures_contour import make_record
from .test_engine import request


def stable_evidence(sequence,source_key=('controlled','device',0)):
    from ..parking_state import StabilityEvidence
    return StabilityEvidence(sequence,1.+sequence*.1,source_key,.1,0.,0.,True,300,1.)


def static_independent_sample(sequence):
    a=np.linspace(-.36,.36,40)
    scene=np.array([[.7,x,y+1.] for x in a for y in a]+[[x,.8,y+1.] for x in a for y in a]+
        [[x,y,1.5] for x in a for y in a])
    rod=np.array([[.5+.01*np.cos(t),-.55+.01*np.sin(t),z]
        for z in np.linspace(.6,1.4,40) for t in np.linspace(0.,2*np.pi,16,endpoint=False)])
    points=np.vstack((scene,rod));rng=np.random.default_rng(9100+sequence)
    return points+rng.normal(0.,.0003,points.shape)


def parking_scans(count,bad_sequence=None,pose_shift_m=.03):
    from ..state import ScanRecord
    from ..parking_state import CapturedScan
    result=[]
    for sequence in range(count):
        original=make_record(sequence);points=static_independent_sample(sequence);pose=np.eye(4)
        if sequence==bad_sequence:pose[0,3]=pose_shift_m
        record=ScanRecord(original.source_key,sequence,original.reference_s,original.span_s,points,
            np.full(len(points),original.reference_s),np.arange(len(points)),None,points,pose)
        result.append(CapturedScan(record,'p',0,dict(observable=True,usable=True,
            correspondence_count=300,coverage=1.)))
    return tuple(result)


def parking_request(sequence,points=None,request_id='p',remaining_s=60.):
    return dict(request(sequence,static_independent_sample(sequence) if points is None else points),
        capture_request_id=request_id,capture_remaining_s=remaining_s)
