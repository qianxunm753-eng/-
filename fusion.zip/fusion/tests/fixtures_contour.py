"""Controlled geometry only; never a claimed physical parking capture."""
import pickle
import numpy as np
from ..state import ScanRecord
from .test_core import scene


def make_record(sequence=0,reference_s=None):
    reference_s=1.+sequence*.1 if reference_s is None else reference_s
    points=scene()
    return ScanRecord(('controlled','device',0),sequence,reference_s,(reference_s,reference_s),
        points,np.full(len(points),reference_s),np.arange(len(points)),None,points,np.eye(4),None)


def snapshot_bytes(mapper):
    geometry=None if mapper.geometry is None else (mapper.geometry[0],mapper.geometry[2],mapper.geometry[3])
    return pickle.dumps((list(mapper.keys),geometry,mapper.pose,mapper.relative,mapper.previous_dt,
        mapper.last_good_time,mapper.key_time,mapper.key_pose,list(mapper.key_sources)),protocol=4)


def make_window(count,pose_error_m=0.,seed=17):
    rng=np.random.default_rng(seed);records=[]
    for sequence in range(count):
        points=scene()+rng.normal(0.,.0003,(1200,3))
        r=make_record(sequence);pose=np.eye(4)
        if sequence<count-1:pose[:3,3]=rng.normal(0.,pose_error_m,3)
        records.append(ScanRecord(r.source_key,sequence,r.reference_s,r.span_s,points,
            r.point_times,r.original_indices,None,points,pose,None))
    return tuple(records)
