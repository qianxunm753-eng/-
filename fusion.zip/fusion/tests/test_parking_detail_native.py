import unittest
from unittest.mock import patch
from ... import fusion_native
from ...clearance.tests.test_live_clearance import Action
from . import test_parking_native as support


class ParkingDetailNativeTests(unittest.TestCase):
    def controller(self):
        c,logic,selected=support.ParkingNativeTests().controller()
        c.detail_action=Action()
        return c,logic,selected

    def enabled(self,seen):
        def enable(logic,contour_mode='baseline',parking_detail=False):
            seen.append((contour_mode,parking_detail))
            logic.app.railOverlay=support.ParkingStyledOverlay(logic.getReader());return logic.app.railOverlay
        return patch.object(fusion_native,'enable_image',enable)

    def test_detail_default_off_and_only_available_inside_parking_replay(self):
        c,logic,selected=self.controller();c.source_ready()
        self.assertFalse(c.detail_action.enabled);self.assertFalse(c.detail_action.checked)
        seen=[]
        with self.enabled(seen):
            c.set_parking_capture(True);self.assertTrue(c.detail_action.enabled)
            c.set_parking_detail(True);self.assertEqual(seen[-1],('parking',True))
            logic.getSensor=lambda:object();c.source_ready()
            self.assertFalse(c.detail_action.enabled)

    def test_switch_rebuilds_worker_preserves_ab_settings_and_capture_inherits_flag(self):
        c,logic,selected=self.controller();seen=[]
        with self.enabled(seen):
            c.set_parking_capture(True);old=c.overlay
            c.single_view(True);c.clean_view(True)
            c.overlay.set_image_display_settings(True,1.25,(-1.,1.,-2.,2.,-3.,3.))
            c.begin_parking_capture();old_driver=c.parking_driver
            c.set_parking_detail(True)
            self.assertTrue(old.closed);self.assertFalse(old_driver.active)
            self.assertIsNotNone(c.parking_driver);self.assertTrue(c.parking_driver.active)
            self.assertNotEqual(old_driver.request_id,c.parking_driver.request_id)
            self.assertTrue(c.detail_action.checked)
            self.assertEqual(c.overlay.settings['point_size'],1.25)
            self.assertTrue(c.overlay.image_single_view);self.assertTrue(c.overlay.image_clean_view)
            c.begin_parking_capture();self.assertEqual(seen[-1],('parking',True))
            c.set_parking_detail(False);self.assertEqual(seen[-1],('parking',False))
            self.assertIsNotNone(c.parking_driver);self.assertTrue(c.parking_driver.active)
        c.source_closed();self.assertFalse(c.parking_detail)
        self.assertFalse(c.detail_action.enabled);self.assertFalse(c.detail_action.checked)

    def test_detail_config_cannot_enable_ordinary_mode(self):
        c,logic,selected=self.controller()
        with patch.object(fusion_native,'enable_recorded',return_value=object()) as enabled:
            fusion_native.enable_image(logic,contour_mode='parking',parking_detail=True)
            self.assertTrue(enabled.call_args[0][1]['image_parking_detail'])
            with self.assertRaises(ValueError):fusion_native.enable_image(logic,parking_detail=True)


if __name__=='__main__':unittest.main()
