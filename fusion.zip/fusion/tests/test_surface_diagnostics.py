"""Real-return surface views must not deform or replace the compensated baseline."""
import importlib
import unittest
import numpy as np
from ..engine import ImageFusionEngine
from ..p3_snapshot import SnapshotKey, CompensatedScan, CompensatedWindowSnapshot
from ..state import RefinementBudget


def small_window(count=20):
    points=np.array([[1.,0.,1.],[1.,.003,1.],[1.,.006,1.],[1.,.015,1.]])
    scans=tuple(CompensatedScan(i,float(i), (float(i),float(i)),points.copy(),
        np.full(4,float(i)),np.arange(4,dtype=np.int64),np.eye(4)) for i in range(count))
    engine=ImageFusionEngine()
    pair=dict(engine.paired_views(np.concatenate([r.corrected_xyz for r in scans]),points),
        sequence=count-1,time=float(count-1),source_frames=list(range(count)),raw_points=4*count,bytes=4*count*40)
    # Actual input returns, NOT a relabeling of corrected_xyz.
    pair['_surface_raw_single']=dict(xyz=points.astype('<f4'),indices=np.arange(4,dtype=np.int64))
    origins=dict(fused=np.array([[0,0],[0,3]]),single=np.array([[count-1,0],[count-1,3]]))
    key=SnapshotKey('fixture:surface','clock:fixture',0,1,count,count-1,float(count-1),tuple(range(count)))
    return CompensatedWindowSnapshot(key,scans,pair,origins)


class SurfaceDiagnosticTests(unittest.TestCase):
    def setUp(self):
        try:self.module=importlib.import_module('rsview_centerline.fusion.surface_diagnostics')
        except ImportError:self.fail('same-window surface diagnostics not implemented')
        self.roi=(.9,1.1,-.01,.03,.9,1.1)

    def run_view(self,snapshot=None,**kwargs):
        return self.module.diagnose_window(snapshot or small_window(),self.roi,RefinementBudget(),**kwargs)

    def test_finer_local_sampling_preserves_observed_three_mm_details_without_new_points(self):
        result=self.run_view();views=result['pair']['surface_views']
        baseline=np.frombuffer(views['baseline']['data'],dtype='<f4').reshape(-1,3)
        detail=np.frombuffer(views['local']['data'],dtype='<f4').reshape(-1,3)
        self.assertEqual(len(baseline),2);self.assertEqual(len(detail),4)
        self.assertEqual(set(np.round(detail[:,1],6)),{np.float32(0.),np.float32(.003),np.float32(.006),np.float32(.015)})
        self.assertEqual(result['report']['coordinate_edits'],0)
        self.assertFalse(result['report']['measurement_allowed'])

    def test_frame_view_keeps_actual_twenty_scan_owners_not_only_first_voxel_owner(self):
        entry=self.run_view()['pair']['surface_views']['frames']
        ids=np.frombuffer(entry['frame_data'],dtype='<f4')
        self.assertEqual(len(ids),entry['count']);self.assertEqual(set(ids),set(range(20)))
        self.assertEqual(entry['count'],80)

    def test_raw_single_is_actual_input_and_is_not_reconstructed_from_corrected_points(self):
        snapshot=small_window();raw=snapshot.baseline_pair['_surface_raw_single']['xyz']
        raw[:,2]=np.float32(1.05)
        result=self.run_view(snapshot)['pair']['surface_views']['raw_single']
        actual=np.frombuffer(result['data'],dtype='<f4').reshape(-1,3)
        self.assertTrue(np.all(actual[:,2]==np.float32(1.05)))
        snapshot.baseline_pair.pop('_surface_raw_single')
        with self.assertRaisesRegex(ValueError,'raw single'):self.run_view(snapshot)

    def test_baseline_bytes_and_corrected_scans_remain_unchanged(self):
        snapshot=small_window();base=snapshot.baseline_pair['fused']['data']
        saved=[r.corrected_xyz.copy() for r in snapshot.scans]
        result=self.run_view(snapshot)
        self.assertEqual(result['pair']['fused']['data'],base)
        self.assertEqual(snapshot.baseline_pair['fused']['data'],base)
        for record,points in zip(snapshot.scans,saved):np.testing.assert_array_equal(record.corrected_xyz,points)
        self.assertEqual(result['report']['source_frames'],list(range(20)))

    def test_incomplete_window_does_not_fabricate_twenty_scans(self):
        with self.assertRaisesRegex(ValueError,'20'):self.run_view(small_window(19))

    def test_budget_and_invalid_roi_fail_without_changing_baseline(self):
        snapshot=small_window();base=snapshot.baseline_pair['fused']['data']
        with self.assertRaises(ValueError):self.module.diagnose_window(snapshot,self.roi,RefinementBudget(temporary_limit_bytes=1))
        for roi in ((1,0,-1,1,-1,1),(0,1,-1,1,float('nan'),1),(-11,1,-1,1,-1,1)):
            with self.assertRaises(ValueError):self.module.diagnose_window(snapshot,roi,RefinementBudget())
        self.assertEqual(snapshot.baseline_pair['fused']['data'],base)

    def test_visible_point_cap_is_enforced_with_matching_owner_lengths(self):
        result=self.run_view(point_limit=25)
        for entry in result['pair']['surface_views'].values():
            self.assertLessEqual(entry['count'],25)
            self.assertEqual(len(entry['data']),entry['count']*12)
            if 'frame_data' in entry:self.assertEqual(len(entry['frame_data']),entry['count']*4)


class SurfaceControlTests(unittest.TestCase):
    def test_surface_control_uses_frozen_key_and_keeps_baseline_geometry(self):
        from .fixtures_p3 import moving_requests,engine_fingerprint
        engine=ImageFusionEngine({'image_snapshot_support':True})
        for request in moving_requests(20):engine.process(request)
        before=engine_fingerprint(engine)
        freeze=dict(command='freeze',request_id='surface',source_key=engine.identity,budget_s=60.,snapshot_key=None)
        frozen=engine.process_image_control(freeze,RefinementBudget())
        control=dict(freeze,command='surface',snapshot_key=frozen['snapshot_key'],options={'roi':(-5,5,-5,5,-5,5)})
        try:result=engine.process_image_control(control,RefinementBudget())
        except ValueError:self.fail('surface control is not connected to the frozen baseline')
        self.assertEqual(result['state'],'accepted');self.assertEqual(result['snapshot_key'],frozen['snapshot_key'])
        self.assertEqual(result['pair']['fused']['data'],frozen['pair']['fused']['data'])
        self.assertIn('surface_views',result['pair']);self.assertEqual(engine_fingerprint(engine),before)
        self.assertEqual(result['report']['coordinate_edits'],0)

    def test_actual_raw_sidecar_is_copied_from_input_after_baseline_acceptance(self):
        from .fixtures_p3 import moving_requests
        engine=ImageFusionEngine({'image_snapshot_support':True});request=moving_requests(1)[0]
        engine.process(request)
        self.assertTrue('_surface_raw_single' in engine.last_pair,'actual input sidecar missing')
        sidecar=engine.last_pair['_surface_raw_single']
        np.testing.assert_array_equal(sidecar['xyz'],np.asarray(request['xyz'])[sidecar['indices']].astype('<f4'))
        self.assertFalse(sidecar['xyz'].flags.writeable)

    def test_surface_options_reject_unknown_fields_and_nonfinite_roi(self):
        from rsview_centerline.image_control import validate_control
        key=small_window().key.primitive()
        for options in ({'roi':(0,1,0,1,0,1),'invent':True},{'roi':(0,1,0,1,0,float('nan'))},None):
            try:
                with self.assertRaises(ValueError):validate_control('surface','s',('fixture:surface','clock:fixture',0),key,60.,options)
            except TypeError:self.fail('surface option validation absent')


if __name__=='__main__':unittest.main()
