import importlib
import unittest
from dataclasses import replace
import numpy as np
from ..state import RefinementBudget
from .fixtures_parking import parking_scans


class ParkingQualityTests(unittest.TestCase):
    def module(self):
        try:return importlib.import_module('rsview_centerline.fusion.parking_quality')
        except ImportError:self.fail('independent parking local checks missing')

    def test_bad_scan_does_not_cut_preceding_good_scans(self):
        m=self.module();scans=parking_scans(4,bad_sequence=1)
        before=[s.record.raw_xyz.tobytes() for s in scans]
        checks=m.check_parking_window(scans,RefinementBudget())
        self.assertEqual(checks[1].status,'rejected',checks)
        self.assertEqual([s.record.sequence for s in m.select_parking_contributors(scans,checks)],[0,2,3])
        self.assertTrue(all(i not in checks[i].reference_ids for i in range(4)))
        self.assertEqual(before,[s.record.raw_xyz.tobytes() for s in scans])

    def test_bootstrap_unknown_can_upgrade_with_independent_sources(self):
        m=self.module();scans=parking_scans(3)
        self.assertEqual(m.check_parking_window(scans[:2],RefinementBudget())[0].status,'unknown')
        checks=m.check_parking_window(scans,RefinementBudget())
        self.assertEqual([c.status for c in checks.values()],['passed']*3)

    def test_mixed_generation_source_and_duplicate_self_are_refused(self):
        m=self.module();scans=parking_scans(3)
        variants=[replace(scans[1],capture_generation=1),
            replace(scans[1],record=replace(scans[1].record,source_key=('other','device',0)))]
        for changed in variants:
            with self.assertRaises(ValueError):m.check_parking_window((scans[0],changed,scans[2]),RefinementBudget())
        with self.assertRaises(ValueError):m.check_parking_window((scans[0],scans[0],scans[2]),RefinementBudget())

    def test_reference_target_has_no_check_or_heldout_geometry(self):
        m=self.module();scans=parking_scans(4)
        changed=[]
        for s in scans:
            points=s.record.raw_xyz.copy();points[s.record.original_indices%5==0]+=[4.,0.,0.]
            changed.append(replace(s,record=replace(s.record,raw_xyz=points,corrected_xyz=points)))
        a=m.build_parking_context(scans,0,RefinementBudget())
        b=m.build_parking_context(tuple(changed),0,RefinementBudget())
        np.testing.assert_array_equal(a.reference_target,b.reference_target)
        self.assertNotIn(0,a.reference_ids)
        self.assertLessEqual(len(a.reference_target),14000)

    def test_five_references_and_budget_limit(self):
        m=self.module();scans=parking_scans(8)
        context=m.build_parking_context(scans,3,RefinementBudget())
        self.assertLessEqual(len(context.reference_ids),5)
        self.assertIsNone(m.build_parking_context(scans,3,RefinementBudget(deadline_s=0.)))

    def test_unresolved_equal_reference_consensus_is_unknown(self):
        m=self.module();scans=list(parking_scans(5))
        for i in (3,4):
            pose=scans[i].record.pose.copy();pose[0,3]=.03
            scans[i]=replace(scans[i],record=replace(scans[i].record,pose=pose))
        checks=m.check_parking_window(tuple(scans),RefinementBudget())
        self.assertEqual(checks[0].status,'unknown')

    def test_sparse_or_novel_surface_is_unknown_not_deleted(self):
        m=self.module();scans=parking_scans(3);s=scans[0];r=s.record
        sparse=replace(r,raw_xyz=r.raw_xyz[:20],corrected_xyz=r.corrected_xyz[:20],
            point_times=r.point_times[:20],original_indices=r.original_indices[:20])
        scans=(replace(s,record=sparse),*scans[1:])
        checks=m.check_parking_window(scans,RefinementBudget())
        self.assertEqual(checks[0].status,'unknown')
        self.assertEqual(len(scans[0].record.raw_xyz),20)

    def test_local_regression_cannot_hide_behind_big_plane_improvement(self):
        m=self.module();scans=parking_scans(4);r=scans[0].record
        pose=r.pose.copy();pose[0,3]=.0015;baseline=replace(r,pose=pose)
        context=m.build_parking_context((replace(scans[0],record=baseline),*scans[1:]),0,RefinementBudget())
        points=baseline.corrected_xyz.copy()
        # Perturb a small planar patch normal to its surface. Translating a
        # cylinder along its axis is not observable by a point-to-plane test.
        small=(points[:,0]>.69)&(points[:,0]<.71)&(points[:,1]<-.16)&(points[:,2]<.96)
        points[small,0]+=.01
        candidate=replace(r,corrected_xyz=points)
        report=m.check_micro_candidate(baseline,candidate,context)
        self.assertFalse(report.accepted)
        self.assertIn(report.reason,('local_patch_regression','heldout_p90_regression','heldout_coverage_regression'))

    def test_noise_and_rows_are_fixed_before_candidate(self):
        m=self.module();scans=parking_scans(4);r=scans[0].record
        context=m.build_parking_context(scans,0,RefinementBudget())
        noise=context.noise_budget_m.copy();rows=context.check_rows.copy()
        candidate=replace(r,corrected_xyz=r.corrected_xyz+np.random.default_rng(8).normal(0.,.04,r.raw_xyz.shape))
        self.assertFalse(m.check_micro_candidate(r,candidate,context).accepted)
        np.testing.assert_array_equal(context.noise_budget_m,noise)
        np.testing.assert_array_equal(context.check_rows,rows)
        self.assertFalse(context.noise_budget_m.flags.writeable)
