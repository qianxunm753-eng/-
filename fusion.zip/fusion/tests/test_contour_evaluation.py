import importlib
import unittest
import numpy as np
import json
from pathlib import Path
import tempfile


class ContourEvaluationTests(unittest.TestCase):
    def test_coverage_uses_baseline_fused_cells_not_only_single_scan(self):
        m=self.module();single=self.plane();other=single+[0.,.6,0.]
        reference=np.vstack([single,other]);baseline=reference.copy();candidate=single.copy()
        baseline[:,0]+=.002;candidate[:,0]+=.0005
        try:
            before=m.contour_metrics(reference,baseline,[-1.]*3,[1.]*3,[[1.,0.,0.]],coverage_reference=baseline)
            after=m.contour_metrics(reference,candidate,[-1.]*3,[1.]*3,[[1.,0.,0.]],coverage_reference=baseline)
        except TypeError:self.fail('baseline-fused occupancy reference is not independent of normal reference')
        self.assertEqual(before['coverage'],1.)
        self.assertLessEqual(after['coverage'],.5)
        decision=m.assess_run({'same_source_ids':True,'baseline':[before],'candidate':[after]})
        self.assertEqual(decision['status'],'failed')

    def test_metric_rows_with_different_actual_references_cannot_pass(self):
        m=self.module();base=dict(available=True,normal_p90_m=.02,coverage=1.,reference_sequence=10,reference_time_s=1.)
        candidate=dict(base,normal_p90_m=.005,reference_sequence=9,reference_time_s=.9)
        result=m.assess_run({'same_source_ids':True,'baseline':[base],'candidate':[candidate]})
        self.assertEqual(result['status'],'unavailable')

    def test_missing_candidate_row_is_not_silently_excluded_from_acceptance(self):
        m=self.module();base=dict(available=True,normal_p90_m=.02,coverage=1.)
        good=dict(base,normal_p90_m=.005);bad=dict(available=False)
        result=m.assess_run({'same_source_ids':True,'baseline':[base,base],'candidate':[good,bad]})
        self.assertEqual(result['status'],'unavailable')

    def module(self):
        try:return importlib.import_module('rsview_centerline.fusion.evaluation')
        except ImportError:self.fail('independent contour metrics / acceptance assessment missing')

    def plane(self):
        axis=np.linspace(-.2,.2,12)
        return np.array([[0.,y,z] for y in axis for z in axis])

    def test_shifted_surface_has_normal_error_and_cannot_fake_coverage(self):
        m=self.module();ref=self.plane();candidate=ref.copy();candidate[:,0]=.03
        metrics=m.contour_metrics(ref,candidate,[-.5]*3,[.5]*3,[[1.,0.,0.]])
        self.assertTrue(metrics['available']);self.assertGreaterEqual(metrics['normal_p90_m'],.029)
        self.assertLess(metrics['coverage'],.95)

    def test_deleting_real_returns_cannot_pass_as_a_sharper_surface(self):
        m=self.module();ref=self.plane()
        metrics=m.contour_metrics(ref,ref[::2],[-.5]*3,[.5]*3,[[1.,0.,0.]])
        self.assertLess(metrics['coverage'],.6)
        self.assertLess(metrics['normal_p90_m'],1e-9)

    def test_curved_surface_and_sparse_input_are_unavailable_not_zero_error(self):
        m=self.module();a=np.linspace(-1.,1.,30)
        curve=np.array([[.3*np.cos(t),.3*np.sin(t),z] for z in [.1,.2,.3] for t in a])
        metrics=m.contour_metrics(curve,curve,[-.5]*3,[.5]*3,[[1.,0.,0.]])
        self.assertFalse(metrics['available']);self.assertIsNone(metrics['normal_p90_m'])
        metrics=m.contour_metrics(self.plane()[:5],self.plane()[:5],[-.5]*3,[.5]*3,[[1.,0.,0.]])
        self.assertFalse(metrics['available'])

    def test_evaluation_requires_matching_consumed_ids_and_nonzero_baseline(self):
        m=self.module()
        with self.assertRaises(ValueError):m.assess_run({'same_source_ids':False})
        metric={'available':True,'normal_p90_m':0.,'coverage':1.}
        result=m.assess_run({'same_source_ids':True,'baseline':[metric],'candidate':[metric],'stationary':False})
        self.assertEqual(result['status'],'unavailable')

    def test_motion_acceptance_checks_improvement_and_coverage_separately(self):
        m=self.module();baseline={'available':True,'normal_p90_m':.02,'coverage':1.}
        candidate={'available':True,'normal_p90_m':.014,'coverage':.96}
        data={'same_source_ids':True,'baseline':[baseline]*3,'candidate':[candidate]*3,'stationary':False}
        self.assertEqual(m.assess_run(data)['status'],'passed')
        data['candidate']=[dict(candidate,coverage=.90)]*3
        self.assertEqual(m.assess_run(data)['status'],'failed')

    def test_stationary_guard_is_not_a_motion_or_accuracy_claim(self):
        m=self.module();baseline={'available':True,'normal_p90_m':.005,'coverage':1.}
        candidate={'available':True,'normal_p90_m':.007001,'coverage':1.}
        data={'same_source_ids':True,'baseline':[baseline],'candidate':[candidate],'stationary':True}
        self.assertEqual(m.assess_run(data)['status'],'failed')

    def test_new_environment_filename_is_never_used_as_actual_speed(self):
        m=self.module();self.assertIsNone(m.speed_metadata('new_clean','300rpm_1.pcap')['actual_rpm'])
        self.assertEqual(m.speed_metadata('original_mixed','150rpm_2.pcap')['actual_rpm'],150)

    def test_exact_plane_does_not_need_any_surface_generation(self):
        m=self.module();ref=self.plane();before=ref.copy()
        result=m.contour_metrics(ref,ref,[-.5]*3,[.5]*3,[[1.,0.,0.]])
        self.assertEqual(result['coverage'],1.);self.assertEqual(result['normal_p90_m'],0.)
        np.testing.assert_array_equal(ref,before)

    def ablation_module(self):
        try:return importlib.import_module('rsview_centerline.analysis.20261012_contour.run_ablation')
        except ImportError:self.fail('bounded real-capture ablation adapter missing')

    def test_missing_original_capture_is_not_silently_substituted(self):
        m=self.ablation_module()
        with tempfile.TemporaryDirectory() as temporary:
            path=Path(temporary)/'manifest.json'
            path.write_text(json.dumps({'input':str(Path(temporary)/'missing.pcap'),'frames':[]}),encoding='utf8')
            with self.assertRaises(FileNotFoundError):m.load_capture(path)

    def test_existing_output_and_array_path_escape_are_refused(self):
        m=self.ablation_module()
        with tempfile.TemporaryDirectory() as temporary:
            folder=Path(temporary)
            with self.assertRaises(FileExistsError):m.prepare_output(folder)
            with self.assertRaises(ValueError):m.read_array(folder,{'file':'../escape.bin','dtype':'float','tuples':2,'components':3})

    def test_moved_source_is_explicit_and_preserves_export_identity(self):
        m=self.ablation_module()
        with tempfile.TemporaryDirectory() as temporary:
            folder=Path(temporary);source=folder/'121.pcap';source.write_bytes(b'owned test capture')
            original=folder/'old'/'121.pcap';manifest=folder/'manifest.json'
            manifest.write_text(json.dumps({'input':str(original),'frames':[{'frame':1,
                'xyz':{'file':'x.bin'},'attributes':{'timestamp':{'file':'t.bin'}}}]}),encoding='utf8')
            try:data,rows,resolved=m.load_capture(manifest,source_override=source)
            except TypeError:self.fail('explicit moved-source resolution missing')
            self.assertEqual(data['input'],str(original));self.assertEqual(resolved,source)
            wrong=folder/'different.pcap';wrong.write_bytes(b'owned different test capture')
            with self.assertRaises(ValueError):m.load_capture(manifest,source_override=wrong)
