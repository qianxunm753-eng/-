import importlib
import unittest
import subprocess
import sys
import numpy as np
from unittest.mock import patch
from .test_core import scene


def request(seq=0,points=None,session='image:test'):
    points=scene() if points is None else points
    stamp=1.+seq*.1
    return dict(sequence=seq,device_time_s=stamp,session_id=session,clock_id='lidar:test',
        xyz=points,point_times=np.full(len(points),stamp),rings=None,scan_span_s=(stamp,stamp))


class EngineTests(unittest.TestCase):
    def setUp(self):
        try:self.module=importlib.import_module('rsview_centerline.fusion.engine')
        except ImportError:self.fail('image-only engine absent')

    def test_twenty_moving_scans_fuse_without_stop_or_measurement_gate(self):
        engine=self.module.ImageFusionEngine()
        with patch('rsview_centerline.clearance.track.observe_track',side_effect=AssertionError('measurement called')):
            for seq in range(20):packet=engine.process(request(seq,scene()-[seq*.01,0.,0.]))
        self.assertEqual(packet['fusion']['scan_count'],20,packet['relative_pose_diagnostics'])
        self.assertEqual(packet['fusion']['source_frames'],list(range(20)))
        self.assertEqual(packet['measurements'],[])
        self.assertEqual(packet['centerline'],[])
        self.assertIn('_single_display',packet)
        self.assertFalse(packet['current_scan_measurement'])

    def test_warmup_displays_actual_fusion_before_twenty_and_rolling_window_is_bounded(self):
        engine=self.module.ImageFusionEngine()
        for seq in range(25):
            packet=engine.process(request(seq))
            if seq==4:self.assertEqual(packet['fusion']['scan_count'],5)
        self.assertEqual(packet['fusion']['source_frames'],list(range(5,25)))
        self.assertEqual(packet['fusion']['scan_count'],20)

    def test_duplicate_scan_never_advances_window(self):
        engine=self.module.ImageFusionEngine()
        for unused in range(25):packet=engine.process(request())
        self.assertEqual(packet['fusion']['scan_count'],1)

    def test_failed_scan_keeps_the_last_paired_reference_with_explicit_age(self):
        engine=self.module.ImageFusionEngine()
        engine.process(request(0));engine.process(request(1))
        packet=engine.process(request(2,np.tile([1.,0.,1.],(100,1))))
        self.assertEqual(packet['fusion']['reference_sequence'],1)
        self.assertTrue(packet['fusion']['held'])
        self.assertAlmostEqual(packet['fusion']['age_s'],.1)

    def test_source_reset_does_not_reuse_old_map_or_display(self):
        engine=self.module.ImageFusionEngine()
        engine.process(request(0));engine.process(request(1))
        packet=engine.process(request(2,session='other'))
        self.assertEqual(packet['fusion']['source_frames'],[2])

    def test_fit_range_is_twenty_meters_but_display_and_original_indices_are_separate(self):
        engine=self.module.ImageFusionEngine()
        points=np.vstack([[[30.,0.,0.]],scene(),[[15.,0.,0.]]])
        packet=engine.process(request(0,points))
        self.assertIn(len(points)-1,engine.window[-1]['indices'])
        self.assertNotIn(0,engine.window[-1]['indices'])
        self.assertEqual(packet['fusion']['display_radius_m'],10.)
        for entry in packet['_display'].values():
            xyz=np.frombuffer(entry['data'],dtype='<f4').reshape(-1,3)
            self.assertTrue(np.all(np.linalg.norm(xyz,axis=1)<=10.+1e-6))

    def test_live_and_recorded_pose_substitution_are_refused(self):
        with self.assertRaises(ValueError):self.module.ImageFusionEngine(source_mode='live')
        with self.assertRaises(ValueError):self.module.ImageFusionEngine(experimental_pose_path='untrusted')

    def test_image_core_can_import_without_the_deferred_measurement_modules(self):
        script='''
import sys
class BlockMeasurement:
    def find_spec(self,fullname,path=None,target=None):
        if fullname in ('rsview_centerline.clearance.online','rsview_centerline.clearance.replay','rsview_centerline.clearance.measure'):
            raise ImportError('measurement unavailable by design')
sys.meta_path.insert(0,BlockMeasurement())
from rsview_centerline.fusion.engine import ImageFusionEngine
ImageFusionEngine()
'''
        result=subprocess.run([sys.executable,'-B','-c',script],capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)

    def test_static_noisy_independent_samples_do_not_create_drift_or_fake_frames(self):
        engine=self.module.ImageFusionEngine();rng=np.random.default_rng(37)
        for seq in range(20):packet=engine.process(request(seq,scene()+rng.normal(0,.001,(1200,3))))
        self.assertEqual(packet['fusion']['scan_count'],20)
        self.assertLess(np.linalg.norm(engine.mapper.pose[:3,3]),.003)
        self.assertEqual(packet['fusion']['source_frames'],list(range(20)))

    def test_raw_window_budget_refusal_does_not_claim_compensation(self):
        engine=self.module.ImageFusionEngine({'image_byte_budget':1})
        packet=engine.process(request())
        self.assertEqual(packet['fusion']['scan_count'],0)
        self.assertEqual(packet['relative_pose_diagnostics']['reason'],'image_capacity_reached')

    def test_optional_clean_preview_keeps_raw_window_and_the_original_pair(self):
        points=np.vstack([scene(),[[6.,6.,0.]]])
        engine=self.module.ImageFusionEngine({'image_display_filter_preview':True})
        packet=engine.process(request(0,points))
        self.assertTrue('_clean_display' in packet,'optional clean paired preview missing')
        raw=np.frombuffer(packet['_display']['object']['data'],dtype='<f4').reshape(-1,3)
        clean=np.frombuffer(packet['_clean_display']['object']['data'],dtype='<f4').reshape(-1,3)
        self.assertEqual(len(raw)-len(clean),1)
        self.assertTrue(any(np.array_equal(p,[6.,6.,0.]) for p in raw))
        self.assertTrue(all(any(np.array_equal(p,q) for q in raw) for p in clean))
        np.testing.assert_array_equal(engine.window[-1]['xyz'],points)
        self.assertEqual(packet['fusion']['raw_window_points'],len(points))
        self.assertEqual(packet['measurements'],[])
        duplicate=engine.process(request(0,points))
        self.assertEqual(duplicate['_clean_display'],packet['_clean_display'])
        self.assertEqual(duplicate['fusion']['source_frames'],[0])

    def test_default_engine_does_not_spend_work_on_an_unrequested_clean_preview(self):
        packet=self.module.ImageFusionEngine().process(request())
        self.assertNotIn('_clean_display',packet)

    def test_rejected_scan_keeps_clean_and_raw_views_on_the_same_reference(self):
        engine=self.module.ImageFusionEngine({'image_display_filter_preview':True})
        first=engine.process(request(0))
        packet=engine.process(request(1,np.tile([1.,0.,1.],(100,1))))
        self.assertTrue(packet['fusion']['held'])
        self.assertTrue('_clean_display' in packet)
        for key in ('_clean_display','_clean_single_display','_display','_single_display'):
            self.assertEqual(packet[key],first[key])

    def test_sixty_low_speed_windows_with_small_rotation_keep_known_geometry(self):
        from scipy.spatial.transform import Rotation
        engine=self.module.ImageFusionEngine({'image_display_filter_preview':True})
        rng=np.random.default_rng(719);points=scene();errors=[]
        for seq in range(60):
            angle=.015*np.sin(seq*.2)
            rotation=Rotation.from_rotvec([0.,0.,angle]).as_matrix()
            translation=np.array([seq*.005,.002*np.sin(seq*.4),0.])
            observed=(points-translation)@rotation+rng.normal(0,.0005,points.shape)
            packet=engine.process(request(seq,observed))
            self.assertFalse(packet['fusion']['held'],packet['relative_pose_diagnostics'])
            if seq>=19:
                self.assertEqual(packet['fusion']['source_frames'],list(range(seq-19,seq+1)))
            errors.append(np.linalg.norm(engine.mapper.pose[:3,3]-translation))
            world=self.module.transform(engine.window[-1]['xyz'],engine.window[-1]['pose'])
            self.assertLess(np.percentile(np.linalg.norm(world-points,axis=1),95),.005)
        self.assertLess(max(errors),.005)
        self.assertEqual(packet['fusion']['scan_count'],20)
        self.assertEqual(packet['measurements'],[])

    def test_bad_scan_is_not_counted_then_the_continuous_window_recovers(self):
        engine=self.module.ImageFusionEngine({'image_display_filter_preview':True})
        for seq in range(35):
            points=np.tile([8.,8.,0.],(100,1)) if seq==22 else scene()-[seq*.005,0.,0.]
            packet=engine.process(request(seq,points))
            if seq==22:
                self.assertTrue(packet['fusion']['held'])
                self.assertEqual(packet['fusion']['reference_sequence'],21)
            if seq==23:self.assertFalse(packet['fusion']['held'],packet['relative_pose_diagnostics'])
        self.assertEqual(packet['fusion']['scan_count'],20)
        self.assertNotIn(22,packet['fusion']['source_frames'])
        self.assertEqual(packet['fusion']['reference_sequence'],34)


if __name__=='__main__':unittest.main()
