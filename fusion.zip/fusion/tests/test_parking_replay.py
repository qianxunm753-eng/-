import importlib
import unittest
from unittest.mock import patch


class FakeClock:
    def __init__(self,value=10.):self.value=value
    def __call__(self):return self.value
    def advance(self,seconds):self.value+=seconds


def packet_for(frame,token='p',generation=0,state='collecting',remaining=60.):
    return dict(sequence=frame,session_id='s',clock_id='c',epoch=0,status='completed',
        parking=dict(request_id=token,capture_generation=generation,pair_generation=generation,
            state=state,remaining_s=remaining,actual_count=1,trusted_count=0))


class ParkingReplayTests(unittest.TestCase):
    def module(self):
        try:return importlib.import_module('rsview_centerline.parking_replay')
        except ImportError:self.fail('serial parking replay driver missing')

    def driver(self,frames=(4,7,9),origin=10.):
        m=self.module();selected=[];clock=FakeClock(origin)
        return m.ParkingReplayDriver(frames,selected.append,clock),selected,clock

    def test_serial_next_frame_requires_matching_ack(self):
        d,selected,c=self.driver();d.start('p',4,('s','c',0))
        self.assertEqual(selected,[4]);d.tick();self.assertEqual(selected,[4])
        self.assertFalse(d.ack(packet_for(3)));self.assertEqual(selected,[4])
        self.assertTrue(d.ack(packet_for(4)));self.assertEqual(selected,[4,7])
        c.advance(60.);d.tick();self.assertFalse(d.ack(packet_for(7)))
        self.assertEqual(selected,[4,7]);self.assertEqual(d.state,'incomplete')

    def test_eof_never_repeats_or_wraps(self):
        d,selected,c=self.driver();d.start('p',7,('s','c',0));d.ack(packet_for(7));d.ack(packet_for(9))
        self.assertEqual(selected,[7,9]);self.assertEqual(d.tick()['reason'],'eof')
        self.assertFalse(d.ack(packet_for(9)))

    def test_wrong_source_token_epoch_or_old_generation_never_admitted(self):
        d,selected,c=self.driver();d.start('p',4,('s','c',0))
        for changed in [dict(packet_for(4),session_id='other'),dict(packet_for(4),clock_id='other'),
            dict(packet_for(4),epoch=1),packet_for(4,token='old')]:self.assertFalse(d.accepts(changed))
        p=packet_for(4,generation=2);p['parking']['pair_generation']=0
        self.assertTrue(d.ack(p));self.assertEqual(d.generation_floor,2)
        self.assertFalse(d.accepts(packet_for(7,generation=1)))
        p=packet_for(7,generation=2);p['parking']['pair_generation']=0
        self.assertTrue(d.accepts(p))

    def test_native_relative_budget_is_not_worker_clock_origin(self):
        d,selected,c=self.driver(origin=1.e9);d.start('p',4,('s','c',0))
        deadline=d.deadline_s;c.advance(20.)
        self.assertEqual(d.request_metadata()['capture_remaining_s'],40.)
        d.ack(packet_for(4,remaining=60.));self.assertEqual(d.deadline_s,deadline)
        c.advance(40.);self.assertFalse(d.accepts(packet_for(7)))
        self.assertEqual(d.state,'incomplete')

    def test_completed_or_failed_packets_freeze_without_selecting_next(self):
        for state in ('capture_complete','incomplete'):
            d,selected,c=self.driver();d.start('p',4,('s','c',0));d.ack(packet_for(4,state=state))
            self.assertEqual(selected,[4]);self.assertFalse(d.active)
        d,selected,c=self.driver();d.start('p',4,('s','c',0))
        p=packet_for(4);p['status']='failed'
        self.assertTrue(d.ack(p));self.assertFalse(d.active);self.assertEqual(selected,[4])

    def test_seek_cancel_and_late_callbacks_do_not_touch_view(self):
        d,selected,c=self.driver();d.start('p',4,('s','c',0))
        self.assertFalse(d.seeked(4));self.assertTrue(d.seeked(9));self.assertFalse(d.active)
        for unused in range(5):d.tick();d.ack(packet_for(4))
        self.assertEqual(selected,[4]);self.assertIsNone(d.request_metadata()['capture_request_id'])

    def test_available_source_ids_are_validated_not_inferred(self):
        m=self.module()
        for frames in ([4,4],[7,4],[1.5,4],[float('nan')],[]):
            with self.assertRaises(ValueError):m.ParkingReplayDriver(frames,lambda frame:None,FakeClock())
        d,selected,c=self.driver()
        with self.assertRaises(ValueError):d.start('p',5,('s','c',0))
        self.assertEqual(selected,[])

    def test_select_failure_is_explicit_incomplete(self):
        m=self.module()
        def unavailable(frame):raise ValueError('reader closed')
        d=m.ParkingReplayDriver([1,2],unavailable,FakeClock());d.start('p',1,('s','c',0))
        self.assertEqual(d.state,'incomplete');self.assertEqual(d.tick()['reason'],'frame_unavailable')

    def test_no_wall_clock_fallback_if_monotonic_unavailable(self):
        m=self.module()
        with patch.object(m.time,'monotonic',None),patch.object(m.os,'name','posix'):
            with self.assertRaises(RuntimeError):m.capture_clock()

    def test_stripped_python2_windows_uses_native_performance_clock_not_wall_time(self):
        m=self.module();original=__import__('builtins').__import__
        def stripped(name,*args,**kwargs):
            if name=='ctypes':raise ImportError('native _ctypes missing')
            return original(name,*args,**kwargs)
        with patch.object(m.time,'monotonic',None),patch.object(m.os,'name','nt'),\
            patch.object(m.time,'clock',lambda:42.,create=True),\
            patch.object(m.time,'time',side_effect=AssertionError('wall clock used')),\
            patch('builtins.__import__',side_effect=stripped):
            self.assertEqual(m.capture_clock(),42.)
