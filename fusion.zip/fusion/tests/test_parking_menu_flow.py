"""User menu sequence, not a probe that manually supplies missing starts."""
import unittest
from unittest.mock import patch
from ... import fusion_native
from . import test_parking_detail_native as support


class ParkingMenuFlowTests(unittest.TestCase):
    def setup_controller(self):
        fixture=support.ParkingDetailNativeTests()
        c,logic,selected=fixture.controller()
        return fixture,c,logic,selected

    def test_parking_check_does_not_claim_rolling_mode_is_active(self):
        fixture,c,logic,selected=self.setup_controller()
        with fixture.enabled([]):c.set_parking_capture(True)
        self.assertEqual(c.contour_mode,'parking')
        self.assertTrue(c.parking_action.checked)
        self.assertFalse(c.action.checked)

    def test_parking_selection_alone_pauses_and_submits_first_real_frame(self):
        fixture,c,logic,selected=self.setup_controller();logic.app.playing=True
        with fixture.enabled([]):c.set_parking_capture(True)
        self.assertFalse(logic.app.playing)
        self.assertIsNotNone(c.parking_driver)
        self.assertTrue(c.parking_driver.active)
        self.assertEqual(selected,[4.])
        self.assertEqual(c.parking_driver.pending_frame,4)
        self.assertIsNotNone(c.parking_driver.request_metadata()['capture_request_id'])

    def test_detail_menu_switch_restarts_capture_without_manual_start(self):
        fixture,c,logic,selected=self.setup_controller();seen=[]
        with fixture.enabled(seen):
            c.set_parking_capture(True)
            self.assertIsNotNone(c.parking_driver)
            old=c.parking_driver;old_overlay=c.overlay
            count=len(selected);c.set_parking_detail(True)
        self.assertFalse(old.active);self.assertTrue(old_overlay.closed)
        self.assertIsNotNone(c.parking_driver)
        self.assertTrue(c.parking_driver.active)
        self.assertNotEqual(old.request_id,c.parking_driver.request_id)
        self.assertEqual(selected[count:],[4.])
        self.assertEqual(seen[-1],('parking',True))
        self.assertFalse(c.action.checked)

    def test_click_rolling_menu_from_parking_really_selects_baseline(self):
        fixture,c,logic,selected=self.setup_controller();seen=[]
        with fixture.enabled(seen):
            c.set_parking_capture(True);c.begin_parking_capture();old=c.parking_driver
            # Exercise old actual handler when the corrected menu seam is
            # not yet present; the failure then names the wrong mode, not a
            # missing test-only symbol.
            getattr(c,'set_image_fusion',c.toggle)(True)
        self.assertEqual(c.contour_mode,'baseline')
        self.assertEqual(seen[-1],('baseline',False))
        self.assertFalse(old.active);self.assertIsNone(c.parking_driver)
        self.assertTrue(c.action.checked);self.assertFalse(c.parking_action.checked)

    def test_failed_auto_start_is_explicit_and_has_no_active_driver(self):
        fixture,c,logic,selected=self.setup_controller()
        logic.app.statusLabel.setText('PCAP REPLAY')
        with fixture.enabled([]),patch.object(fusion_native,'capture_clock',side_effect=RuntimeError('clock_unavailable')):
            c.set_parking_capture(True)
        self.assertIsNone(c.parking_driver)
        self.assertEqual(selected,[])
        self.assertIn('clock_unavailable',logic.app.statusLabel.text)
        self.assertIn('PARK',logic.app.statusLabel.text)
        self.assertFalse(c.action.checked)


if __name__=='__main__':unittest.main()
