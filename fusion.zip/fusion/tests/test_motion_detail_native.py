import unittest
from types import SimpleNamespace
from unittest.mock import patch
from ... import fusion_native
from ...clearance.tests.test_live_clearance import Action
from ...clearance.tests import test_recorded_playback as replay_support
from .test_contour_native import StyledOverlay


class MotionDetailNativeTests(unittest.TestCase):
    def controller(self):
        logic=replay_support.RecordedMenuTests().logic();action=Action()
        try:controller=fusion_native.ImageFusionController(logic,Action(),Action(),Action(),
            contour_action=Action(),motion_detail_action=action)
        except TypeError:self.fail('rolling detail native action not connected')
        return controller,logic,action

    def test_config_is_opt_in_replay_baseline_and_keeps_source(self):
        logic=SimpleNamespace(getReaderFileName=lambda:'C:/测试/121.pcap')
        with patch.object(fusion_native,'enable_recorded',side_effect=lambda logic,config:config):
            try:config=fusion_native.enable_image(logic,motion_detail=True)
            except TypeError:self.fail('rolling detail config missing')
            self.assertTrue(config['image_motion_detail']);self.assertTrue(config['image_snapshot_support'])
            self.assertTrue(config['image_fusion_only']);self.assertEqual(config['image_source_path'],'C:/测试/121.pcap')
            self.assertNotIn('image_motion_detail',fusion_native.enable_image(logic))
            for mode in ('quality','parking','trajectory','window'):
                with self.assertRaises(ValueError):fusion_native.enable_image(logic,contour_mode=mode,motion_detail=True)

    def test_switch_rebuilds_owned_worker_and_preserves_view_then_can_return_to_baseline(self):
        controller,logic,action=self.controller();created=[];seen=[]
        camera=SimpleNamespace(CameraPosition=[1.,2.,3.],CameraFocalPoint=[0.,0.,0.],CameraViewUp=[0.,0.,1.])
        logic.getRenderView=lambda:camera
        def enable(native_logic,contour_mode='baseline',motion_detail=False):
            seen.append((contour_mode,motion_detail));overlay=StyledOverlay(native_logic.getReader())
            created.append(overlay);native_logic.app.railOverlay=overlay;return overlay
        with patch.object(fusion_native,'enable_image',enable):
            controller.source_ready();self.assertFalse(action.enabled or action.checked)
            controller.toggle(True);self.assertTrue(action.enabled);self.assertFalse(action.checked)
            controller.overlay.set_image_display_settings(True,1.25,(-1.,1.,-2.,2.,-3.,3.))
            controller.set_motion_detail(True)
            self.assertTrue(created[0].closed);self.assertTrue(action.checked)
            self.assertEqual(seen,[('baseline',False),('baseline',True)])
            self.assertEqual(controller.overlay.settings['roi'],(-1.,1.,-2.,2.,-3.,3.))
            controller.set_motion_detail(True);self.assertEqual(len(created),2)
            controller.set_motion_detail(False);self.assertFalse(action.checked)
            self.assertEqual(seen[-1],('baseline',False))
        self.assertEqual(camera.CameraPosition,[1.,2.,3.]);controller.source_closed()
        self.assertFalse(controller.motion_detail);self.assertFalse(action.checked or action.enabled)

    def test_mode_or_source_changes_cannot_leak_the_flag(self):
        controller,logic,action=self.controller();seen=[]
        def enable(native_logic,contour_mode='baseline',motion_detail=False):
            seen.append((contour_mode,motion_detail));native_logic.app.railOverlay=StyledOverlay(native_logic.getReader())
            return native_logic.app.railOverlay
        with patch.object(fusion_native,'enable_image',enable):
            controller.toggle(True);controller.set_motion_detail(True);controller.set_contour_refinement(True)
            self.assertFalse(controller.motion_detail or action.checked or action.enabled)
            self.assertEqual(seen[-1],('quality',False))
            controller.set_motion_detail(True);self.assertEqual(seen[-1],('quality',False))
            controller.set_contour_refinement(False);self.assertEqual(seen[-1],('baseline',False))
            logic.getSensor=lambda:object();controller.source_ready();controller.set_motion_detail(True)
            self.assertFalse(action.checked or action.enabled)

    def test_status_exposes_the_algorithm_not_a_display_filter(self):
        overlay=replay_support.RecordedNativeTests().overlay();overlay.last_input=20;overlay.image_single_view=False
        packet={'sequence':20,'measurement_basis':'image_only','current_source':True,
            'fusion':{'state':'window_ready','scan_count':20,'motion_detail_enabled':True,
                'reference_sequence':20,'reference_time_s':10.,'age_s':0.}}
        status=overlay.packet_status(packet)
        self.assertIn('MOTION DETAIL',status);self.assertIn('20/20 real scans',status)
        self.assertIn('NO MEASUREMENT',status)


if __name__=='__main__':unittest.main()
