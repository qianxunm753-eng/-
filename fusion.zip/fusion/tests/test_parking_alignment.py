import importlib
import unittest
from dataclasses import replace
from unittest.mock import patch
import numpy as np
from ..registration import LocalMap
from ..state import ScanRecord,RefinementBudget
from ..imu import ImuSeries
from .test_core import scene
from .fixtures_contour import make_record,snapshot_bytes
from .test_contour_trajectory import moving_scan


class ParkingAlignmentTests(unittest.TestCase):
    def module(self):
        try:return importlib.import_module('rsview_centerline.fusion.parking_alignment')
        except ImportError:self.fail('training-only parking motion and complete-return model missing')

    def masked(self,mapper,points,times,rings,reference,imu,mask):
        try:return mapper.update(points,times,rings,reference,imu,fit_mask=mask,save_model=True)
        except TypeError:self.fail('LocalMap lacks training mask / complete saved model')

    def past(self):
        m=LocalMap();p=scene();m.update(p,np.full(len(p),.9),None,.9,None)
        return m

    def test_holdout_cannot_change_fit_but_remains_in_full_output(self):
        p=scene()-[.003,0.,0.];mask=np.arange(len(p))%5!=0;changed=p.copy();changed[~mask]+=[.02,0.,0.]
        times=np.full(len(p),1.);m=self.past()
        a=self.masked(m.fork(),p,times,None,1.,None,mask)
        b=self.masked(m.fork(),changed,times,None,1.,None,mask)
        self.assertTrue(a.usable);self.assertTrue(b.usable)
        np.testing.assert_array_equal(a.pose,b.pose)
        self.assertEqual(len(b.points),len(p));self.assertIsNotNone(b.model)
        np.testing.assert_allclose(b.model.corrected_points(changed,times,None),b.points,atol=1e-10)

    def test_training_only_rebuild_cannot_put_holdout_geometry_in_target(self):
        r=make_record();p=r.raw_xyz.copy();p[r.original_indices%5==0,2]+=5.
        r=replace(r,raw_xyz=p,corrected_xyz=p)
        try:m=LocalMap().rebuilt((r,),RefinementBudget(),training_only=True)
        except TypeError:self.fail('map rebuild has no training-only boundary')
        self.assertLessEqual(m.geometry[0][:,2].max(),1.5)
        self.assertGreater(LocalMap().rebuilt((r,),RefinementBudget()).geometry[0][:,2].max(),5.)

    def test_rings_and_filtered_original_indices_keep_disjoint_fit(self):
        self.module();points=scene();indices=np.arange(len(points))+3
        mask=indices%5!=0;rings=np.arange(len(points))%4;modified=points.copy()
        modified[~mask| (rings%2!=0)]+=[0.,0.,.05]
        times=np.full(len(points),1.);m=self.past()
        a=self.masked(m.fork(),points,times,rings,1.,None,mask)
        b=self.masked(m.fork(),modified,times,rings,1.,None,mask)
        np.testing.assert_array_equal(a.pose,b.pose)
        self.assertEqual(len(b.points),len(points))

    def test_saved_model_matches_the_used_translation_not_later_guess(self):
        self.module();record,imu,truth=moving_scan([.015,-.008,.01],[.003,.004,-.002])
        m=LocalMap();m.update(truth,np.full(len(truth),.95),None,.95,None)
        result=self.masked(m,record.raw_xyz,record.point_times,None,record.reference_s,imu,
            record.original_indices%5!=0)
        self.assertTrue(result.usable,result.diagnostics)
        np.testing.assert_allclose(result.model.corrected_points(record.raw_xyz,record.point_times,imu),result.points,atol=1e-10)
        np.testing.assert_allclose(result.model.reference_pose,result.pose,atol=1e-10)

    def test_gyro_anchor_reconstruction_has_one_rotation_and_input_is_immutable(self):
        self.module();record,imu,truth=moving_scan([0.,0.,0.],[0.,0.,.03])
        original=record.raw_xyz.copy()
        result=self.masked(LocalMap(),record.raw_xyz,record.point_times,None,record.reference_s,imu,
            record.original_indices%5!=0)
        np.testing.assert_allclose(result.points,truth,atol=1e-10)
        np.testing.assert_allclose(result.model.corrected_points(record.raw_xyz,record.point_times,imu),truth,atol=1e-10)
        np.testing.assert_array_equal(record.raw_xyz,original);self.assertFalse(record.raw_xyz.flags.writeable)

    def test_lidar_only_nonzero_span_model_reconstructs_complete_output(self):
        self.module();record,unused,truth=moving_scan([.01,0.,0.],[0.,0.,0.],False)
        m=LocalMap();m.update(truth,np.full(len(truth),.95),None,.95,None)
        r=self.masked(m,record.raw_xyz,record.point_times,None,record.reference_s,None,record.original_indices%5!=0)
        self.assertTrue(r.usable,r.diagnostics)
        np.testing.assert_allclose(r.model.corrected_points(record.raw_xyz,record.point_times,None),r.points,atol=1e-10)

    def test_filtered_times_do_not_replace_the_actual_scan_endpoints(self):
        self.module();p=scene();times=np.linspace(1.07,1.1,len(p));m=self.past()
        try:r=m.update(p,times,None,1.05,None,fit_mask=np.arange(len(p))%5!=0,
            save_model=True,scan_span_s=(1.,1.1))
        except TypeError:self.fail('actual full scan span cannot be preserved after point filtering')
        self.assertEqual(r.model.span_s,(1.,1.1))
        np.testing.assert_allclose(r.model.corrected_points(p,times,None),r.points,atol=1e-10)

    def test_zero_span_uses_a_rigid_model_without_inventing_endpoint_time(self):
        module=self.module();r=make_record(1);m=self.past()
        result=self.masked(m,r.raw_xyz,r.point_times,r.rings,r.reference_s,None,r.original_indices%5!=0)
        self.assertIsInstance(result.model,module.RigidScanModel)
        np.testing.assert_array_equal(result.model.corrected_points(r.raw_xyz,r.point_times),r.raw_xyz)
        bad=np.eye(4);bad[0,0]=2.
        with self.assertRaises(ValueError):module.RigidScanModel(bad)

    def test_alignment_never_mutates_past_map_and_bootstrap_is_not_zero_speed(self):
        module=self.module();record=make_record();past=LocalMap();before=snapshot_bytes(past)
        result=module.align_parking_scan(record,past,None,RefinementBudget())
        self.assertIsNotNone(result.baseline);self.assertFalse(result.evidence.observable)
        self.assertIsNone(result.evidence.translation_rate_m_s)
        self.assertEqual(snapshot_bytes(past),before)
        self.assertEqual(len(result.baseline.corrected_xyz),len(record.raw_xyz))

    def test_budget_self_support_and_single_plane_do_not_get_new_accepted_pose(self):
        module=self.module();record=make_record(1);m=self.past();before=snapshot_bytes(m)
        result=module.align_parking_scan(record,m,None,RefinementBudget(deadline_s=0.))
        self.assertIsNone(result.baseline);self.assertEqual(snapshot_bytes(m),before)
        m.key_sources.append((record.source_key,record.sequence))
        result=module.align_parking_scan(record,m,None,RefinementBudget())
        self.assertIsNone(result.baseline);self.assertIn('self_support',result.diagnostics['reason'])
        plane=replace(record,raw_xyz=record.raw_xyz[:400],corrected_xyz=record.corrected_xyz[:400],
            point_times=record.point_times[:400],original_indices=record.original_indices[:400])
        pm=LocalMap();pm.update(plane.raw_xyz,np.full(400,.9),None,.9,None)
        result=module.align_parking_scan(plane,pm,None,RefinementBudget())
        self.assertIsNone(result.baseline);self.assertFalse(result.evidence.observable)

    def test_small_motion_evidence_uses_actual_reference_interval_and_training_support(self):
        module=self.module();record=make_record(1);p=record.raw_xyz-[.002,0.,0.]
        record=replace(record,raw_xyz=p,corrected_xyz=p)
        m=self.past();before=snapshot_bytes(m)
        result=module.align_parking_scan(record,m,None,RefinementBudget())
        self.assertIsNotNone(result.baseline,result.diagnostics)
        self.assertTrue(result.evidence.observable);self.assertAlmostEqual(result.evidence.reference_dt_s,.2)
        self.assertAlmostEqual(result.evidence.translation_rate_m_s,.01,places=5)
        self.assertEqual(snapshot_bytes(m),before)

    def test_micro_step_outside_bound_is_refused_not_clipped_and_window_solver_is_unused(self):
        module=self.module();record=make_record(1);m=self.past()
        # Baseline is real; isolate only its final saved pose to present a
        # known 2cm residual to the independent small-step refinement stage.
        original=module.LocalMap.update
        def misplaced(mapper,*args,**kwargs):
            result=original(mapper,*args,**kwargs);result.pose=result.pose.copy();result.pose[0,3]+=.02
            result.model=module.rebase_model(result.model,result.pose)
            return result
        with patch.object(module.LocalMap,'update',misplaced),patch(
            'rsview_centerline.fusion.window_refinement.WindowRefiner.refine',side_effect=AssertionError('joint solve used')):
            result=module.align_parking_scan(record,m,None,RefinementBudget())
        self.assertIsNotNone(result.baseline);self.assertIsNone(result.candidate)
        self.assertEqual(result.diagnostics['micro_reason'],'step_outside_parking_capture')
