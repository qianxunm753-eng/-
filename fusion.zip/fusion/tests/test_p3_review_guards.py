"""Adversarial regressions from the fresh whole-route review."""
import inspect
import unittest
from dataclasses import replace
from unittest.mock import patch
import numpy as np
from .fixtures_p3 import structure_snapshot,moving_requests,engine_fingerprint,locked_engine
from ..engine import ImageFusionEngine
from ..p3_geometry import build_geometry,GeometryPolicy,GeometryPatch
from ..p3_enhancement import enhance
from ..state import RefinementBudget


class P3ReviewGuardTests(unittest.TestCase):
    def test_different_scans_seeing_opposite_thin_faces_remain_ambiguous(self):
        snapshot=structure_snapshot('thin_gap',count=4)
        scans=[]
        for i,scan in enumerate(snapshot.scans):
            keep=scan.corrected_xyz[:,0]<(2.01) if i%2==0 else scan.corrected_xyz[:,0]>2.01
            scans.append(replace(scan,corrected_xyz=scan.corrected_xyz[keep],point_times=scan.point_times[keep],
                original_indices=scan.original_indices[keep],rings=scan.rings[keep]))
        context=build_geometry(replace(snapshot,scans=tuple(scans)),RefinementBudget(),GeometryPolicy())
        self.assertGreater(context.ambiguous_association_count,0)
        self.assertFalse(context.patches)
        self.assertFalse(context.check_references)

    def test_second_incompatible_surface_within_ratio_refuses_association(self):
        from .. import p3_geometry as geometry
        self.assertTrue(hasattr(geometry,'fixed_associations'),'incompatible second-surface gate absent')
        supports=[]
        for i,x in enumerate((-.005,.005)):
            points=np.array([[x,0.,0.],[x,.01,0.],[x,0.,.01]])
            local=GeometryPatch('plane',np.array([0,1,2]),np.arange(3),points,points.mean(axis=0),
                np.array([[1.],[0.],[0.]]),0.)
            supports.append((i,local,points))
        assignment,targets,ambiguous=geometry.fixed_associations(np.array([[0.,0.,0.],[-.004,0.,0.]]),
            supports,GeometryPolicy())
        np.testing.assert_array_equal(assignment,[-1,0])
        np.testing.assert_array_equal(ambiguous,[True,False])
        np.testing.assert_array_equal(targets[1],[-.005,0.,0.])

    def test_unsupported_return_near_background_stays_unknown(self):
        snapshot=structure_snapshot('single_plane',count=4)
        scans=[]
        for scan in snapshot.scans:
            scans.append(replace(scan,corrected_xyz=np.vstack((scan.corrected_xyz,[.39283114,.39226005,1.13])),
                point_times=np.r_[scan.point_times,scan.reference_s],original_indices=np.r_[scan.original_indices,1089],
                rings=np.r_[scan.rings,95]))
        context=build_geometry(replace(snapshot,scans=tuple(scans)),RefinementBudget(),GeometryPolicy())
        self.assertTrue(context.patches)
        for scan in scans:self.assertIn(1089,context.unknown_origins[scan.sequence])

    def test_unchecked_local_arc_cannot_claim_all_local_guards(self):
        snapshot=structure_snapshot(pose_error_m=.0015)
        scans=[]
        for scan in snapshot.scans:
            indices=scan.original_indices.copy();indices[3387:]=indices[3387:]*5+1
            scans.append(replace(scan,original_indices=indices))
        origins={name:points.copy() for name,points in snapshot.display_origins.items()}
        for points in origins.values():
            arc=points[:,1]>=3387;points[arc,1]=points[arc,1]*5+1
        result=enhance(replace(snapshot,scans=tuple(scans),display_origins=origins),RefinementBudget(),GeometryPolicy())
        self.assertFalse(result.accepted)
        self.assertEqual(result.reason,'unknown_geometry')
        self.assertFalse(result.report['all_local_guards_passed'])
        self.assertIs(result.pair,snapshot.baseline_pair)

    def test_optional_sampling_origin_allocation_failure_keeps_committed_window(self):
        engine=ImageFusionEngine({'image_snapshot_support':True});old=locked_engine()
        items=moving_requests(2)
        engine.process(items[0]);old.process(items[0]);old.process(items[1])
        original=np.flatnonzero
        def allocation_failure(value):
            if inspect.currentframe().f_back.f_code.co_name=='_sampled_with_rows':
                raise MemoryError('optional source rows')
            return original(value)
        with patch('rsview_centerline.fusion.engine.np.flatnonzero',new=allocation_failure):
            result=engine.process(items[1])
        self.assertEqual(result['fusion']['scan_count'],2)
        self.assertEqual(engine_fingerprint(engine),engine_fingerprint(old))
        with self.assertRaisesRegex(ValueError,'metadata'):engine.freeze_window(RefinementBudget())
