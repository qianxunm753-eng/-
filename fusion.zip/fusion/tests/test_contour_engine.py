import json
import pickle
import unittest
import tracemalloc
from unittest.mock import patch
from dataclasses import replace
import numpy as np
from ..engine import ImageFusionEngine
from ..state import RefinementBudget
from ..validation import ValidationMetrics,ValidationReport
from .test_engine import request
from .test_core import scene
from .fixtures_contour import make_window,snapshot_bytes


class ContourEngineTests(unittest.TestCase):
    def test_quality_engine_checks_adopted_history_even_when_window_is_rejected(self):
        from ..window_refinement import WindowResult
        engine=ImageFusionEngine({'image_contour_mode':'quality'})
        engine.process(request(0));engine.process(request(1))
        records=tuple(engine.contour_records);bad_pose=records[1].pose.copy();bad_pose[0,3]=.03
        engine.contour_records[1]=replace(records[1],pose=bad_pose)
        with patch('rsview_centerline.fusion.contour_engine.WindowRefiner.refine',
                   side_effect=lambda records,budget:WindowResult(records,False,'candidate_rejected')):
            packet=engine.process(request(2))
        self.assertEqual(packet['fusion']['window_sources'] if 'window_sources' in packet['fusion'] else
            [r.sequence for r in engine.contour_records],[0,1,2])
        self.assertEqual(packet['fusion']['effective_source_frames'],[2])
        self.assertEqual(packet['fusion']['window_scan_count'],3)
        self.assertIn('contribution',packet['relative_pose_diagnostics'])
        self.assertEqual([key[1] for key in engine.mapper.key_sources],[2],
            'next registration still sees excluded display history')

    def test_rejected_candidate_report_cannot_prune_good_adopted_history(self):
        from ..window_refinement import WindowResult
        m=ValidationMetrics(.01,.008,1.,{},True);bad=ValidationReport(False,'heldout_p90_regression',m,m)
        engine=ImageFusionEngine({'image_contour_mode':'quality'});engine.process(request(0))
        with patch('rsview_centerline.fusion.contour_engine.WindowRefiner.refine',
                   side_effect=lambda records,budget:WindowResult(records,False,'candidate_rejected',bad,{0:bad})):
            packet=engine.process(request(1))
        self.assertEqual(packet['fusion']['effective_source_frames'],[0,1])
        self.assertIn('contribution',packet['relative_pose_diagnostics'])

    def test_oversized_scan_is_refused_before_temporary_allocations(self):
        engine=ImageFusionEngine({'image_contour_mode':'quality'})
        engine.process(request());old=engine.last_pair;before=snapshot_bytes(engine.mapper)
        large=request(1,np.tile(scene(),(400,1)))
        tracemalloc.start()
        try:
            packet=engine.process(large)
            unused,peak=tracemalloc.get_traced_memory()
        finally:tracemalloc.stop()
        self.assertLess(peak,64*1024**2,'engine staging exceeded temporary budget')
        self.assertIs(engine.last_pair,old);self.assertEqual(snapshot_bytes(engine.mapper),before)
        self.assertTrue(packet['fusion']['held'])
        self.assertEqual(packet['relative_pose_diagnostics']['reason'],'image_temporary_capacity')

    def test_first_oversized_scan_does_not_build_an_unbounded_raw_fallback(self):
        engine=ImageFusionEngine({'image_contour_mode':'quality'})
        large=request(0,np.tile(scene(),(400,1)))
        with patch.object(engine.mapper,'update',side_effect=AssertionError('allocation before guard')):
            packet=engine.process(large)
        self.assertEqual(packet['fusion']['scan_count'],0)
        self.assertEqual(packet['_display']['object']['count'],0)

    def test_supported_scan_staging_also_stays_within_temporary_budget(self):
        engine=ImageFusionEngine({'image_contour_mode':'quality'})
        normal=request(0,np.tile(scene(),(80,1)))
        tracemalloc.start()
        try:
            packet=engine.process(normal);unused,peak=tracemalloc.get_traced_memory()
        finally:tracemalloc.stop()
        self.assertLess(peak,64*1024**2)
        self.assertEqual(packet['fusion']['scan_count'],1)

    def test_quality_preserves_unknown_new_surfaces_and_partial_check_failure(self):
        from ..contribution import check_adopted_history
        from ..engine import contributing_suffix
        records=make_window(3);unknown=replace(records[0],pose=np.array(
            [[1.,0.,0.,10.],[0.,1.,0.,0.],[0.,0.,1.,0.],[0.,0.,0.,1.]]))
        records=(unknown,records[1],records[2])
        reports,diagnostics=check_adopted_history(records,RefinementBudget())
        self.assertIsNone(reports[0]);self.assertEqual(contributing_suffix(records,reports),records)
        reports,diagnostics=check_adopted_history(records,RefinementBudget(deadline_s=0.))
        self.assertEqual(reports,{})
        self.assertEqual(contributing_suffix(records,reports),records)

    def test_effective_count_matches_real_source_ids_and_has_no_measurement(self):
        engine=ImageFusionEngine({'image_contour_mode':'quality'})
        for sequence in range(20):packet=engine.process(request(sequence))
        self.assertIn('effective_scan_count',packet['fusion'],'enhanced packet missing')
        f=packet['fusion'];self.assertEqual(f['window_scan_count'],20)
        self.assertEqual(f['effective_scan_count'],len(f['effective_source_frames']))
        self.assertEqual(f['effective_source_frames'],list(range(20)))
        self.assertEqual(packet['measurements'],[]);self.assertEqual(packet['centerline'],[])
        self.assertEqual(packet['config_id'],'rsview-image-contour-v1:quality')
        json.dumps(packet['relative_pose_diagnostics']);pickle.dumps(packet,protocol=2)

    def test_invalid_mode_live_and_external_pose_cannot_start_refinement(self):
        with self.assertRaises(ValueError):ImageFusionEngine({'image_contour_mode':'not-a-mode'})
        with self.assertRaises(ValueError):ImageFusionEngine({'image_contour_mode':'quality'},source_mode='live')
        with self.assertRaises(ValueError):ImageFusionEngine({'image_contour_mode':'quality'},experimental_pose_path='old.json')

    def test_default_baseline_is_not_silently_replaced(self):
        default=ImageFusionEngine();explicit=ImageFusionEngine({'image_contour_mode':'baseline'})
        for sequence in range(5):a=default.process(request(sequence));b=explicit.process(request(sequence))
        self.assertEqual(a['_display'],b['_display']);self.assertEqual(a['config_id'],'rsview-image-fusion-v2')

    def test_quality_never_discards_unknown_or_latest_scan(self):
        import rsview_centerline.fusion.engine as module
        self.assertTrue(hasattr(module,'contributing_suffix'),'scan contribution guard missing')
        records=make_window(5);m=ValidationMetrics(.01,.008,1.,{},True)
        bad=ValidationReport(False,'heldout_p90_regression',m,m)
        chosen=module.contributing_suffix(records,{2:bad,3:None,4:bad})
        self.assertEqual([r.sequence for r in chosen],[3,4])
        self.assertEqual(module.contributing_suffix(records,{0:None}),records)

    def test_enhanced_capacity_and_pack_failure_keep_all_geometry(self):
        engine=ImageFusionEngine({'image_contour_mode':'quality'});engine.process(request())
        before=snapshot_bytes(engine.mapper);old=engine.last_pair
        engine.byte_budget=1;packet=engine.process(request(1))
        self.assertEqual(snapshot_bytes(engine.mapper),before);self.assertIs(engine.last_pair,old)
        self.assertTrue(packet['fusion']['held'])
        engine.byte_budget=96*1024**2
        with patch.object(engine,'paired_views',side_effect=MemoryError('pack failure')):
            packet=engine.process(request(2))
        self.assertEqual(snapshot_bytes(engine.mapper),before);self.assertIs(engine.last_pair,old)
        self.assertTrue(packet['fusion']['held'])

    def test_expired_enhancement_budget_still_publishes_real_baseline(self):
        engine=ImageFusionEngine({'image_contour_mode':'quality'})
        self.assertTrue(hasattr(engine,'make_refinement_budget'),'bounded enhancement deadline missing')
        with patch.object(engine,'make_refinement_budget',return_value=RefinementBudget(deadline_s=0.)):
            packet=engine.process(request())
        self.assertEqual(packet['fusion']['effective_scan_count'],1)
        self.assertIn('baseline',packet['fusion']['refinement_state'])
        self.assertEqual(packet['fusion']['reference_sequence'],0)

    def test_duplicate_reverse_and_new_source_reset_all_enhancement_records(self):
        engine=ImageFusionEngine({'image_contour_mode':'quality'})
        for sequence in range(5):engine.process(request(sequence))
        duplicate=engine.process(request(4));self.assertIn('window_scan_count',duplicate['fusion'])
        self.assertEqual(duplicate['fusion']['window_scan_count'],5)
        back=engine.process(request(1));self.assertEqual(back['fusion']['window_scan_count'],1)
        new=engine.process(request(0,session='other'));self.assertEqual(new['fusion']['effective_source_frames'],[0])

    def test_hundred_input_scans_keep_bounded_window_and_true_span(self):
        engine=ImageFusionEngine({'image_contour_mode':'trajectory'})
        for sequence in range(100):packet=engine.process(request(sequence,scene()-[sequence*.003,0.,0.]))
        self.assertIn('window_scan_count',packet['fusion'])
        self.assertEqual(packet['fusion']['window_scan_count'],20)
        self.assertEqual(packet['fusion']['effective_source_frames'],list(range(80,100)))
        self.assertLessEqual(packet['fusion']['window_bytes'],96*1024**2)
        self.assertAlmostEqual(packet['fusion']['effective_span_s'][1]-packet['fusion']['effective_span_s'][0],1.9)
