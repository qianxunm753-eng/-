"""Regression for quiet cancel/reopen and persistent native P3 feedback."""
import io
import sys
import time
import unittest
from contextlib import redirect_stdout
from types import SimpleNamespace
from ...clearance_process import ClearanceProcess
from ...image_control import ImageControlChannel,control_reply
from ...clearance.tests.test_live_clearance import Action
from .fixtures_p3 import moving_requests
from . import test_p3_native as native_support
from . import test_parking_native as parking_support


def idle_channel():
    host=SimpleNamespace(closed=False,failed=False,running=None,pending=None,
        current=dict(session_id='s',clock_id='c',epoch=0),_path=lambda name:name)
    channel=ImageControlChannel(host,True,lambda:100.,lambda path:None,
        lambda path,value:None,lambda path:None,lambda path:None)
    channel.active_id='old';channel.suspended=True
    request=dict(command='freeze',request_id='old',source_key=('s','c',0),budget_s=60.)
    return channel,request


class P3ReopenTests(unittest.TestCase):
    def wait(self,call):
        deadline=time.monotonic()+15.
        while time.monotonic()<deadline:
            result=call()
            if result is not None:return result
            time.sleep(.005)
        self.fail('isolated real P3 worker did not reply')

    def controller(self):
        controller,logic,unused=parking_support.ParkingNativeTests().controller()
        overlay=native_support.P3NativeTests().overlay();controller.overlay=overlay
        controller.p3_action=Action();controller.p3_baseline_action=Action()
        overlay.logic=logic;overlay.status_label=logic.app.statusLabel
        cloud=dict(data=b'',count=0,dtype='little-float32-xyz')
        overlay.last_result=dict(measurement_basis='image_only',device_time_s=2.9,current_source=True,
            fusion=dict(state='window_ready',scan_count=20,reference_sequence=19,reference_time_s=2.9),
            _image_pairs=dict(fused=cloud,single=cloud),clouds=cloud)
        # SDK rendering is the external seam; native status/pair selection remains real.
        overlay.display_packet=lambda packet:setattr(overlay,'last_result',packet)
        return controller,logic,overlay

    def refused(self):
        c,logic,overlay=self.controller()
        def refuse(*args,**kwargs):raise ValueError('fixture_control_refused')
        overlay.host.request_image_control=refuse
        return c,logic,overlay

    def test_reopen_keeps_same_twenty_sources_worker_and_base_bytes(self):
        host=ClearanceProcess(python=sys.executable,source_mode='recorded_pcap',
            config=dict(image_fusion_only=True,image_snapshot_support=True))
        self.addCleanup(host.close)
        for frame in moving_requests(20):
            host.submit(frame,force=True);base=self.wait(host.poll)
        pid=host.child.pid;source=dict(host.current)
        c,logic,overlay=self.controller();overlay.host=host
        overlay.last_result=None  # Wire-level integration, no synthetic rendered pair.
        overlay.session=host.current['session_id'];overlay.clock=host.current['clock_id']
        for drain_cancel in (True,False):
            c.set_p3_detail(True)
            self.assertIsNotNone(c.p3_driver)
            self.assertTrue(c.p3_driver.processing,logic.app.statusLabel.text)
            frozen=self.wait(c.p3_driver.poll)
            self.assertEqual(frozen['snapshot_key']['source_frames'],tuple(range(20)))
            self.assertEqual(frozen['pair']['fused']['data'],base['_display']['object']['data'])
            self.wait(c.p3_driver.poll)
            c.set_p3_detail(False)
            if drain_cancel:host.poll_image_control()
        c.set_p3_detail(True)
        self.assertTrue(c.p3_driver.processing,logic.app.statusLabel.text)
        self.assertTrue(c.p3_action.checked)
        self.assertIs(c.overlay,overlay);self.assertEqual(host.current,source)
        self.assertEqual(host.child.pid,pid);self.assertFalse(host.failed)
        c.set_p3_detail(False)

    def test_repeated_cancel_does_not_recreate_consumed_receipt(self):
        channel,request=idle_channel()
        self.assertTrue(channel.cancel('old'));self.assertEqual(channel.poll()['state'],'cancelled')
        self.assertTrue(channel.cancel('old'))
        self.assertIsNone(channel.poll())

    def test_resume_consumes_only_matching_terminal_cancel(self):
        for state,token,source in [('cancelled','old',('s','c',0)),('accepted','old',('s','c',0)),
                ('cancelled','other',('s','c',0)),('cancelled','old',('other','c',0))]:
            with self.subTest(state=state,token=token,source=source):
                channel,request=idle_channel();channel.cancelled=True
                reply=control_reply(dict(request,request_id=token,source_key=source),state,'fixture')
                channel.result=reply
                self.assertTrue(channel.resume())
                if state=='cancelled' and token=='old' and source==('s','c',0):self.assertIsNone(channel.result)
                else:self.assertIs(channel.result,reply)

    def test_resume_waits_for_inflight_cancel_ack(self):
        channel,request=idle_channel();channel.cancelled=True;channel.running=request
        reply=control_reply(request,'cancelled','fixture');channel.result=reply
        self.assertFalse(channel.resume());self.assertIs(channel.result,reply)
        self.assertTrue(channel.suspended)

    def test_start_failure_survives_normal_poll_without_changing_pair(self):
        c,logic,overlay=self.refused();pair=overlay.last_result
        with redirect_stdout(io.StringIO()):c.set_p3_detail(True)
        before=logic.app.statusLabel.text
        self.assertIn('fixture_control_refused',before)
        overlay.poll()
        self.assertIn('fixture_control_refused',logic.app.statusLabel.text)
        self.assertIs(overlay.last_result,pair);self.assertFalse(c.p3_action.checked)
        c.set_p3_detail(False);overlay.poll()
        self.assertNotIn('fixture_control_refused',logic.app.statusLabel.text)

    def test_start_failure_is_reported_to_console(self):
        c,logic,overlay=self.refused();output=io.StringIO()
        with redirect_stdout(output):c.set_p3_detail(True)
        self.assertIn('fixture_control_refused',output.getvalue())

    def test_start_failure_does_not_follow_another_frame_or_source(self):
        c,logic,overlay=self.refused()
        with redirect_stdout(io.StringIO()):c.set_p3_detail(True)
        overlay.requested_frame=20;overlay.poll()
        self.assertNotIn('fixture_control_refused',logic.app.statusLabel.text)
        overlay.session='other';overlay.poll()
        self.assertNotIn('fixture_control_refused',logic.app.statusLabel.text)

    def test_active_freeze_and_compute_feedback_survives_poll(self):
        c,logic,overlay=self.controller();c.set_p3_detail(True)
        for phase,word in [('freeze','freezing'),('enhance','computing')]:
            c.p3_driver.phase=phase;overlay.poll()
            self.assertIn('P3 DETAIL',logic.app.statusLabel.text)
            self.assertIn(word,logic.app.statusLabel.text)

    def test_decode_failure_feedback_survives_early_error_return(self):
        c,logic,overlay=self.controller();overlay.input_error='decoder still pending'
        overlay._update_recorded=lambda frame,poll=False:None
        with redirect_stdout(io.StringIO()):c.set_p3_detail(True)
        self.assertIn('selected frame not decoded',logic.app.statusLabel.text)
        overlay.last_result=None  # Geometry may already be invalidated by the decoder.
        self.assertIsNone(overlay.poll())
        self.assertIn('P3 DETAIL',logic.app.statusLabel.text)
        self.assertIn('selected frame not decoded',logic.app.statusLabel.text)
        self.assertIsNone(overlay.last_result)
