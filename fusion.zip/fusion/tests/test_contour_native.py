import unittest
from types import SimpleNamespace
from unittest.mock import patch
from ... import fusion_native,clearance_native
from ...clearance.tests.test_live_clearance import Action,Overlay
from ...clearance.tests import test_recorded_playback as replay_support


class StyledOverlay(Overlay):
    def __init__(self,reader):
        super().__init__(reader);self.settings={'depth':True,'point_size':1.25,'roi':None}
        self.image_single_view=False;self.image_clean_view=False
    def get_image_display_settings(self):return dict(self.settings)
    def set_image_display_settings(self,depth,size,roi=None):
        self.settings={'depth':depth,'point_size':size,'roi':roi};return True
    def set_image_single_view(self,value):self.image_single_view=bool(value);return True
    def set_image_clean_view(self,value):self.image_clean_view=bool(value);return True


class ContourNativeTests(unittest.TestCase):
    def test_native_quality_config_keeps_unicode_source_and_image_only(self):
        logic=SimpleNamespace(getReaderFileName=lambda:'C:/测试/333.pcap')
        with patch.object(fusion_native,'enable_recorded',side_effect=lambda logic,config:config):
            try:config=fusion_native.enable_image(logic,contour_mode='quality')
            except TypeError:self.fail('native enhancement config interface missing')
        self.assertEqual(config['image_contour_mode'],'quality')
        self.assertEqual(config['image_source_path'],'C:/测试/333.pcap')
        self.assertTrue(config['image_fusion_only']);self.assertEqual(config['config_id'],'rsview-image-contour-v1:quality')

    def test_invalid_native_mode_is_not_sent_to_a_worker(self):
        logic=SimpleNamespace(getReaderFileName=lambda:'C:/测试/333.pcap')
        with self.assertRaises(ValueError):fusion_native.enable_image(logic,contour_mode='invalid')

    def test_switch_rebuilds_only_owned_overlay_and_preserves_view_settings(self):
        logic=replay_support.RecordedMenuTests().logic();created=[];modes=[]
        view=SimpleNamespace(CameraPosition=[1.,2.,3.],CameraFocalPoint=[0.,0.,0.],CameraViewUp=[0.,0.,1.])
        logic.getRenderView=lambda:view
        contour=Action()
        try:controller=fusion_native.ImageFusionController(logic,Action(),Action(),Action(),None,contour)
        except TypeError:self.fail('native refinement action missing')
        def enable(native_logic,contour_mode='baseline'):
            modes.append(contour_mode);overlay=StyledOverlay(native_logic.getReader());created.append(overlay)
            native_logic.app.railOverlay=overlay;return overlay
        with patch.object(fusion_native,'enable_image',enable):
            controller.toggle(True);controller.single_view(True);controller.clean_view(True)
            controller.set_contour_refinement(True)
            self.assertEqual(modes,['baseline','quality']);self.assertTrue(created[0].closed)
            self.assertIs(controller.overlay,created[1]);self.assertFalse(created[1].closed)
            self.assertEqual(created[1].settings,{'depth':True,'point_size':1.25,'roi':None})
            self.assertTrue(created[1].image_single_view and created[1].image_clean_view)
            controller.set_contour_refinement(True);self.assertEqual(len(created),2)
            controller.set_contour_refinement(False);self.assertEqual(modes,['baseline','quality','baseline'])
        self.assertEqual(view.CameraPosition,[1.,2.,3.])
        controller.source_closed();self.assertFalse(contour.enabled or contour.checked)
        self.assertEqual(logic.getReader().trailing,17)

    def test_refinement_cannot_create_an_overlay_without_a_replay_source(self):
        logic=replay_support.RecordedMenuTests().logic();logic.app.reader=None;contour=Action()
        try:controller=fusion_native.ImageFusionController(logic,Action(),Action(),contour_action=contour)
        except TypeError:self.fail('native refinement action missing')
        controller.set_contour_refinement(True)
        self.assertIsNone(controller.overlay);self.assertFalse(contour.checked)

    def test_status_reports_actual_contribution_not_only_window_count(self):
        overlay=replay_support.RecordedNativeTests().overlay();overlay.last_input=20;overlay.image_single_view=False
        packet={'sequence':20,'measurement_basis':'image_only','current_source':True,
            'fusion':{'state':'window_ready','scan_count':3,'window_scan_count':20,'effective_scan_count':3,
                'refinement_state':'joint_window','reference_sequence':20,'reference_time_s':10.,'age_s':0.}}
        status=overlay.packet_status(packet)
        self.assertIn('contributed 3',status);self.assertIn('window 20',status);self.assertIn('joint_window',status)

    def test_real_vtk_camera_interface_is_preserved_without_get_render_view(self):
        logic=replay_support.RecordedMenuTests().logic();position=[1.,2.,3.]
        camera=SimpleNamespace(GetPosition=lambda:tuple(position),GetFocalPoint=lambda:(0.,0.,0.),
            GetViewUp=lambda:(0.,0.,1.),GetParallelScale=lambda:4.,GetParallelProjection=lambda:1,
            SetPosition=lambda *v:position.__setitem__(slice(None),v),SetFocalPoint=lambda *v:None,
            SetViewUp=lambda *v:None,SetParallelScale=lambda v:None,SetParallelProjection=lambda v:None)
        logic.app.mainView=SimpleNamespace(GetRenderer=lambda:SimpleNamespace(GetActiveCamera=lambda:camera))
        controller=fusion_native.ImageFusionController(logic,Action(),Action(),contour_action=Action())
        def enable(native_logic,contour_mode='baseline'):
            if contour_mode=='quality':position[:]=[9.,9.,9.]
            native_logic.app.railOverlay=StyledOverlay(native_logic.getReader());return native_logic.app.railOverlay
        with patch.object(fusion_native,'enable_image',enable):
            controller.toggle(True);controller.set_contour_refinement(True)
        self.assertEqual(position,[1.,2.,3.])
