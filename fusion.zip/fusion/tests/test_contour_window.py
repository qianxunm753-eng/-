import importlib
from dataclasses import replace
import unittest
import numpy as np
from ..state import RefinementBudget,ScanRecord
from ..registration import LocalMap,transform
from .fixtures_contour import make_window,make_record,snapshot_bytes


class ContourWindowTests(unittest.TestCase):
    def module(self):
        try:return importlib.import_module('rsview_centerline.fusion.window_refinement')
        except ImportError:self.fail('joint multi-scan window refinement missing')

    def test_twenty_scan_joint_solve_tightens_without_moving_latest_anchor(self):
        m=self.module();records=make_window(20,pose_error_m=.02);poses=[r.pose.copy() for r in records]
        before=np.median([np.linalg.norm(r.pose[:3,3]) for r in records[:-1]])
        result=m.WindowRefiner().refine(records,RefinementBudget())
        self.assertTrue(result.accepted,result.reason)
        after=np.median([np.linalg.norm(r.pose[:3,3]) for r in result.records[:-1]])
        self.assertLess(after,before*.5)
        np.testing.assert_array_equal(result.records[-1].pose,records[-1].pose)
        for old,new,pose in zip(records,result.records,poses):
            np.testing.assert_array_equal(old.raw_xyz,new.raw_xyz)
            np.testing.assert_array_equal(old.corrected_xyz,new.corrected_xyz)
            np.testing.assert_array_equal(old.original_indices,new.original_indices)
            np.testing.assert_array_equal(old.pose,pose)

    def test_features_never_use_one_scan_or_validation_indices_as_training(self):
        m=self.module();self.assertEqual(m.build_patches(make_window(1)),())
        records=make_window(4);patches=m.build_patches(records,exclude_sequence=1)
        self.assertGreater(len(patches),0)
        for p in patches:
            self.assertGreaterEqual(len(set(p.scan_ids)),2)
            self.assertNotIn(1,p.scan_ids)
            self.assertTrue(np.all(np.asarray(p.original_indices)%5!=0))

    def test_parallel_plane_cannot_get_a_new_solved_pose(self):
        m=self.module();records=[]
        for r in make_window(4,.02):
            rows=np.arange(400)
            records.append(ScanRecord(r.source_key,r.sequence,r.reference_s,r.span_s,r.raw_xyz[rows],
                r.point_times[rows],r.original_indices[rows],None,r.corrected_xyz[rows],r.pose,None))
        result=m.WindowRefiner().refine(tuple(records),RefinementBudget())
        self.assertFalse(result.accepted)
        self.assertIn(result.reason,('unobservable_window','insufficient_shared_features'))

    def test_cancel_capacity_mixed_source_and_duplicate_are_rejected(self):
        m=self.module();records=make_window(4,.02)
        for invalid in (make_window(21),records+(records[-1],),records[::-1],
                        records[:-1]+(replace(records[-1],source_key=('other','device',0)),)):
            self.assertFalse(m.WindowRefiner().refine(invalid,RefinementBudget()).accepted)
        self.assertFalse(m.WindowRefiner().refine(records,RefinementBudget(deadline_s=0.)).accepted)
        self.assertFalse(m.WindowRefiner().refine(records,RefinementBudget(temporary_limit_bytes=1)).accepted)

    def test_joint_result_can_rebuild_consistent_predictor_without_mutating_old_map(self):
        m=self.module();records=make_window(5,.02);old=LocalMap();before=snapshot_bytes(old)
        result=m.WindowRefiner().refine(records,RefinementBudget())
        self.assertTrue(result.accepted,result.reason)
        rebuilt=old.rebuilt(result.records,RefinementBudget())
        self.assertEqual(snapshot_bytes(old),before)
        np.testing.assert_allclose(rebuilt.relative,np.linalg.inv(result.records[-2].pose)@result.records[-1].pose)
        self.assertAlmostEqual(rebuilt.previous_dt,.1)

    def test_mixed_parallel_surfaces_do_not_become_one_flat_constraint(self):
        m=self.module();records=[];grid=np.linspace(-.1,.1,12)
        a=np.array([[.705,y,z] for y in grid for z in grid]);b=a.copy();b[:,0]=.735
        points=np.vstack([a,b])
        for i in range(3):
            r=make_record(i);records.append(ScanRecord(r.source_key,i,r.reference_s,r.span_s,points,
                np.full(len(points),r.reference_s),np.arange(len(points)),None,points,np.eye(4),None))
        for patch in m.build_patches(tuple(records)):
            self.assertLess(np.ptp(patch.world_points[:,0]),.015)

    def test_sparse_rod_and_new_visible_returns_are_never_deleted(self):
        m=self.module();records=make_window(5,.02);last=records[-1]
        rod=np.array([[2.,2.,z] for z in np.linspace(.2,1.5,31)])
        xyz=np.vstack([last.raw_xyz,rod]);times=np.full(len(xyz),last.reference_s)
        latest=ScanRecord(last.source_key,last.sequence,last.reference_s,last.span_s,xyz,times,
            np.arange(len(xyz)),None,xyz,last.pose,None)
        result=m.WindowRefiner().refine(records[:-1]+(latest,),RefinementBudget())
        np.testing.assert_array_equal(result.records[-1].raw_xyz,xyz)
        np.testing.assert_array_equal(result.records[-1].corrected_xyz,xyz)

    def test_window_rebases_saved_trajectory_but_keeps_corrected_coordinates(self):
        from ..trajectory import TrajectoryModel
        m=self.module();records=list(make_window(5,.02));r=records[0]
        model=TrajectoryModel('gyro',(r.reference_s-.04,r.reference_s+.04),r.reference_s,r.pose,r.pose)
        records[0]=replace(r,model=model)
        result=m.WindowRefiner().refine(tuple(records),RefinementBudget())
        self.assertTrue(result.accepted,result.reason)
        np.testing.assert_allclose(result.records[0].model.reference_pose,result.records[0].pose,atol=1e-10)
        np.testing.assert_array_equal(result.records[0].corrected_xyz,r.corrected_xyz)

    def test_curved_hood_coordinates_are_not_projected_to_a_plane(self):
        m=self.module();records=[];angle=np.linspace(-1.,1.,61)
        hood=np.column_stack((1.8+.12*np.cos(angle),.12*np.sin(angle),np.full(61,1.3)))
        for r in make_window(5,.02):
            xyz=np.vstack([r.raw_xyz,hood])
            records.append(ScanRecord(r.source_key,r.sequence,r.reference_s,r.span_s,xyz,
                np.full(len(xyz),r.reference_s),np.arange(len(xyz)),None,xyz,r.pose,None))
        result=m.WindowRefiner().refine(tuple(records),RefinementBudget())
        for old,new in zip(records,result.records):np.testing.assert_array_equal(old.corrected_xyz,new.corrected_xyz)

    def test_a_minority_different_face_cannot_hide_inside_majority_plane(self):
        m=self.module();from scipy.spatial.transform import Rotation
        grid=np.linspace(-.075,.075,16);base=np.array([[x,y,0.] for x in grid for y in grid])
        records=[]
        for i in range(4):
            r=make_record(i);p=base.copy()
            if i==3:p=Rotation.from_euler('y',35,degrees=True).apply(p)
            p+=[.22,.22,.84]
            records.append(ScanRecord(r.source_key,i,r.reference_s,r.span_s,p,
                np.full(len(p),r.reference_s),np.arange(len(p)),None,p,np.eye(4),None))
        for patch in m.build_patches(tuple(records)):
            if patch.kind!='plane':continue
            c=patch.world_points-patch.world_points.mean(axis=0);unused,v=np.linalg.eigh(c.T@c)
            normal=v[:,0]
            for owner in np.unique(patch.owners):
                p=patch.world_points[patch.owners==owner]
                if len(p)<6:continue
                c=p-p.mean(axis=0);unused,vv=np.linalg.eigh(c.T@c)
                self.assertGreaterEqual(abs(normal@vv[:,0]),np.cos(np.deg2rad(20))-1e-6)

    def test_joint_training_updates_decrease_the_same_surface_objective(self):
        m=self.module();result=m.WindowRefiner().refine(make_window(20,.03),RefinementBudget())
        self.assertTrue(result.accepted,result.reason)
        self.assertTrue(hasattr(result,'training_costs'),'joint step acceptance evidence missing')
        self.assertGreaterEqual(len(result.training_costs),2)
        self.assertTrue(all(b<=a+1e-12 for a,b in zip(result.training_costs,result.training_costs[1:])))

    def test_edge_cost_counts_both_perpendicular_components(self):
        m=self.module()
        points=np.array([[x,y,z] for x in [-.2,.2] for y in [-.005,.005] for z in [-.007,.007]])
        patch=m.FeaturePatch('edge',(0,)*4+(1,)*4,np.arange(8),points,points,np.array([0]*4+[1]*4))
        self.assertAlmostEqual(m._feature_cost((patch,),(make_record(0),make_record(1))),.000074,places=10)
