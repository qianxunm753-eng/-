"""Image fusion regressions; fixtures are not production imports."""
