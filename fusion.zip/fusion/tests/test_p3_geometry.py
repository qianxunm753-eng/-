import importlib
import unittest
from dataclasses import replace
import numpy as np
from .fixtures_p3 import structure_snapshot
from ..state import RefinementBudget


class P3GeometryTests(unittest.TestCase):
    def geometry(self,snapshot):
        try:module=importlib.import_module('rsview_centerline.fusion.p3_geometry')
        except ImportError:self.fail('P3 fixed geometry support absent')
        return module.build_geometry(snapshot,RefinementBudget(),module.GeometryPolicy())

    def test_fit_and_check_are_disjoint_and_reference_excludes_owner(self):
        context=self.geometry(structure_snapshot(count=4))
        self.assertTrue(context.training_origins.isdisjoint(context.check_origins))
        self.assertTrue(context.check_references)
        for scan_id,reference in context.check_references:self.assertNotIn(scan_id,reference.owners)
        self.assertGreater(context.small_structure_count,0)
        self.assertGreaterEqual(context.background_fraction,.5)
        self.assertEqual(context.synthetic_points,0)

    def test_single_ring_scanning_stripe_is_not_physical_edge(self):
        context=self.geometry(structure_snapshot('stripe',count=4))
        self.assertEqual(context.stripe_as_edge_count,0)
        self.assertEqual(context.small_structure_count,0)
        self.assertTrue(context.unknown_origins)

    def test_curved_support_is_not_whole_lamp_plane(self):
        context=self.geometry(structure_snapshot('arc',count=4))
        self.assertGreater(context.small_structure_count,0)
        self.assertTrue(any(p.kind=='neighborhood' for p in context.patches))

    def test_parallel_thin_faces_are_not_forced_nearest_matches(self):
        context=self.geometry(structure_snapshot('thin_gap',count=4))
        self.assertGreater(context.ambiguous_association_count,0)
        self.assertEqual(context.forced_matches,0)

    def test_missing_ring_or_sparse_support_does_not_invent_edges(self):
        s=structure_snapshot('stripe',count=4)
        s=replace(s,scans=tuple(replace(r,rings=None) for r in s.scans))
        self.assertEqual(self.geometry(s).small_structure_count,0)
        self.assertEqual(self.geometry(structure_snapshot('sparse',count=2)).small_structure_count,0)

    def test_context_does_not_mutate_input(self):
        s=structure_snapshot(count=4);before=tuple(r.corrected_xyz.tobytes() for r in s.scans)
        self.geometry(s)
        self.assertEqual(tuple(r.corrected_xyz.tobytes() for r in s.scans),before)
