import sys
import subprocess
import os
import errno
from pathlib import Path
import time
import unittest
from unittest.mock import patch
from .fixtures_p3 import moving_requests,engine_fingerprint
from ..engine import ImageFusionEngine
from ..state import RefinementBudget
from ...clearance_process import ClearanceProcess


class P3IpcTests(unittest.TestCase):
    def host(self,config=None):
        host=ClearanceProcess(python=sys.executable,source_mode='recorded_pcap',config=config or
            dict(image_fusion_only=True,image_snapshot_support=True))
        self.addCleanup(host.close)
        self.assertTrue(hasattr(host,'request_image_control'),'isolated P3 control IPC absent')
        return host

    def packet(self,host,control=False):
        deadline=time.monotonic()+15.
        while time.monotonic()<deadline:
            packet=host.poll_image_control() if control else host.poll()
            if packet is not None:
                if not control:self.assertNotEqual(packet.get('status'),'failed',packet.get('error'))
                return packet
            time.sleep(.005)
        self.fail('real worker did not answer bounded request')

    def source(self,host):
        return tuple(host.current[k] for k in ('session_id','clock_id','epoch'))

    def test_freeze_drains_actual_inflight_and_pending_without_overwriting_current(self):
        host=self.host();frames=moving_requests(3)
        host.submit(frames[0]);host.submit(frames[1],force=True);host.submit(frames[2],force=True)
        current=dict(host.current);cadence=host.next_time;pid=host.child.pid
        self.assertTrue(host.request_image_control('freeze','drain',self.source(host)))
        self.assertFalse(host.submit(moving_requests(4)[-1],force=True))
        reply=self.packet(host,True)
        self.assertEqual(reply['state'],'frozen')
        self.assertEqual(reply['snapshot_key']['reference_sequence'],2)
        self.assertEqual(reply['snapshot_key']['source_frames'][-1],2)
        self.assertEqual(host.current,current);self.assertEqual(host.next_time,cadence)
        self.assertEqual(host.child.pid,pid);self.assertFalse(host.failed)
        normal=self.packet(host);self.assertEqual(normal['calculation'],'image_fusion_only')

    def test_twenty_actual_scans_refusal_keeps_worker_and_snapshot(self):
        host=self.host()
        for frame in moving_requests(20):
            host.submit(frame,force=True);self.packet(host)
        pid=host.child.pid;source=self.source(host);current=dict(host.current)
        host.request_image_control('freeze','twenty',source);frozen=self.packet(host,True)
        host.request_image_control('enhance','twenty',source,frozen['snapshot_key']);result=self.packet(host,True)
        self.assertEqual(result['state'],'baseline_retained')  # Three-plane scene, no asserted small device.
        self.assertEqual(result['snapshot_key']['source_frames'],tuple(range(20)))
        self.assertEqual(result['pair']['fused']['data'],frozen['pair']['fused']['data'])
        self.assertEqual(host.child.pid,pid);self.assertEqual(host.current,current)
        self.assertTrue(host.resume_image_submissions())
        host.submit(moving_requests(21)[-1],force=True);packet=self.packet(host)
        self.assertEqual(packet['fusion']['source_frames'],list(range(1,21)))

    def test_invalid_control_input_does_not_mutate_scan_identity(self):
        host=self.host();host.submit(moving_requests(1)[0]);self.packet(host);source=self.source(host);current=dict(host.current)
        for command,token,seconds,key in [('bad','x',1.,None),('freeze','',1.,None),('freeze','x'*65,1.,None),
            ('freeze','x',float('inf'),None),('freeze','x',float('nan'),None),('freeze','x',60.1,None),
            ('enhance','x',1.,None)]:
            with self.assertRaises(ValueError):host.request_image_control(command,token,source,key,seconds)
            self.assertEqual(host.current,current)

    def test_cancel_before_dispatch_is_not_worker_failure(self):
        host=self.host();host.submit(moving_requests(1)[0]);source=self.source(host);pid=host.child.pid
        host.request_image_control('freeze','cancel',source)
        self.assertTrue(host.cancel_image_control('cancel'))
        reply=self.packet(host,True);self.assertEqual(reply['state'],'cancelled')
        deadline=time.monotonic()+10.
        while not host.resume_image_submissions() and time.monotonic()<deadline:host.poll();time.sleep(.005)
        self.assertTrue(host.resume_image_submissions())
        self.assertFalse(host.failed);self.assertEqual(host.child.pid,pid)

    def test_enhancement_exception_does_not_reset_completed_engine(self):
        engine=ImageFusionEngine({'image_snapshot_support':True})
        for frame in moving_requests(20):engine.process(frame)
        before=engine_fingerprint(engine)
        self.assertTrue(hasattr(engine,'process_image_control'),'control dispatcher absent')
        source=engine.identity
        request=dict(command='freeze',request_id='exception',source_key=source,snapshot_key=None,budget_s=60.)
        frozen=engine.process_image_control(request,RefinementBudget())
        request.update(command='enhance',snapshot_key=frozen['snapshot_key'])
        with patch('rsview_centerline.fusion.p3_enhancement.enhance',side_effect=RuntimeError('optional failure')):
            reply=engine.process_image_control(request,RefinementBudget())
        self.assertEqual(reply['state'],'baseline_retained');self.assertEqual(engine_fingerprint(engine),before)

    def test_plain_clearance_or_parking_cannot_receive_image_controls(self):
        for config in ({'image_fusion_only':True,'image_contour_mode':'parking'},{'image_fusion_only':False}):
            host=self.host(config)
            with self.assertRaises(ValueError):host.request_image_control('freeze','not-image',('s','c',0))

    def test_control_key_cannot_contain_arbitrary_objects(self):
        from ...image_control import validate_control
        key=dict(session_id='s',clock_id='c',epoch=0,generation=1,revision=1,
            reference_sequence=0,reference_time_s=1.,source_frames=(0,))
        for field in ('generation','revision','reference_time_s'):
            with self.assertRaises(ValueError):validate_control('enhance','x',('s','c',0),dict(key,**{field:object()}))

    def test_clock_rounding_never_extends_sixty_second_wire_budget(self):
        host=self.host();host.submit(moving_requests(1)[0]);self.packet(host)
        host.image_control.clock=lambda:16360.01
        host.request_image_control('freeze','clock',self.source(host),budget_s=60.)
        self.assertLessEqual(host.image_control.running['budget_s'],60.)
        self.assertGreater(host.image_control.running['budget_s'],0.)

    def test_deadline_cancels_control_without_terminating_base_process(self):
        host=self.host();host.submit(moving_requests(1)[0]);self.packet(host);pid=host.child.pid
        host.request_image_control('freeze','deadline',self.source(host),budget_s=.000001)
        reply=self.packet(host,True)
        self.assertEqual(reply['state'],'cancelled')
        self.assertFalse(host.failed);self.assertIsNone(host.child.poll());self.assertEqual(host.child.pid,pid)

    def test_duplicate_freeze_is_not_a_new_window_or_deadline(self):
        host=self.host();host.submit(moving_requests(1)[0]);self.packet(host)
        source=self.source(host);host.request_image_control('freeze','unique',source);self.packet(host,True)
        deadline=host.image_control.deadline
        with self.assertRaises(ValueError):host.request_image_control('freeze','unique',source)
        self.assertEqual(host.image_control.deadline,deadline)

    def test_embedded_standalone_import_does_not_require_package_parent(self):
        folder=str(Path(__file__).resolve().parents[2])
        script='''
import sys,builtins
sys.path.insert(0,sys.argv[1])
original=builtins.__import__
def standalone(name,*args,**kwargs):
    if name=='rsview_centerline.image_control':raise ImportError('embedded standalone import')
    return original(name,*args,**kwargs)
builtins.__import__=standalone
from clearance_process import ClearanceProcess
host=ClearanceProcess(python=sys.executable,source_mode='recorded_pcap',config={'image_fusion_only':True})
try:
    assert host.image_control.enabled
finally:host.close()
'''
        completed=subprocess.run([sys.executable,'-c',script,folder],capture_output=True,text=True)
        self.assertEqual(completed.returncode,0,completed.stderr)

    def test_transient_result_file_lock_does_not_discard_completed_scan(self):
        host=self.host();host.submit(moving_requests(1)[0]);deadline=time.monotonic()+10.
        while not os.path.isfile(host._path('result')) and time.monotonic()<deadline:time.sleep(.005)
        self.assertTrue(os.path.isfile(host._path('result')))
        running=dict(host.running)
        with patch('rsview_centerline.clearance_process._read',side_effect=OSError(errno.EACCES,'temporary sharing lock')):
            self.assertIsNone(host.poll())
        self.assertEqual(host.running,running);self.assertFalse(host.failed)
        packet=self.packet(host);self.assertEqual(packet['status'],'completed');self.assertEqual(packet['sequence'],0)
