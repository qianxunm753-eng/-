import importlib
import struct
import unittest
import time
import numpy as np


def scene():
    a=np.linspace(-.4,.4,20)
    return np.array([[.7,x,y+1.] for x in a for y in a]+[[x,.8,y+1.] for x in a for y in a]+
                    [[x,y,1.5] for x in a for y in a])


def imu_packet(second,raw=(0,0,32768),gyro_range=0):
    packet=bytearray(51);packet[:4]=b'\xaa\x55\x5a\x05'
    packet[4:10]=int(second).to_bytes(6,'big')
    struct.pack_into('>3i',packet,26,*raw);packet[44]=gyro_range;packet[-2:]=b'\xf0\x0f'
    return bytes(packet)


class CoreTests(unittest.TestCase):
    def setUp(self):
        try:
            self.imu=importlib.import_module('rsview_centerline.fusion.imu')
            self.registration=importlib.import_module('rsview_centerline.fusion.registration')
        except ImportError:self.fail('image-only IMU / local-map implementation absent')

    def test_analytical_rotation_deskew_uses_real_point_time(self):
        series=self.imu.ImuSeries([0.,1.],[[0.,0.,np.pi/2]]*2)
        points=series.deskew(np.array([[1.,0.,0.],[1.,0.,0.]]),np.array([0.,1.]),1.)
        np.testing.assert_allclose(points,[[0.,-1.,0.],[1.,0.,0.]],atol=1e-12)
        with self.assertRaises(ValueError):series.deskew(np.array([[1.,0.,0.]]),np.array([-1.]),0.)

    def test_airys_actual_gyro_range_and_difop_rotation(self):
        difop=bytearray(1248);difop[:4]=b'\xa5\xff\x00\x5a'
        struct.pack_into('>7f',difop,1092,0.,0.,0.,1.,0.,0.,0.)
        series=self.imu.ImuSeries.from_packets([(0.,7788,bytes(difop)),(0.,6688,imu_packet(0)),
            (1.,6688,imu_packet(1))])
        self.assertAlmostEqual(series.gyro[0,2],np.deg2rad(250.),places=12)
        self.assertEqual(series.diagnostics['real_imu_samples'],2)
        with self.assertRaises(ValueError):self.imu.ImuSeries.from_packets([(0.,6688,imu_packet(0))])

    def test_recording_clock_reset_is_not_sorted_into_a_false_imu_timeline(self):
        difop=bytearray(1248);difop[:4]=b'\xa5\xff\x00\x5a'
        struct.pack_into('>7f',difop,1092,0.,0.,0.,1.,0.,0.,0.)
        with self.assertRaises(ValueError):
            self.imu.ImuSeries.from_packets([(0.,7788,bytes(difop)),(0.,6688,imu_packet(2)),
                (1.,6688,imu_packet(0)),(2.,6688,imu_packet(1))])

    def test_stationary_repeated_scene_has_no_invented_motion(self):
        mapper=self.registration.LocalMap()
        points=scene()
        for stamp in (1.,1.1,1.2):
            result=mapper.update(points,np.full(len(points),stamp),None,stamp,None)
        self.assertTrue(result.usable,result.diagnostics)
        np.testing.assert_allclose(result.pose,np.eye(4),atol=.001)

    def test_translated_scene_aligns_to_past_map_without_zero_speed_gate(self):
        mapper=self.registration.LocalMap();points=scene()
        mapper.update(points,np.ones(len(points)),None,1.,None)
        result=mapper.update(points-[.02,0.,0.],np.full(len(points),1.1),None,1.1,None)
        self.assertTrue(result.usable,result.diagnostics)
        self.assertAlmostEqual(result.pose[0,3],.02,delta=.003)
        self.assertEqual(result.diagnostics['target_latest_time_s'],1.)

    def test_unobservable_plane_does_not_enter_map_as_solved_pose(self):
        mapper=self.registration.LocalMap()
        points=np.array([[x,y,1.] for x in np.linspace(-1,1,25) for y in np.linspace(-1,1,25)])
        mapper.update(points,np.ones(len(points)),None,1.,None)
        result=mapper.update(points,np.full(len(points),1.1),None,1.1,None)
        self.assertFalse(result.usable)
        self.assertEqual(mapper.last_good_time,1.)

    def test_large_display_voxel_selection_cpu_budget(self):
        points=np.random.default_rng(17).uniform(-10.,10.,(600000,3))
        started=time.process_time()
        rows=self.registration.representatives(points,.008,150000)
        cpu=time.process_time()-started
        self.assertEqual(len(rows),150000)
        self.assertLess(cpu,.3,'structured voxel sorting dominates the image pipeline')

    def test_voxel_representatives_keep_first_real_point_for_negative_and_extreme_keys(self):
        for points in (np.array([[-.009,0,0],[-.0091,0,0],[.009,0,0],[0,0,0]]),
                       np.array([[-1e9,-1e9,-1e9],[1e9,1e9,1e9],[1e9,1e9,1e9]])):
            rows=self.registration.representatives(points,.008,100)
            unused,expected=np.unique(np.floor(points/.008).astype(np.int64),axis=0,return_index=True)
            np.testing.assert_array_equal(rows,expected)

    def test_imu_can_constrain_rotation_when_translation_is_observable(self):
        from scipy.spatial import cKDTree
        mapper=self.registration.LocalMap()
        normals=np.repeat(np.eye(3),80,axis=0)
        # At least 50 fitting representatives after the 9cm fit voxel; tiny
        # shifts avoid changing the known correspondence on these test rays.
        target=normals*np.tile(np.linspace(1.,4.,80),3)[:,None]
        mapper.geometry=(target,cKDTree(target),normals,np.ones(len(target)))
        pose,result=mapper._align(target-[.001,.002,.003],np.eye(4),(.1,),5,imu_rotation=np.eye(3))
        self.assertTrue(result['usable'],result)
        np.testing.assert_allclose(pose[:3,3],[.001,.002,.003],atol=1e-9)
        self.assertEqual(result['rotation_constraint'],'same-recording IMU')

    def test_gap_between_valid_scan_brackets_disables_the_imu_rotation_constraint(self):
        imu=self.imu.ImuSeries([0.,.005,.01,.11,.115,.12],[[0.,0.,1.]]*6,max_gap_s=.025)
        mapper=self.registration.LocalMap();points=scene()
        mapper.update(points,np.full(len(points),.005),None,.005,imu)
        result=mapper.update(points,np.full(len(points),.115),None,.115,imu)
        self.assertFalse(result.diagnostics['imu_active'],'missing inter-scan gyro interval was treated as supported rotation')
        self.assertIn('IMU sample gap',result.diagnostics['imu_status'])

    def test_reported_residual_checks_the_final_pose_not_the_previous_iteration(self):
        mapper=self.registration.LocalMap();points=scene()
        mapper.update(points,np.ones(len(points)),None,1.,None)
        pose,result=mapper._align(points-[.025,.015,.01],np.eye(4),(.3,),1)
        self.assertTrue(result['usable'],result)
        self.assertLess(result['residual_p90_m'],.002,
            'acceptance still uses residuals computed before the final pose update')
        self.assertAlmostEqual(pose[0,3],.025,delta=.002)

    def test_a_small_matching_patch_does_not_validate_an_otherwise_unmatched_scan(self):
        mapper=self.registration.LocalMap();points=scene()
        mapper.update(points,np.ones(len(points)),None,1.,None)
        unmatched=np.random.default_rng(103).uniform(4.,9.,(6000,3))
        unused,result=mapper._align(np.vstack([points,unmatched]),np.eye(4),(.1,),5)
        self.assertFalse(result['usable'],'a tiny overlap accepted a largely unsupported scan')
        self.assertEqual(result['reason'],'insufficient_overlap')

    def test_light_display_filter_removes_only_isolated_representatives(self):
        # Dense surface and sparse 4cm rod must survive. The separated return
        # has no neighbour within the range-adaptive display radius.
        points=np.array([[1.,0.,0.],[1.,.01,0.],[1.,.02,0.],
                         [2.,0.,0.],[2.,0.,.04],[2.,0.,.08],[6.,6.,0.]])
        self.assertTrue(hasattr(self.registration,'display_support'),
            'bounded real-return display filter absent')
        rows=self.registration.display_support(points)
        np.testing.assert_array_equal(rows,[0,1,2,3,4,5])

    def test_light_display_filter_does_not_use_height_or_remove_the_ground(self):
        self.assertTrue(hasattr(self.registration,'display_support'))
        points=np.array([[1.,0.,-2.],[1.,.04,-2.],[1.,.08,-2.]])
        np.testing.assert_array_equal(self.registration.display_support(points),[0,1,2])

    def test_translation_deskew_refines_a_real_scan_not_just_its_frame_pose(self):
        mapper=self.registration.LocalMap();world=scene();reference=1.1
        mapper.update(world,np.ones(len(world)),None,1.,None)
        # Independently constructed constant-velocity measurements: the cart
        # moves 4cm over this scan; raw returns belong to different poses.
        times=np.random.default_rng(307).uniform(1.,reference,len(world))
        observed=world-(times-1.)[:,None]*np.array([.4,0.,0.])
        result=mapper.update(observed,times,None,reference,None)
        self.assertTrue(result.usable,result.diagnostics)
        self.assertAlmostEqual(result.pose[0,3],.04,delta=.002)
        recovered=self.registration.transform(result.points,result.pose)
        self.assertLess(np.percentile(np.linalg.norm(recovered-world,axis=1),95),.002,
            'frame alignment passed but within-scan translation still broadens the surface')
        self.assertTrue('deskew_refinement_converged' in result.diagnostics,
            'work limit must not silently masquerade as velocity convergence')
        self.assertFalse(result.diagnostics['deskew_refinement_converged'])
        self.assertEqual(result.diagnostics['deskew_refinement_state'],'work_limit_reached')

    def test_failed_fine_solve_reports_rejection_and_does_not_commit_the_map(self):
        from unittest.mock import patch
        mapper=self.registration.LocalMap();points=scene()
        mapper.update(points,np.ones(len(points)),None,1.,None)
        original=mapper._align
        def fine_failure(source,initial,distances,iterations,imu_rotation=None):
            if distances==(.10,):
                return initial.copy(),dict(usable=False,reason='unobservable_map')
            return original(source,initial,distances,iterations,imu_rotation)
        with patch.object(mapper,'_align',side_effect=fine_failure):
            result=mapper.update(points-[.02,0.,0.],np.full(len(points),1.1),None,1.1,None)
        self.assertFalse(result.usable)
        self.assertEqual(result.diagnostics.get('deskew_refinement_state'),'registration_rejected')
        self.assertEqual(mapper.last_good_time,1.)
        np.testing.assert_array_equal(mapper.pose,np.eye(4))


if __name__=='__main__':unittest.main()
