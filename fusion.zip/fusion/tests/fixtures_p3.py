"""Independent bounded fixtures and fingerprints for the P3 enhancement contract."""
import hashlib
import subprocess
import types
import numpy as np
from .test_core import scene
from .test_engine import request


def moving_requests(count=20):
    return [request(i, scene()-[i*.01, 0., 0.]) for i in range(count)]


def engine_fingerprint(engine):
    def digest(array):
        return hashlib.sha256(np.asarray(array).tobytes()).hexdigest()
    records=tuple((r['sequence'],r['time'],*(digest(r[k]) for k in
        ('xyz','indices','point_times','pose'))) for r in engine.window)
    pair=engine.last_pair or {}
    return (records,digest(engine.mapper.pose),digest(engine.mapper.relative),
        tuple(pair.get('source_frames',())),tuple((k,hashlib.sha256(pair[k]['data']).hexdigest())
        for k in ('fused','single','clean_fused','clean_single') if k in pair))


def locked_engine():
    source=subprocess.check_output(['git','show','d1a26ac5:rsview_centerline/fusion/engine.py'])
    module=types.ModuleType('rsview_centerline.fusion._locked_p3_engine')
    module.__package__='rsview_centerline.fusion'
    exec(compile(source,'locked-d1a26ac5-engine.py','exec'),module.__dict__)
    return module.ImageFusionEngine()


def structure_snapshot(kind='mixed',pose_error_m=0.,seed=20261013,count=20):
    """Known static real-return geometry with erroneous BASE frame poses only."""
    from ..p3_snapshot import SnapshotKey,CompensatedScan,CompensatedWindowSnapshot,selection,readonly
    from ..engine import ImageFusionEngine
    from ..registration import transform
    rng=np.random.default_rng(seed)
    grid=np.linspace(-.48,.48,33);u,v=np.meshgrid(grid,grid);u=u.ravel();v=v.ravel()
    planes=[np.c_[u,v,np.ones(len(u))],np.c_[np.full(len(u),-1.),u,v+1.],np.c_[u,np.ones(len(u)),v+1.]]
    z=np.linspace(.7,1.1,120);rod=np.c_[np.full(len(z),2.),np.full(len(z),.4),z]
    theta,height=np.meshgrid(np.linspace(-1.3,1.3,48),np.linspace(.8,1.1,20))
    arc=np.c_[3.+.13*np.cos(theta.ravel()),.13*np.sin(theta.ravel()),height.ravel()]
    if kind=='single_plane':world=planes[0]
    elif kind=='stripe':world=rod
    elif kind=='arc':world=arc
    elif kind=='sparse':world=rod[::40]
    elif kind=='thin_gap':world=np.vstack([np.c_[np.full(len(u),2.005),u,v+1.],np.c_[np.full(len(u),2.015),u,v+1.]])
    else:world=np.vstack(planes+[rod,arc])
    scans=[]
    for seq in range(count):
        noise=rng.normal(0.,.000015,world.shape)
        points=world+noise;pose=np.eye(4)
        if seq!=count-1:pose[0,3]=pose_error_m*np.sin(seq*1.9)
        rings=np.full(len(world),3,dtype=np.int32) if kind=='stripe' else np.arange(len(world),dtype=np.int32)%96
        indices=np.arange(len(world),dtype=np.int64);stamp=1.+seq*.1
        scans.append(CompensatedScan(seq,stamp,(stamp,stamp),points,np.full(len(points),stamp),indices,pose,rings))
    fused=np.concatenate([transform(r.corrected_xyz,r.pose) for r in scans]);single=scans[-1].corrected_xyz
    engine=ImageFusionEngine();pair=dict(engine.paired_views(fused,single),source_frames=list(range(count)),
        sequence=count-1,time=scans[-1].reference_s,raw_points=len(fused),bytes=sum(len(r.corrected_xyz)*40 for r in scans))
    origins=np.c_[np.repeat(np.arange(count),len(world)),np.tile(np.arange(len(world)),count)]
    display=dict(fused=readonly(origins[selection(fused,150000)]),single=readonly(np.c_[np.full(len(single),count-1),np.arange(len(single))][selection(single,150000)]))
    key=SnapshotKey('synthetic:p3','actual:synthetic',0,1,count,count-1,scans[-1].reference_s,tuple(range(count)))
    return CompensatedWindowSnapshot(key,tuple(scans),pair,display)
