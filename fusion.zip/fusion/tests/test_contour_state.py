import importlib
import pickle
import time
import unittest
import numpy as np
from unittest.mock import patch
from .test_core import scene
from .test_engine import request
from ..engine import ImageFusionEngine
from ..registration import LocalMap


def snapshot_bytes(mapper):
    geometry=None if mapper.geometry is None else (mapper.geometry[0],mapper.geometry[2],mapper.geometry[3])
    return pickle.dumps((list(mapper.keys),geometry,mapper.pose,mapper.relative,
        mapper.previous_dt,mapper.last_good_time,mapper.key_time,mapper.key_pose),protocol=4)


class ContourStateTests(unittest.TestCase):
    def state(self):
        try:return importlib.import_module('rsview_centerline.fusion.state')
        except ImportError:self.fail('immutable contour records / budget are missing')

    def record(self,sequence=0,points=None):
        s=self.state();points=scene() if points is None else points;t=1.+sequence*.1
        return s.ScanRecord(('test','clock',0),sequence,t,(t,t),points,
            np.full(len(points),t),np.arange(len(points)),None,points,np.eye(4),None)

    def test_owned_record_does_not_freeze_or_alias_caller(self):
        points=scene();record=self.record(points=points)
        self.assertTrue(points.flags.writeable)
        self.assertFalse(record.raw_xyz.flags.writeable)
        before=record.raw_xyz.copy();points[:]=0.
        np.testing.assert_array_equal(record.raw_xyz,before)
        self.assertIs(record.raw_xyz,record.corrected_xyz)

    def test_window_counts_shared_storage_once_and_distinct_storage_twice(self):
        s=self.state();r=self.record();expected=r.raw_xyz.nbytes+r.point_times.nbytes+r.original_indices.nbytes+r.pose.nbytes
        self.assertEqual(s.retained_bytes((r,)),expected)
        r2=s.ScanRecord(r.source_key,1,r.reference_s,r.span_s,r.raw_xyz,r.point_times,
            r.original_indices,None,r.raw_xyz+1.,r.pose,None)
        self.assertEqual(s.retained_bytes((r,r2)),expected+r.raw_xyz.nbytes)

    def test_budget_rejects_before_allocation_and_after_deadline_or_cancel(self):
        s=self.state();budget=s.RefinementBudget(deadline_s=time.monotonic()+60.)
        self.assertFalse(budget.check(64*1024**2+1))
        self.assertTrue(budget.check(1024))
        self.assertFalse(s.RefinementBudget(deadline_s=0.).check(0))
        self.assertFalse(s.RefinementBudget(cancelled=lambda:True).check(0))

    def test_record_rejects_mismatched_or_out_of_span_points(self):
        s=self.state();r=self.record()
        with self.assertRaises(ValueError):s.ScanRecord(r.source_key,1,1.,(1.,1.),r.raw_xyz,
            np.full(len(r.raw_xyz),2.),r.original_indices,None,r.corrected_xyz,r.pose,None)

    def test_capacity_refusal_keeps_the_map_and_prediction(self):
        engine=ImageFusionEngine({'image_byte_budget':1});before=snapshot_bytes(engine.mapper)
        packet=engine.process(request())
        self.assertEqual(packet['relative_pose_diagnostics']['reason'],'image_capacity_reached')
        self.assertEqual(snapshot_bytes(engine.mapper),before)
        self.assertIsNone(engine.last_pair)

    def test_capacity_refusal_after_good_frame_preserves_entire_pair(self):
        engine=ImageFusionEngine();engine.process(request());before=snapshot_bytes(engine.mapper)
        old=engine.last_pair;engine.byte_budget=1
        packet=engine.process(request(1,scene()-[.01,0.,0.]))
        self.assertEqual(snapshot_bytes(engine.mapper),before)
        self.assertIs(engine.last_pair,old)
        self.assertTrue(packet['fusion']['held'])

    def test_map_fork_and_rebuild_do_not_change_original(self):
        s=self.state();mapper=LocalMap();r=self.record()
        mapper.update(scene(),r.point_times,None,1.,None);before=snapshot_bytes(mapper)
        self.assertTrue(hasattr(mapper,'fork'),'transactional map fork missing')
        fork=mapper.fork();fork.update(scene()-[.03,0.,0.],r.point_times+.1,None,1.1,None)
        self.assertEqual(snapshot_bytes(mapper),before)
        rebuilt=mapper.rebuilt((r,),s.RefinementBudget())
        self.assertIsNot(rebuilt,mapper)
        self.assertEqual(snapshot_bytes(mapper),before)
        self.assertEqual(rebuilt.key_sources[-1],(r.source_key,r.sequence))

    def test_bad_rebuild_cannot_commit_a_partial_map(self):
        s=self.state();mapper=LocalMap();r=self.record();before=snapshot_bytes(mapper)
        self.assertTrue(hasattr(mapper,'rebuilt'),'validated map rebuild missing')
        with self.assertRaises(ValueError):mapper.rebuilt((r,r),s.RefinementBudget())
        with self.assertRaises(ValueError):mapper.rebuilt((r,),s.RefinementBudget(deadline_s=0.))
        self.assertEqual(snapshot_bytes(mapper),before)

    def test_failed_view_pack_does_not_partially_commit_the_window(self):
        engine=ImageFusionEngine();engine.process(request());before=snapshot_bytes(engine.mapper)
        old_pair=engine.last_pair;old_window=list(engine.window)
        with patch.object(engine,'paired_views',side_effect=MemoryError('bounded pack failed')):
            with self.assertRaises(MemoryError):engine.process(request(1))
        self.assertEqual(snapshot_bytes(engine.mapper),before)
        self.assertEqual(len(engine.window),len(old_window))
        self.assertIs(engine.last_pair,old_pair)

    def test_valid_default_pair_matches_preserved_v2_math(self):
        import subprocess,types
        source=subprocess.check_output(['git','show','ad79c73:rsview_centerline/fusion/engine.py'],encoding='utf8')
        module=types.ModuleType('rsview_centerline.fusion.saved_v2');module.__package__='rsview_centerline.fusion'
        exec(compile(source,'saved-v2','exec'),module.__dict__)
        old=module.ImageFusionEngine();new=ImageFusionEngine()
        for seq in range(22):
            req=request(seq,scene()-[seq*.01,0.,0.]);a=old.process(req);b=new.process(req)
            self.assertEqual(a['_display'],b['_display'])
            self.assertEqual(a['_single_display'],b['_single_display'])
            self.assertEqual(a['fusion']['source_frames'],b['fusion']['source_frames'])
