"""The replay window distance branch owns one frozen mature image window."""
import unittest
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np

from ... import fusion_native, clearance_native, clearance_overlay
from ...clearance.tests.test_live_clearance import Action
from ...clearance.tests import test_recorded_playback as replay_support
from . import test_parking_native as parking_support
from . import test_p3_native as p3_support


class MenuAction(Action):
    def __init__(self, title, owner):
        super().__init__(); self.title = title; self.slots = {}; self.name = None
    def setObjectName(self, name): self.name = name
    def setCheckable(self, value): self.checkable = value
    def setToolTip(self, value): self.tooltip = value
    def connect(self, signal, slot): self.slots[signal] = slot


class Menu:
    def __init__(self): self.actions = []
    def addAction(self, action): self.actions.append(action)
    def addMenu(self, title): return Menu()


class WindowMeasurementNativeTests(unittest.TestCase):
    def controller(self):
        controller, logic, unused = parking_support.ParkingNativeTests().controller()
        controller.window_measurement_action = Action()
        controller.measure_action = Action()
        controller.p3_action = Action(); controller.surface_action = Action()
        controller.motion_detail_action = Action()
        controller.pending_window_action = Action()
        return controller, logic

    def enabled(self, logic, **options):
        overlay = parking_support.ParkingStyledOverlay(logic.getReader())
        overlay.host = p3_support.ControlHost()
        overlay.requested_frame = overlay.last_input = 19
        overlay.worker_config = dict(image_fusion_only=True, **options)
        if options.get('window_measurement'):overlay.worker_config['image_window_measurement'] = True
        logic.app.railOverlay = overlay
        return overlay

    def overlay(self):
        overlay = p3_support.P3NativeTests().overlay()
        overlay.worker_config['image_window_measurement'] = True
        return overlay

    def measured(self, driver):
        control = p3_support.receipt(driver, 'accepted')
        control.update(command='measure', reason='rolling_window_measured')
        key = control['snapshot_key']
        item = dict(distance_m=.8, uncertain=False, display_id='R1', flags=[], point_count=40,
            point_L=[2., .8, .4], projected_L=[2., .8, 0.], foot_L=[2., 0., 0.],
            measurement_basis='rolling_20_window')
        packet = dict(sequence=19, device_time_s=key['reference_time_s'], session_id=key['session_id'], clock_id=key['clock_id'],
            epoch=key['epoch'], centerline=[([0., 0., 0.], [4., 0., 0.])], measurements=[item],
            secondary_measurements=[], config_id='window-fixture', mode='nominal',
            measurement_basis='rolling_20_window', current_scan_measurement=False,
            absolute_accuracy_verified=False, semantic_one_object_one_label_verified=False,
            window_measurement=dict(state='measured', scan_count=20, source_frames=list(range(20)),
                reference_sequence=19, reference_time_s=key['reference_time_s'], age_s=1.9))
        control['report']['measurement_packet'] = packet
        return control

    def with_pending(self, control):
        pending = dict(distance_m=.42, uncertain=True, flags=['pending_window_raw_preview'], point_count=12,
            point_L=[3., .42, .2], projected_L=[3., .42, 0.], foot_L=[3., 0., 0.],
            measurement_basis='rolling_20_window', window_raw_preview=True, supported_distance_m=None,
            source_sequence=5, source_index=72, source_time_s=1.5)
        packet = control['report']['measurement_packet']
        packet['pending_window_measurements'] = [pending]
        packet['window_measurement'].update(pending_preview_count=1, qualified_annotation_count=1)
        return control

    def freeze_and_measure(self, overlay):
        driver = fusion_native.P3ReplayEnhancement(overlay.host, lambda: 100., command='measure')
        driver.begin((overlay.session, overlay.clock, 0)); overlay.p3_driver = driver
        overlay.set_p3_receiver(driver.accepts, lambda packet: None, True)
        overlay.host.control_packet = p3_support.receipt(driver); overlay.poll()
        overlay.host.control_packet = self.measured(driver); overlay.poll()
        return driver

    def test_enable_uses_mature_image_worker_with_separate_window_measurement_config(self):
        # Dropping the opt-in or flattening measurement options would change
        # the mature image registration policy instead of annotating its window.
        logic = SimpleNamespace(getReaderFileName=lambda: 'C:/测试/333.pcap')
        with patch.object(fusion_native, 'enable_recorded', side_effect=lambda logic, config: config):
            try:
                config = fusion_native.enable_image(logic, window_measurement=True)
            except TypeError:
                self.fail('window measurement native opt-in is missing')
        self.assertTrue(config['image_fusion_only'])
        self.assertTrue(config['image_snapshot_support'])
        self.assertTrue(config['image_window_measurement'])
        self.assertEqual(config['image_display_limit'], 150000)
        self.assertEqual(config['image_source_path'], 'C:/测试/333.pcap')
        nested = config['image_window_measurement_config']
        self.assertEqual(nested['config_id'], 'rsview-replay-bounded-fast-continuity-beta-v32')
        self.assertTrue(nested['above_rail_uncertainty'])
        self.assertNotIn('above_rail_measurement_only', config)
        self.assertNotIn('image_motion_detail', config)

    def test_window_option_rejects_nonboolean_and_other_registration_policies(self):
        logic = SimpleNamespace(getReaderFileName=lambda: '333.pcap')
        cases = [dict(window_measurement=1), dict(window_measurement='true'),
                 dict(window_measurement=True, motion_detail=True),
                 dict(window_measurement=True, contour_mode='parking'),
                 dict(window_measurement=True, contour_mode='quality')]
        with patch.object(fusion_native, 'enable_recorded', side_effect=lambda logic, config: config):
            for options in cases:
                with self.subTest(options=options), self.assertRaises(ValueError):
                    fusion_native.enable_image(logic, **options)

    def test_original_baseline_has_measure_capability_without_entering_measurement_view(self):
        logic = SimpleNamespace(getReaderFileName=lambda: '333.pcap')
        with patch.object(fusion_native, 'enable_recorded', side_effect=lambda logic, config: config):
            baseline = fusion_native.enable_image(logic)
            detail = fusion_native.enable_image(logic, motion_detail=True)
        self.assertTrue(baseline.get('image_window_measurement_capable'))
        self.assertFalse(baseline.get('image_window_measurement', False))
        self.assertIn('image_window_measurement_config', baseline)
        self.assertFalse(detail.get('image_window_measurement_capable', False))

    def test_original_twenty_window_can_calculate_directly_without_branch_checkbox(self):
        c, logic = self.controller(); overlay = self.overlay()
        overlay.worker_config.pop('image_window_measurement')
        overlay.worker_config['image_window_measurement_capable'] = True
        c.overlay = overlay; overlay.logic = logic
        c.source_ready()
        self.assertFalse(c.window_measurement_action.checked)
        self.assertTrue(c.measure_action.enabled, 'mature image window must not need a second checkbox')
        host = overlay.host
        with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)), \
             patch.object(fusion_native, 'enable_image') as rebuild:
            c.calculate_window_measurement()
            self.assertTrue(c.window_measurement_action.checked)
            self.assertEqual(host.commands[-1][0], 'freeze')
            overlay.host.control_packet = p3_support.receipt(c.p3_driver); overlay.poll()
            overlay.host.control_packet = self.measured(c.p3_driver); overlay.poll()
            self.assertEqual(overlay.last_result['measurement_basis'], 'rolling_20_window')
            self.assertFalse(c.p3_driver.processing)
            self.assertTrue(c.measure_action.enabled)
            self.assertEqual(host.requests, [])
            self.assertIs(c.overlay, overlay); self.assertIs(overlay.host, host)
            rebuild.assert_not_called()

    def test_compatible_baseline_branch_toggle_preserves_worker_and_image_window(self):
        c, logic = self.controller(); overlay = self.overlay()
        overlay.worker_config.pop('image_window_measurement')
        overlay.worker_config['image_window_measurement_capable'] = True
        c.overlay = overlay; overlay.logic = logic; host = overlay.host
        with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)), \
             patch.object(fusion_native, 'enable_image') as rebuild:
            c.set_window_measurement(True)
            self.assertTrue(c.window_measurement_action.checked)
            self.assertTrue(c.measure_action.enabled)
            c.set_window_measurement(False)
            self.assertFalse(c.window_measurement_action.checked)
            self.assertTrue(c.measure_action.enabled)
            self.assertIs(c.overlay, overlay); self.assertIs(overlay.host, host)
            self.assertEqual(host.commands, []); self.assertEqual(host.requests, [])
            self.assertFalse(overlay.closed)
            rebuild.assert_not_called()

    def test_explicit_calculation_with_no_qualified_result_shows_labeled_pending_preview(self):
        c, logic = self.controller(); overlay = self.overlay()
        c.overlay = overlay; overlay.logic = logic
        with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)):
            c.calculate_window_measurement()
            overlay.host.control_packet = p3_support.receipt(c.p3_driver); overlay.poll()
            result = self.with_pending(self.measured(c.p3_driver))
            result['report']['measurement_packet']['measurements'] = []
            result['report']['measurement_packet']['window_measurement']['qualified_annotation_count'] = 0
            overlay.host.control_packet = result; overlay.poll()
            self.assertTrue(c.pending_window_action.checked)
            self.assertTrue(overlay.window_pending_view)
            self.assertEqual(overlay.last_result['_qualified_window_measurements'], [])
            self.assertEqual(len(overlay.last_result['measurements']), 1)
            label = clearance_overlay.measurement_label(overlay.last_result['measurements'][0])
            self.assertIn('20F Window raw ?', label)
            self.assertIn('qualified 0', overlay.packet_status(overlay.last_result))
            c.set_window_pending(False)
            self.assertEqual(overlay.last_result['measurements'], [])
            self.assertFalse(c.pending_window_action.checked)

    def test_window_branch_rejects_live_source_even_when_an_old_reader_exists(self):
        logic = SimpleNamespace(getReaderFileName=lambda: 'old.pcap', getSensor=lambda: object())
        with patch.object(fusion_native, 'enable_recorded', side_effect=lambda logic, config: config):
            with self.assertRaises(ValueError):
                fusion_native.enable_image(logic, window_measurement=True)

    def test_non_pcap_or_wrong_lidar_cannot_create_window_overlay(self):
        for filename, model in [('333.bin', 'RSAIRY'), ('333.pcap', 'RS16')]:
            logic = replay_support.RecordedMenuTests().logic(filename, model)
            with self.subTest(filename=filename, model=model), self.assertRaises(ValueError):
                fusion_native.enable_image(logic, window_measurement=True)
            self.assertIsNone(logic.app.railOverlay)

    def test_branch_switch_rebuilds_owned_worker_keeps_camera_and_excludes_other_modifiers(self):
        c, logic = self.controller()
        self.assertTrue(hasattr(c, 'set_window_measurement'), 'window branch action is missing')
        self.assertFalse(c.window_measurement)
        position = [1., 2., 3.]
        camera = SimpleNamespace(GetPosition=lambda: tuple(position), GetFocalPoint=lambda: (0., 0., 0.),
            GetViewUp=lambda: (0., 0., 1.), GetParallelScale=lambda: 4., GetParallelProjection=lambda: 1,
            SetPosition=lambda *v: position.__setitem__(slice(None), v), SetFocalPoint=lambda *v: None,
            SetViewUp=lambda *v: None, SetParallelScale=lambda v: None, SetParallelProjection=lambda v: None)
        logic.app.mainView = SimpleNamespace(GetRenderer=lambda: SimpleNamespace(GetActiveCamera=lambda: camera))
        def enable(native_logic, **options):
            overlay = self.enabled(native_logic, **options)
            position[:] = [9., 9., 9.]
            return overlay
        with patch.object(fusion_native, 'enable_image', enable):
            c.set_image_fusion(True); position[:] = [1., 2., 3.]; old = c.overlay
            old.set_image_display_settings(True, 1.5, (-1., 1., -2., 2., -3., 3.))
            c.set_window_measurement(True)
            self.assertTrue(old.closed)
            self.assertIsNot(c.overlay, old)
            self.assertTrue(c.overlay.worker_config['window_measurement'])
            self.assertTrue(c.window_measurement_action.checked)
            self.assertIn('20F WINDOW DISTANCE', logic.app.statusLabel.text)
            self.assertIn('EXPERIMENTAL', logic.app.statusLabel.text)
            self.assertTrue(c.measure_action.enabled)
            self.assertFalse(c.p3_action.enabled or c.surface_action.enabled or c.motion_detail_action.enabled)
            self.assertEqual(position, [1., 2., 3.])
            self.assertEqual(c.overlay.settings, dict(depth=True, point_size=1.5, roi=(-1., 1., -2., 2., -3., 3.)))
            c.set_contour_refinement(True)
            self.assertFalse(c.window_measurement)
            self.assertFalse(c.window_measurement_action.checked or c.measure_action.enabled)
            self.assertEqual(c.contour_mode, 'quality')
            c.set_window_measurement(True)
            self.assertEqual(c.contour_mode, 'baseline')
            self.assertTrue(c.window_measurement)
        c.source_closed()
        self.assertFalse(c.window_measurement)
        self.assertFalse(c.window_measurement_action.checked or c.measure_action.enabled)
        self.assertEqual(logic.getReader().trailing, 17)

    def test_window_action_cannot_create_overlay_without_rolling_parent_or_with_live_source(self):
        c, logic = self.controller()
        self.assertTrue(hasattr(c, 'set_window_measurement'), 'window branch action is missing')
        c.set_window_measurement(True)
        self.assertIsNone(c.overlay)
        self.assertFalse(c.window_measurement)
        logic.getSensor = lambda: object()
        c.source_ready()
        self.assertFalse(c.window_measurement_action.enabled or c.measure_action.enabled)

    def test_calculate_pauses_and_freezes_same_owned_window_then_cancel_restores_baseline(self):
        c, logic = self.controller(); overlay = self.overlay()
        c.overlay = overlay; c.window_measurement = True; overlay.logic = logic
        c.single_action.setChecked(True); c.clean_action.setChecked(True)
        overlay.image_single_view = overlay.image_clean_view = True
        logic.app.playing = True
        self.assertTrue(hasattr(c, 'calculate_window_measurement'), 'window calculate action is missing')
        with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)):
            c.calculate_window_measurement()
            self.assertIs(c.overlay, overlay)
            self.assertFalse(logic.app.playing)
            self.assertEqual(c.p3_driver.command, 'measure')
            self.assertEqual(overlay.host.commands[-1][0], 'freeze')
            self.assertFalse(c.measure_action.enabled)
            overlay.host.control_packet = p3_support.receipt(c.p3_driver); overlay.poll()
            self.assertEqual(overlay.host.commands[-1][0], 'measure')
            self.assertEqual(overlay.host.commands[-1][3]['reference_sequence'], 19)
            overlay.host.control_packet = self.measured(c.p3_driver); overlay.poll()
            self.assertEqual(overlay.last_result['measurement_basis'], 'rolling_20_window')
            self.assertFalse(c.single_action.checked or c.clean_action.checked)
            self.assertFalse(c.single_action.enabled or c.clean_action.enabled)
            baseline = overlay.last_result['_image_pairs']['fused']
            c.cancel_p3_detail('user')
            self.assertFalse(c.p3_driver.valid)
            self.assertEqual(overlay.last_result['measurements'], [])
            self.assertEqual(overlay.last_result['measurement_basis'], 'image_only')
            self.assertEqual(overlay.last_result['clouds'], baseline)
            self.assertEqual(overlay.host.requests, [])

    def test_accepted_measurement_annotates_original_frozen_150k_display_without_p3_geometry(self):
        overlay = self.overlay()
        driver = fusion_native.P3ReplayEnhancement(overlay.host, lambda: 100., command='measure')
        driver.begin((overlay.session, overlay.clock, 0))
        frozen = p3_support.receipt(driver)
        cloud = dict(data=np.tile(np.array([[1., 0., 1.]], dtype='<f4'), (150000, 1)).tobytes(),
                     count=150000, dtype='little-float32-xyz')
        frozen['pair']['fused'] = cloud
        with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)):
            overlay._display_p3_packet(frozen)
            pair = overlay.last_result['_image_pairs']
            accepted = self.measured(driver); accepted['pair']['fused'] = cloud
            overlay._display_p3_packet(accepted)
        packet = overlay.last_result
        self.assertEqual(packet['measurement_basis'], 'rolling_20_window')
        self.assertEqual(packet['measurements'][0]['distance_m'], .8)
        self.assertTrue(packet['measurements'][0]['uncertain'])
        self.assertEqual(packet['clouds']['object']['count'], 150000)
        self.assertIs(packet['clouds']['object']['data'], cloud['data'])
        self.assertEqual(packet['_image_pairs'], pair)
        self.assertNotIn('detail_fused', packet['_image_pairs'])
        self.assertFalse(overlay.image_detail_view)
        self.assertFalse(packet['current_scan_measurement'] or packet['absolute_accuracy_verified']
                         or packet['semantic_one_object_one_label_verified'])
        label = clearance_overlay.measurement_label(packet['measurements'][0])
        self.assertIn('20F Window pending', label)
        self.assertIn('0.800 m', label)
        status = overlay.packet_status(packet)
        self.assertIn('20F WINDOW DISTANCE', status)
        self.assertIn('20/20', status)
        self.assertIn('ref 19', status)
        self.assertIn('EXPERIMENTAL', status)
        self.assertIn('NOT CURRENT SCAN', status)

    def test_source_identity_change_clears_measurements_before_any_late_reply_is_consumed(self):
        for field, value in [('session', 'new-session'), ('clock', 'new-clock'), ('epoch', 1)]:
            with self.subTest(field=field):
                overlay = self.overlay()
                with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)):
                    driver = self.freeze_and_measure(overlay)
                    self.assertEqual(len(overlay.last_result['measurements']), 1)
                    late = self.measured(driver); overlay.host.control_packet = late
                    setattr(overlay.host if field == 'epoch' else overlay, field, value)
                    overlay.poll()
                self.assertFalse(driver.valid)
                self.assertEqual(overlay.last_result['measurements'], [])
                self.assertEqual(overlay.last_result['measurement_basis'], 'image_only')
                self.assertIn('pair', late)

    def test_roi_change_cancels_distance_while_color_and_size_changes_keep_same_window(self):
        overlay = self.overlay()
        settings = dict(depth=True, point_size=2., roi=None)
        overlay.image_appearance = SimpleNamespace(snapshot=lambda: dict(settings),
            configure=lambda depth, size, roi: settings.update(depth=depth, point_size=size, roi=roi))
        with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)):
            driver = self.freeze_and_measure(overlay)
            overlay.set_image_display_settings(False, 1.5, None)
            self.assertTrue(driver.valid)
            self.assertEqual(len(overlay.last_result['measurements']), 1)
            overlay.set_image_display_settings(False, 1.5, (-1., 1., -2., 2., -3., 3.))
        self.assertFalse(driver.valid)
        self.assertEqual(driver.reason, 'roi_changed')
        self.assertEqual(overlay.last_result['measurements'], [])
        self.assertEqual(overlay.last_result['measurement_basis'], 'image_only')

    def test_window_distance_passes_through_appearance_prepare_and_finish(self):
        overlay = self.overlay(); events = []
        overlay.image_appearance = SimpleNamespace(prepare=lambda p: events.append(('prepare', p)),
            finish=lambda p: events.append(('finish', p)))
        packet = dict(sequence=19, measurement_basis='rolling_20_window')
        def base_display(adapter, actual, frame=None):
            events.append(('display', actual)); adapter.last_result = actual; return actual
        with patch.object(clearance_native.VtkClearanceOverlay, 'display_packet', base_display):
            overlay.display_packet(packet)
        self.assertEqual([name for name, unused in events], ['prepare', 'display', 'finish'])

    def test_matching_packet_identity_cannot_promote_window_distance_to_current_scan_distance(self):
        packet = dict(sequence=19, session_id='s', clock_id='c', epoch=0, status='completed',
                      received_at=100., measurement_basis='rolling_20_window', measurements=[{'distance_m': .8}])
        state = clearance_native.display_state(packet, dict(sequence=19, session_id='s', clock_id='c', epoch=0), 103.)
        self.assertTrue(state['current_source'],'an exact source is not a current-scan distance claim')
        self.assertFalse(state['fresh_distance'])
        self.assertEqual(state['result_age_s'], 3.)

    def test_registered_menu_actions_enter_branch_and_dispatch_one_freeze_request(self):
        logic = replay_support.RecordedMenuTests().logic()
        logic.QtGui = SimpleNamespace(QAction=MenuAction)
        logic.app.actions = {}; logic.stop = lambda: setattr(logic.app, 'playing', False)
        menu = Menu(); controller = fusion_native.install(logic, menu, object())
        self.assertIn('actionImageWindowMeasurement', logic.app.actions)
        self.assertIn('actionImageMeasureWindow', logic.app.actions)
        window = logic.app.actions['actionImageWindowMeasurement']
        measure = logic.app.actions['actionImageMeasureWindow']
        self.assertIn(window, menu.actions); self.assertIn(measure, menu.actions)
        self.assertFalse(window.enabled or measure.enabled)
        def enable(native_logic, **options):
            overlay = self.enabled(native_logic, **options)
            overlay.set_p3_receiver = lambda *args: None
            return overlay
        with patch.object(fusion_native, 'enable_image', enable):
            logic.app.actions['actionImageFusion'].slots['triggered(bool)'](True)
            window.slots['triggered(bool)'](True)
            self.assertTrue(controller.window_measurement)
            logic.app.playing = True
            measure.slots['triggered()']()
            self.assertFalse(logic.app.playing)
            self.assertEqual(controller.overlay.host.commands[-1][0], 'freeze')
            self.assertEqual(controller.p3_driver.command, 'measure')

    def test_failed_measure_control_keeps_exact_baseline_and_reports_no_distance(self):
        overlay = self.overlay()
        driver = fusion_native.P3ReplayEnhancement(overlay.host, lambda: 100., command='measure')
        driver.begin((overlay.session, overlay.clock, 0)); overlay.p3_driver = driver
        overlay.set_p3_receiver(driver.accepts, lambda p: None, True)
        with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)):
            overlay.host.control_packet = p3_support.receipt(driver); overlay.poll()
            original = overlay.last_result['_image_pairs']['fused']
            failure = p3_support.receipt(driver, 'failed')
            failure.update(command='measure', reason='window_measurement_failed')
            overlay.host.control_packet = failure; overlay.poll()
        self.assertEqual(overlay.last_result['clouds'], original)
        self.assertEqual(overlay.last_result['measurements'], [])
        self.assertIn('20F WINDOW DISTANCE', overlay.status_label.text)
        self.assertIn('window_measurement_failed', overlay.status_label.text)
        self.assertIn('NO DISTANCE', overlay.status_label.text)
        self.assertIn('EXPERIMENTAL', overlay.status_label.text)

    def test_report_window_membership_must_match_the_frozen_baseline(self):
        overlay = self.overlay()
        driver = fusion_native.P3ReplayEnhancement(overlay.host, lambda: 100., command='measure')
        driver.begin((overlay.session, overlay.clock, 0))
        frozen = p3_support.receipt(driver)
        with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)):
            overlay._display_p3_packet(frozen)
            accepted = self.measured(driver)
            accepted['report']['measurement_packet']['window_measurement']['source_frames'] = list(range(1, 21))
            overlay._display_p3_packet(accepted)
        self.assertEqual(overlay.last_result['measurement_basis'], 'image_only')
        self.assertEqual(overlay.last_result['measurements'], [])

    def test_frozen_distance_age_advances_without_redecode_or_current_scan_promotion(self):
        overlay = self.overlay(); overlay.last_result = dict(sequence=19, received_at=190.)
        with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)):
            with patch.object(clearance_native.time, 'time', return_value=200.):
                self.freeze_and_measure(overlay)
            with patch.object(clearance_native.time, 'time', return_value=203.):
                overlay.poll()
        self.assertEqual(overlay.last_result.get('result_age_s', 0.), 3.)
        self.assertFalse(overlay.last_result['fresh_distance'])
        self.assertFalse(overlay.last_result['current_scan_measurement'])
        self.assertEqual(overlay.host.requests, [])

    def test_failure_without_display_pair_clears_previous_window_distance(self):
        overlay = self.overlay()
        with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)):
            driver = self.freeze_and_measure(overlay)
            original = overlay.last_result['_image_pairs']['fused']
            failure = p3_support.receipt(driver, 'failed')
            failure.update(command='measure', pair=None, reason='worker_failed')
            overlay.host.control_packet = failure; overlay.poll()
        self.assertEqual(overlay.last_result['measurements'], [])
        self.assertEqual(overlay.last_result['clouds'], original)
        self.assertEqual(overlay.last_result['measurement_basis'], 'image_only')
        self.assertIn('NO DISTANCE', overlay.status_label.text)

    def test_replay_advance_clears_accepted_window_distance_before_the_new_scan(self):
        overlay = self.overlay(); before_decode = []
        def decode(frame):
            before_decode.append((overlay.last_result['measurement_basis'], overlay.last_result['measurements']))
            raise ValueError('diagnostic selected scan is unavailable')
        with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)):
            driver = self.freeze_and_measure(overlay)
            with patch.object(overlay.reader, 'UpdatePipeline', decode):
                overlay._update_recorded(20, poll=False)
        self.assertFalse(driver.valid)
        self.assertEqual(before_decode, [('image_only', [])])
        self.assertIsNone(overlay.last_result)
        self.assertEqual(driver.reason, 'replay_advanced')

    def test_underfilled_window_does_not_reacquire_or_invent_distances(self):
        overlay = self.overlay()
        driver = fusion_native.P3ReplayEnhancement(overlay.host, lambda: 100., command='measure')
        driver.begin((overlay.session, overlay.clock, 0)); overlay.p3_driver = driver
        overlay.set_p3_receiver(driver.accepts, lambda p: None, True)
        with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)):
            overlay.host.control_packet = p3_support.receipt(driver, count=4); overlay.poll()
        self.assertEqual([command[0] for command in overlay.host.commands], ['freeze'])
        self.assertEqual(overlay.host.requests, [])
        self.assertEqual(overlay.last_result['measurements'], [])
        self.assertIn('4/20', overlay.status_label.text)
        self.assertIn('NO DISTANCE', overlay.status_label.text)

    def test_pending_view_is_off_by_default_and_toggles_exact_raw_points_without_promoting_metrics(self):
        overlay = self.overlay()
        self.assertTrue(hasattr(overlay, 'set_window_pending_view'), 'window raw preview view is missing')
        driver = fusion_native.P3ReplayEnhancement(overlay.host, lambda: 100., command='measure')
        driver.begin((overlay.session, overlay.clock, 0)); overlay.p3_driver = driver
        overlay.set_p3_receiver(driver.accepts, lambda p: None, True)
        with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)):
            overlay.host.control_packet = p3_support.receipt(driver); overlay.poll()
            overlay.host.control_packet = self.with_pending(self.measured(driver)); overlay.poll()
            packet = overlay.last_result; original = packet['clouds']; commands = list(overlay.host.commands)
            self.assertFalse(getattr(overlay, 'window_pending_view', False))
            self.assertEqual([m['distance_m'] for m in packet['measurements']], [.8])
            self.assertTrue(overlay.set_window_pending_view(True))
            shown = overlay.last_result['measurements']
            self.assertEqual([m['distance_m'] for m in shown], [.8, .42])
            raw = shown[-1]
            self.assertEqual(raw['point_L'], [3., .42, .2])
            self.assertEqual(raw['projected_L'], [3., .42, 0.])
            self.assertEqual(raw['foot_L'], [3., 0., 0.])
            self.assertEqual((raw['source_sequence'], raw['source_index'], raw['source_time_s']), (5, 72, 1.5))
            self.assertIsNone(raw['supported_distance_m'])
            self.assertEqual(overlay.last_result['clouds'], original)
            self.assertEqual(overlay.host.commands, commands)
            self.assertEqual(overlay.host.requests, [])
            self.assertFalse(overlay.last_result['fresh_distance'])
            self.assertTrue(overlay.set_window_pending_view(False))
            self.assertEqual([m['distance_m'] for m in overlay.last_result['measurements']], [.8])
            self.assertEqual(len(overlay.last_result['pending_window_measurements']), 1)

    def test_zero_qualified_annotations_can_show_only_explicit_raw_preview_with_zero_qualified_status(self):
        overlay = self.overlay()
        driver = fusion_native.P3ReplayEnhancement(overlay.host, lambda: 100., command='measure')
        driver.begin((overlay.session, overlay.clock, 0))
        accepted = self.with_pending(self.measured(driver))
        accepted['report']['measurement_packet']['measurements'] = []
        accepted['report']['measurement_packet']['window_measurement']['qualified_annotation_count'] = 0
        with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)):
            overlay._display_p3_packet(p3_support.receipt(driver)); overlay._display_p3_packet(accepted)
            self.assertEqual(overlay.last_result['measurements'], [])
            status = overlay.packet_status(overlay.last_result)
            self.assertIn('qualified 0', status)
            self.assertIn('pending shown 0/1', status)
            overlay.set_window_pending_view(True)
            raw = overlay.last_result['measurements'][0]
            label = clearance_overlay.measurement_label(raw)
            self.assertIn('20F Window raw ?', label)
            self.assertIn('0.420 m', label)
            self.assertNotIn('supported', label.lower())
            self.assertNotIn('confirmed', label.lower())
            self.assertEqual(overlay.last_result['_qualified_window_measurements'], [])
            self.assertEqual(overlay.last_result['window_measurement']['qualified_annotation_count'], 0)
            status = overlay.packet_status(overlay.last_result)
            self.assertIn('qualified 0', status)
            self.assertIn('pending shown 1/1', status)
            self.assertIn('EXPERIMENTAL', status)
            self.assertIn('NOT CURRENT SCAN', status)
            self.assertFalse(overlay.last_result['fresh_distance'])

    def test_pending_menu_is_default_off_and_available_only_for_a_completed_pending_window(self):
        logic = replay_support.RecordedMenuTests().logic(); logic.QtGui = SimpleNamespace(QAction=MenuAction)
        logic.app.actions = {}; logic.stop = lambda: setattr(logic.app, 'playing', False)
        menu = Menu(); controller = fusion_native.install(logic, menu, object())
        self.assertIn('actionImageWindowPending', logic.app.actions)
        action = logic.app.actions['actionImageWindowPending']
        self.assertFalse(action.enabled or action.checked)
        overlay = self.overlay(); controller.overlay = overlay; controller.window_measurement = True
        overlay.logic = logic
        with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)):
            driver = self.freeze_and_measure(overlay)
            overlay._display_p3_packet(self.with_pending(self.measured(driver)))
            controller.p3_driver = driver; controller.source_ready()
            self.assertTrue(action.enabled); self.assertFalse(action.checked)
            action.slots['triggered(bool)'](True)
            self.assertTrue(action.checked)
            self.assertEqual([m['distance_m'] for m in overlay.last_result['measurements']], [.8, .42])
            action.slots['triggered(bool)'](False)
            self.assertFalse(action.checked)
            self.assertEqual([m['distance_m'] for m in overlay.last_result['measurements']], [.8])

    def test_preview_resets_when_cancelled_replayed_or_source_identity_changes(self):
        for operation in ('cancel', 'replay', 'source'):
            with self.subTest(operation=operation):
                overlay = self.overlay(); controller, logic = self.controller()
                controller.overlay = overlay; controller.window_measurement = True; overlay.logic = logic
                with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)):
                    driver = self.freeze_and_measure(overlay); controller.p3_driver = driver
                    overlay._display_p3_packet(self.with_pending(self.measured(driver)))
                    controller.source_ready()
                    self.assertTrue(hasattr(controller, 'set_window_pending'), 'pending preview action handler is missing')
                    controller.set_window_pending(True)
                    self.assertTrue(overlay.window_pending_view)
                    if operation == 'cancel': controller.cancel_p3_detail('user')
                    elif operation == 'replay': overlay._update_recorded(20, poll=False)
                    else: overlay.session = 'new-source'; overlay.poll()
                self.assertFalse(overlay.window_pending_view)
                self.assertFalse(controller.pending_window_action.checked or controller.pending_window_action.enabled)
                if overlay.last_result is not None:
                    self.assertEqual(overlay.last_result['measurements'], [])
                    self.assertNotIn('pending_window_measurements', overlay.last_result)

    def test_preview_resets_on_source_close_or_switch_to_another_branch(self):
        for operation in ('close', 'branch'):
            with self.subTest(operation=operation):
                overlay = self.overlay(); controller, logic = self.controller()
                controller.overlay = overlay; controller.window_measurement = True; overlay.logic = logic
                logic.app.railOverlay = overlay
                with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)):
                    driver = self.freeze_and_measure(overlay); controller.p3_driver = driver
                    overlay._display_p3_packet(self.with_pending(self.measured(driver)))
                    controller.source_ready(); controller.set_window_pending(True)
                    with patch.object(overlay, 'close', side_effect=lambda: setattr(overlay, 'closed', True)):
                        if operation == 'close': controller.source_closed()
                        else:
                            with patch.object(fusion_native, 'enable_image', self.enabled):
                                controller.set_contour_refinement(True)
                self.assertFalse(overlay.window_pending_view)
                self.assertFalse(controller.pending_window_action.checked or controller.pending_window_action.enabled)
                self.assertFalse(controller.window_measurement)

    def test_baseline_or_empty_pending_result_cannot_enable_raw_preview(self):
        overlay = self.overlay()
        with patch.object(overlay, 'display_packet', side_effect=lambda p: setattr(overlay, 'last_result', p)):
            driver = self.freeze_and_measure(overlay)
            self.assertFalse(overlay.set_window_pending_view(True))
            self.assertFalse(overlay.window_pending_view)
            self.assertEqual([m['distance_m'] for m in overlay.last_result['measurements']], [.8])
            overlay.set_image_detail_view(False)
            self.assertFalse(overlay.set_window_pending_view(True))
            self.assertEqual(overlay.last_result['measurements'], [])


if __name__ == '__main__':
    unittest.main()
