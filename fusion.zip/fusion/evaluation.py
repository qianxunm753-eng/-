"""Fixed-reference geometric checks, never semantic or physical-accuracy truth."""
import re
import numpy as np
from scipy.spatial import cKDTree


def contour_metrics(reference_xyz,candidate_xyz,roi_min,roi_max,patch_normals,coverage_reference=None):
    result=dict(available=False,normal_p90_m=None,coverage=None,reason='insufficient_geometry',
        physical_accuracy_verified=False)
    ref=np.asarray(reference_xyz,dtype=float);candidate=np.asarray(candidate_xyz,dtype=float)
    lo=np.asarray(roi_min,dtype=float);hi=np.asarray(roi_max,dtype=float);normals=np.asarray(patch_normals,dtype=float)
    if ref.ndim!=2 or ref.shape[1]!=3 or candidate.ndim!=2 or candidate.shape[1]!=3 or lo.shape!=(3,) or hi.shape!=(3,) or np.any(hi<=lo):
        raise ValueError('explicit aligned XYZ and finite ROI required')
    valid_ref=np.isfinite(ref).all(axis=1)&np.all((ref>=lo)&(ref<=hi),axis=1)
    ref=ref[valid_ref];candidate=candidate[np.isfinite(candidate).all(axis=1)&np.all((candidate>=lo)&(candidate<=hi),axis=1)]
    if len(ref)<50 or len(candidate)<20:return result
    if normals.shape==(1,3):
        norm=float(np.linalg.norm(normals[0]))
        if norm<=0 or not np.isfinite(norm):raise ValueError('finite independent normal required')
        n=normals[0]/norm
        if np.percentile(np.abs((ref-ref.mean(axis=0))@n),90)>.006:
            result['reason']='not_one_planar_reference_patch';return result
        normals=np.tile(n,(len(ref),1))
    elif normals.shape==(len(reference_xyz),3):
        normals=normals[valid_ref];length=np.linalg.norm(normals,axis=1)
        if not np.isfinite(length).all() or np.any(length<=0):raise ValueError('finite independent normals required')
        normals=normals/length[:,None]
    else:raise ValueError('one validated plane normal or aligned local normals required')
    tree=cKDTree(ref);distance,indices=tree.query(candidate,workers=1)
    supported=distance<.25
    if supported.sum()<20:return result
    errors=np.abs(np.einsum('ij,ij->i',candidate[supported]-ref[indices[supported]],normals[indices[supported]]))
    occupied=ref if coverage_reference is None else np.asarray(coverage_reference,dtype=float)
    if occupied.ndim!=2 or occupied.shape[1]!=3:raise ValueError('aligned baseline fused occupancy required')
    occupied=occupied[np.isfinite(occupied).all(axis=1)&np.all((occupied>=lo)&(occupied<=hi),axis=1)]
    if not len(occupied):return result
    ref_cells={tuple(k) for k in np.floor(occupied/.008).astype(np.int64)}
    candidate_cells={tuple(k) for k in np.floor(candidate/.008).astype(np.int64)}
    result.update(available=True,reason='fixed_independent_reference',normal_p90_m=float(np.percentile(errors,90)),
        coverage=len(ref_cells&candidate_cells)/max(len(ref_cells),1),reference_points=len(ref),candidate_points=len(candidate),
        boundary_bandwidth_m=float(np.percentile(distance[supported],90)),
        coverage_basis='baseline_fused' if coverage_reference is not None else 'independent_reference')
    return result


def assess_run(results):
    if not results.get('same_source_ids'):raise ValueError('same consumed real scan IDs required')
    baseline=results.get('baseline',[]);candidate=results.get('candidate',[])
    if len(baseline)!=len(candidate):raise ValueError('paired metric rows required')
    if any((a.get('reference_sequence'),a.get('reference_time_s'))!=
           (b.get('reference_sequence'),b.get('reference_time_s')) for a,b in zip(baseline,candidate)):
        return dict(status='unavailable',reason='different_actual_reference_frames')
    pairs=[(a,b) for a,b in zip(baseline,candidate) if a.get('available') and b.get('available')]
    if not pairs:return dict(status='unavailable',reason='no_independent_target_metrics')
    if len(pairs)!=len(baseline):return dict(status='unavailable',reason='incomplete_paired_target_metrics')
    before=np.array([a['normal_p90_m'] for a,b in pairs]);after=np.array([b['normal_p90_m'] for a,b in pairs])
    coverage=min(b['coverage'] for a,b in pairs)
    if results.get('stationary'):
        passed=np.percentile(after,90)<=np.percentile(before,90)+.002+1e-12 and coverage>=.95
        return dict(status='passed' if passed else 'failed',reason='stationary_geometry_guard',physical_accuracy_verified=False)
    median=float(np.median(before))
    if median<=1e-9:return dict(status='unavailable',reason='zero_baseline_not_an_improvement_rate')
    improvement=1-float(np.median(after))/median
    passed=improvement>=.2 and np.percentile(after,90)<=np.percentile(before,90)*1.05+1e-12 and coverage>=.95
    return dict(status='passed' if passed else 'failed',improvement=improvement,minimum_coverage=coverage,
        reason='motion_geometry_and_coverage',physical_accuracy_verified=False)


def speed_metadata(scene,filename):
    match=re.search(r'(\d+)rpm',filename,re.I);label=int(match.group(1)) if match else None
    return dict(filename_rpm_label=label,actual_rpm=label if scene=='original_mixed' else None,
        rpm_provenance='user_confirmed' if scene=='original_mixed' else 'label_only_not_actual_speed')
