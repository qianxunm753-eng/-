"""Replay-only phase adapter: mature compensated returns -> existing clearance.

The reference is the frozen window's latest scan. No extra pose estimation,
display sampling as measurement input, smoothing or generated coordinates.
"""
from dataclasses import replace
import numpy as np
from .registration import transform
from ..clearance.protocol import ClearanceConfig,CloudFrame,PointRef,measurement_model
from ..clearance.stop_window import StopWindow
from ..clearance.stop_fusion import measure_window
from ..clearance.track import observe_track
from ..clearance.scene import extract_scene
from ..clearance.objects import refine_objects
from ..clearance.rsview_cache import build_packet
from ..clearance.motion import valid_matrix
from ..clearance_overlay import select_display_measurements


def _config(value):
    if isinstance(value,dict):
        settings=dict(value);settings.setdefault('stop_window_map_budget',300000)
        value=ClearanceConfig(**settings)
    if not 1<=value.stop_window_map_budget<=300000:
        raise ValueError('bounded phase map capacity required')
    return value


def build_measurement_window(snapshot,config,budget):
    """Preserve every retained return and native origin in latest coordinates."""
    budget.ensure();config=_config(config);scans=snapshot.scans;key=snapshot.key
    if (len(scans)!=20 or tuple(s.sequence for s in scans)!=key.source_frames
        or key.reference_sequence!=scans[-1].sequence or key.reference_time_s!=scans[-1].reference_s
        or any(b.reference_s<=a.reference_s for a,b in zip(scans,scans[1:]))):
        raise ValueError('complete exact twenty-scan snapshot required')
    if not all(valid_matrix(s.pose) for s in scans):raise ValueError('valid mature compensated poses required')
    estimate=max(len(s.corrected_xyz) for s in scans)*120+min(
        sum(len(s.corrected_xyz) for s in scans),config.stop_window_map_budget)*256
    budget.ensure(estimate)
    window=StopWindow(10.,config.stop_window_voxel_m,60.,
        min(config.stop_window_byte_budget,budget.window_limit_bytes),config.stop_window_point_budget,
        config.stop_window_map_budget)
    window.reference_pose=np.eye(4);window.reference_sequence=key.reference_sequence
    inverse=np.linalg.inv(scans[-1].pose)
    for scan in scans:
        budget.ensure(estimate+window.compressed_bytes)
        xyz=transform(scan.corrected_xyz,inverse@scan.pose)
        refs=tuple(PointRef(scan.sequence,int(i),float(t)) for i,t in zip(scan.original_indices,scan.point_times))
        frame=CloudFrame(key.session_id,scan.sequence,scan.reference_s,key.clock_id,xyz,refs,
            scan.rings,scan.span_s,'rolling_window_aligned',{'real_returns_only':True})
        if not window.add(frame,np.eye(4)):raise ValueError('window measurement capacity: '+window.reason)
    if window.scan_count!=20:raise ValueError('twenty contributing scans required')
    return window


def pending_previews(results,layers,packet):
    """Separate opt-in raw preview, never promote failed annotation quality.

    Role, rail, terrain and ownership refusals remain unavailable. Each preview
    uses the literal observed minimum AND its own native origin, not a supported
    boundary's coordinates. No asset identity or support claim is assigned.
    """
    reasons={item['candidate_id']:item['reason'] for item in packet['secondary_measurements']}
    candidates={item.candidate_id:item for item in layers.candidates}
    output=[]
    for result in results:
        if reasons.get(result.candidate_id)!='unresolved_annotation_quality':continue
        evidence=result.observed_evidence;distance=result.observed_min_distance_m
        if evidence is None or distance is None or not np.isfinite(distance):continue
        candidate=candidates[result.candidate_id];ref=evidence.point_ref
        output.append(dict(candidate_id=result.candidate_id,distance_m=float(distance),
            observed_min_distance_m=float(distance),supported_distance_m=None,
            point_L=evidence.point_L.tolist(),projected_L=evidence.projected_L.tolist(),
            foot_L=evidence.foot_L.tolist(),source_frame=int(ref.frame),source_index=int(ref.index),
            source_time_s=float(ref.time_s),point_count=len(candidate.point_indices),
            observed_source_frame=int(ref.frame),observed_source_index=int(ref.index),
            observed_source_time_s=float(ref.time_s),observed_point_L=evidence.point_L.tolist(),
            observed_projected_L=evidence.projected_L.tolist(),observed_foot_L=evidence.foot_L.tolist(),
            uncertain=True,window_raw_preview=True,object_id=None,display_id=None,surface_id=None,
            side=result.side,boundary_choice='unconfirmed_window_raw_return',raw_near_warning=True,
            flags=list(result.flags)+['pending_window_raw_preview']))
    return select_display_measurements(output,8,balance_sides=True)


def measure_snapshot(snapshot,config,budget):
    config=_config(config)
    config=replace(config,config_id='rsview-rolling20-clearance-phase-v1',
        sensor_max_range_m=10.,measurement_height_range_m=None,above_rail_measurement_only=True,
        confirmed_background_path=None,confirmed_measurement_scope_path=None,stop_window_fusion=False)
    window=build_measurement_window(snapshot,config,budget);budget.ensure()
    geometry=window.geometry()
    local=np.flatnonzero(np.einsum('ij,ij->i',geometry.xyz_L,geometry.xyz_L)<=25.+1e-12)
    rail_frame=replace(geometry,xyz_L=geometry.xyz_L[local],refs=tuple(geometry.refs[int(i)] for i in local),
        rings=None if geometry.rings is None else geometry.rings[local])
    track=observe_track(rail_frame,None,config);budget.ensure()
    layers=extract_scene(geometry,track,[],config);budget.ensure()
    layers=refine_objects(geometry,track,layers,config);budget.ensure()
    results=measure_window(window,track,layers,config,budget.ensure)
    packet=build_packet(geometry,track,layers,results,config);packet.pop('_display',None)
    packet['pending_window_measurements']=pending_previews(results,layers,packet)
    # Frame/point timestamps remain native origins. This is a multi-scan model,
    # never a currently observed single-scan distance or an accuracy proof.
    for name in ('measurements','secondary_measurements','pending_window_measurements'):
        for item in packet[name]:
            item.update(measurement_basis='rolling_20_window',uncertain=True,
                current_scan_measurement=False,
                point_age_s=max(0.,geometry.ref_time_s-item['source_time_s']) if item.get('source_time_s') is not None else None,
                object_identity_semantics='window geometric region; not verified equipment identity')
            item['flags']=list(dict.fromkeys(item['flags']+['rolling_window_experimental','relative_pose_accuracy_unverified']))
    key=snapshot.key
    packet.update(epoch=key.epoch,source_mode='recorded_pcap',calculation='rolling_20_window_measurement',
        measurement_basis='rolling_20_window',current_scan_measurement=False,
        absolute_accuracy_verified=False,semantic_one_object_one_label_verified=False,
        window_measurement=dict(state='measured' if measurement_model(track) is not None else 'track_unavailable',
            source_frames=list(key.source_frames),reference_sequence=key.reference_sequence,
            reference_time_s=key.reference_time_s,scan_count=20,raw_points=window.point_count,
            map_points=len(geometry.xyz_L),reference='latest mature baseline scan',
            qualified_annotation_count=len(packet['measurements']),
            pending_preview_count=len(packet['pending_window_measurements']),
            map_point_limit=window.map_budget,temporary_byte_limit=budget.temporary_limit_bytes,
            measurement_source='full compensated real returns within 10m; not display representatives',
            display_pair_unchanged=True,accuracy_verified=False))
    budget.ensure();return packet
