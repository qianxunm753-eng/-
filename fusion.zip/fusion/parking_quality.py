"""Independent multi-source local evidence; no contiguous-suffix rejection."""
from dataclasses import dataclass
from itertools import combinations
import numpy as np
from scipy.spatial import cKDTree
from .registration import representatives,detail_representatives,transform
from .state import freeze,retained_bytes
from .validation import ValidationMetrics,accept_refinement,local_feature_groups


@dataclass(frozen=True)
class ParkingCheckContext:
    checked_sequence:int
    capture_key:tuple
    reference_ids:tuple
    reference_target:np.ndarray
    check_rows:np.ndarray
    target:np.ndarray
    normals:np.ndarray
    groups:tuple
    noise_budget_m:np.ndarray
    mad_scale_m:np.ndarray
    support_fraction:float
    ambiguous_rows:int
    local_support_complete:bool=True

    def __post_init__(self):
        for name in ('reference_target','check_rows','target','normals','groups','noise_budget_m','mad_scale_m'):
            object.__setattr__(self,name,freeze(getattr(self,name)))


@dataclass(frozen=True)
class ParkingScanCheck:
    status:str
    reason:str
    reference_ids:tuple
    metrics:dict
    patch_metrics:dict


def _window(scans):
    if (len(scans)>20 or len({s.capture_key for s in scans})>1
        or len({s.record.sequence for s in scans})!=len(scans)
        or any(b.record.reference_s<=a.record.reference_s for a,b in zip(scans,scans[1:]))):
        raise ValueError('one bounded increasing capture window required')


def _training(record,detail_sampling=False):
    mask=record.original_indices%5!=0
    if record.rings is not None:mask &= record.rings%2==0
    points=transform(record.corrected_xyz[mask],record.pose)
    sampler=detail_representatives if detail_sampling else representatives
    return points[sampler(points,.04,2800)]


def _patches(points,query):
    if len(points)<12:return None
    tree=cKDTree(points);distance,nearest=tree.query(query,k=12,workers=1)
    patches=points[nearest];center=patches.mean(axis=1);offset=patches-center[:,None,:]
    eigen,vectors=np.linalg.eigh(np.einsum('nki,nkj->nij',offset,offset)/12.)
    normals=vectors[:,:,0]
    axis=np.argmax(np.abs(normals),axis=1)
    normals*=np.where(normals[np.arange(len(normals)),axis]<0.,-1.,1.)[:,None]
    scatter=np.sqrt(np.maximum(eigen[:,0],0.))
    residual=np.einsum('nki,ni->nk',offset,normals)
    mad=np.median(np.abs(residual-np.median(residual,axis=1)[:,None]),axis=1)*1.4826
    valid=(distance[:,0]<=.12)&(distance[:,-1]<=.18)&(scatter<=.006)
    valid &= eigen[:,1]>np.maximum(eigen[:,2]*.005,1e-10)
    return center,normals,scatter,mad,valid


def build_parking_context(scans,checked_sequence,budget,detail_sampling=False):
    _window(scans)
    if not budget.check(14000*12*3*8*4) or retained_bytes(scans)>budget.window_limit_bytes:return None
    chosen=next((s for s in scans if s.record.sequence==checked_sequence),None)
    if chosen is None:raise ValueError('checked real scan absent')
    others=[s for s in scans if s.record.sequence!=checked_sequence and s.geometry_diag.get('observable',False)]
    if len(others)<2:return None
    # Uniformly distributed actual references, never extrapolated frames.
    if len(others)>5:others=[others[i] for i in np.linspace(0,len(others)-1,5,dtype=int)]
    record=chosen.record;rows=np.flatnonzero(record.original_indices%5==0)
    if detail_sampling:
        # Check-only selection cannot feed registration or reference geometry.
        heldout=transform(record.corrected_xyz[rows],record.pose)
        rows=rows[detail_representatives(heldout,.04,3500)]
    elif len(rows)>3500:rows=rows[np.linspace(0,len(rows)-1,3500,dtype=int)]
    query=transform(record.corrected_xyz[rows],record.pose)
    source=_patches(_training(record,detail_sampling),query)
    if source is None:return None
    # A thin curved feature can have tiny training PCA scatter after voxel
    # sampling while its independent returns lie on the other side of the
    # curve. That is an invalid local plane, not evidence of a bad pose.
    source_residual=np.abs(np.einsum('ij,ij->i',query-source[0],source[1]))
    source[4][:] &= source_residual<=source[2]+.002
    target_parts=[];parts=[];reference_ids=[]
    for s in others:
        budget.ensure(14000*12*3*8*4)
        training=_training(s.record,detail_sampling);patch=_patches(training,query)
        if patch is not None:
            target_parts.append(training);parts.append(patch);reference_ids.append(s.record.sequence)
    if len(parts)<2:return None
    centers=np.stack([p[0] for p in parts]);normals=np.stack([p[1] for p in parts])
    scatters=np.stack([p[2] for p in parts]);mads=np.stack([p[3] for p in parts]);valid=np.stack([p[4] for p in parts])
    valid &= source[4][None,:]
    # Enumerate the at most 26 multi-reference cliques. A tie between
    # incompatible maximal consensuses remains unknown, not nearest-wins.
    compatibility={}
    for a,b in combinations(range(len(parts)),2):
        dot=np.abs(np.einsum('ij,ij->i',normals[a],normals[b]))
        offset=np.abs(np.einsum('ij,ij->i',centers[a]-centers[b],normals[a]))
        compatibility[a,b]=(dot>=.95)&(offset<=np.hypot(scatters[a],scatters[b])+.002)
    best_size=np.zeros(len(rows),dtype=int);best_mask=np.zeros(len(rows),dtype=int);ambiguous=np.zeros(len(rows),dtype=bool)
    for size in range(2,len(parts)+1):
        for subset in combinations(range(len(parts)),size):
            eligible=np.all(valid[list(subset)],axis=0)
            for a,b in combinations(subset,2):eligible &= compatibility[a,b]
            bits=sum(1<<i for i in subset);better=eligible&(size>best_size)
            tied=eligible&(size==best_size)&(best_mask!=bits)
            # Overlapping equally-sized cliques are still different evidence
            # choices; only a larger consistent clique resolves their tie.
            ambiguous[tied]=True;ambiguous[better]=False
            best_mask[better]=bits;best_size[better]=size
    supported=(best_size>=2)&~ambiguous;out_rows=rows[supported]
    q=np.zeros((len(out_rows),3));n=np.zeros_like(q);noise=np.zeros(len(out_rows));mad=np.zeros(len(out_rows))
    selected_mask=best_mask[supported]
    for i in range(len(parts)):
        member=(selected_mask&(1<<i))!=0
        q[member]+=centers[i,supported][member]/best_size[supported][member,None]
        n[member]+=normals[i,supported][member]/best_size[supported][member,None]
        noise[member]=np.maximum(noise[member],scatters[i,supported][member])
        mad[member]=np.maximum(mad[member],mads[i,supported][member])
    if len(n):n/=np.linalg.norm(n,axis=1)[:,None]
    noise=np.hypot(noise,source[2][supported])+.002
    mad=np.maximum(np.hypot(mad,source[3][supported]),1e-6)
    groups=local_feature_groups(q,n)
    local_complete=True
    if detail_sampling:
        groups+=tuple((('detail',name),member) for name,member in local_feature_groups(q,n,.12,6))
        # A big supported wall cannot conceal a locally unsupported valid
        # source surface. Invalid curved-plane models remain unknown rather
        # than being promoted through these checks.
        cells=np.floor(query/.12).astype(np.int64)
        unused,inverse=np.unique(cells,axis=0,return_inverse=True)
        eligible=np.bincount(inverse,weights=source[4])
        matched=np.bincount(inverse,weights=supported,minlength=len(eligible))
        local_complete=bool(np.all(matched[eligible>=6]>=.6*eligible[eligible>=6]))
    return ParkingCheckContext(checked_sequence,chosen.capture_key,tuple(reference_ids),
        np.concatenate(target_parts),out_rows,q,n,groups,noise,mad,
        len(out_rows)/max(len(rows),1),int(ambiguous.sum()),local_complete)


def _evaluate(record,context):
    world=transform(record.corrected_xyz[context.check_rows],record.pose)
    residual=np.abs(np.einsum('ij,ij->i',world-context.target,context.normals))
    within=np.linalg.norm(world-context.target,axis=1)<=.12
    patches={};detailed={};regression=False
    for index,(name,member) in enumerate(context.groups):
        r=residual[member];envelope=context.noise_budget_m[member]
        p90=float(np.percentile(r,90));rms=float(np.sqrt(np.mean(r*r)))
        patches[str(index)]=(p90,rms,float(np.mean(within[member])))
        detailed[str(index)]=dict(p90_m=p90,rms_m=rms,coverage=patches[str(index)][2],
            allowed_p90_m=float(np.percentile(envelope,90)),allowed_rms_m=float(np.sqrt(np.mean(envelope**2))),
            normalized_p90=float(np.percentile(r/context.mad_scale_m[member],90)),rows=int(len(member)))
        regression |= p90>detailed[str(index)]['allowed_p90_m'] or rms>detailed[str(index)]['allowed_rms_m']
    support=len(residual)>=50 and context.support_fraction>=.2 and bool(patches) and context.local_support_complete
    metrics=ValidationMetrics(float(np.percentile(residual,90)) if len(residual) else np.inf,
        float(np.sqrt(np.mean(residual**2))) if len(residual) else np.inf,
        float(np.mean(within))*context.support_fraction if len(within) else 0.,patches,support)
    return metrics,detailed,regression


def check_micro_candidate(baseline,candidate,context):
    if context.checked_sequence!=baseline.sequence or candidate.sequence!=baseline.sequence:
        raise ValueError('same checked real scan required')
    before,unused,unused=_evaluate(baseline,context)
    after,unused,unused=_evaluate(candidate,context)
    return accept_refinement(before,after)


def check_parking_window(scans,budget):
    _window(scans);checks={}
    for s in scans:
        try:context=build_parking_context(scans,s.record.sequence,budget)
        except ValueError:
            if budget.check():raise
            context=None
        if context is None:
            checks[s.record.sequence]=ParkingScanCheck('unknown','insufficient_independent_references',(),{},{});continue
        metrics,patches,regression=_evaluate(s.record,context)
        status=('unknown' if not metrics.independent_support or context.ambiguous_rows>=12 else
            'rejected' if regression else 'passed')
        reason={'unknown':'insufficient_or_ambiguous_local_support','rejected':'local_surface_outside_noise_envelope','passed':'independent_local_references'}[status]
        values=dict(p90_m=metrics.p90_m,rms_m=metrics.rms_m,coverage=metrics.coverage,
            checked_rows=len(context.check_rows),ambiguous_rows=context.ambiguous_rows)
        # No contexts or KD trees are retained in the twenty-result map.
        checks[s.record.sequence]=ParkingScanCheck(status,reason,context.reference_ids,values,patches)
    return checks


def select_parking_contributors(scans,checks):
    _window(scans)
    return tuple(s for s in scans if checks[s.record.sequence].status=='passed')
