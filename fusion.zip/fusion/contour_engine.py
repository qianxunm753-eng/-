"""Enhanced adapter: causal real scans, staged state, primitive native packets."""
from collections import deque
from dataclasses import replace
import time
import numpy as np
from .state import ScanRecord,retained_bytes
from .registration import LocalMap,transform,representatives
from .trajectory import JointTrajectorySolver
from .window_refinement import WindowRefiner
from .contribution import check_adopted_history


def wire_diagnostics(diagnostics):
    from .validation import ValidationReport
    def wire(value):
        if isinstance(value,ValidationReport):
            return dict(accepted=value.accepted,reason=value.reason,
                before=dict(p90_m=wire(value.before.p90_m),rms_m=wire(value.before.rms_m),coverage=value.before.coverage,
                    patches=wire(value.before.patch_metrics)),
                after=dict(p90_m=wire(value.after.p90_m),rms_m=wire(value.after.rms_m),coverage=value.after.coverage,
                    patches=wire(value.after.patch_metrics)))
        if isinstance(value,dict):return {str(k):wire(v) for k,v in value.items()}
        if isinstance(value,(tuple,list)):return [wire(v) for v in value]
        if isinstance(value,np.generic):value=value.item()
        if isinstance(value,float) and not np.isfinite(value):return None
        return value
    return wire(diagnostics)


def fused_preview(records,reference_pose,limit,budget):
    """Bounded chunks: real 8mm representatives, never dense synthetic cells."""
    inverse=np.linalg.inv(reference_pose);selected=np.empty((0,3),dtype=np.float32)
    for record in records:
        pose=inverse@record.pose
        for start in range(0,len(record.corrected_xyz),20000):
            budget.ensure((limit+20000)*128)
            points=transform(record.corrected_xyz[start:start+20000],pose)
            points=points[np.einsum('ij,ij->i',points,points)<=100.+1e-12]
            merged=np.vstack([selected,points.astype(np.float32)])
            selected=merged[representatives(merged,.008,limit)]
    return selected


def _point_count(value):
    """Inspect the IPC buffer before float conversion or advanced-index copies."""
    if isinstance(value,dict):
        data=value['data'];size=np.dtype(value.get('dtype','<f8')).itemsize
        if len(data)%(size*3):raise ValueError('aligned XYZ buffer required')
        return len(data)//(size*3)
    if isinstance(value,np.ndarray):
        if value.size%3:raise ValueError('aligned XYZ buffer required')
        return value.size//3
    if not len(value):return 0
    return len(value) if hasattr(value[0],'__len__') else len(value)//3


def process_contour(engine,request,epoch):
    from .engine import _array,contributing_suffix
    started=time.monotonic();seq=int(request['sequence']);stamp=float(request['device_time_s'])
    span=tuple(request.get('scan_span_s',(stamp,stamp)))
    budget=engine.make_refinement_budget()
    # Filtering, baseline deskew/registration, immutable copies and paired
    # packing overlap in lifetime. Refuse BEFORE allocating any of them.
    # This conservative envelope includes the bounded map/preview work.
    staging_estimate=_point_count(request['xyz'])*320+20*1024**2
    over_temporary=staging_estimate>budget.temporary_limit_bytes
    if over_temporary:
        xyz=np.empty((0,3));times=np.empty(0);rings=None
    else:
        xyz=_array(request['xyz'],'<f8',(-1,3));times=_array(request['point_times'],'<f8',(-1,))
        rings=None if request.get('rings') is None else _array(request['rings'],'<i4',(-1,))
    if (not np.isfinite(stamp) or len(times)!=len(xyz) or rings is not None and len(rings)!=len(xyz)
        or len(span)!=2 or not np.isfinite(span).all() or not span[0]<=stamp<=span[1]):
        raise ValueError('real point buffers / reference time required')
    identity=(request['session_id'],request['clock_id'],int(epoch));key=(seq,stamp)
    if (identity!=engine.identity or engine.last_input is not None and
        (seq<engine.last_input[0] or stamp<engine.last_input[1] or stamp-engine.last_input[1]>.6+1e-9)):
        engine.reset()
    engine.identity=identity;duplicate=key==engine.last_input
    norm=np.einsum('ij,ij->i',xyz,xyz)
    valid=np.isfinite(xyz).all(axis=1)&np.isfinite(times)&(norm>.04)&(norm<400.)
    rows=np.flatnonzero(valid);points=xyz[rows];point_times=times[rows]
    selected_rings=None if rings is None else rings[rows]
    if len(rows) and (point_times.min()<span[0]-1e-6 or point_times.max()>span[1]+1e-6):
        raise ValueError('point time outside actual scan span')
    diagnostics={'reason':'duplicate_scan'};accepted=False;timing={};state='baseline'
    if not duplicate:
        if engine.mapper.last_good_time is not None and stamp-engine.mapper.last_good_time>.6+1e-9:
            engine.reset();engine.identity=identity
        retained=tuple(engine.contour_records)[-19:]
        minimum=retained_bytes(retained)+len(points)*64+128
        if over_temporary:diagnostics={'reason':'image_temporary_capacity','usable':False,
            'estimated_staging_bytes':staging_estimate}
        elif minimum>engine.byte_budget:diagnostics={'reason':'image_capacity_reached','usable':False}
        else:
            try:
                past=engine.mapper;candidate_map=past.fork();base_started=time.monotonic()
                result=candidate_map.update(points,point_times,selected_rings,stamp,engine.imu,scan_key=(identity,seq))
                timing['baseline']=(time.monotonic()-base_started)*1000.;diagnostics=dict(result.diagnostics)
                if result.usable:
                    record=ScanRecord(identity,seq,stamp,span,points,point_times,rows,selected_rings,
                        result.points,result.pose,result.model)
                    candidate_records=retained+(record,);state='baseline'
                    if budget.check(len(points)*256):
                        phase=time.monotonic();frame=JointTrajectorySolver().solve(record,past,engine.imu,budget)
                        timing['trajectory']=(time.monotonic()-phase)*1000.;diagnostics['trajectory']=wire_diagnostics(frame.diagnostics)
                        if frame.usable:
                            improved=replace(record,corrected_xyz=frame.points,pose=frame.pose,model=frame.model)
                            try:
                                rebuilt=past.rebuilt(retained+(improved,),budget)
                                record=improved;candidate_records=retained+(record,);candidate_map=rebuilt;state='trajectory'
                            except ValueError as error:diagnostics['trajectory_rebuild_refused']=str(error)
                    else:diagnostics['trajectory']={'reason':'refinement_budget'}
                    if engine.contour_mode in ('window','quality') and len(candidate_records)>=2 and budget.check():
                        phase=time.monotonic();window=WindowRefiner().refine(candidate_records,budget)
                        timing['window']=(time.monotonic()-phase)*1000.
                        diagnostics['window']={'accepted':window.accepted,'reason':window.reason,
                            'validation':wire_diagnostics({'report':window.validation})['report']}
                        if window.accepted:
                            try:
                                rebuilt=past.rebuilt(window.records,budget)
                                candidate_records=window.records;record=candidate_records[-1];candidate_map=rebuilt
                                state='joint_window'
                            except ValueError as error:diagnostics['window_rebuild_refused']=str(error)
                    effective=candidate_records
                    if engine.contour_mode=='quality':
                        phase=time.monotonic();per_scan,check=check_adopted_history(candidate_records,budget)
                        timing['contribution_check']=(time.monotonic()-phase)*1000.
                        effective=contributing_suffix(candidate_records,per_scan)
                        if len(effective)!=len(candidate_records):
                            # The next frame must not register against ghosts
                            # that the independently checked display excludes.
                            candidate_map=past.rebuilt(effective,budget)
                        diagnostics['contribution']=dict(check,validation=wire_diagnostics(per_scan),
                            retained_sequences=[r.sequence for r in candidate_records],
                            contributing_sequences=[r.sequence for r in effective])
                    size=retained_bytes(candidate_records)
                    if size>engine.byte_budget:raise ValueError('image_capacity_reached')
                    phase=time.monotonic()
                    # Enhancement deadlines do not prevent trusted baseline
                    # preview publication; use a fresh allocation-only guard.
                    display_budget=engine.make_refinement_budget()
                    if not display_budget.check():
                        from .state import RefinementBudget
                        display_budget=RefinementBudget(window_limit_bytes=engine.byte_budget)
                    fused=fused_preview(effective,record.pose,engine.point_limit,display_budget)
                    pair=dict(engine.paired_views(fused,points),sequence=seq,time=stamp,
                        source_frames=[r.sequence for r in effective],window_sources=[r.sequence for r in candidate_records],
                        raw_points=sum(len(r.raw_xyz) for r in candidate_records),bytes=size,refinement_state=state,
                        effective_span_s=(effective[0].span_s[0],effective[-1].span_s[1]),timing=timing)
                    timing['display_prepare']=(time.monotonic()-phase)*1000.
                    # No state write before every fallible step has succeeded.
                    engine.mapper=candidate_map;engine.contour_records=deque(candidate_records,maxlen=20)
                    engine.window=deque((dict(sequence=r.sequence,time=r.reference_s,xyz=r.corrected_xyz,
                        indices=r.original_indices,point_times=r.point_times,pose=r.pose) for r in candidate_records),maxlen=20)
                    engine.last_pair=pair;accepted=True
            except (ValueError,MemoryError,np.linalg.LinAlgError) as error:
                diagnostics.update(reason=str(error),usable=False,enhancement='held original state')
        engine.last_input=key
    pair=engine.last_pair;held=not accepted and pair is not None and pair['sequence']!=seq
    if pair is None:
        pair=dict(engine.paired_views(points,points),sequence=seq,time=stamp,source_frames=[],window_sources=[],
            raw_points=0,bytes=0,refinement_state='uncompensated',effective_span_s=span,timing={})
    count=len(pair['source_frames']);window_count=len(pair['window_sources'])
    fstate='held_pair' if held else 'uncompensated' if not count else 'window_ready' if window_count==20 else 'building_window'
    packet=dict(format='rsview-clearance-playback-v1',sequence=seq,device_time_s=stamp,
        session_id=identity[0],clock_id=identity[1],epoch=identity[2],status='completed',source_mode='recorded_pcap',
        config_id='rsview-image-contour-v1:'+engine.contour_mode,mode='image_only',calculation='image_fusion_only',
        measurement_basis='image_only',current_scan_measurement=False,measurements=[],secondary_measurements=[],centerline=[],
        candidate_count=0,annotation_region_count=0,measurement_region_count=0,scene_diagnostics={},layer_counts={},
        relative_pose_diagnostics=wire_diagnostics(diagnostics),pose_scope='image_local_map_experimental',
        motion_status='image_compensated' if count else 'raw',retained_points=len(rows),display_limit=0,
        fusion=dict(state=fstate,scan_count=count,source_frames=pair['source_frames'],window_scan_count=window_count,
            effective_scan_count=count,effective_source_frames=pair['source_frames'],effective_span_s=pair['effective_span_s'],
            refinement_state=pair['refinement_state'],reference_sequence=pair['sequence'],reference_time_s=pair['time'],held=held,
            age_s=max(0.,stamp-pair['time']),registration_radius_m=20.,display_radius_m=10.,display_voxel_m=.008,
            display_limit=engine.point_limit,raw_window_points=pair['raw_points'],window_bytes=pair['bytes'],byte_budget=engine.byte_budget,
            temporary_budget_bytes=64*1024**2,imu_available=engine.imu is not None,imu_status=engine.imu_reason,
            clean_preview_available='clean_fused' in pair,clean_preview_counts=pair.get('clean_counts',{}),
            representatives='real returns; bounded chunk sampling, no generated cells'),
        absolute_accuracy_verified=False,semantic_one_object_one_label_verified=False,
        timing_ms=dict(pair['timing'],packet_total=(time.monotonic()-started)*1000.),
        _display={'object':pair['fused']},_single_display={'object':pair['single']})
    if 'clean_fused' in pair:packet.update(_clean_display={'object':pair['clean_fused']},_clean_single_display={'object':pair['clean_single']})
    return packet
