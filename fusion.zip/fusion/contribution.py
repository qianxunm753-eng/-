"""Independent consistency checks on adopted, immutable replay geometry."""
import numpy as np
from dataclasses import replace
from .registration import transform
from .validation import split_original_indices,compare_geometry,ValidationMetrics,accept_refinement
from .window_refinement import _target


def _holdout(record):
    unused,rows=split_original_indices(record.original_indices)
    if record.rings is not None:rows=rows[record.rings[rows]%2==0]
    if len(rows)>3500:rows=rows[np.linspace(0,len(rows)-1,3500,dtype=int)]
    return transform(record.corrected_xyz[rows],record.pose)


def check_adopted_history(records,budget):
    """Newest TRAINING returns check older HELD-OUT real returns.

    Newest holdout estimates its intrinsic normal scatter against the same
    training map; a 4mm noise floor plus the existing 2mm guard avoids pruning
    quantisation-scale disagreement. This is not a physical accuracy bound.
    Unknown/poor overlap is kept, latest is never pruned, and raw history is
    never deleted. Rejected candidate geometry/reports are not inputs here.
    """
    records=tuple(records);reports={}
    if len(records)<2:return reports,dict(reason='building_consistency_support')
    try:
        budget.ensure(16*1024**2)
        anchor=records[-1];geometry=_target(anchor);check=_holdout(anchor)
        calibration=compare_geometry(check,check,geometry).before
        if not calibration.independent_support:
            return {},dict(reason='unknown_anchor_support')
        p90=max(.004,calibration.p90_m);rms=max(.004,calibration.rms_m)
        for record in records[:-1]:
            budget.ensure(16*1024**2);points=_holdout(record)
            actual=compare_geometry(points,points,geometry).before
            if not actual.independent_support:
                reports[record.sequence]=None;continue
            envelope=ValidationMetrics(p90,rms,actual.coverage,
                {name:(p90,rms,1.) for name in actual.patch_metrics},True)
            report=accept_refinement(envelope,actual)
            if report.reason in ('independent_improvement','no_independent_improvement'):
                report=replace(report,accepted=True,reason='consistent_adopted_geometry')
            reports[record.sequence]=report
        reports[anchor.sequence]=None
        return reports,dict(reason='adopted_geometry_checked',basis='latest training / disjoint original holdout',
            noise_floor_m=.004,guard_m=.002,anchor_sequence=anchor.sequence,
            excluded_sequences=[seq for seq,r in reports.items() if r is not None and
                r.reason in ('heldout_p90_regression','heldout_coverage_regression','local_patch_regression')])
    except (ValueError,np.linalg.LinAlgError):
        # Never let a partial/expired check silently change the display set.
        return {},dict(reason='consistency_check_unavailable_keep_history')
