"""Same-origin P3 acceptance: independent local checks, exact baseline fallback."""
from dataclasses import dataclass
import time
import numpy as np
from .p3_geometry import build_geometry,geometry_workspace_estimate
from .p3_refinement import refine_shadow,displacement_guard
from .registration import transform
from .state import retained_bytes


@dataclass(frozen=True)
class EnhancementResult:
    key:object
    accepted:bool
    reason:str
    pair:dict
    report:dict
    display_origins:dict


def pack_shadow_pair(snapshot,poses,budget):
    pair=dict(snapshot.baseline_pair);lookup={r.sequence:(r,p) for r,p in zip(snapshot.scans,poses)}
    inverse=np.linalg.inv(snapshot.scans[-1].pose)
    for name in ('fused','clean_fused'):
        if name not in snapshot.display_origins:continue
        origins=snapshot.display_origins[name];budget.ensure(len(origins)*128)
        cloud=np.empty((len(origins),3),dtype='<f4')
        for sequence in np.unique(origins[:,0]):
            budget.ensure(len(origins)*128)
            if sequence not in lookup:raise ValueError('display origin source missing')
            scan,pose=lookup[sequence];out=np.flatnonzero(origins[:,0]==sequence)
            rows=np.searchsorted(scan.original_indices,origins[out,1])
            if (np.any(rows>=len(scan.original_indices)) or
                not np.array_equal(scan.original_indices[rows],origins[out,1])):raise ValueError('display origin index missing')
            points=transform(scan.corrected_xyz[rows],inverse@pose)
            if np.any(np.einsum('ij,ij->i',points,points)>100.+1e-12):raise ValueError('display boundary crossing')
            cloud[out]=points
        pair[name]=dict(data=cloud.tobytes(),count=len(cloud),dtype='little-float32-xyz')
    return pair


def _metrics(points,targets,directions,maximum):
    residual=np.linalg.norm((points-targets)@directions,axis=1)
    coverage=float(np.mean(np.linalg.norm(points-targets,axis=1)<=maximum)) if len(points) else 0.
    return dict(rms_m=float(np.sqrt(np.mean(residual**2))),p90_m=float(np.percentile(residual,90)),coverage=coverage)


def temporary_peak_estimate(point_counts,packed_bytes):
    return geometry_workspace_estimate(point_counts)+packed_bytes*3


def enhance(snapshot,budget,policy):
    report=dict(source_frames=snapshot.key.source_frames,reference_excludes_checked_scan=True,
        supported_local_improvement=False,all_local_guards_passed=False,physical_accuracy_verified=False,
        policy=policy.primitive(),local_checks=[],unknown_geometry_verified=False)
    def fallback(reason):return EnhancementResult(snapshot.key,False,reason,snapshot.baseline_pair,report,snapshot.display_origins)
    if len(snapshot.scans)!=20:return fallback('base_window_incomplete')
    started=time.monotonic()
    packed_bytes=sum(snapshot.baseline_pair[name]['count']*12 for name in
        ('fused','single','clean_fused','clean_single') if name in snapshot.baseline_pair)
    # Base pair, candidate and worst host serialization copy are simultaneously possible.
    retained=retained_bytes((snapshot,))+packed_bytes*3
    counts=tuple(len(r.corrected_xyz) for r in snapshot.scans)
    temporary=temporary_peak_estimate(counts,packed_bytes)
    retained_upper=retained+sum(counts)*8+min(sum(counts),3500*20)*64
    report.update(retained_estimate_bytes=retained,retained_upper_estimate_bytes=retained_upper,temporary_estimate_bytes=temporary)
    if retained_upper>budget.window_limit_bytes or not budget.check(temporary):return fallback('budget')
    try:
        context=build_geometry(snapshot,budget,policy)
        report['retained_array_bytes_after_geometry']=retained_bytes((snapshot,context))+packed_bytes*3
        if report['retained_array_bytes_after_geometry']>budget.window_limit_bytes:return fallback('budget')
        report.update(small_structure_count=context.small_structure_count,background_fraction=context.background_fraction,
            geometry_diagnostics=context.local_diagnostics,ambiguous_association_count=context.ambiguous_association_count)
        if not context.patches:return fallback('unknown_geometry')
        if not context.small_structure_count:return fallback('no_small_structure_support')
        required={(snapshot.scans[int(owner)].sequence,index) for index,patch in enumerate(context.patches)
            for owner in np.unique(patch.owners)}
        covered={(sequence,reference.patch_index) for sequence,reference in context.check_references}
        report['required_local_checks']=len(required);report['covered_local_checks']=len(required&covered)
        if not required.issubset(covered):return fallback('unknown_geometry')
        proposal=refine_shadow(snapshot,context,budget,policy)
        if not proposal.solved:return fallback(proposal.reason)
        if proposal.key!=snapshot.key or len(proposal.poses)!=len(snapshot.scans):return fallback('invalid_proposal')
        if not np.array_equal(proposal.poses[-1],snapshot.scans[-1].pose):return fallback('invalid_proposal')
        bounded,diagnostics=displacement_guard(snapshot,proposal.poses,budget,policy)
        report.update(diagnostics)
        if not bounded:return fallback('point_displacement')
        lookup={r.sequence:(r,p) for r,p in zip(snapshot.scans,proposal.poses)}
        for sequence,unknown in context.unknown_origins.items():
            scan,pose=lookup[sequence];rows=np.searchsorted(scan.original_indices,unknown)
            for start in range(0,len(rows),8192):
                budget.ensure(temporary);points=scan.corrected_xyz[rows[start:start+8192]]
                movement=np.linalg.norm(transform(points,pose)-transform(points,scan.pose),axis=1)
                if np.max(movement,initial=0.)>policy.unknown_displacement_m+1e-12:return fallback('unknown_geometry')
        improved=False;checked=set()
        for sequence,reference in context.check_references:
            budget.ensure(temporary)
            if sequence in reference.owners:return fallback('invalid_check_reference')
            scan,pose=lookup[sequence];points=scan.corrected_xyz[reference.rows]
            before=_metrics(transform(points,scan.pose),reference.targets,reference.directions,policy.association_m)
            after=_metrics(transform(points,pose),reference.targets,reference.directions,policy.association_m)
            local=dict(sequence=sequence,kind=reference.kind,patch=reference.patch_index,before=before,after=after,
                noise_m=reference.noise_m,reference_owners=reference.owners)
            report['local_checks'].append(local);checked.add(sequence)
            if (after['rms_m']>before['rms_m']+policy.regression_m or after['p90_m']>before['p90_m']+policy.regression_m
                or after['coverage']<before['coverage']*policy.coverage_ratio):return fallback('local_patch_regression')
            if reference.kind!='plane' and before['rms_m']-after['rms_m']>max(1e-9,2.*reference.noise_m):improved=True
        if checked!=set(snapshot.key.source_frames):return fallback('unknown_geometry')
        if not improved:return fallback('no_local_improvement')
        report.update(supported_local_improvement=True,all_local_guards_passed=True)
        try:
            budget.ensure(temporary);pair=pack_shadow_pair(snapshot,proposal.poses,budget)
            budget.ensure(temporary)
        except (ValueError,MemoryError):return fallback('packing_failed')
        report.update(total_ms=(time.monotonic()-started)*1000.,shadow_diagnostics=proposal.diagnostics)
        return EnhancementResult(snapshot.key,True,'supported_local_improvement',pair,report,snapshot.display_origins)
    except (ValueError,MemoryError,np.linalg.LinAlgError):return fallback('budget')
