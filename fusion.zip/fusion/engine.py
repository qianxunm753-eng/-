"""20-real-scan image engine; optional frozen replay measurement adapter.

Normal image processing does not run track, scene or measurement algorithms.
"""
from collections import deque
import time
import numpy as np
from .imu import ImuSeries
from .registration import LocalMap,representatives,transform,display_support


def contributing_suffix(records,per_scan_validation):
    cut=0
    for index,record in enumerate(records[:-1]):
        report=(per_scan_validation or {}).get(record.sequence)
        if report is not None and report.reason in ('heldout_p90_regression','heldout_coverage_regression','local_patch_regression'):
            cut=index+1
    return tuple(records[cut:])


def _array(value,dtype,shape):
    if isinstance(value,dict):
        data=value['data']
        if isinstance(data,str):data=data.encode('latin1')  # Owned Python2 protocol-2 IPC only.
        result=np.frombuffer(data,dtype=value.get('dtype',dtype))
    else:result=np.asarray(value,dtype=dtype)
    return result.reshape(shape)


class ImageFusionEngine:
    def __init__(self,config=None,source_mode='recorded_pcap',experimental_pose_path=None):
        if source_mode!='recorded_pcap' or experimental_pose_path:
            raise ValueError('image fusion is replay-only without recorded pose substitution')
        self.config=dict(config or {});self.imu=None;self.imu_reason='selected recording IMU unavailable; LiDAR-only'
        self.contour_mode=self.config.get('image_contour_mode','baseline')
        if self.contour_mode not in ('baseline','trajectory','window','quality','parking'):raise ValueError('invalid contour mode')
        if self.config.get('image_parking_detail',False) and self.contour_mode!='parking':
            raise ValueError('detail registration is parking replay only')
        self.motion_detail=self.config.get('image_motion_detail',False)
        if type(self.motion_detail) is not bool:
            raise ValueError('motion detail must be a boolean')
        if self.motion_detail and self.contour_mode!='baseline':
            raise ValueError('motion detail requires the rolling baseline replay')
        window_measurement=self.config.get('image_window_measurement',False)
        if type(window_measurement) is not bool:raise ValueError('window measurement must be a boolean')
        capable=self.config.get('image_window_measurement_capable',False)
        if type(capable) is not bool:raise ValueError('window measurement capability must be a boolean')
        if (window_measurement or capable) and (self.contour_mode!='baseline' or self.motion_detail):
            raise ValueError('window measurement requires mature rolling baseline replay')
        path=self.config.get('image_source_path')
        if path:
            try:self.imu=ImuSeries.from_pcap(path);self.imu_reason='same-recording IMU loaded'
            except (OSError,ValueError) as error:self.imu_reason=str(error)+'; LiDAR-only'
        self.byte_budget=int(self.config.get('image_byte_budget',96*1024**2))
        self.point_limit=int(self.config.get('image_display_limit',150000))
        self.clean_preview=bool(self.config.get('image_display_filter_preview',False))
        if self.byte_budget<=0 or not 1<=self.point_limit<=150000:raise ValueError('bounded image limits required')
        self.identity=None;self.last_input=None;self.reset()

    def reset(self):
        self._reset_snapshot_identity()
        self.mapper=LocalMap(detail_sampling=self.motion_detail,extended_deskew=self.motion_detail);self.window=deque(maxlen=20);self.last_pair=None
        self.last_input=None;self.failures=0
        self.contour_records=deque(maxlen=20)

    def _reset_snapshot_identity(self):
        self.generation=getattr(self,'generation',0)+1;self.revision=0
        self.frozen_snapshot=None

    def snapshot_key(self):
        if self.last_pair is None or not self.window or self.identity is None:return None
        from .p3_snapshot import SnapshotKey
        return SnapshotKey(*self.identity,self.generation,self.revision,self.last_pair['sequence'],
            self.last_pair['time'],tuple(self.last_pair['source_frames']))

    def freeze_window(self,budget):
        from .p3_snapshot import freeze_window
        snapshot=freeze_window(self,budget)
        self.frozen_snapshot=snapshot
        return snapshot

    def process_image_control(self,request,budget):
        from rsview_centerline.image_control import validate_control,control_reply,wire_pair
        request=validate_control(request['command'],request['request_id'],request['source_key'],
            request.get('snapshot_key'),request.get('budget_s',60.),request.get('options'))
        if self.contour_mode!='baseline' or tuple(request['source_key'])!=self.identity:
            return control_reply(request,'failed','source_or_mode_mismatch',request.get('snapshot_key'))
        try:
            if request['command']=='freeze':
                snapshot=self.freeze_window(budget)
                return control_reply(request,'frozen','completed_window',snapshot.key.primitive(),wire_pair(snapshot.baseline_pair),
                    dict(scan_count=len(snapshot.scans)))
            snapshot=self.frozen_snapshot
            if snapshot is None or snapshot.key!=self.snapshot_key() or snapshot.key.primitive()!=request['snapshot_key']:
                return control_reply(request,'failed','snapshot_changed',request['snapshot_key'])
            if request['command']=='measure':
                if not (self.config.get('image_window_measurement',False) or self.config.get('image_window_measurement_capable',False)):
                    return control_reply(request,'failed','window_measurement_disabled',snapshot.key.primitive())
                from .window_measurement import measure_snapshot
                packet=measure_snapshot(snapshot,self.config.get('image_window_measurement_config',{}),budget)
                return control_reply(request,'accepted','rolling_window_measured',snapshot.key.primitive(),
                    wire_pair(snapshot.baseline_pair),{'measurement_packet':packet})
            if request['command']=='surface':
                from .surface_diagnostics import diagnose_window
                result=diagnose_window(snapshot,request['options']['roi'],budget,self.point_limit)
                return control_reply(request,'accepted','surface_diagnostic_only',snapshot.key.primitive(),
                    wire_pair(result['pair']),result['report'])
            from .p3_enhancement import enhance
            from .p3_geometry import GeometryPolicy
            result=enhance(snapshot,budget,GeometryPolicy())
            return control_reply(request,'accepted' if result.accepted else 'baseline_retained',result.reason,
                result.key.primitive(),wire_pair(result.pair),result.report)
        except Exception as error:
            snapshot=self.frozen_snapshot
            if snapshot is not None and snapshot.key==self.snapshot_key():
                reason=('surface_diagnosis_failed' if request['command']=='surface' else
                    'window_measurement_failed' if request['command']=='measure' else 'enhancement_failed')
                return control_reply(request,'baseline_retained',reason,snapshot.key.primitive(),
                    wire_pair(snapshot.baseline_pair),{'error':str(error)[:2000]})
            return control_reply(request,'failed','snapshot_unavailable',request.get('snapshot_key'),report={'error':str(error)[:2000]})

    def make_refinement_budget(self):
        from .state import RefinementBudget
        return RefinementBudget(window_limit_bytes=self.byte_budget,
            deadline_s=time.monotonic()+60.,cancelled=lambda:False)

    @staticmethod
    def packed(points):
        return dict(data=np.asarray(points,dtype='<f4').tobytes(),count=len(points),dtype='little-float32-xyz')

    def sampled(self,points):
        keep=np.einsum('ij,ij->i',points,points)<=100.+1e-12
        points=points[keep]
        return points[representatives(points,.008,self.point_limit)] if len(points) else points

    def _sampled_with_rows(self,points):
        keep=np.einsum('ij,ij->i',points,points)<=100.+1e-12
        points=points[keep]
        selected=representatives(points,.008,self.point_limit) if len(points) else np.empty(0,dtype=int)
        sampled=points[selected]
        # The real baseline sample is complete before any optional origin allocation.
        try:rows=np.flatnonzero(keep)[selected]
        except (MemoryError,ValueError):rows=None
        return sampled,rows

    def paired_views(self,fused,single):
        metadata=self.config.get('image_snapshot_support',False) and self.contour_mode=='baseline'
        if metadata:
            fused,fused_rows=self._sampled_with_rows(fused);single,single_rows=self._sampled_with_rows(single)
        else:fused=self.sampled(fused);single=self.sampled(single)
        views=dict(fused=self.packed(fused),single=self.packed(single))
        if self.clean_preview:
            clean_fused_rows=display_support(fused);clean_single_rows=display_support(single)
            clean_fused=fused[clean_fused_rows];clean_single=single[clean_single_rows]
            views.update(clean_fused=self.packed(clean_fused),clean_single=self.packed(clean_single),
                clean_counts=dict(fused_raw=len(fused),fused_kept=len(clean_fused),
                    single_raw=len(single),single_kept=len(clean_single)))
        if metadata and fused_rows is not None and single_rows is not None:
            try:
                selection=dict(fused=fused_rows,single=single_rows)
                if self.clean_preview:selection.update(clean_fused=clean_fused_rows,clean_single=clean_single_rows)
                views['_p3_selection']=selection
            except (MemoryError,ValueError):views.pop('_p3_selection',None)
        return views

    def process(self,request,epoch=0):
        if self.contour_mode=='parking':
            from .parking_engine import process_parking
            return process_parking(self,request,epoch)
        if self.contour_mode!='baseline':
            from .contour_engine import process_contour
            return process_contour(self,request,epoch)
        started=time.monotonic();seq=int(request['sequence']);stamp=float(request['device_time_s'])
        span=tuple(request.get('scan_span_s',(stamp,stamp)))
        xyz=_array(request['xyz'],'<f8',(-1,3));times=_array(request['point_times'],'<f8',(-1,))
        rings=None if request.get('rings') is None else _array(request['rings'],'<i4',(-1,))
        if (not np.isfinite(stamp) or len(times)!=len(xyz) or rings is not None and len(rings)!=len(xyz)
            or len(span)!=2 or not np.isfinite(span).all() or not span[0]<=stamp<=span[1]):
            raise ValueError('real point buffers / device reference time required')
        identity=(request['session_id'],request['clock_id'],int(epoch))
        key=(seq,stamp)
        reset=identity!=self.identity or self.last_input is not None and (
            seq<self.last_input[0] or stamp<self.last_input[1] or stamp-self.last_input[1]>.6+1e-9)
        if reset:self.reset()
        self.identity=identity
        duplicate=key==self.last_input
        valid=np.isfinite(xyz).all(axis=1)&np.isfinite(times)
        norm=np.einsum('ij,ij->i',np.nan_to_num(xyz),np.nan_to_num(xyz))
        valid&=(norm>.04)&(norm<400.)
        rows=np.flatnonzero(valid);points=xyz[rows];point_times=times[rows]
        if len(rows) and (point_times.min()<span[0]-1e-6 or point_times.max()>span[1]+1e-6):
            raise ValueError('native point time outside actual scan span')
        diagnostics={'reason':'duplicate_scan'};held=False;accepted=False
        if not duplicate:
            # Recover from a prolonged unsolved segment with a visibly new
            # local reference, never reinterpret old points under that map.
            if self.mapper.last_good_time is not None and stamp-self.mapper.last_good_time>.6+1e-9:
                self._reset_snapshot_identity()
                self.mapper=LocalMap(detail_sampling=self.motion_detail,extended_deskew=self.motion_detail);self.window.clear();self.last_pair=None
            candidate_mapper=self.mapper.fork()
            result=candidate_mapper.update(points,point_times,None if rings is None else rings[rows],stamp,self.imu)
            diagnostics=dict(result.diagnostics)
            if result.usable:
                record=dict(sequence=seq,time=stamp,xyz=result.points,indices=rows,
                    point_times=point_times,pose=result.pose.copy())
                retained=list(self.window)[1:] if len(self.window)==20 else list(self.window)
                size=sum(r['xyz'].nbytes+r['indices'].nbytes+r['point_times'].nbytes for r in retained+[record])
                if size>self.byte_budget:
                    diagnostics.update(reason='image_capacity_reached',usable=False)
                else:
                    candidate_window=deque(retained+[record],maxlen=20);inverse=np.linalg.inv(result.pose)
                    fused=np.concatenate([transform(r['xyz'],inverse@r['pose']) for r in candidate_window])
                    candidate_pair=dict(self.paired_views(fused,points),
                        sequence=seq,time=stamp,source_frames=[r['sequence'] for r in candidate_window],
                        raw_points=sum(len(r['xyz']) for r in candidate_window),bytes=size)
                    self.mapper=candidate_mapper;self.window=candidate_window;self.last_pair=candidate_pair
                    self.revision+=1;self.frozen_snapshot=None
                    if self.config.get('image_snapshot_support',False):
                        from .p3_snapshot import attach_metadata
                        try:
                            attach_metadata(self,candidate_pair,fused,points,candidate_window,rows,span,
                                None if rings is None else rings[rows])
                        except Exception as error:
                            candidate_pair.pop('_p3_origins',None)
                            diagnostics['snapshot_metadata_error']=str(error)[:160]
                        from .surface_diagnostics import attach_raw_single
                        attach_raw_single(self,candidate_pair,points,rows)
                    accepted=True
            held=not accepted and self.last_pair is not None
            self.last_input=key
        pair=self.last_pair
        if pair is None:
            pair=dict(self.paired_views(points,points),sequence=seq,time=stamp,source_frames=[],raw_points=0,bytes=0)
        if duplicate:held=pair['sequence']!=seq
        count=len(pair['source_frames'])
        state='held_pair' if held else 'uncompensated' if not count else 'window_ready' if count==20 else 'building_window'
        packet=dict(format='rsview-clearance-playback-v1',sequence=seq,device_time_s=stamp,
            session_id=identity[0],clock_id=identity[1],epoch=identity[2],status='completed',source_mode='recorded_pcap',
            config_id='rsview-image-fusion-v2',mode='image_only',calculation='image_fusion_only',
            measurement_basis='image_only',current_scan_measurement=False,measurements=[],secondary_measurements=[],
            centerline=[],candidate_count=0,annotation_region_count=0,measurement_region_count=0,
            scene_diagnostics={},layer_counts={},relative_pose_diagnostics=diagnostics,
            pose_scope='image_local_map_experimental',motion_status='image_compensated' if count else 'raw',
            retained_points=len(rows),display_limit=0,
            fusion=dict(state=state,scan_count=count,source_frames=pair['source_frames'],
                reference_sequence=pair['sequence'],reference_time_s=pair['time'],held=held,
                age_s=max(0.,stamp-pair['time']),registration_radius_m=20.,display_radius_m=10.,
                display_voxel_m=.008,display_limit=self.point_limit,raw_window_points=pair['raw_points'],
                window_bytes=pair['bytes'],byte_budget=self.byte_budget,imu_available=self.imu is not None,
                clean_preview_available='clean_fused' in pair,clean_preview_counts=pair.get('clean_counts',{}),
                imu_status=self.imu_reason,representatives='real returns, not generated voxel centers'),
            absolute_accuracy_verified=False,semantic_one_object_one_label_verified=False,
            timing_ms={'packet_total':(time.monotonic()-started)*1000.},
            _display={'object':pair['fused']},_single_display={'object':pair['single']})
        if 'clean_fused' in pair:
            packet.update(_clean_display={'object':pair['clean_fused']},
                _clean_single_display={'object':pair['clean_single']})
        if self.config.get('image_snapshot_support',False):
            snapshot_key=self.snapshot_key()
            packet['fusion']['snapshot_key']=None if snapshot_key is None else snapshot_key.primitive()
        if self.motion_detail:
            packet['fusion'].update(motion_detail_enabled=True,
                fitting_policy='feature-balanced real-return sampling; background coverage reserved',
                deskew_refinement_limit=60)
        return packet
