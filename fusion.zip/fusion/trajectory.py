"""Joint endpoint motion fitting on actual point times, against past geometry."""
from dataclasses import dataclass
import numpy as np
from scipy.spatial.transform import Rotation,Slerp
from .registration import Registration,representatives,transform
from .state import freeze
from .validation import split_original_indices,compare_geometry


@dataclass(frozen=True)
class TrajectoryModel:
    mode:str
    span_s:tuple
    reference_s:float
    begin_pose:np.ndarray
    end_pose:np.ndarray

    def __post_init__(self):
        if self.mode not in ('gyro','lidar') or not self.span_s[0]<=self.reference_s<=self.span_s[1]:
            raise ValueError('real endpoint model required')
        for name in ('begin_pose','end_pose'):
            pose=np.asarray(getattr(self,name),dtype=float)
            if (pose.shape!=(4,4) or not np.isfinite(pose).all()
                or not np.allclose(pose[3],[0.,0.,0.,1.])
                or not np.allclose(pose[:3,:3].T@pose[:3,:3],np.eye(3),atol=1e-7)
                or np.linalg.det(pose[:3,:3])<.999999):raise ValueError('finite rigid endpoint pose required')
            object.__setattr__(self,name,freeze(pose))

    def alpha(self,times):
        values=np.asarray(times,dtype=float);duration=self.span_s[1]-self.span_s[0]
        if duration<=0 or not np.isfinite(values).all() or np.any(values<self.span_s[0]-1e-6) or np.any(values>self.span_s[1]+1e-6):
            raise ValueError('nonzero real scan time coverage required')
        return (values-self.span_s[0])/duration

    @property
    def reference_pose(self):
        a=float(self.alpha(np.array([self.reference_s]))[0]);pose=np.eye(4)
        pose[:3,3]=(1-a)*self.begin_pose[:3,3]+a*self.end_pose[:3,3]
        pose[:3,:3]=(self.begin_pose[:3,:3] if self.mode=='gyro' else
            Slerp([0.,1.],Rotation.from_matrix(np.stack([self.begin_pose[:3,:3],self.end_pose[:3,:3]])))([a]).as_matrix()[0])
        return pose

    def world_points(self,raw_xyz,point_times,imu=None):
        a=self.alpha(point_times);translation=(1-a[:,None])*self.begin_pose[:3,3]+a[:,None]*self.end_pose[:3,3]
        if self.mode=='gyro':
            if imu is None:raise ValueError('same-recording gyro coverage required')
            rotated=imu.deskew(raw_xyz,point_times,self.reference_s)@self.begin_pose[:3,:3].T
        else:
            rotations=Slerp([0.,1.],Rotation.from_matrix(np.stack([self.begin_pose[:3,:3],self.end_pose[:3,:3]])))(np.clip(a,0.,1.))
            vectors=np.asarray(raw_xyz)
            if not vectors.flags.writeable:vectors=vectors.copy()
            rotated=rotations.apply(vectors)
        return rotated+translation

    def corrected_points(self,raw_xyz,point_times,imu=None):
        return transform(self.world_points(raw_xyz,point_times,imu),np.linalg.inv(self.reference_pose))


class JointTrajectorySolver:
    def solve(self,record,past_map,imu,budget):
        active=False;imu_status='IMU missing; LiDAR-only'
        def reject(reason,**extra):
            return Registration(record.pose.copy(),record.corrected_xyz,False,
                dict(reason=reason,imu_active=active,imu_status=imu_status,**extra))
        if not budget.check(len(record.raw_xyz)*256):return reject('refinement_budget')
        if (record.source_key,record.sequence) in past_map.key_sources:return reject('self_support_refused')
        if past_map.geometry is None:return reject('no_past_geometry')
        if record.span_s[1]-record.span_s[0]<=1e-9:return reject('zero_scan_span')
        rotated=record.raw_xyz
        if imu is not None:
            try:
                imu.orientation(np.array([past_map.last_good_time,*record.span_s]))
                rotated=imu.deskew(record.raw_xyz,record.point_times,record.reference_s)
                active=True;imu_status='same-recording genuine gyro interval'
            except ValueError as error:imu_status=str(error)+'; LiDAR-only'
        a=(record.point_times-record.span_s[0])/(record.span_s[1]-record.span_s[0])
        ar=(record.reference_s-record.span_s[0])/(record.span_s[1]-record.span_s[0]);beta=a-ar
        denom=float(beta@beta)
        delta_local=np.sum(beta[:,None]*(record.corrected_xyz-rotated),axis=0)/max(denom,1e-20)
        displacement=record.pose[:3,:3]@delta_local
        begin=record.pose.copy();end=record.pose.copy()
        begin[:3,3]-=ar*displacement;end[:3,3]+=(1-ar)*displacement
        model=TrajectoryModel('gyro' if active else 'lidar',record.span_s,record.reference_s,begin,end)
        fit,check=split_original_indices(record.original_indices)
        if record.rings is not None:
            fit=fit[record.rings[fit]%2==0];check=check[record.rings[check]%2==0]
        if len(fit)<50 or len(check)<50:return reject('insufficient_independent_points')
        fit=fit[representatives(record.corrected_xyz[fit],.04,3500)]
        if len(check)>3500:check=check[np.linspace(0,len(check)-1,3500,dtype=int)]
        raw=record.raw_xyz[fit];times=record.point_times[fit];af=a[fit]
        target,tree,normals,confidence=past_map.geometry;rank=0
        for iteration in range(5):
            if not budget.check(len(record.raw_xyz)*256):return reject('refinement_budget')
            world=model.world_points(raw,times,imu if active else None)
            distance,idx=tree.query(world,distance_upper_bound=.12,workers=1);keep=np.isfinite(distance)
            if keep.sum()<50:return reject('insufficient_correspondences')
            q=target[idx[keep]];n=normals[idx[keep]];conf=confidence[idx[keep]]
            r=np.einsum('ij,ij->i',q-world[keep],n)
            translations=(1-af[:,None])*model.begin_pose[:3,3]+af[:,None]*model.end_pose[:3,3]
            cross=np.cross(world[keep]-translations[keep],n)
            left=(1-af[keep,None]);right=af[keep,None]
            jac=(np.column_stack((cross,n*left,n*right)) if active else
                np.column_stack((cross*left,n*left,cross*right,n*right)))
            weight=np.sqrt(np.minimum(1.,.02/(np.abs(r)+1e-9))*conf)
            weighted=jac*weight[:,None]
            singular=np.linalg.svd(weighted,compute_uv=False);expected=9 if active else 12
            rank=int(np.sum(singular>singular[0]*1e-5))
            if rank<expected or singular[0]/max(singular[-1],1e-15)>1e7:
                return reject('unobservable_motion',rank=rank)
            step=np.linalg.lstsq(np.vstack([weighted,.001*np.eye(expected)]),
                np.concatenate([r*weight,np.zeros(expected)]),rcond=1e-5)[0]
            if not np.isfinite(step).all():return reject('nonfinite_motion')
            begin=model.begin_pose.copy();end=model.end_pose.copy()
            if active:
                rotation=Rotation.from_rotvec(step[:3]).as_matrix()
                begin[:3,:3]=rotation@begin[:3,:3];end[:3,:3]=rotation@end[:3,:3]
                begin[:3,3]+=step[3:6];end[:3,3]+=step[6:9]
            else:
                begin[:3,:3]=Rotation.from_rotvec(step[:3]).as_matrix()@begin[:3,:3]
                begin[:3,3]+=step[3:6]
                end[:3,:3]=Rotation.from_rotvec(step[6:9]).as_matrix()@end[:3,:3];end[:3,3]+=step[9:12]
            model=TrajectoryModel(model.mode,model.span_s,model.reference_s,begin,end)
            if np.linalg.norm(step)<1e-5:break
        old=transform(record.corrected_xyz[check],record.pose)
        new=model.world_points(record.raw_xyz[check],record.point_times[check],imu if active else None)
        report=compare_geometry(old,new,past_map.geometry)
        diagnostics=dict(reason=report.reason,imu_active=active,imu_status=imu_status,rank=rank,
            iterations=iteration+1,validation=report,registration='joint real-time endpoint trajectory; past-map only')
        if not report.accepted:return Registration(record.pose.copy(),record.corrected_xyz,False,diagnostics)
        points=model.corrected_points(record.raw_xyz,record.point_times,imu if active else None)
        return Registration(model.reference_pose,points,True,diagnostics,model)
