"""Read-only completed P3 windows; corrected coordinates are NEVER raw scans."""
from dataclasses import dataclass,asdict
from types import MappingProxyType
import numpy as np
from .registration import representatives,display_support
from .state import retained_bytes


def readonly(value,copy=False):
    result=np.array(value,copy=True) if copy else np.asarray(value).view()
    result.flags.writeable=False
    return result


@dataclass(frozen=True)
class SnapshotKey:
    session_id:str
    clock_id:str
    epoch:int
    generation:int
    revision:int
    reference_sequence:int
    reference_time_s:float
    source_frames:tuple

    def primitive(self):
        return asdict(self)


@dataclass(frozen=True)
class CompensatedScan:
    sequence:int
    reference_s:float
    span_s:tuple
    corrected_xyz:np.ndarray
    point_times:np.ndarray
    original_indices:np.ndarray
    pose:np.ndarray
    rings:object=None

    def __post_init__(self):
        n=len(self.corrected_xyz)
        if (self.corrected_xyz.shape!=(n,3) or self.point_times.shape!=(n,)
            or self.original_indices.shape!=(n,) or self.pose.shape!=(4,4)
            or self.rings is not None and self.rings.shape!=(n,)
            or len(self.span_s)!=2 or not self.span_s[0]<=self.reference_s<=self.span_s[1]):
            raise ValueError('aligned compensated scan metadata required')
        for name in ('corrected_xyz','point_times','original_indices','pose','rings'):
            value=getattr(self,name)
            if value is not None:object.__setattr__(self,name,readonly(value,copy=name=='pose'))


@dataclass(frozen=True)
class CompensatedWindowSnapshot:
    key:SnapshotKey
    scans:tuple
    baseline_pair:dict
    display_origins:dict


def selection(points,limit):
    rows=np.flatnonzero(np.einsum('ij,ij->i',points,points)<=100.+1e-12)
    return rows[representatives(points[rows],.008,limit)] if len(rows) else rows


def attach_metadata(engine,pair,fused,single,window,indices,span,rings):
    """Optional bounded sidecar. Allocation failure never rejects a base scan."""
    limit=min(16*1024**2,int(engine.config.get('image_snapshot_metadata_limit',16*1024**2)))
    selections=pair.pop('_p3_selection',None)
    if selections is None:return
    estimate=(min(len(fused),engine.point_limit)+min(len(single),engine.point_limit))*32
    ring_bytes=sum(r.get('_p3_rings',np.empty(0)).nbytes for r in window)
    ring_bytes+=0 if rings is None else rings.nbytes
    if estimate+ring_bytes>limit or pair['bytes']+estimate+ring_bytes>engine.byte_budget:
        for record in window:record.pop('_p3_rings',None)
        return
    try:
        window[-1]['_p3_span']=tuple(span)
        if rings is not None:window[-1]['_p3_rings']=rings.copy()
        selected=selections['fused'];single_rows=selections['single']
        counts=np.array([len(r['xyz']) for r in window]);ends=np.cumsum(counts)
        owners=np.searchsorted(ends,selected,side='right');starts=np.r_[0,ends[:-1]]
        origins=np.empty((len(selected),2),dtype=np.int64)
        for owner,record in enumerate(window):
            rows=np.flatnonzero(owners==owner)
            origins[rows,0]=record['sequence'];origins[rows,1]=record['indices'][selected[rows]-starts[owner]]
        single_origins=np.column_stack((np.full(len(single_rows),pair['sequence'],dtype=np.int64),indices[single_rows]))
        mapping=dict(fused=readonly(origins),single=readonly(single_origins))
        if 'clean_fused' in pair:
            mapping.update(clean_fused=readonly(origins[selections['clean_fused']]),
                clean_single=readonly(single_origins[selections['clean_single']]))
        actual=retained_bytes(tuple(mapping.values()))+sum(r.get('_p3_rings',np.empty(0)).nbytes for r in window)
        if actual<=limit and pair['bytes']+actual<=engine.byte_budget:pair['_p3_origins']=mapping
    except (MemoryError,ValueError):
        pass  # Explicit missing metadata on freeze; base pair remains usable.
    if '_p3_origins' not in pair:
        for r in window:r.pop('_p3_rings',None)


def freeze_window(engine,budget):
    budget.ensure()
    if engine.contour_mode!='baseline' or not engine.config.get('image_snapshot_support',False):
        raise ValueError('P3 snapshot requires enabled baseline metadata')
    pair=engine.last_pair
    if pair is None or not engine.window:raise ValueError('base window unavailable')
    if '_p3_origins' not in pair:raise ValueError('snapshot metadata capacity')
    size=retained_bytes(tuple(engine.window))+retained_bytes(tuple(pair['_p3_origins'].values()))
    size+=sum(pair[name]['count']*12 for name in ('fused','single','clean_fused','clean_single') if name in pair)
    size+=retained_bytes((pair.get('_surface_raw_single',{}),))
    if size+len(engine.window)*128>budget.window_limit_bytes:raise ValueError('snapshot window capacity')
    scans=tuple(CompensatedScan(r['sequence'],r['time'],r.get('_p3_span',(float(r['point_times'].min()),float(r['point_times'].max()))),
        r['xyz'],r['point_times'],r['indices'],r['pose'],r.get('_p3_rings')) for r in engine.window)
    return CompensatedWindowSnapshot(engine.snapshot_key(),scans,pair,
        MappingProxyType({k:readonly(v) for k,v in pair['_p3_origins'].items()}))
