"""Fixed real-return training/heldout supports for post-baseline rigid refinement.

Geometry roles are numerical constraints, NOT equipment classes or truth labels.
"""
from dataclasses import dataclass,field,asdict
import numpy as np
from scipy.spatial import cKDTree
from .registration import representatives,detail_representatives,transform
from .p3_snapshot import readonly


@dataclass(frozen=True)
class GeometryPolicy:
    version:str='p3-geometry-v1'
    training_limit:int=3500
    max_patches:int=512
    association_m:float=.08
    direction_degrees:float=20.
    translation_m:float=.02
    rotation_degrees:float=.1
    visible_displacement_m:float=.02
    context_displacement_m:float=.04
    unknown_displacement_m:float=.002
    regression_m:float=.002
    coverage_ratio:float=.95

    def primitive(self):return asdict(self)


@dataclass(frozen=True)
class GeometryPatch:
    kind:str
    owners:np.ndarray
    rows:np.ndarray
    local_points:np.ndarray
    center:np.ndarray
    directions:np.ndarray
    noise_m:float
    check_rms_before:float=0.


@dataclass(frozen=True)
class CheckReference:
    owners:tuple
    rows:np.ndarray
    targets:np.ndarray
    directions:np.ndarray
    patch_index:int
    kind:str
    noise_m:float


@dataclass
class GeometryContext:
    patches:tuple=()
    check_references:tuple=()
    training_origins:set=field(default_factory=set)
    check_origins:set=field(default_factory=set)
    small_structure_count:int=0
    background_fraction:float=1.
    stripe_as_edge_count:int=0
    ambiguous_association_count:int=0
    forced_matches:int=0
    synthetic_points:int=0
    local_diagnostics:tuple=()
    unknown_origins:dict=field(default_factory=dict)
    estimated_temporary_bytes:int=0


def _pca(points):
    centered=points-points.mean(axis=0)
    eigen,vectors=np.linalg.eigh(centered.T@centered/max(1,len(points)))
    return eigen,vectors,centered


def _mad(values):
    values=np.asarray(values).ravel()
    return float(1.4826*np.median(np.abs(values-np.median(values))))


def _parallel_split(points,normal):
    """A sampling gap alone is not two faces: both sides must be locally parallel."""
    projected=points@normal;order=np.argsort(projected);gaps=np.diff(projected[order])
    if len(gaps)<12:return False
    split=int(np.argmax(gaps[5:-5]))+6
    if gaps[split-1]<=.003:return False
    left=points[order[:split]];right=points[order[split:]]
    a,va,ca=_pca(left);b,vb,cb=_pca(right)
    return (a[0]<.02*max(a[1],1e-12) and b[0]<.02*max(b[1],1e-12)
        and abs(va[:,0]@vb[:,0])>np.cos(np.deg2rad(10.))
        and max(np.percentile(abs(ca@va[:,0]),90),np.percentile(abs(cb@vb[:,0]),90))
            <min(.001,gaps[split-1]/4.))


def geometry_workspace_estimate(point_counts,training_limit=3500):
    """All unknown indices survive; full-coordinate transforms coexist for ONE scan only."""
    point_counts=tuple(point_counts);total=sum(point_counts)
    return min(total,training_limit*len(point_counts))*480+total*8+max(point_counts,default=0)*64


def _compatible_surfaces(a,b,policy):
    """Adjacent cells may support one surface; parallel offset faces may not."""
    tolerance=max(.002,2.*max(a.noise_m,b.noise_m))
    delta=a.center-b.center
    if a.kind=='line' or b.kind=='line':
        if a.kind!=b.kind:return False
        axis_a=np.cross(a.directions[:,0],a.directions[:,1]);axis_a/=np.linalg.norm(axis_a)
        axis_b=np.cross(b.directions[:,0],b.directions[:,1]);axis_b/=np.linalg.norm(axis_b)
        return (abs(axis_a@axis_b)>=np.cos(np.deg2rad(policy.direction_degrees))
            and np.linalg.norm(np.cross(delta,axis_a))<=tolerance)
    normal_a=a.directions[:,0]/np.linalg.norm(a.directions[:,0])
    normal_b=b.directions[:,0]/np.linalg.norm(b.directions[:,0])
    return (abs(normal_a@normal_b)>=np.cos(np.deg2rad(policy.direction_degrees))
        and max(abs(delta@normal_a),abs(delta@normal_b))<=tolerance)


def fixed_associations(query,supports,policy,check_budget=lambda:None):
    """Freeze nearest REAL targets, refusing a second incompatible surface at <=1.25x.

    Two sequential tree passes avoid a queries-by-patches distance matrix.
    """
    best=np.full(len(query),np.inf);assignment=np.full(len(query),-1,dtype=int);targets=np.zeros_like(query)
    prepared=[]
    for index,patch,points in supports:
        check_budget();tree=cKDTree(points);prepared.append((index,patch,tree))
        distance,near=tree.query(query,distance_upper_bound=policy.association_m,workers=1)
        keep=(distance<best)&np.isfinite(distance)
        best[keep]=distance[keep];assignment[keep]=index;targets[keep]=points[near[keep]]
    ambiguous=np.zeros(len(query),dtype=bool);lookup={index:patch for index,patch,tree in prepared}
    for index,patch,tree in prepared:
        check_budget()
        for winner in np.unique(assignment[assignment>=0]):
            if winner==index or _compatible_surfaces(patch,lookup[int(winner)],policy):continue
            rows=np.flatnonzero(assignment==winner)
            distance,unused=tree.query(query[rows],distance_upper_bound=policy.association_m,workers=1)
            ambiguous[rows]|=distance<=1.25*best[rows]+1e-12
    assignment[ambiguous]=-1
    return assignment,targets,ambiguous


def build_geometry(snapshot,budget,policy):
    context=GeometryContext();scans=snapshot.scans
    estimate=geometry_workspace_estimate((len(r.corrected_xyz) for r in scans),policy.training_limit)
    budget.ensure(estimate);context.estimated_temporary_bytes=estimate
    if len(scans)<3:
        context.unknown_origins={r.sequence:readonly(r.original_indices) for r in scans}
        return context
    world=[];local=[];owners=[];rows=[];reserved=selected_count=0
    for owner,scan in enumerate(scans):
        budget.ensure(estimate)
        fit=np.flatnonzero(scan.original_indices%5!=0)
        points=scan.corrected_xyz[fit]
        coarse=representatives(points,.045,policy.training_limit)
        effective_limit=min(policy.training_limit,max(1,2*len(coarse)))
        selected=detail_representatives(points,.045,effective_limit)
        reserve=coarse[np.linspace(0,len(coarse)-1,min(len(coarse),(effective_limit+1)//2),dtype=int)] if len(coarse) else coarse
        reserved+=len(np.intersect1d(selected,reserve));selected_count+=len(selected)
        fit=fit[selected];points=scan.corrected_xyz[fit]
        local.append(points);world.append(transform(points,scan.pose));rows.append(fit)
        owners.append(np.full(len(fit),owner,dtype=np.int32))
        context.training_origins.update((scan.sequence,int(index)) for index in scan.original_indices[fit])
    context.background_fraction=min(1.,reserved/max(1,selected_count))
    world=np.concatenate(world);local=np.concatenate(local);rows=np.concatenate(rows);owners=np.concatenate(owners)
    if not len(world):
        context.unknown_origins={r.sequence:readonly(r.original_indices) for r in scans};return context
    keys=np.floor(world/.16).astype(np.int64);unused,inverse=np.unique(keys,axis=0,return_inverse=True)
    order=np.argsort(inverse,kind='stable');groups=np.split(order,np.flatnonzero(np.diff(inverse[order]))+1)
    stack=[(group,.16) for group in groups];patches=[];diagnostics=[]
    while stack and len(patches)<policy.max_patches:
        budget.ensure(estimate);member,size=stack.pop()
        who=np.unique(owners[member]);who=np.array([i for i in who if np.sum(owners[member]==i)>=6],dtype=int)
        if len(who)<3:continue
        member=member[np.isin(owners[member],who)];points=world[member]
        eigen,vectors,centered=_pca(points)
        if eigen[2]<=1e-12:continue
        kind='line' if eigen[1]<.1*eigen[2] else 'plane' if eigen[0]<.2*eigen[1] else 'neighborhood'
        directions=vectors[:,:2] if kind=='line' else vectors[:,:1]
        # Opposite faces may appear in DIFFERENT scans, not within one scan.
        if kind!='line' and _parallel_split(points,vectors[:,0]):
            context.ambiguous_association_count+=len(member);continue
        reliable=True;curved=False;noises=[];scatter=[];ambiguous=False
        for owner in who:
            own=points[owners[member]==owner];ev,vv,c=_pca(own)
            direction=vv[:,2] if kind=='line' else vv[:,0]
            shared=vectors[:,2] if kind=='line' else vectors[:,0]
            if abs(direction@shared)<np.cos(np.deg2rad(policy.direction_degrees)):reliable=False;break
            intrinsic=c@(vv[:,:2] if kind=='line' else vv[:,:1])
            scatter.append(float(np.percentile(np.linalg.norm(intrinsic,axis=1),90)))
            noises.append(_mad(intrinsic))
            if kind=='line':
                scan=scans[owner];rr=rows[member][owners[member]==owner]
                if scan.rings is None or len(np.unique(scan.rings[rr]))<2:reliable=False;break
            else:
                if _parallel_split(own,vv[:,0]):ambiguous=True;break
                curved|=ev[0]>.001*max(ev[1],1e-12)
        if ambiguous:
            context.ambiguous_association_count+=len(member);continue
        if kind=='line' and not reliable:continue  # A stripe is never promoted just for being line-like.
        if reliable and max(scatter,default=np.inf)<=.006:
            if curved and kind!='line':kind='neighborhood'
            if kind=='neighborhood':
                # Covariance-weighted REAL neighborhood; never a whole-lamp flattening model.
                directions=vectors@np.diag(np.sqrt(np.clip(max(eigen[0],1e-10)/np.maximum(eigen,1e-10),.02,1.)))
            patch=GeometryPatch(kind,readonly(owners[member]),readonly(rows[member]),readonly(local[member]),
                readonly(points.mean(axis=0)),readonly(directions),float(np.median(noises)))
            patches.append(patch)
            diagnostics.append(dict(kind=kind,sources=len(who),size_m=size,within_scan_p90_m=max(scatter),
                cross_scan_p90_m=float(np.percentile(np.linalg.norm(centered@directions,axis=1),90)),noise_m=patch.noise_m))
        elif size>.020001:
            child=np.floor(points/(size/2.)).astype(np.int64);unused,inv=np.unique(child,axis=0,return_inverse=True)
            ordered=np.argsort(inv,kind='stable')
            for group in np.split(ordered,np.flatnonzero(np.diff(inv[ordered]))+1):stack.append((member[group],size/2.))
    context.patches=tuple(patches);context.local_diagnostics=tuple(diagnostics)
    context.small_structure_count=sum(p.kind!='plane' for p in patches)
    references=[]
    # Check association/targets are fixed BEFORE proposing or evaluating any pose change.
    for owner,scan in enumerate(scans):
        budget.ensure(estimate)
        check=np.flatnonzero(scan.original_indices%5==0)
        if len(check)>3500:check=check[np.linspace(0,len(check)-1,3500,dtype=int)]
        query=transform(scan.corrected_xyz[check],scan.pose)
        context.check_origins.update((scan.sequence,int(i)) for i in scan.original_indices[check])
        supports=[]
        for index,patch in enumerate(patches):
            external=patch.owners!=owner
            if not external.any() or not np.any(patch.owners==owner):continue
            external_owners=np.unique(patch.owners[external]);target=np.empty((external.sum(),3));offset=0
            for i in external_owners:
                pp=patch.local_points[external&(patch.owners==i)];target[offset:offset+len(pp)]=transform(pp,scans[i].pose);offset+=len(pp)
            supports.append((index,patch,target))
        assignment,targets,ambiguous=fixed_associations(query,supports,policy,lambda:budget.ensure(estimate))
        context.ambiguous_association_count+=int(ambiguous.sum())
        known=np.zeros(len(scan.corrected_xyz),dtype=bool)
        for patch in patches:known[patch.rows[patch.owners==owner]]=True
        for index in np.unique(assignment[assignment>=0]):
            selected=np.flatnonzero(assignment==index);patch=patches[index]
            external_ids=tuple(scans[i].sequence for i in np.unique(patch.owners) if i!=owner)
            references.append((scan.sequence,CheckReference(external_ids,readonly(check[selected]),readonly(targets[selected]),
                patch.directions,int(index),patch.kind,patch.noise_m)))
            known[check[selected]]=True
        # Only actual supported fit/check origins are known, not a centroid radius.
        context.unknown_origins[scan.sequence]=readonly(scan.original_indices[~known])
    context.check_references=tuple(references)
    return context
