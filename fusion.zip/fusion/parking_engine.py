"""Transactional parking-only image capture; no measurement imports."""
from dataclasses import replace
import time
import numpy as np
from .state import ScanRecord,retained_bytes
from .registration import LocalMap
from .parking_state import ParkingCapture,ParkingBudget,CapturedScan,_token
from .parking_alignment import align_parking_scan,rebase_model,parking_detail_candidate
from .parking_quality import (build_parking_context,check_micro_candidate,
    check_parking_window,select_parking_contributors,_evaluate,ParkingScanCheck)
from .contour_engine import fused_preview,wire_diagnostics,_point_count


def _detail_pass(records,checks,previous,previous_checks,budget):
    """Optional staged proposal; failure must not discard a valid baseline."""
    diag=dict(detail_state='baseline_retained',detail_reason='insufficient_independent_support')
    wrapped=records[-1];seq=wrapped.record.sequence
    if checks[seq].status!='passed':return records,checks,diag
    try:
        past=tuple(s.record for s in select_parking_contributors(previous,previous_checks)) if previous else ()
        detail,reason=parking_detail_candidate(wrapped.record,past,budget)
        diag['detail_reason']=reason
        if detail is None:return records,checks,diag
        ordinary=build_parking_context(records,seq,budget)
        fine=build_parking_context(records,seq,budget,detail_sampling=True)
        if ordinary is None or fine is None or fine.ambiguous_rows>=12:
            diag['detail_reason']='insufficient_or_ambiguous_detail_support';return records,checks,diag
        before,unused,bad_before=_evaluate(wrapped.record,fine)
        metric,patches,outside=_evaluate(detail,fine)
        report=check_micro_candidate(wrapped.record,detail,fine)
        old_report=check_micro_candidate(wrapped.record,detail,ordinary)
        diag['detail_validation']=wire_diagnostics({'report':report})['report']
        if not before.independent_support or not metric.independent_support:
            diag['detail_reason']='insufficient_detail_support';return records,checks,diag
        if bad_before or outside:
            diag['detail_reason']='detail_surface_outside_fixed_noise';return records,checks,diag
        if not report.accepted or not old_report.accepted:
            diag['detail_reason']=report.reason if not report.accepted else 'ordinary_'+old_report.reason
            return records,checks,diag
        candidate=records[:-1]+(replace(wrapped,record=detail),)
        staged_checks=check_parking_window(candidate,budget)
        # The candidate also becomes a reference for other scans. Never
        # trade a trusted neighbour's support for this scan's improvement.
        if any(c.status=='passed' and staged_checks[i].status!='passed' for i,c in checks.items()):
            diag['detail_reason']='other_scan_support_regression';return records,checks,diag
        staged_checks[seq]=ParkingScanCheck('passed','independent_detail_improvement',fine.reference_ids,
            dict(p90_m=metric.p90_m,rms_m=metric.rms_m,coverage=metric.coverage,
                checked_rows=len(fine.check_rows),ambiguous_rows=fine.ambiguous_rows),patches)
        diag.update(detail_state='accepted',detail_reason='independent_detail_improvement')
        return candidate,staged_checks,diag
    except (ValueError,MemoryError,np.linalg.LinAlgError) as error:
        diag['detail_reason']=str(error);return records,checks,diag


class ParkingRuntime:
    def __init__(self,config,imu,clock=time.monotonic,cancelled=lambda:False):
        self.config=dict(config);self.imu=imu;self.clock=clock;self.cancelled=cancelled
        self.capture=ParkingCapture(clock);self.mapper=LocalMap();self.records=()
        self.checks={};self.last_pair=None;self.identity=None;self.command_token=None
        self.last_input=None
        self.detail_enabled=bool(config.get('image_parking_detail',False))

    def budget(self,capture):
        return ParkingBudget(capture.deadline_s,self.clock,self.cancelled,
            window_limit_bytes=int(self.config.get('image_byte_budget',96*1024**2)))

    def finish(self,reason):return self.capture.finish(reason)

    def _pair_bytes(self):
        if self.last_pair is None:return 0
        return sum(len(self.last_pair[k]['data']) for k in ('fused','single','clean_fused','clean_single')
            if k in self.last_pair)

    def process(self,engine,request,epoch):
        from .engine import _array
        started=self.clock();seq=int(request['sequence']);stamp=float(request['device_time_s'])
        identity=(request['session_id'],request['clock_id'],int(epoch));key=(seq,stamp)
        token=request.get('capture_request_id');remaining=request.get('capture_remaining_s',0.)
        if token is not None:_token(token)
        control=self.capture.fork()
        new_command=token is not None and token!=self.command_token
        source_changed=self.identity is not None and identity!=self.identity
        if new_command:
            control.start(token,identity);self.command_token=token
            self.mapper=LocalMap();self.records=();self.checks={};self.last_input=None
            if source_changed:self.last_pair=None
        elif source_changed:
            control.cancel('source_changed');self.records=();self.checks={};self.mapper=LocalMap();self.last_pair=None
        elif token is None and control.state!='idle':control.cancel('manual_cancel')
        self.identity=identity
        if token is not None:control.limit_remaining(float(remaining))
        if self.cancelled():control.finish('cancelled')
        duplicate=key==self.last_input
        budget=self.budget(control)
        count=_point_count(request['xyz']);staging=count*320+20*1024**2
        capacity=staging>budget.temporary_limit_bytes
        # Account the old frozen pair and immutable records during staging,
        # before decoding or making full scan copies.
        minimum=retained_bytes(self.records)+self._pair_bytes()+count*64+128
        if minimum>budget.window_limit_bytes:capacity=True
        points=np.empty((0,3));rows=np.empty(0,dtype=np.int64);times=np.empty(0);rings=None
        span=tuple(request.get('scan_span_s',(stamp,stamp)));diag={'reason':'duplicate_scan' if duplicate else control.reason}
        accepted=False;warm_mapper=None
        active=control.state in ('awaiting_stability','collecting')
        if not duplicate and active and not capacity and budget.check(staging):
            xyz=_array(request['xyz'],'<f8',(-1,3));all_times=_array(request['point_times'],'<f8',(-1,))
            all_rings=None if request.get('rings') is None else _array(request['rings'],'<i4',(-1,))
            if len(all_times)!=len(xyz) or all_rings is not None and len(all_rings)!=len(xyz):
                raise ValueError('aligned real scan buffers required')
            norm=np.einsum('ij,ij->i',xyz,xyz)
            valid=np.isfinite(xyz).all(axis=1)&np.isfinite(all_times)&(norm>.04)&(norm<400.)
            rows=np.flatnonzero(valid);points=xyz[rows];times=all_times[rows]
            rings=None if all_rings is None else all_rings[rows]
            before_scan_control=control.fork()
            try:
                record=ScanRecord(identity,seq,stamp,span,points,times,rows,rings,points,np.eye(4))
                past_map=self.mapper
                if (control.state=='awaiting_stability' and past_map.last_good_time is not None
                    and stamp-past_map.last_good_time>.6+1e-9):
                    # A run of weak scans can expire the warm reference even
                    # while the input timeline itself remains continuous.
                    # Reanchor only a staged map; its unknown motion evidence
                    # clears prior stability and cannot count as zero speed.
                    past_map=LocalMap()
                aligned=align_parking_scan(record,past_map,self.imu,budget)
                diag=dict(aligned.diagnostics)
                if past_map is not self.mapper:diag['warm_reference_reanchored']=True
                decision=control.observe(aligned.evidence)
                if decision['reset_capture_window']:
                    self.records=();self.checks={};self.mapper=LocalMap()
                elif aligned.baseline is not None and not decision['accept_capture_scan']:
                    if control.state=='awaiting_stability' or self.capture.state=='awaiting_stability':
                        # Warm map retains bounded training representatives,
                        # never full original pre-stability scans.
                        warm_mapper=aligned.baseline_map
                elif aligned.baseline is not None and decision['accept_capture_scan']:
                    baseline=aligned.baseline;candidate=aligned.candidate
                    if not self.records:
                        # First post-stability real scan anchors the new map.
                        # Warm history was used for evidence, not retained.
                        shift=np.linalg.inv(baseline.pose)
                        baseline=replace(baseline,pose=np.eye(4),model=rebase_model(baseline.model,np.eye(4)))
                        if candidate is not None:
                            pose=shift@candidate.pose
                            candidate=replace(candidate,pose=pose,model=rebase_model(candidate.model,pose))
                    wrapped=CapturedScan(baseline,token,control.capture_generation,
                        dict(observable=aligned.evidence.observable,usable=True,
                            correspondence_count=aligned.evidence.correspondence_count,coverage=aligned.evidence.coverage))
                    records=self.records[-19:]+(wrapped,)
                    checks=check_parking_window(records,budget)
                    context=build_parking_context(records,seq,budget)
                    if candidate is not None and context is not None and checks[seq].status=='passed':
                        report=check_micro_candidate(baseline,candidate,context)
                        diag['micro_validation']=wire_diagnostics({'report':report})['report']
                        metric,patches,outside=_evaluate(candidate,context)
                        if report.accepted and metric.independent_support and not outside:
                            wrapped=replace(wrapped,record=candidate);records=records[:-1]+(wrapped,)
                            checks=check_parking_window(records,budget)
                            # Preserve this scan's candidate-before noise and
                            # references even while rechecking other scans.
                            checks[seq]=ParkingScanCheck('passed','independent_micro_improvement',context.reference_ids,
                                dict(p90_m=metric.p90_m,rms_m=metric.rms_m,coverage=metric.coverage,
                                    checked_rows=len(context.check_rows),ambiguous_rows=context.ambiguous_rows),patches)
                    trusted=select_parking_contributors(records,checks)
                    actual=tuple(s for s in records if checks[s.record.sequence].status!='rejected')
                    owned=retained_bytes((self.records,records,self.mapper.keys,self.mapper.geometry))+self._pair_bytes()
                    if owned>budget.window_limit_bytes:raise ValueError('image_capacity_reached')
                    budget.ensure(staging)
                    # Only trusted geometry feeds the next predictor. During
                    # bootstrap, an explicitly unknown real preview supplies
                    # training geometry without being counted as trusted.
                    map_records=tuple(s.record for s in (trusted or actual))
                    # An old held image is allowed, but rejected geometry
                    # cannot remain in the next frame's map or predictor.
                    # Allocate the empty replacement before committing any
                    # checks so failure still rolls the transaction back.
                    mapper=self.mapper.rebuilt(map_records,budget,training_only=True) if map_records else LocalMap()
                    if checks[seq].status=='rejected':
                        pair=self.last_pair
                    else:
                        ref=wrapped.record
                        fused=fused_preview(tuple(s.record for s in actual),ref.pose,engine.point_limit,budget)
                        budget.ensure(staging)
                        pair=dict(engine.paired_views(fused,ref.raw_xyz),sequence=seq,time=stamp,
                            source_frames=[s.record.sequence for s in actual],trusted_source_frames=[s.record.sequence for s in trusted],
                            generation=control.capture_generation,request_id=token,
                            raw_points=sum(len(s.record.raw_xyz) for s in records),bytes=retained_bytes(records))
                    control.update_counts(len(actual),len(trusted))
                    budget.ensure()
                    if self.detail_enabled:
                        # The complete ordinary map/pair is staged BEFORE the
                        # optional solve. Deadline/capacity/packing failure in
                        # detail must retain this already validated baseline,
                        # without new geometry or packing after expiry.
                        diag.update(detail_state='baseline_retained',detail_reason='refinement_budget')
                        extra=16000*12*3*8*4
                        pair_bytes=sum(len(pair[k]['data']) for k in ('fused','single','clean_fused','clean_single') if pair is not None and k in pair)
                        # retained_bytes walks tuple/list, not deque. Count
                        # both old and staged keys explicitly, and reserve a
                        # bounded extra map BEFORE its allocation, even when
                        # the user selects a very small display-point limit.
                        optional_owned=retained_bytes((self.records,records,tuple(self.mapper.keys),self.mapper.geometry,
                            tuple(mapper.keys),mapper.geometry))+self._pair_bytes()+pair_bytes+4*engine.point_limit*12+4*1024**2
                        if optional_owned>budget.window_limit_bytes:diag['detail_reason']='detail_capacity_reached'
                        if optional_owned<=budget.window_limit_bytes and budget.check(staging+extra):
                            detail_records,detail_checks,detail_diag=_detail_pass(records,checks,self.records,self.checks,budget)
                            diag.update(detail_diag)
                            if detail_records is not records:
                                try:
                                    owned=retained_bytes((self.records,records,detail_records,tuple(self.mapper.keys),self.mapper.geometry,
                                        tuple(mapper.keys),mapper.geometry))+self._pair_bytes()+pair_bytes+4*engine.point_limit*12+4*1024**2
                                    if owned>budget.window_limit_bytes:raise ValueError('detail_capacity_reached')
                                    budget.ensure(staging+extra)
                                    detail_trusted=select_parking_contributors(detail_records,detail_checks)
                                    detail_actual=tuple(s for s in detail_records if detail_checks[s.record.sequence].status!='rejected')
                                    detail_map=mapper.rebuilt(tuple(s.record for s in (detail_trusted or detail_actual)),budget,training_only=True)
                                    owned=retained_bytes((self.records,records,detail_records,tuple(self.mapper.keys),self.mapper.geometry,
                                        tuple(mapper.keys),mapper.geometry,tuple(detail_map.keys),detail_map.geometry))
                                    owned+=self._pair_bytes()+pair_bytes+4*engine.point_limit*12+1024**2
                                    if owned>budget.window_limit_bytes:raise ValueError('detail_capacity_reached')
                                    ref=detail_records[-1].record
                                    fused=fused_preview(tuple(s.record for s in detail_actual),ref.pose,engine.point_limit,budget)
                                    budget.ensure(staging+extra)
                                    detail_pair=dict(engine.paired_views(fused,ref.raw_xyz),sequence=seq,time=stamp,
                                        source_frames=[s.record.sequence for s in detail_actual],trusted_source_frames=[s.record.sequence for s in detail_trusted],
                                        generation=control.capture_generation,request_id=token,
                                        raw_points=sum(len(s.record.raw_xyz) for s in detail_records),bytes=retained_bytes(detail_records))
                                    budget.ensure(staging+extra)
                                    mapper=detail_map;records=detail_records;checks=detail_checks;pair=detail_pair
                                    control.update_counts(len(detail_actual),len(detail_trusted))
                                except (ValueError,MemoryError,np.linalg.LinAlgError) as error:
                                    diag.update(detail_state='baseline_retained',detail_reason=str(error))
                        if not budget.check():control.finish('deadline_or_cancelled')
                    # Commit records, predictor, pair and capture only after
                    # all allocation, model, validation and packing succeeded.
                    self.mapper=mapper;self.records=records;self.checks=checks;self.last_pair=pair;accepted=True
            except (ValueError,MemoryError,np.linalg.LinAlgError) as error:
                control=before_scan_control
                diag.update(reason=str(error),usable=False)
                control.reason=str(error)
                if not budget.check():control.finish('deadline_or_cancelled')
        elif active and capacity:
            control.finish('image_capacity_reached');diag['reason']='image_capacity_reached'
        elif active and not budget.check():control.finish('deadline_or_cancelled')
        # Input and deadline control are causal even if a scan fails. Pose,
        # full records and frozen pair were not partially staged on failure.
        pair=self.last_pair
        if pair is None:
            # Raw fallback never uses a fresh post-deadline refinement budget.
            views=dict(fused=engine.packed(np.empty((0,3))),single=engine.packed(np.empty((0,3))))
            if budget.check(staging):
                try:
                    views=engine.paired_views(points,points);budget.ensure(staging)
                    if warm_mapper is not None:self.mapper=warm_mapper
                except (ValueError,MemoryError,np.linalg.LinAlgError) as error:
                    control=before_scan_control if 'before_scan_control' in locals() else control
                    control.reason=str(error);diag['reason']=str(error)
                    if not budget.check():control.finish('deadline_or_cancelled')
            pair=dict(views,sequence=seq,time=stamp,source_frames=[],trusted_source_frames=[],
                generation=None,request_id=token,raw_points=0,bytes=0)
        elif warm_mapper is not None:
            # A held previous-generation pair already exists; no new packing
            # is needed to retain that exact preview while warming.
            if budget.check(staging):self.mapper=warm_mapper
        self.capture=control
        if not duplicate:self.last_input=key
        snap=control.snapshot()
        held=pair['sequence']!=seq
        actual_ids=[s.record.sequence for s in self.records if self.checks.get(s.record.sequence) is not None
            and self.checks[s.record.sequence].status!='rejected']
        trusted_ids=[s.record.sequence for s in select_parking_contributors(self.records,self.checks)] if self.records else []
        parking=dict(snap,pair_generation=pair['generation'],pair_request_id=pair['request_id'],
            retained_count=len(self.records),unknown_count=sum(c.status=='unknown' for c in self.checks.values()),
            rejected_count=sum(c.status=='rejected' for c in self.checks.values()),source_frames=actual_ids,
            trusted_source_frames=trusted_ids,checks={str(i):dict(status=c.status,reason=c.reason,
                reference_ids=list(c.reference_ids),metrics=c.metrics,patch_metrics=c.patch_metrics) for i,c in self.checks.items()})
        if self.detail_enabled:parking['detail_enabled']=True
        packet=dict(format='rsview-clearance-playback-v1',sequence=seq,device_time_s=stamp,
            session_id=identity[0],clock_id=identity[1],epoch=identity[2],status='completed',source_mode='recorded_pcap',
            config_id='rsview-parking-image-v1',mode='image_only',calculation='image_fusion_only',measurement_basis='image_only',
            current_scan_measurement=False,measurements=[],secondary_measurements=[],centerline=[],candidate_count=0,
            annotation_region_count=0,measurement_region_count=0,scene_diagnostics={},layer_counts={},
            relative_pose_diagnostics=wire_diagnostics(diag),pose_scope='parking_image_local_map_experimental',
            motion_status='image_compensated' if pair['source_frames'] else 'raw',retained_points=len(rows),display_limit=0,
            parking=wire_diagnostics(parking),fusion=dict(state=snap['state'],scan_count=len(pair['source_frames']),
                source_frames=pair['source_frames'],window_scan_count=len(self.records),effective_scan_count=len(pair['source_frames']),
                effective_source_frames=pair['source_frames'],refinement_state='parking',reference_sequence=pair['sequence'],
                reference_time_s=pair['time'],held=held,age_s=max(0.,stamp-pair['time']),registration_radius_m=20.,
                display_radius_m=10.,display_voxel_m=.008,display_limit=engine.point_limit,raw_window_points=pair['raw_points'],
                window_bytes=pair['bytes'],byte_budget=budget.window_limit_bytes,temporary_budget_bytes=budget.temporary_limit_bytes,
                clean_preview_available='clean_fused' in pair,clean_preview_counts=pair.get('clean_counts',{}),
                imu_available=self.imu is not None,imu_status=engine.imu_reason,
                representatives='real returns; unknown preview is not trusted geometry'),
            absolute_accuracy_verified=False,semantic_one_object_one_label_verified=False,
            timing_ms=dict(packet_total=(self.clock()-started)*1000.),
            _display={'object':pair['fused']},_single_display={'object':pair['single']})
        if 'clean_fused' in pair:packet.update(_clean_display={'object':pair['clean_fused']},_clean_single_display={'object':pair['clean_single']})
        return packet


def process_parking(engine,request,epoch=0):
    if not hasattr(engine,'parking_runtime'):
        engine.parking_runtime=ParkingRuntime(engine.config,engine.imu)
    return engine.parking_runtime.process(engine,request,epoch)
