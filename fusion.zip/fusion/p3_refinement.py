"""Anchored shadow-only window poses. No mapper feedback or point projection."""
from dataclasses import dataclass
import numpy as np
from scipy.spatial.transform import Rotation
from .registration import transform
from .p3_snapshot import readonly


@dataclass(frozen=True)
class ShadowProposal:
    key:object
    poses:tuple
    solved:bool
    reason:str
    diagnostics:dict


def displacement_guard(snapshot,poses,budget,policy):
    """Inspect every real point in bounded chunks, not just fitted representatives."""
    visible=context=0.;inverse=np.linalg.inv(snapshot.scans[-1].pose)
    for scan,pose in zip(snapshot.scans,poses):
        delta_rotation=pose[:3,:3]@scan.pose[:3,:3].T
        if (not np.isfinite(pose).all() or np.linalg.norm(pose[:3,3]-scan.pose[:3,3])>policy.translation_m+1e-12
            or Rotation.from_matrix(delta_rotation).magnitude()>np.deg2rad(policy.rotation_degrees)+1e-12):
            return False,dict(reason='pose_cap',max_visible_displacement_m=visible,max_context_displacement_m=context)
        for start in range(0,len(scan.corrected_xyz),8192):
            budget.ensure(8192*144)
            points=scan.corrected_xyz[start:start+8192]
            before=transform(points,inverse@scan.pose);after=transform(points,inverse@pose)
            distance=np.linalg.norm(after-before,axis=1);near=np.einsum('ij,ij->i',before,before)<=100.+1e-12
            visible=max(visible,float(np.max(distance[near],initial=0.)))
            context=max(context,float(np.max(distance[~near],initial=0.)))
    return (visible<=policy.visible_displacement_m+1e-12 and context<=policy.context_displacement_m+1e-12,
        dict(max_visible_displacement_m=visible,max_context_displacement_m=context))


def _world(patch,poses):
    world=np.empty_like(patch.local_points)
    for owner in np.unique(patch.owners):
        keep=patch.owners==owner;world[keep]=transform(patch.local_points[keep],poses[owner])
    return world


def _cost(patches,poses):
    cost=0.
    for patch in patches:
        points=_world(patch,poses);residual=(points-points.mean(axis=0))@patch.directions
        residual=np.abs(residual)
        cost+=float(np.sum(np.where(residual<=.02,residual**2,.04*residual-.0004))/len(points))
    return cost


def refine_shadow(snapshot,context,budget,policy):
    original=tuple(readonly(r.pose,copy=True) for r in snapshot.scans)
    def reject(reason,diagnostics=None):return ShadowProposal(snapshot.key,original,False,reason,diagnostics or {})
    if not 3<=len(original)<=20:return reject('invalid_window')
    dimension=(len(original)-1)*6
    estimate=context.estimated_temporary_bytes+dimension**2*24
    if not budget.check(estimate):return reject('budget')
    if not context.patches:return reject('insufficient_shared_features')
    current=original;cost=_cost(context.patches,current);costs=[cost];diagnostics={}
    try:
        for iteration in range(3):
            budget.ensure(estimate);h=np.zeros((dimension,dimension));g=np.zeros(dimension)
            for patch in context.patches:
                count=len(patch.owners);budget.ensure(estimate+count*dimension*24)
                points=_world(patch,current);centered=points-points.mean(axis=0)
                for direction in patch.directions.T:
                    residual=centered@direction;jacobian=np.zeros((count,dimension))
                    for owner in np.unique(patch.owners):
                        if owner==len(current)-1:continue
                        member=np.flatnonzero(patch.owners==owner);rotated=points[member]-current[owner][:3,3]
                        jacobian[member,owner*6:owner*6+3]=np.cross(rotated,direction)
                        jacobian[member,owner*6+3:owner*6+6]=direction
                    jacobian-=jacobian.mean(axis=0)
                    weights=np.sqrt(np.minimum(1.,.02/(np.abs(residual)+1e-9))/count)
                    j=jacobian*weights[:,None];r=residual*weights
                    h+=j.T@j;g+=j.T@r
            eigen=np.linalg.eigvalsh(h)
            if eigen[-1]<=0 or np.sum(eigen>eigen[-1]*1e-7)<dimension:return reject('unobservable_window')
            budget.ensure(estimate)
            step=np.linalg.solve(h+np.diag(np.maximum(np.diag(h),1e-8)*.01),-g)
            if not np.isfinite(step).all():return reject('nonfinite_window')
            improved=False
            for scale in (1.,.5,.25,.125,.0625,.03125):
                budget.ensure(estimate);poses=[]
                for owner,pose in enumerate(current):
                    if owner==len(current)-1:poses.append(pose);continue
                    delta=step[owner*6:owner*6+6]*scale;candidate=pose.copy()
                    candidate[:3,:3]=Rotation.from_rotvec(delta[:3]).as_matrix()@candidate[:3,:3]
                    candidate[:3,3]+=delta[3:];poses.append(candidate)
                bounded,diagnostics=displacement_guard(snapshot,poses,budget,policy)
                if not bounded:continue
                candidate_cost=_cost(context.patches,poses)
                if candidate_cost<cost-1e-15:
                    current=tuple(poses);cost=candidate_cost;costs.append(cost);improved=True;break
            if not improved:break
        if len(costs)<2:return reject('no_training_improvement',diagnostics)
        diagnostics.update(training_costs=tuple(costs),iterations=len(costs)-1,anchor_sequence=snapshot.key.reference_sequence)
        return ShadowProposal(snapshot.key,tuple(readonly(p,copy=True) for p in current),True,'shadow_proposal',diagnostics)
    except (ValueError,MemoryError,np.linalg.LinAlgError):return reject('budget')
