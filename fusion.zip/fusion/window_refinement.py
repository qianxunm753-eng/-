"""Anchored multi-scan surface/edge refinement, with independent real checks."""
from dataclasses import dataclass,replace
import numpy as np
from scipy.spatial.transform import Rotation
from .registration import LocalMap,transform,representatives
from .state import retained_bytes,freeze
from .validation import split_original_indices,ValidationMetrics,ValidationReport,compare_geometry,accept_refinement


@dataclass(frozen=True)
class FeaturePatch:
    kind:str
    scan_ids:tuple
    original_indices:np.ndarray
    local_points:np.ndarray
    world_points:np.ndarray
    owners:np.ndarray


@dataclass(frozen=True)
class WindowResult:
    records:tuple
    accepted:bool
    reason:str
    validation:object=None
    per_scan_validation:object=None
    training_costs:tuple=()


def build_patches(records,exclude_sequence=None):
    local=[];world=[];owners=[];indices=[]
    for owner,r in enumerate(records):
        if r.sequence==exclude_sequence:continue
        fit,unused=split_original_indices(r.original_indices)
        if r.rings is not None:fit=fit[r.rings[fit]%2==0]
        fit=fit[representatives(r.corrected_xyz[fit],.04,3500)]
        local.append(r.corrected_xyz[fit]);world.append(transform(r.corrected_xyz[fit],r.pose))
        owners.append(np.full(len(fit),owner));indices.append(r.original_indices[fit])
    if len(local)<2:return ()
    local=np.concatenate(local);world=np.concatenate(world);owners=np.concatenate(owners);indices=np.concatenate(indices)
    keys=np.floor(world/.32).astype(np.int64);unused,inverse=np.unique(keys,axis=0,return_inverse=True)
    order=np.argsort(inverse);groups=np.split(order,np.flatnonzero(np.diff(inverse[order]))+1)
    stack=[(g,.32) for g in groups];patches=[]
    while stack:
        rows,size=stack.pop();who=np.unique(owners[rows])
        if len(rows)<12 or len(who)<2:continue
        p=world[rows];centered=p-p.mean(axis=0);e,v=np.linalg.eigh(centered.T@centered/len(p))
        kind='edge' if e[1]<.1*max(e[2],1e-12) else 'plane' if e[0]<.2*max(e[1],1e-12) else None
        good=kind is not None
        # Cross-frame thickness may be pose error. Within ONE real scan,
        # parallel surfaces or curvature are not one surface to flatten.
        supported=0
        if good:
            for owner in who:
                cloud=p[owners[rows]==owner]
                if len(cloud)<6:continue
                c=cloud-cloud.mean(axis=0);ev,vv=np.linalg.eigh(c.T@c/len(c))
                global_direction=v[:,2] if kind=='edge' else v[:,0]
                local_direction=vv[:,2] if kind=='edge' else vv[:,0]
                if abs(global_direction@local_direction)<np.cos(np.deg2rad(20)):
                    good=False;break
                directions=vv[:,:2] if kind=='edge' else vv[:,:1]
                scatter=np.linalg.norm(c@directions,axis=1)
                if np.percentile(scatter,90)>.006:good=False;break
                supported+=1
            good=good and supported>=2
        if good:
            patches.append(FeaturePatch(kind,tuple(records[i].sequence for i in owners[rows]),
                freeze(indices[rows]),freeze(local[rows]),freeze(p),freeze(owners[rows])))
        elif size>.020001:
            smaller=size/2.;child=np.floor(p/smaller).astype(np.int64)
            unused,inv=np.unique(child,axis=0,return_inverse=True);ordered=np.argsort(inv)
            for g in np.split(ordered,np.flatnonzero(np.diff(inv[ordered]))+1):stack.append((rows[g],smaller))
    if len(patches)>512:patches=[patches[i] for i in np.linspace(0,len(patches)-1,512,dtype=int)]
    return tuple(patches)


def _world(patch,records):
    points=np.empty_like(patch.local_points)
    for owner in np.unique(patch.owners):
        rows=np.flatnonzero(patch.owners==owner)
        points[rows]=transform(patch.local_points[rows],records[owner].pose)
    return points


def _feature_cost(patches,records):
    cost=0.
    for patch in patches:
        p=_world(patch,records);c=p-p.mean(axis=0);unused,v=np.linalg.eigh(c.T@c/len(p))
        normals=v[:,:2] if patch.kind=='edge' else v[:,:1]
        residual=np.abs(c@normals)
        cost+=float(np.sum(np.where(residual<=.02,residual**2,.04*residual-.0004))/len(p))
    return cost


def _target(record):
    mapper=LocalMap();fit,unused=split_original_indices(record.original_indices)
    mask=np.zeros(len(record.raw_xyz),bool);mask[fit]=True
    if record.rings is not None:mask&=record.rings%2==0
    mapper.scan_key=(record.source_key,record.sequence)
    mapper._refresh(record.corrected_xyz,mask,record.pose,record.reference_s)
    return mapper.geometry


def _validate(before,after,budget):
    anchor=before[-1];geometry=_target(anchor);reports={};old=[];new=[]
    for a,b in zip(before[:-1],after[:-1]):
        budget.ensure();unused,check=split_original_indices(a.original_indices)
        if a.rings is not None:check=check[a.rings[check]%2==0]
        if len(check)>3500:check=check[np.linspace(0,len(check)-1,3500,dtype=int)]
        report=compare_geometry(transform(a.corrected_xyz[check],a.pose),
            transform(b.corrected_xyz[check],b.pose),geometry)
        reports[a.sequence]=report;old.append(report.before);new.append(report.after)
        # Per-scan safety, not per-scan strict improvement: the unchanged
        # anchor and already-aligned scans need not become "even better".
        if report.reason not in ('independent_improvement','no_independent_improvement'):
            return False,report,reports
    reports[anchor.sequence]=None  # fixed, no self-validation claim
    def combine(metrics):
        return ValidationMetrics(max(m.p90_m for m in metrics),
            float(np.sqrt(np.mean([m.rms_m**2 for m in metrics]))),
            min(m.coverage for m in metrics),{},all(m.independent_support for m in metrics))
    report=accept_refinement(combine(old),combine(new))
    return report.accepted,report,reports


class WindowRefiner:
    def refine(self,records,budget):
        records=tuple(records)
        def reject(reason,report=None,per_scan=None):return WindowResult(records,False,reason,report,per_scan or {})
        if (not 2<=len(records)<=20 or len({r.source_key for r in records})!=1
            or len({r.sequence for r in records})!=len(records)
            or any(b.reference_s<=a.reference_s for a,b in zip(records,records[1:]))):return reject('invalid_window_timeline')
        if retained_bytes(records)>budget.window_limit_bytes:return reject('window_capacity')
        pool=min(sum(len(r.raw_xyz) for r in records),3500*len(records))
        base_temporary=pool*256+((len(records)-1)*6)**2*24
        if not budget.check(base_temporary):return reject('refinement_budget')
        current=records;dimension=(len(records)-1)*6
        try:
            patches=build_patches(current)
            if not patches:return reject('insufficient_shared_features')
            cost=_feature_cost(patches,current);costs=[cost]
            for iteration in range(3):
                budget.ensure(base_temporary)
                h=np.zeros((dimension,dimension));g=np.zeros(dimension)
                for patch in patches:
                    rows=len(patch.owners);budget.ensure(base_temporary+rows*dimension*24)
                    p=_world(patch,current);c=p-p.mean(axis=0);e,v=np.linalg.eigh(c.T@c/rows)
                    directions=v[:,:2] if patch.kind=='edge' else v[:,:1]
                    for n in directions.T:
                        residual=c@n;jac=np.zeros((rows,dimension))
                        for owner in np.unique(patch.owners):
                            if owner==len(current)-1:continue
                            member=np.flatnonzero(patch.owners==owner)
                            rotated=p[member]-current[owner].pose[:3,3]
                            jac[member,owner*6:owner*6+3]=np.cross(rotated,n)
                            jac[member,owner*6+3:owner*6+6]=n
                        # Eliminating the shared centroid creates the actual
                        # cross-scan blocks, not independent per-frame ICP.
                        jac-=jac.mean(axis=0)
                        weight=np.sqrt(np.minimum(1.,.02/(np.abs(residual)+1e-9))/rows)
                        j=jac*weight[:,None];r=residual*weight
                        h+=j.T@j;g+=j.T@r
                eigen=np.linalg.eigvalsh(h)
                if eigen[-1]<=0 or np.count_nonzero(eigen>eigen[-1]*1e-7)<dimension:return reject('unobservable_window')
                step=np.linalg.solve(h+np.diag(np.maximum(np.diag(h),1e-8)*.01),-g)
                if not np.isfinite(step).all():return reject('nonfinite_window')
                accepted_step=False
                for scale in (1.,.5,.25,.125,.0625,.03125):
                    budget.ensure(base_temporary);updated=[];outside=False
                    for owner,r in enumerate(current):
                        if owner==len(current)-1:updated.append(r);continue
                        delta=step[owner*6:owner*6+6]*scale;pose=r.pose.copy()
                        if np.linalg.norm(delta[:3])>.1 or np.linalg.norm(delta[3:])>.12:outside=True;break
                        pose[:3,:3]=Rotation.from_rotvec(delta[:3]).as_matrix()@pose[:3,:3];pose[:3,3]+=delta[3:]
                        model=r.model
                        if model is not None:
                            from .trajectory import TrajectoryModel
                            rebase=pose@np.linalg.inv(model.reference_pose)
                            model=TrajectoryModel(model.mode,model.span_s,model.reference_s,
                                rebase@model.begin_pose,rebase@model.end_pose)
                        updated.append(replace(r,pose=pose,model=model))
                    if outside:continue
                    proposed=tuple(updated);proposed_cost=_feature_cost(patches,proposed)
                    if proposed_cost<=cost+1e-12:
                        current=proposed;cost=proposed_cost;costs.append(cost);accepted_step=True;break
                if not accepted_step:return reject('window_no_descent')
                if np.linalg.norm(step)<1e-5:break
            accepted,report,per_scan=_validate(records,current,budget)
            if not accepted:return reject(report.reason,report,per_scan)
            return WindowResult(current,True,'joint_window_validated',report,per_scan,tuple(costs))
        except ValueError as error:return reject('refinement_refused: '+str(error))
