"""Bounded replay capture control; geometric stability is not parking truth."""
from collections import deque
from dataclasses import dataclass
from numbers import Integral
import copy
import math
import time
from .state import ScanRecord,RefinementBudget,freeze


def _count(value):
    return isinstance(value,Integral) and not isinstance(value,bool) and value>=0


def _token(value):
    if not isinstance(value,str) or not 1<=len(value)<=128 or not value.isascii():
        raise ValueError('bounded nonempty ASCII capture request required')
    return value


@dataclass(frozen=True)
class StabilityEvidence:
    sequence:int
    reference_s:float
    source_key:tuple
    reference_dt_s:object
    translation_rate_m_s:object
    rotation_rate_rad_s:object
    observable:bool
    correspondence_count:int
    coverage:float


@dataclass(frozen=True)
class CapturedScan:
    record:ScanRecord
    capture_request_id:str
    capture_generation:int
    geometry_diag:dict

    def __post_init__(self):
        _token(self.capture_request_id)
        if not isinstance(self.record,ScanRecord) or not _count(self.capture_generation):
            raise ValueError('owned real record and nonnegative capture generation required')
        object.__setattr__(self,'geometry_diag',freeze(self.geometry_diag))

    @property
    def capture_key(self):
        return (self.record.source_key,self.capture_request_id,self.capture_generation)


class ParkingBudget(RefinementBudget):
    def __init__(self,deadline_s,clock,cancelled,window_limit_bytes=96*1024**2,
                 temporary_limit_bytes=64*1024**2):
        if not math.isfinite(deadline_s) or window_limit_bytes<=0 or temporary_limit_bytes<0:
            raise ValueError('finite local deadline and bounded memory required')
        super().__init__(window_limit_bytes,temporary_limit_bytes,deadline_s,cancelled)
        self.clock=clock

    def check(self,estimated_temporary_bytes=0):
        try:
            now=float(self.clock())
            return (math.isfinite(now) and 0<=estimated_temporary_bytes<=self.temporary_limit_bytes
                and now<self.deadline_s and not self.cancelled())
        except (ValueError,TypeError):return False


class ParkingCapture:
    def __init__(self,clock=time.monotonic,timeout_s=60.):
        if not math.isfinite(timeout_s) or not 0.<timeout_s<=60.:
            raise ValueError('capture timeout must be within 60 seconds')
        self.clock=clock;self.timeout_s=float(timeout_s);self.state='idle'
        self.request_id=None;self.source_key=None;self.capture_generation=0;self.deadline_s=0.
        self.actual_count=self.trusted_count=0;self.stable_times=deque(maxlen=5)
        self.last_input=None;self.motion_steps=self.failed_steps=0;self.reason='not_started'

    def _now(self,now_s):
        now=float(self.clock() if now_s is None else now_s)
        if not math.isfinite(now):raise ValueError('finite local clock required')
        return now

    def start(self,request_id,source_key,now_s=None):
        request_id=_token(request_id);source_key=tuple(source_key);now=self._now(now_s)
        if (len(source_key)!=3 or not all(isinstance(s,str) and s for s in source_key[:2])
            or not _count(source_key[2])):raise ValueError('real source identity required')
        self.request_id=request_id;self.source_key=source_key;self.capture_generation=0
        self.deadline_s=now+self.timeout_s;self.state='awaiting_stability';self.reason='manual_start'
        self.actual_count=self.trusted_count=0;self.last_input=None;self.stable_times.clear()
        self.motion_steps=self.failed_steps=0
        return self.snapshot(now)

    def fork(self):
        result=copy.copy(self);result.stable_times=deque(self.stable_times,maxlen=5)
        return result

    def _expire(self,now):
        if self.state in ('awaiting_stability','collecting') and now>=self.deadline_s:
            self.state='incomplete';self.reason='deadline'

    def limit_remaining(self,seconds,now_s=None):
        now=self._now(now_s)
        if not math.isfinite(seconds) or not 0.<=seconds<=60.:
            raise ValueError('remaining capture duration must be within 0--60 seconds')
        if self.state in ('awaiting_stability','collecting'):
            self.deadline_s=min(self.deadline_s,now+seconds);self._expire(now)

    def snapshot(self,now_s=None):
        now=self._now(now_s);self._expire(now)
        return dict(state=self.state,request_id=self.request_id,source_key=self.source_key,
            capture_generation=self.capture_generation,actual_count=self.actual_count,
            trusted_count=self.trusted_count,stable_count=len(self.stable_times),reason=self.reason,
            remaining_s=max(0.,self.deadline_s-now) if self.request_id is not None else 0.)

    def _decision(self,now,accept=False,reset=False,motion=False):
        return dict(self.snapshot(now),accept_capture_scan=accept,reset_capture_window=reset,
            generation=self.capture_generation,motion_detected=motion)

    def cancel(self,reason):
        self.state='idle';self.reason=str(reason);self.capture_generation+=1
        self.stable_times.clear();self.last_input=None;self.actual_count=self.trusted_count=0
        self.motion_steps=self.failed_steps=0

    def finish(self,reason,now_s=None):
        now=self._now(now_s)
        if self.state in ('awaiting_stability','collecting'):
            self.state='incomplete';self.reason=str(reason)
        return self.snapshot(now)

    def update_counts(self,actual,trusted,now_s=None):
        now=self._now(now_s)
        if not _count(actual) or not _count(trusted) or not trusted<=actual<=20:
            raise ValueError('bounded actual and trusted capture counts required')
        self._expire(now)
        if self.state=='collecting':
            self.actual_count=int(actual);self.trusted_count=int(trusted)
            if actual==trusted==20:self.state='capture_complete';self.reason='twenty_trusted_scans'
        return self.snapshot(now)

    def _new_generation(self,reason):
        self.capture_generation+=1;self.state='awaiting_stability';self.reason=reason
        self.actual_count=self.trusted_count=0;self.stable_times.clear()
        self.motion_steps=self.failed_steps=0

    def observe(self,evidence,now_s=None):
        now=self._now(now_s);self._expire(now)
        if self.state not in ('awaiting_stability','collecting'):return self._decision(now)
        if (not _count(evidence.sequence) or not math.isfinite(evidence.reference_s)
            or tuple(evidence.source_key)!=self.source_key):
            self.cancel('source_or_identity_changed');return self._decision(now,reset=True)
        key=(evidence.sequence,evidence.reference_s)
        if key==self.last_input:return self._decision(now)
        if self.last_input is not None:
            gap=key[1]-self.last_input[1]
            if key[0]<=self.last_input[0] or not 0.<gap<=.6+1e-9:
                self.cancel('input_discontinuity');return self._decision(now,reset=True)
        self.last_input=key
        values=(evidence.reference_dt_s,evidence.translation_rate_m_s,
            evidence.rotation_rate_rad_s,evidence.coverage)
        supported=(evidence.observable and all(v is not None and math.isfinite(v) for v in values)
            and 0.<evidence.reference_dt_s<=.6+1e-9 and evidence.translation_rate_m_s>=0.
            and evidence.rotation_rate_rad_s>=0. and evidence.correspondence_count>=150
            and .5<=evidence.coverage<=1.)
        if not supported:
            self.stable_times.clear();self.motion_steps=0;self.failed_steps+=1
            self.reason='stability_support_unavailable'
            if self.state=='collecting' and self.failed_steps>=3:
                self._new_generation('evidence_lost');return self._decision(now,reset=True)
            return self._decision(now)
        self.failed_steps=0
        if self.state=='awaiting_stability':
            self.reason='awaiting_stability'
            if (evidence.translation_rate_m_s<=.03+1e-12 and
                evidence.rotation_rate_rad_s<=math.radians(1.)+1e-12):
                self.stable_times.append(evidence.reference_s)
                if len(self.stable_times)==5 and self.stable_times[-1]-self.stable_times[0]>=.4-1e-9:
                    self.state='collecting';self.reason='geometric_stability_confirmed'
            else:self.stable_times.clear()
            return self._decision(now)
        if (evidence.translation_rate_m_s>.06+1e-12 or
            evidence.rotation_rate_rad_s>math.radians(2.)+1e-12):
            self.motion_steps+=1;self.reason='motion_outlier'
            if self.motion_steps>=3:
                self._new_generation('motion_evidence');return self._decision(now,reset=True,motion=True)
            return self._decision(now)
        self.motion_steps=0;self.reason='new_geometrically_stable_scan'
        return self._decision(now,accept=True)
