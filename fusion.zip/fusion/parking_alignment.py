"""Training-only past-map registration and bounded parking micro corrections."""
from dataclasses import dataclass,replace
import numpy as np
from scipy.spatial.transform import Rotation
from .registration import LocalMap,representatives,detail_representatives,transform
from .trajectory import TrajectoryModel
from .state import freeze
from .parking_state import StabilityEvidence


@dataclass(frozen=True)
class RigidScanModel:
    reference_pose:np.ndarray

    def __post_init__(self):
        pose=np.asarray(self.reference_pose,dtype=float)
        if (pose.shape!=(4,4) or not np.isfinite(pose).all()
            or not np.allclose(pose[3],[0.,0.,0.,1.])
            or not np.allclose(pose[:3,:3].T@pose[:3,:3],np.eye(3),atol=1e-7)
            or np.linalg.det(pose[:3,:3])<.999999):
            raise ValueError('finite rigid reference pose required')
        object.__setattr__(self,'reference_pose',freeze(pose))

    def corrected_points(self,raw_xyz,point_times,imu=None):
        return np.asarray(raw_xyz).copy()

    def world_points(self,raw_xyz,point_times,imu=None):
        return transform(self.corrected_points(raw_xyz,point_times,imu),self.reference_pose)


def saved_scan_model(pose,span,reference,velocity,gyro_active):
    duration=span[1]-span[0]
    if duration<=1e-12:return RigidScanModel(pose)
    alpha=(reference-span[0])/duration
    displacement=pose[:3,:3]@velocity*duration
    begin=pose.copy();end=pose.copy()
    begin[:3,3]-=alpha*displacement;end[:3,3]+=(1-alpha)*displacement
    return TrajectoryModel('gyro' if gyro_active else 'lidar',span,reference,begin,end)


def rebase_model(model,pose):
    if isinstance(model,RigidScanModel):return RigidScanModel(pose)
    if not isinstance(model,TrajectoryModel):raise ValueError('complete motion model required')
    delta=pose@np.linalg.inv(model.reference_pose)
    return TrajectoryModel(model.mode,model.span_s,model.reference_s,
        delta@model.begin_pose,delta@model.end_pose)


@dataclass
class ParkingAlignmentResult:
    baseline:object
    candidate:object
    evidence:StabilityEvidence
    baseline_map:LocalMap
    diagnostics:dict


def _micro(record,past_map,budget):
    if past_map.geometry is None:return None,'no_past_geometry'
    fit=record.original_indices%5!=0
    if record.rings is not None:fit &= record.rings%2==0
    points=record.corrected_xyz[fit]
    sampler=detail_representatives if past_map.detail_sampling else representatives
    points=points[sampler(points,.04,3500)]
    target,tree,normals,confidence=past_map.geometry
    pose=record.pose.copy();origin=pose.copy();improved=False
    # Freeze correspondences once; they cannot change to conceal a bad step.
    world=transform(points,pose)
    distance,ids=tree.query(world,distance_upper_bound=.08,workers=1)
    keep=np.isfinite(distance)
    if keep.sum()<50:return None,'insufficient_micro_support'
    points=points[keep];q=target[ids[keep]];n=normals[ids[keep]];conf=confidence[ids[keep]]
    for unused in range(3):
        if not budget.check(len(points)*256):return None,'refinement_budget'
        world=transform(points,pose);r=np.einsum('ij,ij->i',q-world,n)
        jac=np.column_stack((np.cross(world,n),n))
        weight=np.sqrt(np.minimum(1.,.002/(np.abs(r)+1e-9))*conf)
        step,unused,rank,singular=np.linalg.lstsq(jac*weight[:,None],r*weight,rcond=1e-5)
        if rank!=6 or not np.isfinite(step).all():return None,'unobservable_micro_step'
        delta=np.eye(4);delta[:3,:3]=Rotation.from_rotvec(step[:3]).as_matrix();delta[:3,3]=step[3:]
        candidate=delta@pose;relative=candidate@np.linalg.inv(origin)
        if (np.linalg.norm(relative[:3,3])>.005+1e-12
            or Rotation.from_matrix(relative[:3,:3]).magnitude()>np.deg2rad(.5)+1e-12):
            return None,'step_outside_parking_capture'
        new_r=np.einsum('ij,ij->i',q-transform(points,candidate),n)
        if float(new_r@new_r)>=float(r@r)-1e-16:break
        improved=True;pose=candidate
        if np.linalg.norm(step)<1e-6:break
    if not improved:return None,'already_aligned'
    return replace(record,pose=pose,model=rebase_model(record.model,pose)),'training_improved_pending_check'


def parking_detail_candidate(record,previous_records,budget):
    """Extra proposal only; the ordinary parking map/predictor stays intact."""
    if len(previous_records)<2:return None,'insufficient_trusted_past_scans'
    if not budget.check(16000*12*3*8*4):return None,'refinement_budget'
    if any(r.sequence==record.sequence for r in previous_records):raise ValueError('detail self support refused')
    mapper=LocalMap(detail_sampling=True).rebuilt(previous_records,budget,training_only=True)
    return _micro(record,mapper,budget)


def align_parking_scan(record,past_map,imu,budget):
    diag={};dt=None if past_map.last_good_time is None else record.reference_s-past_map.last_good_time
    unknown=StabilityEvidence(record.sequence,record.reference_s,record.source_key,dt,None,None,False,0,0.)
    def refused(reason):
        return ParkingAlignmentResult(None,None,unknown,past_map,dict(reason=reason))
    if not budget.check(len(record.raw_xyz)*256):return refused('refinement_budget')
    if (record.source_key,record.sequence) in past_map.key_sources:return refused('self_support_refused')
    mapper=past_map.fork()
    registration=mapper.update(record.raw_xyz,record.point_times,record.rings,record.reference_s,imu,
        scan_key=(record.source_key,record.sequence),fit_mask=record.original_indices%5!=0,
        save_model=True,scan_span_s=record.span_s)
    diag.update(registration.diagnostics)
    if not registration.usable:return refused(diag.get('reason','registration_rejected'))
    baseline=replace(record,corrected_xyz=registration.points,pose=registration.pose,model=registration.model)
    evidence=unknown
    if dt is not None and 0.<dt<=.6+1e-9:
        relative=np.linalg.inv(past_map.pose)@baseline.pose
        observable=(diag.get('rank')==6 or diag.get('rank')==3 and diag.get('rotation_constraint')=='same-recording IMU')
        evidence=StabilityEvidence(record.sequence,record.reference_s,record.source_key,dt,
            float(np.linalg.norm(relative[:3,3])/dt),float(Rotation.from_matrix(relative[:3,:3]).magnitude()/dt),
            observable,int(diag.get('correspondence_count',0)),float(diag.get('overlap_fraction',0.)))
    candidate,reason=_micro(baseline,past_map,budget)
    diag['micro_reason']=reason
    return ParkingAlignmentResult(baseline,candidate,evidence,mapper,diag)
