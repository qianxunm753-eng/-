"""Same-window real-return surface views; no fitting, smoothing or invented points.

The mature baseline and its poses remain authoritative. Local sampling is finer
only for reversible inspection; this is not a new metrology surface.
"""
import numpy as np
from scipy.spatial import cKDTree
from .registration import representatives, transform


def _roi(value):
    bounds=np.asarray(value,dtype=float)
    if (bounds.shape!=(6,) or not np.isfinite(bounds).all() or np.max(np.abs(bounds))>10.
        or np.any(bounds[::2]>=bounds[1::2])):
        raise ValueError('ordered finite surface ROI within -10..10m required')
    return bounds


def _inside(points,bounds,radius=10.):
    return (np.all((points>=bounds[::2])&(points<=bounds[1::2]),axis=1)
        & (np.einsum('ij,ij->i',points,points)<=radius*radius+1e-12))


def _pack(points,ordinals=None):
    result=dict(data=np.asarray(points,dtype='<f4').tobytes(),count=len(points),dtype='little-float32-xyz')
    if ordinals is not None:result['frame_data']=np.asarray(ordinals,dtype='<f4').tobytes()
    return result


def _bounded_rows(count,limit):
    return np.arange(count) if count<=limit else np.linspace(0,count-1,limit,dtype=int)


def _scan_support(queries,scans,inverse,bounds,budget,total):
    """Count distinct scans in a 20mm sphere, NOT correctness or noise labels.

    One nearest-neighbour test per scan prevents dense repeated returns from
    faking temporal evidence. Small query batches bound temporary storage and
    honour cancellation. No fitting or normal-directed coordinate edits.
    """
    counts=np.zeros(len(queries),dtype=np.uint8)
    tolerance=.020000000001
    halo=bounds+np.array([-tolerance,tolerance]*3)
    for scan in scans:
        estimate=total*160+len(queries)*32+len(scan.corrected_xyz)*80
        budget.ensure(estimate)
        # Evidence crosses manual ROI and 10m display boundaries; only the
        # pre-existing displayed query points receive a scalar or selection.
        aligned=transform(scan.corrected_xyz,inverse@scan.pose)
        points=aligned[_inside(aligned,halo,10.+tolerance)]
        if not len(points):
            del points,aligned
            continue
        tree=cKDTree(points)
        for start in range(0,len(queries),4096):
            budget.ensure(estimate)
            distance,unused=tree.query(queries[start:start+4096],k=1,
                distance_upper_bound=np.nextafter(tolerance,np.inf),workers=1)
            counts[start:start+4096]+=(distance<=tolerance)
        del tree,points,aligned
    return counts


def diagnose_window(snapshot,roi,budget,point_limit=150000):
    bounds=_roi(roi)
    if not 20<=point_limit<=150000:raise ValueError('surface display limit must be 20..150000')
    if len(snapshot.scans)!=20 or tuple(r.sequence for r in snapshot.scans)!=snapshot.key.source_frames:
        raise ValueError('surface diagnosis requires the same actual 20 scans')
    pair=snapshot.baseline_pair;raw=pair.get('_surface_raw_single')
    if raw is None:raise ValueError('actual raw single input unavailable; corrected scans are not raw single')
    budget.ensure()
    inverse=np.linalg.inv(snapshot.scans[-1].pose)
    pieces=[];owners=[];originals=[];total=0
    for ordinal,scan in enumerate(snapshot.scans):
        budget.ensure(total*80+len(scan.corrected_xyz)*80)
        if not np.isfinite(scan.corrected_xyz).all():raise ValueError('nonfinite real surface points')
        aligned=transform(scan.corrected_xyz,inverse@scan.pose)
        rows=np.flatnonzero(_inside(aligned,bounds));total+=len(rows)
        budget.ensure(total*128+len(scan.corrected_xyz)*80)
        pieces.append(aligned[rows]);owners.append(np.full(len(rows),ordinal,dtype=np.int32))
        originals.append(scan.original_indices[rows])
    if not total:raise ValueError('surface ROI has no compensated returns')
    budget.ensure(total*160)
    all_points=np.concatenate(pieces);all_owners=np.concatenate(owners);all_originals=np.concatenate(originals)
    # All outputs are selected existing rows; even the 2mm cells use real returns.
    fine_rows=representatives(all_points,.002,point_limit)
    frame_rows=_bounded_rows(total,point_limit)
    baseline=np.frombuffer(pair['fused']['data'],dtype='<f4').reshape(-1,3)
    base_rows=np.flatnonzero(_inside(baseline,bounds))
    base_rows=base_rows[_bounded_rows(len(base_rows),point_limit)]
    raw_points=np.asarray(raw['xyz']);raw_rows=np.flatnonzero(_inside(raw_points,bounds))
    raw_rows=raw_rows[_bounded_rows(len(raw_rows),point_limit)]
    views=dict(baseline=_pack(baseline[base_rows]),raw_single=_pack(raw_points[raw_rows]),
        frames=_pack(all_points[frame_rows],all_owners[frame_rows]),local=_pack(all_points[fine_rows]))
    support_report=dict(support_state='available',support_radius_m=.02,support_min_scans=3,support_scan_count=20,
        support_meaning='distinct scans nearby; NOT noise truth or accuracy')
    try:
        support=_scan_support(all_points[fine_rows],snapshot.scans,inverse,bounds,budget,total)
        stable=support>=3
        # Weak evidence can be a real sparse feature, occlusion or misalignment.
        views['support']=dict(views['local'],support_data=np.asarray(support,dtype='<f4').tobytes())
        views['stable']=_pack(all_points[fine_rows[stable]])
        support_report.update(support_histogram=np.bincount(support,minlength=21).tolist(),
            stable_point_count=int(stable.sum()),weak_support_count=int((~stable).sum()))
    except (ValueError,MemoryError) as error:
        # Optional evidence must not regress the existing local diagnostic.
        # Deadline/cancellation are still authoritative, never hidden here.
        budget.ensure()
        views.pop('support',None);views.pop('stable',None)
        support_report['support_state']='allocation_unavailable' if isinstance(error,MemoryError) else 'temporary_budget'
    local_origins=np.column_stack((np.asarray(snapshot.key.source_frames)[all_owners[fine_rows]],all_originals[fine_rows]))
    report=dict(scope='surface_diagnostic_only',coordinate_edits=0,measurement_allowed=False,
        source_frames=list(snapshot.key.source_frames),reference_sequence=snapshot.key.reference_sequence,
        roi=bounds.tolist(),local_real_point_count=total,baseline_roi_count=len(base_rows),
        local_unique_count=len(fine_rows),raw_single_count=len(raw_rows),local_voxel_m=.002,
        local_origin_frames=len(np.unique(local_origins[:,0])),
        frame_ordinal_labels=list(snapshot.key.source_frames),point_limit=point_limit)
    report.update(support_report)
    budget.ensure(total*160)
    return dict(pair=dict(pair,surface_views=views),report=report,
        local_origins=local_origins,frame_origins=np.column_stack((
            np.asarray(snapshot.key.source_frames)[all_owners[frame_rows]],all_originals[frame_rows])))


def attach_raw_single(engine,pair,points,indices):
    """Optional sidecar of the actual accepted input, after baseline completion.

    A capacity failure omits diagnostics; it must never reject a baseline scan.
    Only the newest accepted pair retains this extra input, not every old scan.
    """
    from .state import retained_bytes
    try:
        rows=np.flatnonzero(np.einsum('ij,ij->i',points,points)<=100.+1e-12)
        estimate=len(rows)*20
        metadata=retained_bytes(tuple(engine.window)+(pair.get('_p3_origins',{}),))
        display_bytes=sum(pair[name]['count']*12 for name in ('fused','single','clean_fused','clean_single') if name in pair)
        if estimate>4*1024**2 or metadata+display_bytes+estimate+len(engine.window)*128>engine.byte_budget:return
        xyz=points[rows].astype('<f4');origin=indices[rows].copy()
        xyz.flags.writeable=False;origin.flags.writeable=False
        pair['_surface_raw_single']=dict(xyz=xyz,indices=origin)
    except (ValueError,MemoryError):
        pair.pop('_surface_raw_single',None)
