"""Owned immutable real scans and allocation guards for replay refinements."""
from dataclasses import dataclass,field,fields,is_dataclass
from types import MappingProxyType
from collections.abc import Mapping
import time
import numpy as np


def freeze(value,memo=None):
    memo={} if memo is None else memo
    if isinstance(value,np.ndarray):
        if id(value) not in memo:
            owned=value if value.flags.owndata and not value.flags.writeable else value.copy()
            owned.flags.writeable=False;memo[id(value)]=owned
        return memo[id(value)]
    if isinstance(value,Mapping):return MappingProxyType({k:freeze(v,memo) for k,v in value.items()})
    if isinstance(value,(tuple,list)):return tuple(freeze(v,memo) for v in value)
    return value


@dataclass(frozen=True)
class ScanRecord:
    source_key:tuple
    sequence:int
    reference_s:float
    span_s:tuple
    raw_xyz:np.ndarray
    point_times:np.ndarray
    original_indices:np.ndarray
    rings:object
    corrected_xyz:np.ndarray
    pose:np.ndarray
    model:object=None

    def __post_init__(self):
        n=len(self.raw_xyz)
        if (len(self.source_key)!=3 or len(self.span_s)!=2 or not np.isfinite(self.span_s).all()
            or not self.span_s[0]<=self.reference_s<=self.span_s[1]
            or np.shape(self.raw_xyz)!=(n,3) or np.shape(self.corrected_xyz)!=(n,3)
            or np.shape(self.point_times)!=(n,) or np.shape(self.original_indices)!=(n,)
            or self.rings is not None and np.shape(self.rings)!=(n,)
            or np.shape(self.pose)!=(4,4)):
            raise ValueError('aligned real scan arrays and reference required')
        if (not all(np.isfinite(a).all() for a in (self.raw_xyz,self.corrected_xyz,self.point_times,self.pose))
            or n and (self.point_times.min()<self.span_s[0]-1e-6 or self.point_times.max()>self.span_s[1]+1e-6)):
            raise ValueError('finite points inside real scan span required')
        memo={}
        for name in ('source_key','span_s','raw_xyz','point_times','original_indices','rings','corrected_xyz','pose','model'):
            object.__setattr__(self,name,freeze(getattr(self,name),memo))


def retained_bytes(records):
    roots={}
    def visit(value):
        if isinstance(value,np.ndarray):
            root=value
            while isinstance(root.base,np.ndarray):root=root.base
            roots[id(root)]=root.nbytes
        elif isinstance(value,Mapping):
            for item in value.values():visit(item)
        elif isinstance(value,(tuple,list)):
            for item in value:visit(item)
        elif is_dataclass(value):
            for f in fields(value):visit(getattr(value,f.name))
    visit(tuple(records));return sum(roots.values())


@dataclass
class RefinementBudget:
    window_limit_bytes:int=96*1024**2
    temporary_limit_bytes:int=64*1024**2
    deadline_s:float=field(default_factory=lambda:time.monotonic()+60.)
    cancelled:object=field(default=lambda:False,repr=False)

    def check(self,estimated_temporary_bytes=0):
        return (0<=estimated_temporary_bytes<=self.temporary_limit_bytes
            and time.monotonic()<self.deadline_s and not self.cancelled())

    def ensure(self,estimated_temporary_bytes=0):
        if not self.check(estimated_temporary_bytes):raise ValueError('refinement budget / deadline / cancellation')
