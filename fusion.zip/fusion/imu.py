"""Airy IMU from the selected recording, without changing device settings."""
import struct
import numpy as np
from scipy.spatial.transform import Rotation,Slerp
from ..rail_centerline import PcapPoseIndex


class ImuSeries:
    def __init__(self,times,gyro,max_gap_s=None):
        self.times=np.asarray(times,dtype=float);self.gyro=np.asarray(gyro,dtype=float)
        if (self.times.ndim!=1 or len(self.times)<2 or self.gyro.shape!=(len(self.times),3)
            or not np.isfinite(self.times).all() or not np.isfinite(self.gyro).all()
            or np.any(np.diff(self.times)<=0)):
            raise ValueError('finite increasing real IMU samples required')
        rotations=[Rotation.identity()]
        for index in range(1,len(self.times)):
            rotations.append(rotations[-1]*Rotation.from_rotvec(
                .5*(self.gyro[index-1]+self.gyro[index])*(self.times[index]-self.times[index-1])))
        self.slerp=Slerp(self.times,Rotation.from_quat([r.as_quat() for r in rotations]))
        self.max_gap_s=max_gap_s
        self.diagnostics={'real_imu_samples':len(self.times),'gyro_bias_calibrated':False,
            'translation_from_imu_double_integration':False,'scope':'selected recording IMU, experimental relative rotation'}

    @classmethod
    def from_packets(cls,packets):
        quaternion=None;rows=[]
        for unused,port,payload in packets:
            if port==7788 and len(payload)==1248 and payload[:4]==b'\xa5\xff\x00\x5a' and quaternion is None:
                values=np.array(struct.unpack_from('>7f',payload,1092))
                if np.isfinite(values).all() and np.linalg.norm(values[:4])>1e-8:
                    quaternion=values[:4]/np.linalg.norm(values[:4])
            elif port==6688 and len(payload)==51 and payload[:4]==b'\xaa\x55\x5a\x05' and payload[-2:]==b'\xf0\x0f':
                if payload[44]>3:continue
                timestamp=int.from_bytes(payload[4:10],'big')+struct.unpack_from('>I',payload,10)[0]*1e-6
                if rows and timestamp<rows[-1][0]-.1:
                    raise ValueError('recording IMU clock reset / mixed timeline; no calibrated IMU fusion')
                gyro=np.array(struct.unpack_from('>3i',payload,26))*np.deg2rad(250<<payload[44])/32768.
                rows.append((timestamp,gyro))
        if quaternion is None or len(rows)<2:raise ValueError('same-recording DIFOP calibration / IMU missing')
        rows.sort(key=lambda row:row[0]);unique={row[0]:row[1] for row in rows}
        times=np.array(list(unique));gyro=Rotation.from_quat(quaternion).apply(np.array(list(unique.values())))
        result=cls(times,gyro,max_gap_s=.025)
        result.diagnostics['imu_to_lidar_xyzw']=quaternion.tolist()
        result.diagnostics['metadata_interpolation']='replay-only genuine brackets, maximum gap 25ms'
        return result

    @classmethod
    def from_pcap(cls,path):return cls.from_packets(PcapPoseIndex._udp_packets(path))

    def orientation(self,times):
        values=np.atleast_1d(np.asarray(times,dtype=float))
        if not np.isfinite(values).all() or values.min()<self.times[0] or values.max()>self.times[-1]:
            raise ValueError('IMU clock coverage missing')
        if self.max_gap_s is not None:
            lo=max(0,int(np.searchsorted(self.times,values.min()))-1)
            hi=min(len(self.times),int(np.searchsorted(self.times,values.max(),side='right'))+1)
            if np.any(np.diff(self.times[lo:hi])>self.max_gap_s):raise ValueError('IMU sample gap')
        return self.slerp(values)[0] if np.ndim(times)==0 else self.slerp(values)

    def deskew(self,points,times,reference):
        # SciPy's installed Cython backend requests a writable memoryview even
        # for this read-only operation. Do not thaw an owned historical scan.
        vectors=np.asarray(points)
        if not vectors.flags.writeable:vectors=vectors.copy()
        return (self.orientation(reference).inv()*self.orientation(times)).apply(vectors)
