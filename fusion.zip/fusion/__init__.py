"""Image-only short local-map fusion; independent of clearance measurement."""
