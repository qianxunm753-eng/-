"""Past-only plane ICP with IMU rotation and bounded translation deskew refinement."""
from collections import deque
from dataclasses import dataclass
import copy
import numpy as np
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation


def representatives(points,size,limit):
    if not len(points):return np.empty(0,dtype=int)
    keys=np.floor(points/size).astype(np.int64);low=keys.min(axis=0);high=keys.max(axis=0)
    spans=tuple(int(hi)-int(lo)+1 for lo,hi in zip(low,high))
    if spans[0]*spans[1]*spans[2]<=np.iinfo(np.uint64).max:
        # Collision-free mixed-radix keys, identical lexicographic cells and
        # first-real-return indices, without the costly structured-row sort.
        codes=(keys[:,0]-low[0]).astype(np.uint64)
        codes=codes*np.uint64(spans[1])+(keys[:,1]-low[1]).astype(np.uint64)
        codes=codes*np.uint64(spans[2])+(keys[:,2]-low[2]).astype(np.uint64)
        unused,rows=np.unique(codes,return_index=True)
    else:
        unused,rows=np.unique(keys,axis=0,return_index=True)
    if len(rows)>limit:rows=rows[np.linspace(0,len(rows)-1,limit,dtype=int)]
    return rows


def transform(points,pose):return points@pose[:3,:3].T+pose[:3,3]


def detail_representatives(points,size,limit):
    """Bounded two-scale REAL indices, not denoising or object recognition.

    Reserve half the ordinary coverage for pose observability. Spend the
    remainder on locally supported line-like/nonplanar returns at finer
    resolution. Sparse isolated returns never consume the feature quota;
    they are not removed from stored or displayed scans. All PCA inputs must
    already be training-only when this is called by a fitter.
    """
    if limit<1 or size<=0.:raise ValueError('positive representative budget required')
    coarse=representatives(points,size,limit)
    if len(points)<12:return coarse
    reserve=coarse[np.linspace(0,len(coarse)-1,min(len(coarse),(limit+1)//2),dtype=int)]
    # Do not cap this pool proportional to the final quota: a big plane
    # would discard thin features BEFORE their local geometry is inspected.
    pool=representatives(points,max(.015,size/4.),16000)
    if len(pool)<12:return coarse
    xyz=points[pool];distance,near=cKDTree(xyz).query(xyz,k=12,workers=1)
    offset=xyz[near];offset-=offset.mean(axis=1,keepdims=True)
    e=np.linalg.eigvalsh(np.einsum('nki,nkj->nij',offset,offset)/12.)
    supported=(distance[:,5]<=max(.06,size))&(distance[:,-1]<=max(.12,2.*size))&(e[:,2]>1e-10)
    feature=supported&((e[:,1]<.18*e[:,2])|(e[:,0]>.02*e[:,2]))
    fine=pool[feature&~np.isin(pool,reserve)]
    quota=limit-len(reserve)
    if len(fine)>quota:fine=fine[np.linspace(0,len(fine)-1,quota,dtype=int)]
    selected=np.concatenate((reserve,fine))
    unused=coarse[~np.isin(coarse,selected)]
    return np.concatenate((selected,unused[:limit-len(selected)]))


def display_support(points):
    """Display-only subset: keep a real return with at least one close neighbour.

    Run on the bounded 8mm display representatives, never on fitting inputs or
    stored scans. Sparse rods can survive; no height/shape/class rule is used.
    A truly isolated equipment return is indistinguishable from noise here, so
    this is an optional, reversible preview, not a measurement filter.
    """
    if len(points)<2:return np.empty(0,dtype=int)
    distance,unused=cKDTree(points).query(points,k=2,workers=1)
    radius=np.clip(.015*np.linalg.norm(points,axis=1),.06,.15)
    return np.flatnonzero(distance[:,1]<=radius)


@dataclass
class Registration:
    pose:np.ndarray
    points:np.ndarray
    usable:bool
    diagnostics:dict
    model:object=None


class LocalMap:
    def __init__(self,detail_sampling=False,extended_deskew=False):
        self.detail_sampling=bool(detail_sampling)
        self.extended_deskew=bool(extended_deskew)
        self.keys=deque(maxlen=5);self.last_good_time=None;self.pose=np.eye(4)
        self.relative=np.eye(4);self.previous_dt=None;self.key_pose=np.eye(4);self.key_time=None
        self.geometry=None
        self.key_sources=deque(maxlen=5);self.scan_key=None

    def fork(self):
        result=copy.copy(self);result.keys=deque(self.keys,maxlen=5)
        result.key_sources=deque(self.key_sources,maxlen=5)
        for name in ('pose','relative','key_pose'):setattr(result,name,getattr(self,name).copy())
        return result

    def rebuilt(self,records,budget,training_only=False):
        from .state import retained_bytes
        if not records or retained_bytes(records)>budget.window_limit_bytes:
            raise ValueError('bounded nonempty rebuild records required')
        if (len({r.source_key for r in records})!=1 or len({r.sequence for r in records})!=len(records)
            or any(b.reference_s<=a.reference_s for a,b in zip(records,records[1:]))):
            raise ValueError('one increasing real scan timeline required')
        budget.ensure(16000*12*3*8*4 if self.detail_sampling else 14000*12*3*8*4)
        result=LocalMap(detail_sampling=self.detail_sampling,extended_deskew=self.extended_deskew)
        for record in records:
            budget.ensure()
            fit=np.ones(len(record.raw_xyz),dtype=bool) if record.rings is None else record.rings%2==0
            if training_only:fit &= record.original_indices%5!=0
            result.scan_key=(record.source_key,record.sequence)
            result._refresh(record.corrected_xyz,fit,record.pose,record.reference_s)
        last=records[-1];result.pose=last.pose.copy();result.last_good_time=last.reference_s
        if len(records)>1:
            result.relative=np.linalg.inv(records[-2].pose)@last.pose
            result.previous_dt=last.reference_s-records[-2].reference_s
        return result

    def _refresh(self,points,fit,pose,time_s):
        delta=np.linalg.inv(self.key_pose)@pose
        if (self.key_time is None or time_s-self.key_time>=.2-1e-9
            or np.linalg.norm(delta[:3,3])>.06 or Rotation.from_matrix(delta[:3,:3]).magnitude()>np.deg2rad(1.)):
            sampler=detail_representatives if self.detail_sampling else representatives
            sample=points[fit];sample=sample[sampler(sample,.045,6000)]
            self.keys.append(transform(sample,pose));target=np.concatenate(self.keys)
            self.key_sources.append(self.scan_key)
            target=target[sampler(target,.045,14000)]
            tree=cKDTree(target)
            unused,near=tree.query(target,k=min(12,len(target)),workers=1)
            patches=target[near];centered=patches-patches.mean(axis=1,keepdims=True)
            e,v=np.linalg.eigh(np.einsum('nki,nkj->nij',centered,centered)/patches.shape[1])
            confidence=np.clip((e[:,1]-e[:,0])/np.maximum(e[:,2],1e-12),.02,1.)
            self.geometry=(target,tree,v[:,:,0],confidence)
            self.key_time=time_s;self.key_pose=pose.copy()

    def _align(self,points,initial,distances,iterations,imu_rotation=None):
        target,tree,normal,confidence=self.geometry
        sampler=detail_representatives if self.detail_sampling else representatives
        source=points[sampler(points,.09,3500)];pose=initial.copy();diagnostics={};translation_only=False
        for maximum in distances:
            for unused in range(iterations):
                p=transform(source,pose);distance,indices=tree.query(p,distance_upper_bound=maximum,workers=1)
                keep=np.isfinite(distance)
                if keep.sum()<50:return pose,dict(usable=False,reason='insufficient_correspondences')
                p,q,n,conf=p[keep],target[indices[keep]],normal[indices[keep]],confidence[indices[keep]]
                residual=np.einsum('ij,ij->i',q-p,n)
                jacobian=n if translation_only else np.column_stack((np.cross(p,n),n))
                weight=np.sqrt(np.minimum(1.,.02/(np.abs(residual)+1e-9))*conf)
                step,unused,rank,singular=np.linalg.lstsq(jacobian*weight[:,None],residual*weight,rcond=1e-5)
                diagnostics=dict(rank=int(rank),correspondence_count=int(keep.sum()),
                    condition=float(singular[0]/max(singular[-1],1e-12)),residual_p90_m=float(np.percentile(np.abs(residual),90)))
                if rank!=6 and not translation_only and imu_rotation is not None:
                    # Only real same-recording IMU supplies this rotational
                    # constraint. Recompute residuals after changing rotation.
                    pose[:3,:3]=imu_rotation;translation_only=True;continue
                expected_rank=3 if translation_only else 6
                if rank!=expected_rank or not np.isfinite(step).all() or diagnostics['condition']>(1000. if translation_only else 1e7):
                    return pose,dict(diagnostics,usable=False,reason='unobservable_map')
                if translation_only and np.linalg.norm(step)>maximum:
                    return pose,dict(diagnostics,usable=False,reason='translation_outside_correspondence_capture')
                delta=np.eye(4)
                if translation_only:delta[:3,3]=step
                else:delta[:3,:3]=Rotation.from_rotvec(step[:3]).as_matrix();delta[:3,3]=step[3:]
                pose=delta@pose
                if translation_only and np.linalg.norm(step)<5e-5:break
                if not translation_only and np.linalg.norm(step[:3])<2e-5 and np.linalg.norm(step[3:])<5e-5:break
        # Independently check the RETURNED pose, not the residual before its
        # last update. A tiny matched patch cannot vouch for the whole scan.
        p=transform(source,pose)
        distance,indices=tree.query(p,distance_upper_bound=distances[-1],workers=1)
        keep=np.isfinite(distance);count=int(keep.sum());overlap=count/max(len(source),1)
        diagnostics.update(correspondence_count=count,source_representatives=len(source),
            overlap_fraction=float(overlap),validation='final pose against past map')
        if count<50 or overlap<.2:
            return pose,dict(diagnostics,usable=False,reason='insufficient_overlap')
        residual=np.einsum('ij,ij->i',target[indices[keep]]-p[keep],normal[indices[keep]])
        diagnostics['residual_p90_m']=float(np.percentile(np.abs(residual),90))
        usable=diagnostics['residual_p90_m']<.08
        if translation_only:diagnostics['rotation_constraint']='same-recording IMU'
        return pose,dict(diagnostics,usable=usable,reason='registered' if usable else 'large_residual')

    def update(self,points,times,rings,reference,imu,scan_key=None,
               fit_mask=None,save_model=False,scan_span_s=None):
        mask=None
        if fit_mask is not None:
            mask=np.asarray(fit_mask)
            if mask.shape!=(len(points),) or mask.dtype!=np.bool_:
                raise ValueError('aligned boolean training mask required')
        span=None
        if save_model:
            span=tuple(scan_span_s) if scan_span_s is not None else (float(np.min(times)),float(np.max(times)))
            if (len(span)!=2 or not np.isfinite(span).all() or not span[0]<=reference<=span[1]
                or np.any(times<span[0]-1e-6) or np.any(times>span[1]+1e-6)):
                raise ValueError('actual full scan time coverage required')
        def result(pose,corrected,usable,diag,velocity=None):
            model=None
            if save_model:
                from .parking_alignment import saved_scan_model
                model=saved_scan_model(pose,span,reference,np.zeros(3) if velocity is None else velocity,imu_active)
            return Registration(pose,corrected,usable,diag,model)
        self.scan_key=scan_key
        rotated=points.copy();imu_active=False;imu_reason='IMU missing; LiDAR-only'
        if imu is not None:
            try:rotated=imu.deskew(points,times,reference);imu_active=True;imu_reason='same-recording IMU rotational deskew'
            except ValueError as error:imu_reason=str(error)+'; LiDAR-only'
        fit=np.ones(len(points),dtype=bool) if rings is None else np.asarray(rings)%2==0
        if mask is not None:fit &= mask
        if fit.sum()<50:return result(self.pose.copy(),rotated,False,{'reason':'insufficient_points','imu_active':imu_active})
        if self.last_good_time is None:
            self._refresh(rotated,fit,self.pose,reference);self.last_good_time=reference
            return result(self.pose.copy(),rotated,True,{'reason':'reference_anchor','imu_active':imu_active,'imu_status':imu_reason})
        dt=reference-self.last_good_time
        if not 0.<dt<=.6+1e-9:return result(self.pose.copy(),rotated,False,{'reason':'registration_time_gap','imu_active':imu_active})
        predicted=np.eye(4)
        if imu_active:
            try:
                # Validate the ENTIRE inter-scan interval, not two separate
                # endpoint brackets that could straddle a missing gyro span.
                rotations=imu.orientation(np.array([self.last_good_time,reference]))
                predicted[:3,:3]=(rotations[0].inv()*rotations[1]).as_matrix()
            except ValueError as error:
                imu_active=False;rotated=points.copy()
                imu_reason=str(error)+' between scan references; LiDAR-only'
        if not imu_active and self.previous_dt is not None:
            predicted[:3,:3]=Rotation.from_rotvec(Rotation.from_matrix(self.relative[:3,:3]).as_rotvec()*dt/self.previous_dt).as_matrix()
        if self.previous_dt is not None:
            predicted[:3,3]=self.relative[:3,:3].T@self.relative[:3,3]*dt/self.previous_dt
        velocity=predicted[:3,:3].T@predicted[:3,3]/dt
        current=rotated+(times-reference)[:,None]*velocity
        target_time=self.key_time
        initial=self.pose@predicted;imu_rotation=initial[:3,:3].copy() if imu_active else None
        pose,diagnostics=self._align(current[fit],initial,(.30,.12),10,imu_rotation)
        if diagnostics['usable']:
            # A frame solve on still-distorted returns estimates an average
            # pose, not the reference-time pose. Alternate real-time deskew
            # with the same past map until the remaining velocity change has
            # sub-mm effect on this scan, with an explicit work bound.
            scan_offset=float(np.max(np.abs(times-reference)))
            # Opt-in rolling replay has time for an extended bounded solve.
            # The old rolling and parking policies keep exactly five passes.
            refinement_limit=60 if self.extended_deskew else 5
            for attempt in range(refinement_limit):
                relative=np.linalg.inv(self.pose)@pose
                velocity=relative[:3,:3].T@relative[:3,3]/dt
                current=rotated+(times-reference)[:,None]*velocity
                pose,refined=self._align(current[fit],pose,(.10,),5,imu_rotation)
                diagnostics.update(refined,translation_refinements=attempt+1)
                if not refined['usable']:
                    diagnostics.update(deskew_refinement_converged=False,
                        deskew_refinement_state='registration_rejected')
                    break
                relative=np.linalg.inv(self.pose)@pose
                final_velocity=relative[:3,:3].T@relative[:3,3]/dt
                change=scan_offset*float(np.linalg.norm(final_velocity-velocity))
                diagnostics.update(deskew_remaining_change_m=change,
                    deskew_refinement_converged=change<.0005,
                    deskew_refinement_state='velocity_change_small' if change<.0005 else
                        'work_limit_reached' if attempt==refinement_limit-1 else 'refining')
                if change<.0005:break
        diagnostics.update(imu_active=imu_active,imu_status=imu_reason,target_latest_time_s=target_time,
            registration='past-only local-map plane ICP; predict, solve, bounded deskew refinement',independent_pose_truth=False)
        if diagnostics['usable']:
            self.relative=np.linalg.inv(self.pose)@pose;self.previous_dt=dt
            self.pose=pose.copy();self.last_good_time=reference;self._refresh(current,fit,pose,reference)
        return result(pose,current,bool(diagnostics['usable']),diagnostics,velocity)
