"""Independent real-return checks; optimiser loss alone never accepts a map."""
from dataclasses import dataclass
import numpy as np
from scipy.spatial import cKDTree


@dataclass(frozen=True)
class ValidationMetrics:
    p90_m:float
    rms_m:float
    coverage:float
    patch_metrics:dict
    independent_support:bool


@dataclass(frozen=True)
class ValidationReport:
    accepted:bool
    reason:str
    before:ValidationMetrics
    after:ValidationMetrics


def split_original_indices(indices):
    check=np.asarray(indices)%5==0
    return np.flatnonzero(~check),np.flatnonzero(check)


def accept_refinement(before,after):
    reason='independent_improvement'
    values=[before.p90_m,before.rms_m,before.coverage,after.p90_m,after.rms_m,after.coverage]
    if not before.independent_support or not after.independent_support:reason='insufficient_independent_support'
    elif not np.isfinite(values).all():reason='nonfinite_validation'
    elif after.p90_m>before.p90_m+.002+1e-12:reason='heldout_p90_regression'
    elif after.coverage<before.coverage*.95-1e-12:reason='heldout_coverage_regression'
    else:
        for name,old in before.patch_metrics.items():
            new=after.patch_metrics.get(name)
            if (new is None or not np.isfinite(new).all() or new[0]>old[0]+.002+1e-12
                or new[1]>old[1]+.002+1e-12 or new[2]<old[2]*.95-1e-12):
                reason='local_patch_regression';break
        if reason=='independent_improvement' and after.rms_m>=before.rms_m-1e-9:
            reason='no_independent_improvement'
    return ValidationReport(reason=='independent_improvement',reason,before,after)


def local_feature_groups(points,normals,cell_size=.32,min_rows=12):
    """Fixed target-only surface identity, not an object/semantic classifier.

    Parallel faces keep different offsets; disconnected coplanar features
    stay separate. Sampling-dependent connectivity is bounded to 1.5--6 cm.
    Only BEFORE associations determine groups used for both evaluations.
    """
    if not len(points):return ()
    canonical=normals.copy();axis=np.argmax(np.abs(canonical),axis=1)
    canonical*=np.where(canonical[np.arange(len(axis)),axis]<0.,-1.,1.)[:,None]
    labels=np.column_stack((np.floor(points/cell_size).astype(np.int64),
        np.round(canonical/.25).astype(np.int64),
        np.floor(np.einsum('ij,ij->i',points,canonical)/.008).astype(np.int64)))
    unused,inverse=np.unique(labels,axis=0,return_inverse=True)
    order=np.argsort(inverse);groups=np.split(order,np.flatnonzero(np.diff(inverse[order]))+1)
    result=[]
    for group_index,rows in enumerate(groups):
        if len(rows)<min_rows:continue
        unique,point_inverse=np.unique(points[rows],axis=0,return_inverse=True)
        tree=cKDTree(unique);parent=np.arange(len(unique))
        def root(index):
            while parent[index]!=index:
                parent[index]=parent[parent[index]];index=parent[index]
            return index
        if len(unique)>1:
            distances,unused=tree.query(unique,k=2,workers=1)
            radius=float(np.clip(np.median(distances[:,1])*2.5,.015,.06))
            distance,near=tree.query(unique,k=min(12,len(unique)),distance_upper_bound=radius,workers=1)
            for index,neighbours in enumerate(near):
                for neighbour in neighbours:
                    if neighbour>=len(unique):continue
                    a=root(index);b=root(int(neighbour))
                    if a!=b:parent[b]=a
        components=np.array([root(i) for i in range(len(unique))])[point_inverse]
        for component in np.unique(components):
            member=rows[components==component]
            if len(member)>=min_rows:result.append(((group_index,int(component)),member))
    return tuple(result)


def compare_geometry(before_world,after_world,geometry):
    """Fixed original rows and fixed independent target associations for checks.

    Matches/normals and spatial bins come from the BEFORE target query; an
    after point cannot switch to another surface to hide a regression.
    """
    target,tree,normals,confidence=geometry
    distance,indices=tree.query(before_world,distance_upper_bound=.12,workers=1)
    supported=np.isfinite(distance)
    safe=np.minimum(indices,len(target)-1);supported&=confidence[safe]>.05
    rows=np.flatnonzero(supported)
    q=target[safe[rows]];n=normals[safe[rows]]
    old=np.abs(np.einsum('ij,ij->i',before_world[rows]-q,n))
    new=np.abs(np.einsum('ij,ij->i',after_world[rows]-q,n))
    valid_after=np.linalg.norm(after_world[rows]-q,axis=1)<=.12
    patches_before={};patches_after={}
    for name,member in local_feature_groups(q,n):
        patches_before[name]=(float(np.percentile(old[member],90)),float(np.sqrt(np.mean(old[member]**2))),1.)
        patches_after[name]=(float(np.percentile(new[member],90)),float(np.sqrt(np.mean(new[member]**2))),
            float(np.mean(valid_after[member])))
    independent=len(rows)>=50 and len(rows)/max(len(before_world),1)>=.2
    def metrics(residual,patches,coverage):
        return ValidationMetrics(float(np.percentile(residual,90)) if len(residual) else np.inf,
            float(np.sqrt(np.mean(residual**2))) if len(residual) else np.inf,
            coverage,patches,independent)
    before=metrics(old,patches_before,len(rows)/max(len(before_world),1))
    after=metrics(new,patches_after,float(valid_after.sum())/max(len(before_world),1))
    return accept_refinement(before,after)
